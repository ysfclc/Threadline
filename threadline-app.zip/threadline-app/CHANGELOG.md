## 1.4.0 — Agent workspace and one-tap local AI

- Added a dedicated Agent workspace showing the real governed pipeline: understand → inspect → propose → validate → approve → apply.
- Exposed pending proposal count and a direct review action; the screen explicitly distinguishes current capabilities from future integrations.
- Made the compact local model download a one-tap primary action from Today and the Agent workspace, while retaining the model chooser and compatible-file import path.
- Bumped Android version to 1.4.0 so the next installed debug build is distinguishable from the previous build.
- Static source review completed; a full Android build and physical-device verification are still required in GitHub Actions/on the phone.

# Changelog

## 1.3.0 — Studio and connected work

- Added encrypted Studio content drafts and schema v1 → v2 migration path.
- Added output formats for posts, carousel outlines, short-video scripts, build logs, case studies, technical breakdowns, diagram briefs, website stories, portfolio proof, comments/replies, email drafts and multiple angles.
- Added persistent channel/format/tone preferences and an explicit context-inclusion switch that defaults off.
- Added source reuse from recent captures and completed work, so Studio can reuse existing material rather than requiring copy/paste from scratch.
- Added draft edit, copy, archive, restore, delete and local search.
- Added explicit Private → Public-safe review; this is not a publishing action.
- Extended Talk to propose private content drafts for approval.
- Added Studio to the floating quick-action menu.
- Added a restrained animated status orb.
- Added product system blueprint, user-needs map, feature reality check and outcome-first roadmap.
- Full Android build and device verification remain pending.

## 1.2.0 — Voice-first local assistant

- Added local LiteRT-LM model support, voice conversation, floating quick actions, OCR, task reminders and a daily nudge.
