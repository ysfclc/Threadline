# Changelog

## 1.5.0 — High-fidelity UI and motion system

- Extracted shared semantic palette tokens into `ThreadlineDesignSystem.kt`, with matched light, dark and system-following appearances. The appearance selection persists locally.
- Rebalanced navigation to five primary workspaces and kept Talk one tap away in the header; search, floating actions and settings remain directly accessible. Vault locking remains available in Settings.
- Added gradient hero surfaces, clearer visual hierarchy and subtle card elevation in light mode, with restrained flat surfaces in dark mode.
- Added a shared native motion layer in `ThreadlineMotion.kt`: short screen transitions on navigation, staggered first entrances, tactile 0.965 press feedback and tap haptics. Navigation/record refreshes no longer re-animate the full screen repeatedly.
- Added a low-allocation shimmering skeleton while the local model initializes. It stops on detach and respects reduced-motion preferences and Android's animator setting; the status orb now follows the system animator setting too.
- Applied the same press/haptic and staged menu entrance to the floating quick-action overlay; Reduce Motion now refreshes its looping pulse live.
- System appearance tracks Android `uiMode` changes in place, and the unlock transition receives its own single entrance.
- Fixed a new shared-surface contrast regression on the vault-lock screen.
- Kept the existing Kotlin Android stack. No React Native/Reanimated dependency was added; platform property animation avoids introducing a JS runtime or framework migration to a lightweight Android app.
- Bumped Android version to 1.5.0 (version code 6).
- XML, shared palette compilation and source-level markers were checked here. The full Android Gradle build, lint, APK installation, accessibility and 60fps measurements still require the Android SDK/build pipeline and a physical-device test.

## 1.4.0 — Agent workspace and one-tap local AI

- Added a dedicated Agent workspace showing the real governed pipeline: understand → inspect → propose → validate → approve → apply.
- Exposed pending proposal count and a direct review action; the screen explicitly distinguishes current capabilities from future integrations.
- Made the compact local model download a one-tap primary action from Today and the Agent workspace, while retaining the model chooser and compatible-file import path.
- Bumped Android version to 1.4.0 so the next installed debug build is distinguishable from the previous build.
- Static source review completed; a full Android build and physical-device verification are still required in GitHub Actions/on the phone.

## 1.3.0 — Studio and connected work

- Added encrypted Studio content drafts and schema v1 → v2 migration path.
- Added output formats for posts, carousel outlines, short-video scripts, build logs, case studies, technical breakdowns, diagram briefs, website stories, portfolio proof, comments/replies, email drafts and multiple angles.
- Added persistent channel/format/tone preferences and an explicit context-inclusion switch that defaults off.
- Added source reuse from recent captures and completed work, so Studio can reuse existing material rather than requiring copy/paste from scratch.
- Added draft edit, copy, archive, restore, delete and local search.
- Added explicit Private → Public-safe review; this is not a publishing action.
- Extended Talk to propose private content drafts for approval.
- Added Studio to the floating quick-action menu.
- Added a restrained animated status orb.
- Added product system blueprint, user-needs map, feature reality check and outcome-first roadmap.
- Full Android build and device verification remain pending.

## 1.2.0 — Voice-first local assistant

- Added local LiteRT-LM model support, voice conversation, floating quick actions, OCR, task reminders and a daily nudge.
