# Threadline — product brief

## The problem

People with many ideas and active projects do not need another dashboard that measures how behind they are. They need a private place to unload thoughts quickly, speak them through, reconnect to context, and have the next useful move prepared without spending more effort maintaining a system.

## The promise

**Tell Threadline what's happening. It connects the context, proposes a move, and nudges you when you asked to be nudged.**

## Interaction model

1. **Capture anywhere:** the optional system-wide bubble, quick text, voice transcript, photo, file picker, Android share sheet, or selected-text action.
2. **Keep evidence:** original captures and attachments are stored in the private vault. OCR extracts text from image captures locally; it does not pretend a text-only language model can see arbitrary images.
3. **Understand locally:** a replaceable LiteRT-LM model interprets the request and relevant project/task context. The routine prompt is bounded; reasoning is disabled for routine turns, and generated text streams to the interface.
4. **Plan:** the model can propose new tasks, project links/updates, task completion, and reminders. Proposals refer to exact existing IDs and are validated by deterministic code.
5. **Approve:** nothing changes until the user reviews and applies the proposal.
6. **Follow through:** local reminders and an optional daily nudge make the system proactive without a cloud account or an always-listening microphone.

## What it is not

- Not a chatbot that forgets your work after every conversation.
- Not a task dashboard that treats every thought as a commitment.
- Not an autonomous agent with unrestricted access to the phone.
- Not an AI wrapper that silently uploads private context to an API.

## Current boundaries

Threadline currently orchestrates its own private tasks, projects, captures and reminders. It does not send email, change external calendars, post online, or spend money. Android speech services can vary in offline support. The default Qwen models are text-only; image capture currently uses bundled on-device OCR. Local image generation is a separate optional model/runtime project and is not included in 1.2.0.

## Next high-value extensions

1. **Context-aware daily briefing:** combine open tasks, project next actions and recent captures into one short spoken “here's what matters” briefing.
2. **Local Android calendar bridge:** optional read/write access to the device calendar, with explicit permission and confirmation before changes.
3. **Local notification triage:** turn selected notification text into a capture or proposed action without reading all notifications by default.
4. **PDF/document extraction:** local text extraction for PDFs and office documents, preserving source references.
5. **Optional on-device image generation:** separate downloadable diffusion pack, gated by storage/RAM checks and a real-device performance test; never bundled in the base APK.
6. **Agent run history:** a compact audit trail showing what was proposed, approved, applied, rejected, and why.

The priority is not more buttons. It is fewer steps between a thought and meaningful progress.
