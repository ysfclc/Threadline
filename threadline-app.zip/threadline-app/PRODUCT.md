# Threadline 1.3.0 — Private Personal Operating System

Threadline is a local-first Android app for capturing real life, connecting it to ongoing work, orchestrating useful next steps and turning verified work into outputs. It is designed for a person who thinks in systems, works across several projects and doesn't want another app to maintain.

**The promise:** tell Threadline what is happening. It connects the context, proposes a move, helps create the artifact, and follows up when asked.

## Core experience

- **Today:** a calm command center with three focus slots, next actions, active project threads and a gentle daily nudge.
- **Capture:** text, voice transcript, photo/OCR, file attachment, Android share and the optional floating quick-action button.
- **Talk:** a voice-first local assistant that can reason about current projects/tasks and propose internal changes for approval.
- **Studio:** turn source material into a LinkedIn post, carousel outline, short-video script, build-log episode, case study, technical breakdown, diagram brief, website story, portfolio proof, comment/reply, email draft or multiple angles. Channel, format, writing voice and editable brand/privacy rules are configurable. Drafts stay private by default and can be edited, copied, archived or deleted.
- **Projects:** outcomes, next actions, focus and parked/done states.
- **Reminders:** task reminders and an optional daily nudge, stored locally.
- **Settings:** local model, voice language, floating actions, content defaults, encrypted backup/restore and privacy boundaries.

## Architecture rules

1. Local data is the source of truth; model output is a proposal.
2. Deterministic code validates and applies state changes.
3. Agents, skills, tools, workflows and models remain distinct and replaceable.
4. Reuse existing capabilities before creating new ones.
5. Preserve source, evidence, decisions and outcomes.
6. Private content never becomes public because a model generated it. Public-safe status requires explicit human review; publishing is a separate action.
7. The interface shows real state and errors, not fake progress or unsupported capabilities.
8. The product optimizes for progress and reduced cognitive load, not streaks, time spent or notification volume.

## Local AI and privacy

Threadline uses Google's LiteRT-LM runtime for compatible on-device language models. The model is optional and downloaded separately. OCR, language-model inference and local state handling are separate capabilities. Android speech-recognition/TTS providers can vary; full offline voice must be verified on the actual phone.

Local image generation, broad video understanding, social publication, calendar write actions, and general-purpose agent-team execution are not included as verified capabilities in this release. See `FEATURE_STATUS.md` and `ROADMAP.md`.

## Files in this project

- `PRODUCT_SYSTEM.md` — complete product architecture and interaction rules.
- `USER_NEEDS_MAP.md` — synthesis of recurring user problems and existing project lessons.
- `ROADMAP.md` — outcome-first delivery and commercial readiness gates.
- `FEATURE_STATUS.md` — implemented vs planned vs verified status.
- `VERIFICATION.md` — checks performed and remaining verification.

## Build

JDK 17, Android SDK platform 35, compatible Android Gradle Plugin and Gradle 8.14.4 or newer are expected. Run:

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug
```

Full Android build and device behavior must be verified in GitHub Actions and on the target phone before treating this archive as a release.


## Agent workspace (1.4.0)

The Agent tab makes the current orchestration contract visible: understand the request, inspect local context, propose structured changes, validate them against existing records, request approval, and apply only approved changes. This is a governed single-model workflow, not a claim that independent agents or external integrations already exist. The compact local model can be downloaded directly from Today or Agent; larger-model choice and compatible `.litertlm` import remain available.
