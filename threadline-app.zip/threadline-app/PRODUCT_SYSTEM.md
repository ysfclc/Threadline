# Threadline — Product System Blueprint

**Positioning:** a private personal operating environment that connects life, projects, evidence, tools, creative work and decisions, then helps the owner move from intention to outcome.

**Product promise:** Say what is happening. Threadline finds the relevant context, proposes the smallest useful next move, coordinates the right capability, preserves the evidence, and follows up when asked.

This is a product specification, not a claim that every capability below exists in the current APK. Implementation state is labelled explicitly in `FEATURE_STATUS.md`.

## 1. The product is a connected world, not a pile of modules

The navigation may offer Today, Inbox, Projects, Talk, Studio, Career, People, Media or Settings. Those are views into the same underlying world, not separate silos. A person can be connected to a conversation, opportunity, project, content piece and follow-up without being copied into five unrelated records.

The core record types should remain extensible:

- **Source:** original capture, message, file, web page, code session, screenshot, audio transcript or imported record.
- **Observation:** something directly present in a source (quoted text, date, test output, file diff, visual detail).
- **Interpretation:** what Threadline or a model thinks the source may mean, with confidence and evidence.
- **Decision:** something the owner explicitly chose.
- **Work item:** task, project, goal, experiment, application, conversation follow-up or workflow run.
- **Proof:** test result, screenshot, demo, recording, diff, link or human verification.
- **Story:** a truthful interpretation of an event or work that may be useful to communicate.
- **Output:** post, carousel, video script, image brief, diagram, CV, case study, email, website section or another format.
- **Capability:** agent, skill, tool, workflow, model, integration or permission.
- **Event:** an immutable record of a meaningful change or attempted action.

Each important record needs stable identity, timestamps, relationships, source references, privacy level, state and history. New record types should be addable through configuration/registries rather than requiring a separate app.

## 2. The product loop

1. **Capture:** make it nearly effortless to save a thought, voice note, image, document, link, message, meeting, mistake or moment.
2. **Understand:** extract text and metadata deterministically where possible; use a local model to interpret ambiguity when useful.
3. **Connect:** match people, projects, ideas, work, evidence and prior decisions. Suggest links; don't silently convert guesses into facts.
4. **Decide:** show what matters now, what is blocked, what is waiting on someone, and what could be parked.
5. **Orchestrate:** select the right agent/skill/tool/workflow for a bounded outcome, reuse existing capabilities before creating new ones, and plan dependencies.
6. **Execute:** deterministic tools do deterministic work. Enforce permissions, input validation, timeouts, idempotency and approval boundaries.
7. **Verify:** distinguish attempted, succeeded, failed and independently verified. Capture proof when practical.
8. **Learn:** keep decisions, outcomes, corrections and reusable methods so the next run is better.
9. **Create:** transform selected real work into private notes or public-facing artifacts.
10. **Return:** bring useful responses, results and follow-ups back into the same world.

## 3. Boss: the orchestration layer

Boss is not a chatbot persona that pretends to do work. It is a visible coordinator that owns intent, plans bounded work, selects capabilities and reports state.

For every non-trivial request, the orchestration plan should be inspectable:

- Desired outcome and constraints.
- Relevant evidence and context used.
- Capabilities considered and why they were selected.
- Steps and dependencies.
- Permissions and possible side effects.
- Current state: proposed → queued → running → review → approved → done, or blocked/failed/cancelled.
- Outputs and proof.
- Retry, rollback or recovery path where possible.

### Agents, skills, tools and workflows are different

- **Agent / specialist:** owns a class of reasoning and review (e.g. researcher, content editor, implementation planner, verifier, career analyst). It is not a button hardcoded to one task.
- **Skill:** reusable know-how, a versioned procedure with purpose, inputs, outputs, preconditions, examples and limits.
- **Tool:** the executable capability: local file access, OCR, speech recognition, image generation, Git, calendar adapter, browser, or another service API.
- **Workflow:** a repeatable sequence with dependencies, conditions, retries and review gates.
- **Model:** replaceable reasoning or media-generation infrastructure, not the source of truth.

Boss should search for existing agents, skills and tools, compose/reuse them, and propose creating missing ones only when needed. Newly created capabilities should be tested, versioned, reviewed and registered before broad reuse. The creator cannot self-approve a consequential new capability.

### Approval policy

- Reading local records and drafting a proposal: usually allowed by the current user's explicit request.
- Editing Threadline's own private records: preview and undo/history; batch approval can be a setting for low-risk changes.
- Sending messages, publishing content, sharing private files, modifying external accounts, spending money or deleting important data: require explicit confirmation unless the user directly invoked the action and the source adapter supports it.
- A direct human click should not be burdened with redundant confirmations; an autonomous agent's proposal may need review.

## 4. Attention and follow-through

Threadline should not shame the owner with a sea of overdue tasks. It should reduce cognitive load.

### Home / Today

A living command center answers:

- What changed since I last looked?
- What is the one thing worth moving now?
- Which active project has no next action?
- What am I waiting for?
- What is blocked and what can unblock it?
- What can be done in two minutes, while walking, or without a laptop?
- Is there a useful thing to publish from work already completed?
- What should be deliberately parked?

### Nudges

- Contextual reminder tied to a real event, deadline, person or promised follow-up.
- Daily briefing: three priorities at most, meaningful changes, upcoming commitments, blockers and a single suggested move.
- Snooze, dismiss, reschedule, mute topic, quiet hours and frequency controls.
- No notification flood. Learn from dismissals and corrections; don't treat ignored nudges as permission to increase volume.
- Lock-screen notifications use privacy-safe text by default.
- Driving mode uses short spoken summaries and minimal choices; no interaction requiring looking at the screen while moving.

### Low-friction capture

- Persistent optional floating action button, accessible from other apps when Android permits it.
- One tap to speak, capture text, photograph, attach a file, translate selected text or ask a quick question.
- Android share-sheet and text-selection integration.
- Voice recording and transcription are distinct features and must be labelled honestly.
- Keep the original capture even when extraction fails. Don't force the user to classify it.

## 5. Studio: personal branding and content creation from actual work

Studio is not a generic AI copywriter. It starts with the source and the truth, then finds useful ways to communicate it.

### Inputs

- Build logs, code diffs, screenshots, passing tests, demos and design explorations.
- A voice note, conversation, event, failure, decision, question or changed opinion.
- Previous content, project context, known positioning and user-approved public proof.
- User-provided links and attachments, with their source preserved.

### Discoverable angles

The system can suggest a personal realization, technical explanation, business implication, failure, comparison, tutorial, case study, question, changed-mind story, behind-the-scenes moment, demo, diagram, humor or “not worth publishing.” These are suggestions, not a closed taxonomy.

### Output formats

- LinkedIn text post or comment/reply.
- Carousel outline and slide copy.
- Short-video/Reel script, shot list, voiceover, captions and cut plan.
- Build-log episode, GIF/motion brief or screen-recording plan.
- Technical breakdown, architecture diagram brief, case study, PDF or slide deck.
- Personal website story, portfolio evidence, CV bullet or interview narrative.
- iBuild anonymous output, with identity separation enforced.
- Email, networking message or follow-up draft.
- One source story can create multiple channel/format projections while retaining the same claims and proof.

### Evidence and truth rules

- Never invent metrics, dates, customer outcomes, qualifications, quotes or completion status.
- Label facts, interpretations and open questions separately when needed.
- Keep source references attached to important claims.
- Detect contradictions with older drafts or project state and ask before rewriting reality.
- Use concise, specific, natural language. Avoid generic AI hype, engagement bait and unsupported authority.
- The owner's public identity should reflect systems-building across real work, not a fabricated “AI guru” persona.
- Content starts **Private**. Derived outputs inherit the strictest relevant privacy level. “Public-safe” is an explicit review state, not publication.
- Anonymous identities such as iBuild must not be linked publicly to the owner's real identity.
- Publishing must be a separate, explicit adapter/action with preview and result logging.

## 6. Career and opportunity system

Treat career as a set of connected opportunities and evidence, not just a list of job applications.

- Job/company/recruiter records, source URL, role requirements, date discovered and follow-up date.
- Compare role requirements against canonical career facts and proof; mark gaps honestly.
- Generate role-specific CV projections from the same verified facts, not contradictory biographies.
- Draft recruiter replies, interview prep, follow-ups and concise examples from real work.
- Track conversations and next steps without turning every connection into a sales pipeline.
- Turn projects into portfolio evidence and interview stories.
- Keep private contact details outside public repository content and generated artifacts unless intentionally included.
- Surface suitable roles and warm connections when a relevant signal is captured, but don't spam outreach or apply automatically.

## 7. Personal systems and projects

The system should recognize and connect the owner's existing project ecosystem instead of forcing everything into one active project.

- **ME:** the wider private operating environment and source/evidence graph.
- **Troy:** language intelligence—lexicon, canonical meanings, aliases, context, relationships, confidence and evidence. Deterministic interpretation first; local AI proposes metadata with evidence and human approval.
- **Nexus:** governed development pipeline, small tasks, build/review/approved/done gates, independent verification and durable work memory.
- **EBO/Cockpit:** outbound, CRM and growth workflows; source records, identity resolution, qualification, routing, outcome loop and audit trail.
- **Kovan:** constrained engineering/CAD/CAM workflow grounded in real manufacturing constraints and deterministic geometry, not arbitrary AI shapes.
- **Zommo:** service-business online sales and operational workflows.
- **QRKey:** identity/pages, offers, campaigns, attribution and measurable real-world/digital interactions.
- **Oddo:** driver-network/logistics opportunities and WhatsApp-originating workflows, with real-world constraints represented explicitly.
- **SynthOS:** multi-model handoff/council with traceable collaboration, if/when useful.
- **iBuild:** anonymous experimental/build-media identity.
- **Career / Presence:** CVs, portfolio, LinkedIn, website, networking and proof-of-work.

These are not all equal active priorities. Threadline should support Active (1–2 focus projects), Incubating (research/validation), and Captured (recorded, no engineering commitment). Ideas can enter anytime; execution must earn capacity. The assistant should detect project sprawl and ask which outcome deserves capacity instead of encouraging another build by default.

## 8. Knowledge, evidence and memory

A useful knowledge system must preserve more than summaries:

- Exact source and original content where permitted.
- Extracted observations and metadata.
- Canonical entities and aliases.
- Relationships and why the link is suggested.
- Confidence and evidence references.
- Decisions, rejected hypotheses and changed opinions.
- Contradictions and time-based changes.
- Reusable lessons, skills, prompts and workflows.
- A graph view and practical search, not a graph that simply draws everything connected to everything.

Keep “observed,” “extracted,” “inferred,” “accepted,” “decided” and “acted” distinguishable. AI must not silently turn a hypothesis into a fact. Human review should be possible at the right granularity without becoming a constant approval tax.

## 9. External-world mirrors and integrations

A connector should be a faithful, useful mirror of the source—not merely a one-way dump of normalized events.

Potential sources: Android share sheet/files, calendar, email, LinkedIn, GitHub, coding sessions, local folders, browser, messages and other services. Each connector declares exactly what it can read, write, search, sync and delete. No UI should imply an action is supported when it isn't.

For every source, retain:

- Original source identity and URL/provider ID.
- Last synced time and sync health.
- Read/write permissions and account scope.
- What was mirrored and what remains only in the source.
- The actual result of any attempted external action.
- Retry/error state and duplicate protection.

Connections are opt-in. Sensitive sources are excluded from agent context by default. Local-first means local storage, portability, control and cost discipline—not refusing a useful external capability when the owner explicitly opts in.

## 10. Media, play and curiosity

Threadline can be useful and entertaining without becoming another endless feed.

- **Watch later:** save a video/link with source, timestamp and the reason it mattered.
- **Video understanding:** when a user explicitly provides a video or transcript, extract a summary, claims, chapters, questions, project relevance and useful clips. Preserve timestamps and separate what was actually seen from what was inferred.
- **Explain this:** translate or explain selected text, a screenshot, a diagram, a product page or a technical concept in plain language.
- **Curiosity thread:** a user-controlled, bounded exploration that connects a question to prior ideas and ends with a useful artifact, not an infinite scroll.
- **Entertainment mode:** recommend something short based on available time/energy and user preferences, with an exit point. Never optimize for time spent.
- **Make media:** scripts, shot lists, captions, storyboard, diagrams and short videos from real proof; image generation only when a compatible local model/runtime is installed and device checks pass.

Video playback, arbitrary web browsing, image generation and media editing are distinct capabilities. Don't display fake “watch/analyze/generate” controls until the actual local/runtime flow is implemented and tested.

## 11. Local AI strategy

AI is replaceable infrastructure. The product must still work without a model.

- Deterministic logic for CRUD, validation, search, permissions, reminders, state transitions and repeatable transformations.
- Small model for quick classification, extraction and brief drafting.
- Stronger local model for planning, synthesis and complex writing when device RAM/latency allows. Candidates should include current LiteRT-LM-supported Gemma 4 E2B (about 2.58 GB published artifact), but only after compatibility and real-device memory/latency tests. The [official LiteRT-LM model catalog](https://developers.google.com/edge/litert-lm/overview) publishes device/backend measurements; use those as a starting point, not a promise for every phone.
- Benchmark GPU/NPU acceleration and multi-token prediction where the selected model/runtime supports it. Google's [Gemma 4 guide](https://developers.google.com/edge/litert-lm/models/gemma-4) reports up to 2.2× GPU decode speedup for MTP in supported configurations; do not enable an experimental optimization without measuring correctness, memory and speed on target devices.
- Separate speech recognition, text-to-speech, OCR, image understanding and image generation capabilities; they are not one magical “AI” feature.
- Optional model downloads, known source/revision, hash verification, cancellation, free-space checks, initialization tests and safe rollback to the previous model.
- Report model size, expected RAM, active backend, startup time, generation speed and known limitations.
- Never imply local privacy if the speech provider or external tool may upload content. Show the data boundary before the action.
- Avoid repeated model cold starts; load on demand, warm in background where sensible, stream output and keep routine context small.

## 12. Product-grade settings

Settings must be meaningful and user-owned, not a decorative screen.

- Models: installed model, available downloads, import/remove, storage estimate, backend, performance and fallback behavior.
- Voice: language, speech input provider, offline availability, TTS voice/speed, auto-speak, continuous listening session, stop conditions and driving-safe response length.
- Capture: quick action defaults, source retention, attachment limits, OCR behavior, default project/linking policy.
- Attention: daily briefing time, reminder defaults, quiet hours, snooze, frequency, driving mode and notification privacy.
- Studio: default channel, format, voice, evidence policy, brand rules, private/public-safe default, per-identity rules and approval requirements.
- Orchestration: which tools/skills can run, permissions by risk level, auto-approve low-risk internal actions, external side-effect policy, budgets/timeouts and review gates.
- Privacy: per-source access, per-record privacy, backup/export/delete, lock timeout, sensitive-content rules and audit history.
- Appearance: light/dark/system, motion intensity/reduced motion, density, text size, haptics and accessible contrast.
- Portability: encrypted export/import, open formats, model/provider replaceability and migration status.

## 13. Visual and interaction direction

Professional, alive, controlled—not neon AI slop.

- Deep ink/graphite surfaces, restrained mint/teal accent, clear typography and meaningful spacing.
- Motion is tied to state: idle, listening, thinking, tool running, waiting for approval, success, blocked, failed. Never animate as decoration without information.
- A live activity spine shows the real sequence of events and current state; users can inspect why the system is doing something.
- Voice is first-class, with a large reachable control, live transcript, cancel/interrupt, text fallback and visible privacy status.
- Floating action is accessible but not intrusive; draggable, dismissible, configurable and subject to Android overlay limits.
- All essential actions have text alternatives, accessible labels, reduced-motion behavior and reachable touch targets.
- A polished interface cannot substitute for working features. No dead buttons, fake progress, placeholder metrics or invented activity.

## 14. Commercial product requirements

If Threadline is sold, it needs more than a feature list:

- Onboarding that explains local storage, model download, offline speech and permissions honestly.
- Useful first session before any model download: capture, projects, search, reminders and encrypted backup.
- Model installation recovery, storage checks, cancellation and previous-model rollback.
- Database/schema migrations and restore compatibility tests.
- Crash-safe saves, corruption recovery, idempotent actions, bounded logs and redaction.
- Accessibility, small-screen and large-font checks, battery use and memory-pressure handling.
- Clear export/delete controls and no hidden account or analytics dependency.
- Feature flags/registries for optional capabilities; explicit “not available on this device” states.
- A real test matrix: unit tests, UI flow tests, device matrix, cold/warm inference benchmarks, offline-network test, privacy test, backup migration test and notification/permission lifecycle test.

## 15. Success is progress, not engagement

Measure only with local/private controls unless the owner explicitly opts in:

- Time from thought to capture.
- Captures that become a useful next step.
- Blocked projects unblocked.
- Approved actions that succeed and are verified.
- Useful follow-ups delivered at the right time.
- Content outputs grounded in evidence and approved by the owner.
- How often the owner dismisses or disables nudges.
- Model latency, crash rate and battery/memory cost.

Do not optimize daily active use, streaks, notifications sent or time spent. The best outcome may be that Threadline gets out of the way because the owner is doing the work.
