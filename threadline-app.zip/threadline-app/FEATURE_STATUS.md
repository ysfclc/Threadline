# Feature reality check — Threadline 1.4.0

This file distinguishes what the source now contains from what has actually been verified. A control or class existing in source is not proof of a complete feature.

## In source / implementation present

| Capability | State | Important boundary |
|---|---|---|
| Encrypted local vault and biometric unlock | Existing implementation | Requires device-level lifecycle testing; keep an encrypted backup |
| Tasks, projects, focus limit, review, local reminders | Existing implementation | Not a full dependency-aware project-management engine yet |
| Voice conversation UI and Android speech/TTS | Existing implementation | Offline behavior depends on installed recognition and TTS providers |
| LiteRT-LM local model download/import | Existing implementation | Device-specific speed, RAM, GPU behavior and model compatibility need measurement |
| Floating quick-action overlay | Existing implementation | Android overlay permission and OS limits apply; no always-listening microphone |
| Capture from text, camera, file and Android share flow | Existing implementation | Supported file extraction is not universal; image text uses OCR |
| On-device OCR | Existing implementation | Text recognition, not general image understanding |
| Studio content drafting | Added in this pass | Local model required; quality varies by model; no auto-publishing |
| Studio channel/format/tone defaults and editable brand/privacy rules | Added in this pass | Stored in local app preferences |
| Content drafts encrypted with the vault | Added in this pass | Schema v1 data migrates in memory to v2; restore/build tests still required |
| Studio draft edit/copy/archive/delete | Added in this pass | Copying to clipboard is an explicit user action |
| Manual Private → Public-safe review | Added in this pass | Never publishes; user must inspect claims and disclosure |
| Studio source reuse from recent captures/completed work | Added in this pass | User chooses which source to reuse; no automatic publication |
| Ask/Talk proposal to create a private content draft | Added in this pass | Model output remains a proposal until user approval |
| Search across Studio drafts | Added in this pass | Search results are local to the unlocked vault |
| Animated status orb | Added in this pass | Small state cue, not a complete motion-design system |
| Agent workspace with governed pipeline and pending-approval count | Added in 1.4.0 | Represents the actual single-model + deterministic validation flow, not a multi-agent runtime |
| One-tap compact model download from Today / Agent | Added in 1.4.0 | Still requires internet for first download and device-side runtime initialization |

## Not implemented yet — do not advertise as working

- A general graph/entity browser that connects all personal and external data.
- Dynamic agent/team/skill/tool registries with governed creation and independent verification.
- Real integrations to LinkedIn, email, WhatsApp, calendar, GitHub, browser or coding assistants.
- Direct publication or analytics retrieval from social channels.
- Full career/opportunity pipeline and canonical CV facts.
- Automatic capture of coding sessions, terminal output, screenshots and test proof.
- Full video download/playback, local video understanding, transcript chaptering or clip editing.
- Optional local image-generation runtime and model pack.
- A full event ledger, rollback UI, task dependencies, recurring tasks, project milestones and resource scheduling.
- Multi-device encrypted sync or desktop/Docker companion.
- Automatic proactive reasoning over all data while the app is closed.

## Verification performed for this pass

- `Domain.kt` compiled with the available standalone Kotlin compiler.
- Source archive integrity and text/static checks can be performed locally.
- Full Android Gradle build, lint, unit tests, Android lifecycle, speech, LiteRT model execution, schema migration from a real v1 vault, backup restore and physical-device UX are **not verified in this environment** because the Android SDK/Gradle build environment is unavailable here.

The next required gate is GitHub Actions: `testDebugUnitTest lintDebug assembleDebug`. Then test on the actual phone: unlock old vault, verify old tasks/projects still exist, generate/save/edit/copy/archive a Studio draft, lock/unlock, export and restore an encrypted backup, and verify voice/model behavior.
