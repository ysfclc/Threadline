# Feature reality check — Threadline 1.5.0

This file distinguishes what the source now contains from what has actually been verified. A control or class existing in source is not proof of a complete feature.

## In source / implementation present

| Capability | State | Important boundary |
|---|---|---|
| Light / dark / follow-system appearance selector | Added in 1.5.0 | Manual selection and live system `uiMode` updates are implemented; contrast and Android dialog behavior still need device QA |
| Shared native motion system | Added in 1.5.0 | Screen transitions, staggered entrances, press scale, haptics and shimmer are implemented; 60fps is not measured |
| Reduced-motion handling | Added in 1.5.0 | Honors the app toggle and Android animator disable setting; device/accessibility review remains |
| Dedicated semantic design tokens | Added in 1.5.0 | Palette and motion helpers are extracted; feature/data orchestration still largely resides in MainActivity |
| Encrypted local vault and biometric unlock | Existing implementation | Requires device-level lifecycle testing; keep an encrypted backup |
| Tasks, projects, focus limit, review, local reminders | Existing implementation | Not a full dependency-aware project-management engine yet |
| Voice conversation UI and Android speech/TTS | Existing implementation | Offline behavior depends on installed recognition and TTS providers |
| LiteRT-LM local model download/import | Existing implementation | Device-specific speed, RAM, GPU behavior and model compatibility need measurement |
| Floating quick-action overlay | Existing implementation | Android overlay permission and OS limits apply; no always-listening microphone |
| Capture from text, camera, file and Android share flow | Existing implementation | Supported file extraction is not universal; image text uses OCR |
| On-device OCR | Existing implementation | Text recognition, not general image understanding |
| Studio content drafting | Existing implementation | Local model required; quality varies by model; no auto-publishing |
| Studio channel/format/tone defaults and editable brand/privacy rules | Existing implementation | Stored in local app preferences |
| Content drafts encrypted with the vault | Existing implementation | Schema v1 data migrates in memory to v2; restore/build tests still required |
| Studio draft edit/copy/archive/delete | Existing implementation | Copying to clipboard is an explicit user action |
| Manual Private → Public-safe review | Existing implementation | Never publishes; user must inspect claims and disclosure |
| Studio source reuse from recent captures/completed work | Existing implementation | User chooses which source to reuse; no automatic publication |
| Ask/Talk proposal to create a private content draft | Added in this pass | Model output remains a proposal until user approval |
| Search across Studio drafts | Existing implementation | Search results are local to the unlocked vault |
| Animated status orb | Existing implementation | Small state cue, not a complete motion-design system |
| Agent workspace with governed pipeline and pending-approval count | Added in 1.4.0 | Represents the actual single-model + deterministic validation flow, not a multi-agent runtime |
| One-tap compact model download from Today / Agent | Added in 1.4.0 | Still requires internet for first download and device-side runtime initialization |

## Not implemented yet — do not advertise as working

- A general graph/entity browser that connects all personal and external data.
- Dynamic agent/team/skill/tool registries with governed creation and independent verification.
- Real integrations to LinkedIn, email, WhatsApp, calendar, GitHub, browser or coding assistants.
- Direct publication or analytics retrieval from social channels.
- Full career/opportunity pipeline and canonical CV facts.
- Automatic capture of coding sessions, terminal output, screenshots and test proof.
- Full video download/playback, local video understanding, transcript chaptering or clip editing.
- Optional local image-generation runtime and model pack.
- A full event ledger, rollback UI, task dependencies, recurring tasks, project milestones and resource scheduling.
- Multi-device encrypted sync or desktop/Docker companion.
- Automatic proactive reasoning over all data while the app is closed.

## Verification performed for this pass

- `ThreadlineDesignSystem.kt` compiled with the available standalone Kotlin compiler.
- `styles.xml` and `AndroidManifest.xml` parsed as well-formed XML.
- Source markers checked for persisted appearance selection, motion wiring, live overlay Reduce Motion updates and skeleton use.
- Added JVM unit tests for WCAG AA text/action contrast across the shared light/dark palette.
- The full Android build remains unavailable in this container because the SDK, Gradle installation and external dependency network access are absent.
- Full Android Gradle build, lint, unit tests, Android lifecycle, speech, LiteRT model execution, schema migration from a real v1 vault, backup restore and physical-device UX are **not verified in this environment** because the Android SDK/Gradle build environment is unavailable here.

The next required gate is GitHub Actions: `testDebugUnitTest lintDebug assembleDebug`. Then test on the actual phone: unlock old vault, verify old tasks/projects still exist, generate/save/edit/copy/archive a Studio draft, lock/unlock, export and restore an encrypted backup, and verify voice/model behavior.
