import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');
const exists = relative => fs.existsSync(path.join(root, relative));
const checks = [];
const check = (name, fn) => {
  try { fn(); checks.push({ name, ok: true }); }
  catch (error) { checks.push({ name, ok: false, error: error.message }); }
};

check('JavaScript parses without syntax errors', () => {
  execFileSync(process.execPath, ['--check', path.join(root, 'public/app.js')], { stdio: 'pipe' });
});
check('HTML IDs are unique', () => {
  const html = read('public/index.html');
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
  assert.equal(ids.length, new Set(ids).size, 'duplicate id attributes found');
});
check('Static JavaScript ID selectors exist in HTML or are declared modal fields', () => {
  const html = read('public/index.html');
  const js = read('public/app.js');
  const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]));
  const dynamic = new Set([
    'project-form', 'project-name', 'project-error', 'project-description', 'project-emoji',
    'entry-edit-form', 'edit-entry-text', 'edit-entry-error', 'edit-entry-due', 'edit-entry-kind', 'edit-entry-project',
    'assign-project-form', 'assign-project', 'export-form', 'backup-password', 'backup-error', 'backup-password-confirm',
    'backup-create', 'restore-form', 'restore-check', 'restore-password', 'restore-error', 'confirm-restore',
    'new-vault-pass-form', 'new-vault-pass', 'new-vault-pass-confirm', 'new-vault-pass-error', 'new-vault-pass-submit'
  ]);
  const selectors = [...new Set([...js.matchAll(/\$\('#([\w-]+)'/g)].map(match => match[1]))];
  const missing = selectors.filter(id => !ids.has(id) && !dynamic.has(id));
  assert.deepEqual(missing, [], `missing selectors: ${missing.join(', ')}`);
});
check('PWA manifest is valid JSON and required icons exist', () => {
  const manifest = JSON.parse(read('public/manifest.webmanifest'));
  assert.equal(manifest.display, 'standalone');
  for (const icon of manifest.icons) assert.ok(exists(path.join('public', icon.src)), `missing icon ${icon.src}`);
});
check('Offline shell includes all application files', () => {
  const sw = read('public/sw.js');
  for (const item of ['./index.html', './styles.css', './app.js', './manifest.webmanifest', './icon.svg', './icon-192.png', './icon-512.png']) {
    assert.ok(sw.includes(item), `service worker is not caching ${item}`);
  }
});
check('Android assets mirror the PWA app shell', () => {
  for (const item of fs.readdirSync(path.join(root, 'public'))) {
    assert.ok(exists(path.join('android/app/src/main/assets', item)), `Android assets lack ${item}; Gradle sync should copy it`);
    assert.ok(fs.readFileSync(path.join(root, 'public', item)).equals(fs.readFileSync(path.join(root, 'android/app/src/main/assets', item))), `${item} differs between PWA and Android assets`);
  }
});
check('Android manifest follows least-privilege network policy', () => {
  const manifest = read('android/app/src/main/AndroidManifest.xml');
  assert.ok(/android:allowBackup="false"/.test(manifest));
  assert.ok(/android:usesCleartextTraffic="false"/.test(manifest));
  assert.ok(!/android\.permission\.INTERNET/.test(manifest), 'network permission should not be requested');
  assert.ok(/android\.permission\.RECORD_AUDIO/.test(manifest), 'voice capture permission is missing');
});
check('First-run projects match the current workflow and stay empty of invented tasks', () => {
  const js = read('public/app.js');
  for (const name of ['QRkey', 'Troy', 'Threadline', 'Work & income']) assert.ok(js.includes(`name: '${name}'`), `missing starter project ${name}`);
  assert.ok(js.includes("entries: [],"), 'starter state should not invent tasks or captures');
});
check('Native vault uses AES-GCM, per-vault key aliases, and protected restore', () => {
  const java = read('android/app/src/main/java/app/threadline/mobile/MainActivity.java');
  assert.ok(java.includes('AES/GCM/NoPadding'));
  assert.ok(java.includes('setUserAuthenticationParameters(300'));
  assert.ok(java.includes('replaceVaultWithBackup(String json)'));
  assert.ok(java.includes('writeVaultBlob(cipher.getIV(), encrypted, newAlias)'));
  assert.ok(java.includes('MAGIC_V1') && java.includes('MAGIC_V2'));
});
check('No analytics or remote JavaScript is included in the shell', () => {
  const html = read('public/index.html');
  assert.ok(!/<script[^>]+src=["']https?:/i.test(html), 'external script should not be loaded');
  assert.ok(html.includes("script-src 'self'"), 'the app shell should block inline and remote script execution');
  assert.ok(!/<script>/.test(html), 'HTML should not contain inline JavaScript');
  assert.ok(!/google-analytics|googletagmanager|segment\.com|mixpanel|amplitude/i.test(html + read('public/app.js')));
});
check('Android build and CI workflows are present', () => {
  assert.ok(exists('android/app/build.gradle'));
  assert.ok(exists('.github/workflows/android-apk.yml'));
  assert.ok(exists('.github/workflows/deploy-pwa.yml'));
  assert.ok(exists('scripts/build-android.sh'));
  assert.ok(exists('README.md'));
  assert.ok(read('.github/workflows/android-apk.yml').includes('assembleDebug'));
  assert.ok(read('.github/workflows/deploy-pwa.yml').includes('upload-pages-artifact'));
});

for (const result of checks) {
  console.log(`${result.ok ? 'PASS' : 'FAIL'} ${result.name}${result.error ? ` — ${result.error}` : ''}`);
}
const failed = checks.filter(result => !result.ok);
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`);
if (failed.length) process.exitCode = 1;
