#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cd "$ROOT"
npm test

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle 8.9 is required. Open android/ in Android Studio or install Gradle 8.9." >&2
  exit 127
fi
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]] && [[ ! -f "$ROOT/android/local.properties" ]]; then
  echo "ERROR: Android SDK not configured. Set ANDROID_HOME/ANDROID_SDK_ROOT or configure android/local.properties." >&2
  exit 2
fi

(cd "$ROOT/android" && gradle --no-daemon assembleDebug)
APK="$ROOT/android/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -s "$APK" ]]; then
  echo "ERROR: Gradle completed but the APK was not found at $APK" >&2
  exit 3
fi
mkdir -p "$ROOT/dist"
cp "$APK" "$ROOT/dist/Threadline-debug.apk"
echo "Built: $ROOT/dist/Threadline-debug.apk"
if command -v adb >/dev/null 2>&1 && adb get-state >/dev/null 2>&1; then
  adb install -r "$ROOT/dist/Threadline-debug.apk"
else
  echo "No connected adb device detected. Transfer the APK to Android and install it manually."
fi
