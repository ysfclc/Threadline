# Threadline roadmap — outcome-first delivery

## Release 1.3 — make real work useful

- [x] Persist content drafts in the encrypted vault.
- [x] Studio formats: post, carousel outline, short video script, build-log episode, case study, technical breakdown, diagram brief, website story, portfolio proof, comment/reply, email draft and multiple angles.
- [x] Channel, format, voice and editable brand/privacy rules.
- [x] Explicit context inclusion, off by default.
- [x] Private-by-default drafts and manual public-safe review boundary.
- [x] Edit, copy, archive, restore and delete drafts.
- [x] Let Talk propose a private content draft for approval.
- [x] Add Studio to the floating quick-action menu.
- [x] Schema v1 → v2 in-memory migration path.
- [ ] GitHub Actions compile/test/lint and actual-device validation.

## Release 1.4 — orchestrator you can inspect

- [ ] Durable event ledger: requested → planned → running → review → approved → done/failed.
- [ ] Every action shows input evidence, selected capability, permission, result and proof.
- [ ] Undo/rollback for safe internal mutations; idempotency for retried operations.
- [ ] Editable skills with version, inputs, outputs, preconditions, examples, limits and test cases.
- [ ] Agent/specialist registry separated from tools and skills; dynamic team composition based on the task.
- [ ] Reuse existing capabilities before proposing a new skill or agent.
- [ ] Explicitly distinguish “AI suggests,” “user approved,” “tool ran,” and “independently verified.”
- [ ] Small workflows can run in background with cancellation, timeout and recoverable state.
- [ ] No arbitrary shell execution from model output; tools have typed schemas and allowlists.

## Release 1.5 — attention that helps instead of nags

- [ ] Morning briefing generated from projects, deadlines, recent events, blockers and promised follow-ups.
- [ ] “What can I do now?” modes: 2 minutes, walking, phone-only, low-energy, deep work, waiting for someone.
- [ ] Project health based on missing next action, stale activity, blockers and commitments—not arbitrary scores.
- [ ] Contextual follow-up reminders, quiet hours, snooze, per-topic mute and notification frequency settings.
- [ ] Optional calendar read bridge; show conflicts before proposing edits. No silent invite creation.
- [ ] Capture a person/opportunity/follow-up from voice or shared text and connect it to the source.
- [ ] Driving mode: concise spoken responses, interrupt/stop, no visual interaction while moving, and an explicit OS-recognizer offline status.

## Release 1.6 — proof and career

- [ ] Local import of project docs, CVs, selected conversation exports and coding-session logs.
- [ ] Benchmark supported model candidates and GPU/NPU optimizations; consider Gemma 4 E2B and multi-token prediction only after compatibility, RAM and latency tests: https://developers.google.com/edge/litert-lm/overview
- [ ] Source index with stable IDs, timestamps, source path/provider, privacy, checksum and extraction status.
- [ ] Career records: opportunity, company, contact, interview, follow-up, role requirements and source URL.
- [ ] Canonical career facts; generate tailored CV and interview stories as projections without contradicting source truth.
- [ ] Proof objects: screenshot, video, code diff, test output, demo URL, result, verifier and related work.
- [ ] A passing build or verified demo can suggest a story, update portfolio evidence and prepare a post—but never publish automatically.

## Release 1.7 — media and curiosity

- [ ] Watch-later queue for videos, links, papers and posts with “why I saved this.”
- [ ] Import user-provided video or transcript; extract chapters, timestamps, claims, questions and relevant project links.
- [ ] Optional local speech-to-text model independent from Android's speech service.
- [ ] Local image-generation pack behind RAM/storage/compatibility checks; model is optional, not bundled.
- [ ] Media studio: storyboard, shot list, voiceover, captions, diagram and short-video plan derived from real evidence.
- [ ] “Curiosity thread” mode that explores a question and ends with a summary/artifact rather than infinite scrolling.
- [ ] Local semantic search/embeddings only after data size, model quality and memory cost are measured.

## Release 1.8 — external-world mirrors

Each integration must be real, permissioned and inspectable. Build one end-to-end integration at a time rather than a page of fake connectors.

1. Android share sheet and local files (improve extraction/lineage).
2. Calendar (read first, then explicitly approved write actions).
3. GitHub (repos, issues, pull requests, commits, checks and links to proof).
4. Email (search/read/draft; sending remains an explicit action).
5. Browser/source capture and selected website actions.
6. LinkedIn or other social channels only through a legitimate, supported interface; no unsupported scraping or pretend publication.
7. Coding assistant sessions (Claude Code, Cursor, Copilot, Kimi, OpenCode and other user-selected tools) through import/adapters with sensitivity checks.

## Commercial readiness gate

Before calling the product production-ready:

- Test data migration and backup restoration across every schema version.
- Run unit, lint, UI-flow and device tests.
- Benchmark model cold start, warm first-token latency, tokens/sec, RAM, thermal behavior and battery on supported device classes.
- Test with airplane mode enabled and verify which voice/vision capabilities actually stay local.
- Validate file import sizes, corrupted attachments, cancellation, low-storage behavior and process death.
- Add crash-safe writes, bounded logs, redaction, recovery UI and model rollback.
- Make all permissions understandable and revocable; avoid background microphone access.
- Accessibility: TalkBack, touch targets, contrast, large fonts, reduced motion and one-handed use.
- Have no dead controls, fake progress, invented metrics or “connected” labels without a real integration.
- Ship a transparent feature matrix and privacy/data-flow statement.

## Business model hypothesis (to validate, not assume)

A credible paid product could sell ownership, not an AI token subscription:

- Free/local core: capture, vault, tasks/projects, search, encrypted export and a limited model pack.
- One-time Personal Pro license: richer local workflows, Studio templates/brand profiles, custom skills, model packs and desktop companion.
- Optional paid integrations or setup packs only when they deliver real value; clearly separate external provider costs.
- No mandatory cloud account and no selling personal data. Optional encrypted sync can be a later opt-in service, not a prerequisite.

Validate willingness to pay with a small group before investing in billing or multi-tenant infrastructure.
