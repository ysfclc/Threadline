package app.threadline.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.security.keystore.UserNotAuthenticatedException;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.StandardCopyOption;
import java.security.Key;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Native shell for Threadline.
 * All user-created content is encrypted into an app-private file with an AES-256-GCM key
 * held by Android Keystore. Access requires recent device authentication. No network permission
 * or remote endpoint is used by this app.
 */
public final class MainActivity extends Activity {
    private static final String KEY_ALIAS = "threadline-vault-aes-256-v1";
    private static final String VAULT_FILE = "threadline-vault.bin";
    private static final byte[] MAGIC_V1 = new byte[]{'T', 'L', 'V', '1'};
    private static final byte[] MAGIC_V2 = new byte[]{'T', 'L', 'V', '2'};
    private static final String RESTORE_ALIAS_PREFIX = "threadline-vault-restore-";
    private static final int REQUEST_PICK_FILE = 4101;
    private static final int REQUEST_EXPORT_BACKUP = 4102;
    private static final int REQUEST_AUDIO_PERMISSION = 4103;
    private static final int REQUEST_EXPORT_ATTACHMENT = 4104;
    private static final long AUTH_WINDOW_MILLIS = 240_000L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingAudioRequest;
    private String pendingBackupText;
    private byte[] pendingAttachmentBytes;
    private String pendingAttachmentMime;
    private String pendingAttachmentName;
    private boolean pageLoaded = false;
    private volatile boolean authInProgress = false;
    private volatile long lastAuthAt = 0L;
    private boolean wasBackgrounded = false;
    private boolean documentPickerOpen = false;
    private boolean activityDestroyed = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(247, 248, 245));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(247, 248, 245));
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat bars = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        bars.setAppearanceLightStatusBars(true);
        bars.setAppearanceLightNavigationBars(true);
        // Prevent the system from exposing private content in task switcher screenshots.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setupWebView();
    }

    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(247, 248, 245));
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setDatabaseEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "ThreadlineAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Only this app's bundled asset origin is allowed. No remote content or navigation.
                return !"https".equalsIgnoreCase(uri.getScheme())
                        || !"appassets.androidplatform.net".equalsIgnoreCase(uri.getHost());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                if (wasBackgrounded) {
                    wasBackgrounded = false;
                    mainHandler.postDelayed(() -> evaluate("window.ThreadlineUI && window.ThreadlineUI.resumeFromNative();"), 180);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "image/*", "audio/*", "application/pdf", "text/plain", "text/markdown",
                        "text/csv", "application/json", "application/octet-stream"
                });
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                documentPickerOpen = true;
                try {
                    startActivityForResult(intent, REQUEST_PICK_FILE);
                } catch (Exception error) {
                    documentPickerOpen = false;
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker is available on this device.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean allowedOrigin = request.getOrigin() != null
                            && "https".equalsIgnoreCase(request.getOrigin().getScheme())
                            && "appassets.androidplatform.net".equalsIgnoreCase(request.getOrigin().getHost());
                    boolean asksOnlyForAudio = request.getResources() != null
                            && Arrays.stream(request.getResources()).allMatch(PermissionRequest.RESOURCE_AUDIO_CAPTURE::equals);
                    if (!allowedOrigin || !asksOnlyForAudio) {
                        request.deny();
                        return;
                    }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingAudioRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO_PERMISSION);
                    }
                });
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingAudioRequest == request) pendingAudioRequest = null;
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(webView, (view, windowInsets) -> {
            Insets systemBars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        setContentView(webView);
        ViewCompat.requestApplyInsets(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        WebView.setWebContentsDebuggingEnabled(false);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (wasBackgrounded && pageLoaded && !authInProgress) {
            wasBackgrounded = false;
            mainHandler.postDelayed(() -> evaluate("window.ThreadlineUI && window.ThreadlineUI.resumeFromNative();"), 160);
        }
    }

    @Override
    protected void onStop() {
        if (!isChangingConfigurations() && !isFinishing() && !authInProgress && !documentPickerOpen && pageLoaded) {
            wasBackgrounded = true;
            evaluate("window.ThreadlineUI && window.ThreadlineUI.lockFromNative();");
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        if (pendingAudioRequest != null) pendingAudioRequest.deny();
        try { ioExecutor.shutdown(); } catch (Exception ignored) { }
        if (pendingAttachmentBytes != null) Arrays.fill(pendingAttachmentBytes, (byte) 0);
        pendingAttachmentBytes = null;
        pendingBackupText = null;
        if (webView != null) {
            webView.removeJavascriptInterface("ThreadlineAndroid");
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO_PERMISSION) {
            PermissionRequest request = pendingAudioRequest;
            pendingAudioRequest = null;
            if (request == null) return;
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else request.deny();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_FILE) {
            documentPickerOpen = false;
            if (filePathCallback == null) return;
            Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null
                    ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        } else if (requestCode == REQUEST_EXPORT_BACKUP) {
            documentPickerOpen = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupText != null) {
                Uri uri = data.getData();
                String payload = pendingBackupText;
                ioExecutor.execute(() -> {
                    try (java.io.OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                        if (output == null) throw new IOException("The selected destination could not be opened.");
                        output.write(payload.getBytes(StandardCharsets.UTF_8));
                        output.flush();
                        evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultExported(true, '');");
                    } catch (Exception error) {
                        evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultExported(false, " + JSONObject.quote(safeMessage(error)) + ");");
                    } finally {
                        pendingBackupText = null;
                    }
                });
            } else {
                pendingBackupText = null;
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultExported(false, 'Backup export was cancelled.');");
            }
        } else if (requestCode == REQUEST_EXPORT_ATTACHMENT) {
            documentPickerOpen = false;
            final byte[] dataBytes = pendingAttachmentBytes;
            pendingAttachmentBytes = null;
            pendingAttachmentMime = null;
            pendingAttachmentName = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && dataBytes != null) {
                Uri uri = data.getData();
                ioExecutor.execute(() -> {
                    boolean ok = false;
                    String message = "";
                    try (java.io.OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                        if (output == null) throw new IOException("The selected destination could not be opened.");
                        output.write(dataBytes);
                        output.flush();
                        ok = true;
                    } catch (Exception error) {
                        message = safeMessage(error);
                    } finally {
                        Arrays.fill(dataBytes, (byte) 0);
                    }
                    evaluate("window.ThreadlineNative && window.ThreadlineNative.onAttachmentExported(" + ok + ", " + JSONObject.quote(message) + ");");
                });
            } else {
                if (dataBytes != null) Arrays.fill(dataBytes, (byte) 0);
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onAttachmentExported(false, 'Attachment export was cancelled.');");
            }
        }
    }

    private File vaultFile() { return new File(getFilesDir(), VAULT_FILE); }

    private SecretKey getOrCreateKey(String alias) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        Key existing = keyStore.getKey(alias, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(alias,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(true)
                .setUserAuthenticationParameters(300,
                        KeyProperties.AUTH_BIOMETRIC_STRONG | KeyProperties.AUTH_DEVICE_CREDENTIAL)
                .setInvalidatedByBiometricEnrollment(false)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private String activeVaultKeyAlias() {
        File file = vaultFile();
        if (file.exists()) {
            try { return readVaultBlob(file).keyAlias; }
            catch (Exception ignored) { /* Fall through; the subsequent operation will report file corruption. */ }
        }
        return KEY_ALIAS;
    }

    private Cipher newCipher(int mode, @Nullable byte[] iv) throws Exception {
        return newCipher(mode, iv, activeVaultKeyAlias());
    }

    private Cipher newCipher(int mode, @Nullable byte[] iv, String alias) throws Exception {
        SecretKey key = getOrCreateKey(alias);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        if (mode == Cipher.ENCRYPT_MODE) {
            cipher.init(Cipher.ENCRYPT_MODE, key);
        } else {
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        }
        return cipher;
    }

    private void beginLoad() {
        if (activityDestroyed) return;
        ioExecutor.execute(() -> {
            try {
                File file = vaultFile();
                boolean creating = !file.exists();
                Cipher cipher;
                byte[] payload;
                String keyAlias;
                boolean authenticatedBeforeCipher = false;
                if (creating) {
                    keyAlias = KEY_ALIAS;
                    payload = initialStateJson().getBytes(StandardCharsets.UTF_8);
                    try {
                        cipher = newCipher(Cipher.ENCRYPT_MODE, null, keyAlias);
                    } catch (UserNotAuthenticatedException needsDeviceAuth) {
                        authenticateWithoutCipher("Secure your vault", "Confirm to protect your new vault.").get(90, TimeUnit.SECONDS);
                        cipher = newCipher(Cipher.ENCRYPT_MODE, null, keyAlias);
                        authenticatedBeforeCipher = true;
                    }
                } else {
                    VaultBlob blob = readVaultBlob(file);
                    keyAlias = blob.keyAlias;
                    payload = blob.ciphertext;
                    try {
                        cipher = newCipher(Cipher.DECRYPT_MODE, blob.iv, keyAlias);
                    } catch (UserNotAuthenticatedException needsDeviceAuth) {
                        authenticateWithoutCipher("Unlock Threadline", "Confirm to decrypt your private data.").get(90, TimeUnit.SECONDS);
                        cipher = newCipher(Cipher.DECRYPT_MODE, blob.iv, keyAlias);
                        authenticatedBeforeCipher = true;
                    }
                }
                boolean isCreating = creating;
                CompletableFuture<Void> authentication = authenticatedBeforeCipher
                        ? CompletableFuture.completedFuture(null)
                        : authenticateWithoutCipher(isCreating ? "Secure your vault" : "Unlock Threadline",
                                isCreating ? "Confirm to protect your new vault." : "Confirm to decrypt your private data.");
                authentication.whenCompleteAsync((ignored, authError) -> {
                    if (authError != null) {
                        dispatchLoadError(safeMessage(authError));
                        return;
                    }
                    try {
                        byte[] result = cipher.doFinal(payload);
                        if (isCreating) {
                            writeVaultBlob(cipher.getIV(), result, keyAlias);
                            dispatchLoaded(new String(payload, StandardCharsets.UTF_8));
                        } else {
                            dispatchLoaded(new String(result, StandardCharsets.UTF_8));
                        }
                    } catch (UserNotAuthenticatedException authNeeded) {
                        try {
                            authenticateWithoutCipher("Unlock Threadline", "Confirm to decrypt your private data.").get(90, TimeUnit.SECONDS);
                            Cipher retry = newCipher(isCreating ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                                    isCreating ? null : readVaultBlob(file).iv, keyAlias);
                            byte[] retryResult = retry.doFinal(payload);
                            if (isCreating) writeVaultBlob(retry.getIV(), retryResult, keyAlias);
                            dispatchLoaded(new String(isCreating ? payload : retryResult, StandardCharsets.UTF_8));
                        } catch (Exception retryError) { dispatchLoadError(safeMessage(retryError)); }
                    } catch (Exception error) {
                        dispatchLoadError(safeMessage(error));
                    }
                }, ioExecutor);
            } catch (Exception error) {
                dispatchLoadError(safeMessage(error));
            }
        });
    }

    private void enqueueWrite(String json) {
        final String snapshot = json == null ? initialStateJson() : json;
        ioExecutor.execute(() -> {
            try {
                String keyAlias = activeVaultKeyAlias();
                Cipher cipher;
                boolean authenticatedBeforeCipher = false;
                try {
                    cipher = newCipher(Cipher.ENCRYPT_MODE, null, keyAlias);
                } catch (UserNotAuthenticatedException needsDeviceAuth) {
                    authenticateWithoutCipher("Save your vault", "Confirm to continue saving encrypted data.").get(90, TimeUnit.SECONDS);
                    cipher = newCipher(Cipher.ENCRYPT_MODE, null, keyAlias);
                    authenticatedBeforeCipher = true;
                }
                if (!authenticatedBeforeCipher && SystemClock.elapsedRealtime() - lastAuthAt > AUTH_WINDOW_MILLIS) {
                    authenticateWithoutCipher("Save your vault", "Confirm to continue saving encrypted data.").get(90, TimeUnit.SECONDS);
                }
                byte[] encrypted;
                try {
                    encrypted = cipher.doFinal(snapshot.getBytes(StandardCharsets.UTF_8));
                } catch (UserNotAuthenticatedException authNeeded) {
                    authenticateWithoutCipher("Save your vault", "Confirm to continue saving encrypted data.").get(90, TimeUnit.SECONDS);
                    cipher = newCipher(Cipher.ENCRYPT_MODE, null, keyAlias);
                    encrypted = cipher.doFinal(snapshot.getBytes(StandardCharsets.UTF_8));
                }
                writeVaultBlob(cipher.getIV(), encrypted, keyAlias);
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultSaved(true, '');");
            } catch (Exception error) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultSaved(false, " + JSONObject.quote(safeMessage(error)) + ");");
            }
        });
    }

    private CompletableFuture<Void> authenticateWithoutCipher(String title, String subtitle) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        mainHandler.post(() -> {
            int authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL;
            BiometricManager manager = BiometricManager.from(this);
            int availability = manager.canAuthenticate(authenticators);
            if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
                future.completeExceptionally(new IllegalStateException(authenticatorMessage(availability)));
                return;
            }
            authInProgress = true;
            BiometricPrompt prompt = new BiometricPrompt(this, ContextCompat.getMainExecutor(this), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    authInProgress = false;
                    lastAuthAt = SystemClock.elapsedRealtime();
                    future.complete(null);
                }
                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    authInProgress = false;
                    future.completeExceptionally(new IllegalStateException(errString.toString()));
                }
            });
            try {
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                        .setTitle(title).setSubtitle(subtitle).setAllowedAuthenticators(authenticators).build();
                prompt.authenticate(info);
            } catch (Exception error) { authInProgress = false; future.completeExceptionally(error); }
        });
        return future;
    }

    private String authenticatorMessage(int result) {
        switch (result) {
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                return "This device has no supported biometric sensor. Set up Android device authentication to protect your vault.";
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                return "Device authentication is temporarily unavailable. Try again in a moment.";
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                return "Set up a fingerprint, face unlock, or device screen lock in Android Settings, then try again.";
            default:
                return "Device authentication is unavailable. Set up a secure screen lock and try again.";
        }
    }

    private VaultBlob readVaultBlob(File file) throws Exception {
        try (DataInputStream input = new DataInputStream(new FileInputStream(file))) {
            byte[] magic = new byte[MAGIC_V1.length];
            input.readFully(magic);
            final String keyAlias;
            if (Arrays.equals(magic, MAGIC_V1)) {
                // Backward compatibility with the first native-vault format.
                keyAlias = KEY_ALIAS;
            } else if (Arrays.equals(magic, MAGIC_V2)) {
                keyAlias = input.readUTF();
                if (keyAlias.trim().isEmpty() || keyAlias.length() > 128 || !keyAlias.matches("[A-Za-z0-9._-]+")) {
                    throw new IOException("The encrypted vault contains an invalid key identifier.");
                }
            } else {
                throw new IOException("The encrypted vault has an unknown format.");
            }
            int ivLength = input.readInt();
            if (ivLength != 12) throw new IOException("The encrypted vault has an invalid initialization vector.");
            byte[] iv = new byte[ivLength]; input.readFully(iv);
            ByteArrayOutputStream ciphertextBuffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int count;
            while ((count = input.read(chunk)) != -1) {
                if (ciphertextBuffer.size() + count > 32 * 1024 * 1024) throw new IOException("The encrypted vault is too large.");
                ciphertextBuffer.write(chunk, 0, count);
            }
            byte[] ciphertext = ciphertextBuffer.toByteArray();
            if (ciphertext.length < 16) throw new IOException("The encrypted vault is empty or too large.");
            return new VaultBlob(iv, ciphertext, keyAlias);
        }
    }

    private void writeVaultBlob(byte[] iv, byte[] ciphertext) throws IOException {
        writeVaultBlob(iv, ciphertext, activeVaultKeyAlias());
    }

    private void writeVaultBlob(byte[] iv, byte[] ciphertext, String keyAlias) throws IOException {
        if (iv == null || iv.length != 12 || ciphertext == null || ciphertext.length < 16 || ciphertext.length > 32 * 1024 * 1024) {
            throw new IOException("The encrypted vault payload is invalid.");
        }
        if (keyAlias == null || keyAlias.trim().isEmpty() || keyAlias.length() > 128 || !keyAlias.matches("[A-Za-z0-9._-]+")) {
            throw new IOException("The encrypted vault key identifier is invalid.");
        }
        File destination = vaultFile();
        File temp = new File(getFilesDir(), VAULT_FILE + ".tmp");
        try (FileOutputStream file = new FileOutputStream(temp);
             DataOutputStream output = new DataOutputStream(file)) {
            output.write(MAGIC_V2);
            output.writeUTF(keyAlias);
            output.writeInt(iv.length);
            output.write(iv);
            output.write(ciphertext);
            output.flush();
            file.getFD().sync();
        }
        try {
            Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temp.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private boolean isSupportedAttachmentMime(String mime) {
        return mime != null && (mime.matches("image/(jpeg|png|webp|gif)")
                || mime.matches("audio/(webm|mp4|mpeg|wav|ogg|x-wav)")
                || "application/pdf".equals(mime)
                || mime.matches("text/(plain|markdown|csv)"));
    }

    private String initialStateJson() {
        String now = JSONObject.quote(java.time.Instant.now().toString());
        String projects = "["
                + defaultProjectJson("project-qrkey", "QRkey", "Primary build focus. Capture bugs, record reproductions, and verify fixes.", "⚙", now) + ","
                + defaultProjectJson("project-troy", "Troy", "Language and identity intelligence: evidence first, deterministic meaning before AI.", "✳", now) + ","
                + defaultProjectJson("project-threadline", "Threadline", "A private capture-to-action workspace. Keep the app useful and frictionless.", "↗", now) + ","
                + defaultProjectJson("project-work-income", "Work & income", "Practical next steps for work, income, and opportunities.", "◇", now)
                + "]";
        return "{\"version\":1,\"createdAt\":" + now
                + ",\"updatedAt\":" + now
                + ",\"entries\":[],\"projects\":" + projects
                + ",\"settings\":{\"captureCount\":0}}";
    }

    private String defaultProjectJson(String id, String name, String description, String emoji, String now) {
        return "{\"id\":" + JSONObject.quote(id)
                + ",\"name\":" + JSONObject.quote(name)
                + ",\"description\":" + JSONObject.quote(description)
                + ",\"emoji\":" + JSONObject.quote(emoji)
                + ",\"createdAt\":" + now + "}";
    }

    private void dispatchLoaded(String json) {
        evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultLoaded(" + JSONObject.quote(json) + ");");
    }

    private void dispatchLoadError(String message) {
        evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultError(" + JSONObject.quote(message) + ");");
    }

    private void evaluate(String javascript) {
        mainHandler.post(() -> {
            if (!activityDestroyed && webView != null) {
                try { webView.evaluateJavascript(javascript, null); } catch (Exception ignored) { }
            }
        });
    }

    private String safeMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && (current instanceof java.util.concurrent.ExecutionException || current instanceof java.util.concurrent.CompletionException)) current = current.getCause();
        String message = current.getMessage();
        return message == null || message.trim().isEmpty() ? "An unexpected secure-storage error occurred." : message;
    }

    private final class AndroidBridge {
        @JavascriptInterface public String version() { return "1.0.0"; }
        @JavascriptInterface public void loadVault() { beginLoad(); }
        @JavascriptInterface public void writeVault(String json) {
            if (json == null || json.length() > 24 * 1024 * 1024) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultSaved(false, 'The vault is too large to save safely.');");
                return;
            }
            enqueueWrite(json);
        }
        @JavascriptInterface public void exportAttachment(String dataUrl, String requestedName) {
            if (dataUrl == null || dataUrl.length() > 2_600_000) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onAttachmentExported(false, 'This attachment is too large to export safely.');");
                return;
            }
            final String mime;
            final byte[] bytes;
            try {
                int comma = dataUrl.indexOf(',');
                if (!dataUrl.startsWith("data:") || comma < 6) throw new IllegalArgumentException("Unsupported attachment format.");
                String metadata = dataUrl.substring(5, comma);
                if (!metadata.toLowerCase(java.util.Locale.ROOT).endsWith(";base64")) throw new IllegalArgumentException("Unsupported attachment encoding.");
                mime = metadata.substring(0, metadata.length() - ";base64".length()).toLowerCase(java.util.Locale.ROOT);
                if (!isSupportedAttachmentMime(mime)) throw new IllegalArgumentException("This attachment type cannot be exported from Threadline.");
                bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                if (bytes.length == 0 || bytes.length > 1_800_000) throw new IllegalArgumentException("The attachment is empty or exceeds the 1.8 MB limit.");
            } catch (Exception error) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onAttachmentExported(false, " + JSONObject.quote(safeMessage(error)) + ");");
                return;
            }
            String cleanedName = requestedName == null ? "threadline-attachment" : requestedName;
            cleanedName = cleanedName.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
            if (cleanedName.isEmpty()) cleanedName = "threadline-attachment";
            if (cleanedName.length() > 120) cleanedName = cleanedName.substring(0, 120);
            final String safeName = cleanedName;
            mainHandler.post(() -> {
                pendingAttachmentBytes = bytes;
                pendingAttachmentMime = mime;
                pendingAttachmentName = safeName;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                documentPickerOpen = true;
                try { startActivityForResult(intent, REQUEST_EXPORT_ATTACHMENT); }
                catch (Exception error) {
                    documentPickerOpen = false;
                    if (pendingAttachmentBytes != null) Arrays.fill(pendingAttachmentBytes, (byte) 0);
                    pendingAttachmentBytes = null; pendingAttachmentMime = null; pendingAttachmentName = null;
                    evaluate("window.ThreadlineNative && window.ThreadlineNative.onAttachmentExported(false, " + JSONObject.quote(safeMessage(error)) + ");");
                }
            });
        }

        @JavascriptInterface public void replaceVaultWithBackup(String json) {
            if (json == null || json.length() > 24 * 1024 * 1024) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultReplaced(false, 'The restored vault is too large to process safely.');");
                return;
            }
            try {
                JSONObject candidate = new JSONObject(json);
                org.json.JSONArray entries = candidate.optJSONArray("entries");
                org.json.JSONArray projects = candidate.optJSONArray("projects");
                if (entries == null || projects == null || entries.length() > 20000 || projects.length() > 5000) {
                    throw new IllegalArgumentException("The backup does not contain a valid Threadline vault.");
                }
            } catch (Exception invalid) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultReplaced(false, 'The restored vault data is invalid.');");
                return;
            }
            final String snapshot = json;
            ioExecutor.execute(() -> {
                String newAlias = RESTORE_ALIAS_PREFIX + UUID.randomUUID().toString().replace("-", "");
                String oldAlias = activeVaultKeyAlias();
                boolean vaultReplaced = false;
                try {
                    // Keep the existing key and vault intact until the new ciphertext is committed.
                    authenticateWithoutCipher("Restore Threadline", "Confirm to create a new protected vault from your backup.").get(90, TimeUnit.SECONDS);
                    Cipher cipher;
                    try {
                        cipher = newCipher(Cipher.ENCRYPT_MODE, null, newAlias);
                    } catch (UserNotAuthenticatedException needsDeviceAuth) {
                        authenticateWithoutCipher("Restore Threadline", "Confirm to protect the restored data.").get(90, TimeUnit.SECONDS);
                        cipher = newCipher(Cipher.ENCRYPT_MODE, null, newAlias);
                    }
                    byte[] encrypted;
                    try {
                        encrypted = cipher.doFinal(snapshot.getBytes(StandardCharsets.UTF_8));
                    } catch (UserNotAuthenticatedException needsDeviceAuth) {
                        authenticateWithoutCipher("Restore Threadline", "Confirm to protect the restored data.").get(90, TimeUnit.SECONDS);
                        cipher = newCipher(Cipher.ENCRYPT_MODE, null, newAlias);
                        encrypted = cipher.doFinal(snapshot.getBytes(StandardCharsets.UTF_8));
                    }
                    writeVaultBlob(cipher.getIV(), encrypted, newAlias);
                    vaultReplaced = true;
                    if (oldAlias.startsWith(RESTORE_ALIAS_PREFIX) && !oldAlias.equals(newAlias)) {
                        try {
                            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
                            keyStore.load(null);
                            keyStore.deleteEntry(oldAlias);
                        } catch (Exception ignored) { /* The committed vault remains valid; stale keys are harmless. */ }
                    }
                    evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultReplaced(true, '');");
                } catch (Exception error) {
                    if (!vaultReplaced) {
                        try {
                            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
                            keyStore.load(null);
                            keyStore.deleteEntry(newAlias);
                        } catch (Exception ignored) { }
                    }
                    evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultReplaced(false, " + JSONObject.quote(safeMessage(error)) + ");");
                }
            });
        }

        @JavascriptInterface public void exportBackup(String encryptedBackupJson) {
            if (encryptedBackupJson == null || encryptedBackupJson.length() > 20 * 1024 * 1024) {
                evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultExported(false, 'The backup is too large to export.');");
                return;
            }
            mainHandler.post(() -> {
                pendingBackupText = encryptedBackupJson;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, "threadline-backup-" + java.time.LocalDate.now() + ".threadline");
                try { startActivityForResult(intent, REQUEST_EXPORT_BACKUP); }
                catch (Exception error) {
                    pendingBackupText = null;
                    evaluate("window.ThreadlineNative && window.ThreadlineNative.onVaultExported(false, " + JSONObject.quote(safeMessage(error)) + ");");
                }
            });
        }
    }

    private static final class VaultBlob {
        final byte[] iv;
        final byte[] ciphertext;
        final String keyAlias;
        VaultBlob(byte[] iv, byte[] ciphertext, String keyAlias) {
            this.iv = iv; this.ciphertext = ciphertext; this.keyAlias = keyAlias;
        }
    }
}
