(() => {
  'use strict';

  const PBKDF2_ITERATIONS = 600000;
  const MAX_ATTACHMENT_BYTES = 1_800_000;
  const MAX_TOTAL_ATTACHMENT_BYTES = 8_000_000;
  const BACKUP_FORMAT = 'threadline-encrypted-backup-v1';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const nativeMode = !!(window.ThreadlineAndroid && typeof window.ThreadlineAndroid.version === 'function');
  const freshState = () => {
    const now = new Date().toISOString();
    return {
      version: 1,
      createdAt: now,
      updatedAt: now,
      entries: [],
      projects: [
        { id: 'project-qrkey', name: 'QRkey', description: 'Primary build focus. Capture bugs, record reproductions, and verify fixes.', emoji: '⚙', createdAt: now },
        { id: 'project-troy', name: 'Troy', description: 'Language and identity intelligence: evidence first, deterministic meaning before AI.', emoji: '✳', createdAt: now },
        { id: 'project-threadline', name: 'Threadline', description: 'A private capture-to-action workspace. Keep the app useful and frictionless.', emoji: '↗', createdAt: now },
        { id: 'project-work-income', name: 'Work & income', description: 'Practical next steps for work, income, and opportunities.', emoji: '◇', createdAt: now }
      ],
      settings: { captureCount: 0 }
    };
  };

  let appState = freshState();
  let pwaKey = null;
  let pwaRecord = null;
  let sessionOpen = false;
  let gateMode = 'setup';
  let saveTimer = null;
  let saveQueue = Promise.resolve();
  let saveInProgress = false;
  let pendingAttachment = null;
  let forceNote = false;
  let activePage = 'home';
  let inboxFilter = 'all';
  let newestFirst = true;
  let activeProjectId = null;
  let captureProjectId = null;
  let searchTimer = null;
  let recordStream = null;
  let mediaRecorder = null;
  let recordingChunks = [];
  let recordingStartedAt = 0;
  let recordingInterval = null;
  let recordingLimitTimeout = null;
  let restoreDraft = null;
  let lastActivityTimer = null;
  let hiddenLockTimer = null;
  let currentNativeError = '';

  // The browser build uses a passphrase-derived AES-256-GCM key. The APK delegates
  // encryption and authentication to Android Keystore, exposing only a small bridge.
  const dbPromise = nativeMode ? Promise.resolve(null) : openDatabase();

  function openDatabase() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('This browser does not support encrypted local storage. Use a current browser or the Android app.'));
        return;
      }
      const request = indexedDB.open('threadline-private-vault', 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains('vault')) request.result.createObjectStore('vault', { keyPath: 'id' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Could not open local storage.'));
      request.onblocked = () => reject(new Error('Local storage is busy in another tab. Close other Threadline tabs and retry.'));
    });
  }

  async function dbGet(id = 'main') {
    const db = await dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction('vault', 'readonly');
      const request = tx.objectStore('vault').get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error || new Error('Could not read your vault.'));
    });
  }

  async function dbPut(record) {
    const db = await dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction('vault', 'readwrite');
      tx.objectStore('vault').put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('Could not save your vault.'));
      tx.onabort = () => reject(tx.error || new Error('The vault save was interrupted.'));
    });
  }

  function bytesToBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    return btoa(binary);
  }

  function base64ToBytes(value) {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function randomBytes(length) {
    const result = new Uint8Array(length);
    crypto.getRandomValues(result);
    return result;
  }

  async function deriveKey(passphrase, salt) {
    const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }

  async function encryptObject(value, key) {
    const iv = randomBytes(12);
    const plaintext = new TextEncoder().encode(JSON.stringify(value));
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
    return { version: 1, iv: bytesToBase64(iv), ciphertext: bytesToBase64(new Uint8Array(encrypted)) };
  }

  async function decryptObject(record, key) {
    if (!record || record.version !== 1 || !record.iv || !record.ciphertext) throw new Error('The encrypted vault file is incomplete.');
    const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64ToBytes(record.iv) }, key, base64ToBytes(record.ciphertext));
    return JSON.parse(new TextDecoder().decode(plaintext));
  }

  async function makePwaRecord(state, key, salt) {
    const encrypted = await encryptObject(state, key);
    return { id: 'main', format: 'threadline-pwa-vault-v1', salt: bytesToBase64(salt), ...encrypted, savedAt: new Date().toISOString() };
  }

  function sanitizeState(input) {
    const empty = freshState();
    if (!input || typeof input !== 'object') return empty;
    const entries = Array.isArray(input.entries) ? input.entries.filter(e => e && typeof e.id === 'string' && typeof e.text === 'string').map(e => ({
      id: e.id,
      text: e.text.slice(0, 6000),
      kind: ['task', 'note', 'idea'].includes(e.kind) ? e.kind : 'note',
      createdAt: validIso(e.createdAt) ? e.createdAt : new Date().toISOString(),
      updatedAt: validIso(e.updatedAt) ? e.updatedAt : (validIso(e.createdAt) ? e.createdAt : new Date().toISOString()),
      dueDate: typeof e.dueDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(e.dueDate) ? e.dueDate : null,
      projectId: typeof e.projectId === 'string' ? e.projectId : null,
      done: e.done === true,
      attachment: sanitizeAttachment(e.attachment),
      source: ['text', 'voice', 'file'].includes(e.source) ? e.source : 'text'
    })) : [];
    const projects = Array.isArray(input.projects) ? input.projects.filter(p => p && typeof p.id === 'string' && typeof p.name === 'string').map(p => ({
      id: p.id, name: p.name.slice(0, 100), description: typeof p.description === 'string' ? p.description.slice(0, 500) : '',
      emoji: ['◌', '✳', '⌘', '↗', '◇', '⚙', '▤', '✦'].includes(p.emoji) ? p.emoji : '◌',
      createdAt: validIso(p.createdAt) ? p.createdAt : new Date().toISOString()
    })) : [];
    return {
      version: 1,
      createdAt: validIso(input.createdAt) ? input.createdAt : empty.createdAt,
      updatedAt: validIso(input.updatedAt) ? input.updatedAt : empty.updatedAt,
      entries,
      projects,
      settings: { captureCount: Number.isFinite(input.settings?.captureCount) ? Math.max(0, input.settings.captureCount) : entries.length }
    };
  }

  function validIso(value) { return typeof value === 'string' && Number.isFinite(Date.parse(value)); }

  function sanitizeAttachment(attachment) {
    if (!attachment || typeof attachment !== 'object' || typeof attachment.data !== 'string') return null;
    const allowedMime = /^(?:image\/(?:jpeg|png|webp|gif)|audio\/(?:webm|mp4|mpeg|wav|ogg|x-wav)|application\/pdf|text\/(?:plain|markdown|csv))$/i;
    const mime = typeof attachment.mime === 'string' ? attachment.mime.slice(0, 100).split(';')[0].toLowerCase() : 'application/octet-stream';
    if (!allowedMime.test(mime) || !attachment.data.startsWith(`data:${mime};base64,`) || attachment.data.length > MAX_ATTACHMENT_BYTES * 1.5) return null;
    return {
      name: typeof attachment.name === 'string' ? attachment.name.slice(0, 180) : 'attachment',
      mime,
      data: attachment.data,
      size: Number.isFinite(attachment.size) ? Math.min(attachment.size, MAX_ATTACHMENT_BYTES) : Math.floor(attachment.data.length * .72)
    };
  }

  function html(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  }

  function makeId() {
    return (crypto.randomUUID && crypto.randomUUID()) || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
  }

  function showGate(mode, message = '') {
    sessionOpen = false;
    gateMode = mode;
    $('#workspace').classList.add('hidden');
    $('#bottom-nav').classList.add('hidden');
    $('#loading-screen').classList.add('hidden');
    $('#gate-screen').classList.remove('hidden');
    $('#vault-password').value = '';
    $('#vault-password-confirm').value = '';
    $('#gate-error').textContent = message;
    $('#confirm-wrap').classList.toggle('hidden', mode !== 'setup');
    $('#restore-from-gate').classList.toggle('hidden', mode !== 'unlock');
    $('#vault-password').autocomplete = mode === 'setup' ? 'new-password' : 'current-password';
    $('#vault-password-confirm').required = mode === 'setup';
    $('#password-label').textContent = mode === 'setup' ? 'Create a vault passphrase' : 'Vault passphrase';
    $('#vault-password').placeholder = mode === 'setup' ? 'At least 12 characters' : 'Enter your passphrase';
    $('#gate-title').textContent = mode === 'setup' ? 'A little more room to think.' : 'Welcome back to your space.';
    $('#gate-copy').textContent = mode === 'setup' ? 'Your captures stay on this device, protected by encryption.' : 'Enter your passphrase to decrypt your private vault on this device.';
    $('#gate-submit').innerHTML = mode === 'setup' ? 'Create private vault <span aria-hidden="true">→</span>' : 'Unlock my vault <span aria-hidden="true">→</span>';
    setTimeout(() => $('#vault-password').focus({ preventScroll: true }), 60);
  }

  function showLoading(title, copy, retry = false) {
    $('#gate-screen').classList.add('hidden');
    $('#workspace').classList.add('hidden');
    $('#bottom-nav').classList.add('hidden');
    $('#loading-screen').classList.remove('hidden');
    $('#loading-title').textContent = title;
    $('#loading-copy').textContent = copy;
    $('#retry-native').classList.toggle('hidden', !retry);
    $('#restore-native').classList.toggle('hidden', !(nativeMode && retry));
  }

  function showWorkspace() {
    sessionOpen = true;
    $('#gate-screen').classList.add('hidden');
    $('#loading-screen').classList.add('hidden');
    $('#workspace').classList.remove('hidden');
    $('#bottom-nav').classList.remove('hidden');
    renderAll();
    setSaveLabel('Saved on this device');
    setTimeout(() => $('#capture-input')?.focus({ preventScroll: true }), 120);
    resetInactivityLock();
  }

  function setSaveLabel(text, error = false) {
    $('#save-label').textContent = text;
    $('#save-indicator').style.color = error ? '#b65d47' : '';
    const dot = $('.status-dot', $('#save-indicator'));
    if (dot) dot.style.background = error ? '#bb6b4f' : (text === 'Saving…' ? '#d5a16b' : '#87a95e');
  }

  function showToast(message, type = 'ok') {
    const toast = document.createElement('div');
    toast.className = `toast${type === 'error' ? ' error' : ''}`;
    toast.innerHTML = `<span class="toast-mark">${type === 'error' ? '!' : '✓'}</span><span>${html(message)}</span>`;
    $('#toast-root').appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateY(4px)'; setTimeout(() => toast.remove(), 200); }, 2700);
  }

  async function initPwa() {
    try {
      pwaRecord = await dbGet();
      if (pwaRecord) showGate('unlock'); else showGate('setup');
    } catch (error) {
      showGate('setup', error?.message || 'Could not open encrypted storage on this browser.');
    }
  }

  async function onGateSubmit(event) {
    event.preventDefault();
    const passphrase = $('#vault-password').value;
    const confirm = $('#vault-password-confirm').value;
    if (passphrase.length < 12) { $('#gate-error').textContent = 'Use at least 12 characters for a stronger passphrase.'; return; }
    $('#gate-submit').disabled = true;
    $('#gate-error').textContent = '';
    try {
      if (gateMode === 'setup') {
        if (passphrase !== confirm) throw new Error('Those passphrases do not match.');
        showLoading('Creating your private vault', 'Generating an encryption key on this device…');
        const salt = randomBytes(16);
        const key = await deriveKey(passphrase, salt);
        const state = freshState();
        const record = await makePwaRecord(state, key, salt);
        await dbPut(record);
        pwaKey = key;
        pwaRecord = record;
        appState = state;
        showWorkspace();
        showToast('Your private vault is ready.');
      } else {
        showLoading('Unlocking your private space', 'Decrypting your captures on this device…');
        const salt = base64ToBytes(pwaRecord.salt);
        const key = await deriveKey(passphrase, salt);
        let state;
        try { state = await decryptObject(pwaRecord, key); } catch { throw new Error('That passphrase did not unlock your vault.'); }
        pwaKey = key;
        appState = sanitizeState(state);
        showWorkspace();
      }
    } catch (error) {
      if ($('#loading-screen').classList.contains('hidden')) {
        $('#gate-error').textContent = error?.message || 'Could not unlock the vault.';
      } else {
        showGate(gateMode, error?.message || 'Could not unlock the vault.');
      }
    } finally {
      $('#gate-submit').disabled = false;
    }
  }

  function nativeLoad() {
    if (!nativeMode) return;
    currentNativeError = '';
    showLoading('Unlocking your private space', 'Confirm with your device authentication.');
    try { window.ThreadlineAndroid.loadVault(); }
    catch (error) { nativeFailed(error?.message || 'Device authentication could not start.'); }
  }

  function nativeLoaded(json) {
    try {
      const incoming = typeof json === 'string' ? JSON.parse(json) : json;
      appState = sanitizeState(incoming);
      currentNativeError = '';
      showWorkspace();
    } catch (error) {
      nativeFailed('The encrypted vault could not be read. Restore a backup if you have one.');
    }
  }

  function nativeFailed(message) {
    currentNativeError = String(message || 'Could not unlock the vault.');
    showLoading('Your vault is still locked', currentNativeError, true);
  }

  function nativeSaved(ok, message = '') {
    saveInProgress = false;
    if (ok) {
      setSaveLabel('Saved on this device');
    } else {
      setSaveLabel('Save needs attention', true);
      showToast(message || 'Could not save the vault. Try again.', 'error');
    }
  }

  function requestSave(immediate = false) {
    if (!sessionOpen) return;
    appState.updatedAt = new Date().toISOString();
    setSaveLabel('Saving…');
    clearTimeout(saveTimer);
    if (immediate) { void saveStateNow(); return; }
    saveTimer = setTimeout(() => { void saveStateNow(); }, 280);
  }

  async function saveStateNow() {
    if (!sessionOpen) return;
    const snapshot = JSON.stringify(appState);
    if (nativeMode) {
      saveInProgress = true;
      try { window.ThreadlineAndroid.writeVault(snapshot); }
      catch (error) { nativeSaved(false, error?.message); }
      return;
    }
    const keyForSave = pwaKey;
    const recordForSalt = pwaRecord;
    if (!keyForSave || !recordForSalt) return;
    saveQueue = saveQueue.then(async () => {
      const salt = base64ToBytes(recordForSalt.salt);
      const record = await makePwaRecord(JSON.parse(snapshot), keyForSave, salt);
      await dbPut(record);
      pwaRecord = record;
      if (sessionOpen) setSaveLabel('Saved on this device');
    }).catch(error => {
      setSaveLabel('Save needs attention', true);
      showToast(error?.message || 'Could not save your vault.', 'error');
    });
    await saveQueue;
  }

  function lockApp({ nativeRetry = false, background = false } = {}) {
    if (!sessionOpen && !nativeRetry) return;
    clearTimeout(saveTimer);
    // Every committed native mutation is sent immediately through the serial bridge.
    // Don't enqueue a second write while locking: it could trigger a duplicate device-auth prompt.
    if (sessionOpen && !nativeMode) void saveStateNow();
    sessionOpen = false;
    pwaKey = null;
    appState = freshState();
    pendingAttachment = null;
    stopRecordingSilently();
    $('#workspace').classList.add('hidden');
    $('#bottom-nav').classList.add('hidden');
    ['#next-actions', '#recent-captures', '#inbox-list', '#projects-list', '#project-detail', '#search-results'].forEach(selector => { const node = $(selector); if (node) node.replaceChildren(); });
    $('#search-input').value = '';
    $('#capture-input').value = '';
    $('#attachment-preview').classList.add('hidden');
    if (nativeMode) {
      if (background && !nativeRetry) showLoading('Your vault is locked', 'Return to Threadline and authenticate to continue.', true);
      else nativeLoad();
    } else {
      showGate('unlock');
    }
  }

  function resetInactivityLock() {
    clearTimeout(lastActivityTimer);
    lastActivityTimer = setTimeout(() => lockApp(), 10 * 60 * 1000);
  }

  function renderAll() {
    updateDateLabel();
    renderHome();
    renderInbox();
    renderProjects();
    renderSearch();
    renderSettings();
    updateActivePage();
  }

  function updateDateLabel() {
    const now = new Date();
    $('#today-date').textContent = now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase();
  }

  function isTask(entry) { return entry.kind === 'task'; }
  function visibleEntries() { return appState.entries.filter(entry => !entry.archived).sort((a, b) => newestFirst ? Date.parse(b.createdAt) - Date.parse(a.createdAt) : Date.parse(a.createdAt) - Date.parse(b.createdAt)); }
  function projectById(id) { return appState.projects.find(p => p.id === id) || null; }
  function openTasks() { return visibleEntries().filter(e => e.kind === 'task' && !e.done); }
  function dueDateFromText(text) {
    const lower = text.toLowerCase();
    const now = new Date();
    const day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (/\b(today|tonight|this evening)\b/.test(lower)) return toDateKey(day);
    if (/\b(tomorrow|tmrw|tmr)\b/.test(lower)) return toDateKey(addDays(day, 1));
    const weekdays = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
    const shortDays = ['sun','mon','tue','wed','thu','fri','sat'];
    let match = lower.match(/\b(?:by|on|this|next)?\s*(sunday|monday|tuesday|wednesday|thursday|friday|saturday|sun|mon|tue|tues|wed|weds|thu|thur|thurs|fri|sat)\b/);
    if (match) {
      const token = match[1];
      let target = weekdays.findIndex(w => w.startsWith(token));
      if (target < 0) target = shortDays.findIndex(w => w === token);
      if (target < 0) target = ({tues:2,weds:3,thur:4,thurs:4})[token] ?? -1;
      if (target >= 0) {
        let delta = (target - day.getDay() + 7) % 7;
        if (delta === 0) delta = 7;
        if (/\bnext\s+/.test(match[0])) delta += 7;
        return toDateKey(addDays(day, delta));
      }
    }
    match = text.match(/\b(20\d{2})-(0[1-9]|1[0-2])-([0-2]\d|3[01])\b/);
    if (match) return `${match[1]}-${match[2]}-${match[3]}`;
    return null;
  }

  function addDays(date, days) { const d = new Date(date); d.setDate(d.getDate() + days); return d; }
  function toDateKey(date) { return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; }
  function parseKind(text) {
    const trimmed = text.trim();
    if (/^(idea|idea:|what if|maybe we could|experiment:|concept:|thought:)/i.test(trimmed)) return 'idea';
    const due = dueDateFromText(trimmed);
    const first = trimmed.split(/[\n.!?]/)[0].toLowerCase().trim();
    const pattern = /^(?:(?:todo|to-do|task)\s*:?\s*|i need to\s+|need to\s+|i have to\s+|have to\s+|don't forget to\s+|dont forget to\s+|remember to\s+|follow[- ]?up(?:\s+with)?\s+|call\s+|email\s+|send\s+|reply to\s+|finish\s+|fix\s+|build\s+|book\s+|pay\s+|buy\s+|apply for\s+|schedule\s+|prepare\s+|submit\s+|pick up\s+|check\s+|ask\s+|contact\s+|investigate\s+|review\s+|write\s+|update\s+|create\s+|test\s+|ship\s+|deploy\s+|research\s+|look into\s+|talk to\s+|meet\s+|remind me to\s+)/i;
    if (pattern.test(first) || due || /\b(action item|next step|follow up|follow-up|i should|i must|i need|need a reminder)\b/i.test(trimmed)) return 'task';
    return 'note';
  }

  function kindLabel(kind) { return kind === 'task' ? 'Task' : kind === 'idea' ? 'Idea' : 'Note'; }

  function dueMeta(entry) {
    if (!entry.dueDate) return '';
    const due = new Date(`${entry.dueDate}T12:00:00`);
    if (!Number.isFinite(due.getTime())) return '';
    const today = toDateKey(new Date());
    const tomorrow = toDateKey(addDays(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()), 1));
    const label = entry.dueDate === today ? 'Today' : entry.dueDate === tomorrow ? 'Tomorrow' : due.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const overdue = entry.dueDate < today && !entry.done;
    return `<span class="due-label${overdue ? ' overdue' : ''}">${overdue ? 'Overdue · ' : 'Due · '}${html(label)}</span>`;
  }

  function attachmentMarkup(entry) {
    const a = entry.attachment;
    if (!a) return '';
    const safeData = a.data;
    const label = html(a.name || 'Attachment');
    const icon = a.mime.startsWith('image/') ? '▧' : a.mime.startsWith('audio/') ? '♫' : '↗';
    if (a.mime.startsWith('image/')) return `<a class="entry-attachment" href="${safeData}" download="${label}" data-action="open-attachment" target="_blank" rel="noopener"><span>▧</span><span>${label}</span><span>Open</span></a>`;
    return `<a class="entry-attachment" href="${safeData}" download="${label}" data-action="open-attachment" target="_blank" rel="noopener"><span>${icon}</span><span>${label}</span><span>Open</span></a>`;
  }

  function renderEntry(entry, compact = false) {
    const project = projectById(entry.projectId);
    const checked = entry.kind === 'task' && entry.done;
    const checkbox = entry.kind === 'task' ? `<button class="entry-check${checked ? ' done' : ''}" data-action="toggle" data-id="${html(entry.id)}" aria-label="${checked ? 'Mark as open' : 'Mark complete'}"><svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg></button>` : `<span class="entry-check" style="border-color:transparent;background:#f0f3e9;color:#849671"><svg viewBox="0 0 24 24" style="opacity:1;width:11px;height:11px"><path d="M12 4v16M4 12h16"/></svg></span>`;
    const kindChip = `<span class="type-chip ${html(entry.kind)}${checked ? ' done' : ''}">${checked ? 'Done' : kindLabel(entry.kind)}</span>`;
    const projectChip = project ? `<span class="entry-project">${html(project.emoji)} ${html(project.name)}</span>` : '';
    const actions = compact ? '' : `<div class="entry-actions"><button class="entry-action" data-action="edit" data-id="${html(entry.id)}" title="Edit capture" aria-label="Edit capture"><svg viewBox="0 0 24 24"><path d="m14 5 5 5M4 20l4-.8L19.2 8a2.1 2.1 0 0 0-3-3L5 16.2z"/></svg></button><button class="entry-action" data-action="more" data-id="${html(entry.id)}" title="More actions" aria-label="More actions"><svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg></button></div>`;
    const date = new Date(entry.createdAt);
    const dateText = Number.isFinite(date.getTime()) ? date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '';
    return `<article class="entry-card" data-entry-card="${html(entry.id)}">${checkbox}<div class="entry-main"><p class="entry-text${checked ? ' done-text' : ''}">${html(entry.text)}</p><div class="entry-meta">${kindChip}<span class="entry-date">${html(dateText)}</span>${dueMeta(entry)}${projectChip}</div>${attachmentMarkup(entry)}</div>${actions}</article>`;
  }

  function emptyState(icon, title, copy, buttonText = '', action = '') {
    return `<div class="empty-state"><span class="empty-icon">${icon}</span><h3>${html(title)}</h3><p>${html(copy)}</p>${buttonText ? `<button class="button button-secondary" data-action="${html(action)}" style="margin-top:15px">${html(buttonText)}</button>` : ''}</div>`;
  }

  function renderHome() {
    const tasks = openTasks().sort((a, b) => {
      if (a.dueDate && b.dueDate) return a.dueDate.localeCompare(b.dueDate) || b.createdAt.localeCompare(a.createdAt);
      if (a.dueDate) return -1;
      if (b.dueDate) return 1;
      return b.createdAt.localeCompare(a.createdAt);
    }).slice(0, 3);
    $('#next-actions').innerHTML = tasks.length ? tasks.map(e => renderEntry(e, true)).join('') : emptyState('<svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/><circle cx="12" cy="12" r="10"/></svg>', 'Nothing urgent is waiting.', 'That space is yours. Capture a next step whenever one appears.');
    const recent = visibleEntries().slice(0, 3);
    $('#recent-captures').innerHTML = recent.length ? recent.map(e => renderEntry(e, true)).join('') : emptyState('<svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18"/></svg>', 'Start with one thought.', 'A message to send, something to build, or a thought you do not want to lose.');
    $('#nav-inbox-dot').classList.toggle('hidden', openTasks().length === 0);
  }

  function renderInbox() {
    const active = visibleEntries();
    let filtered = active;
    if (inboxFilter === 'open') filtered = active.filter(e => e.kind === 'task' && !e.done);
    if (inboxFilter === 'tasks') filtered = active.filter(e => e.kind === 'task');
    if (inboxFilter === 'notes') filtered = active.filter(e => e.kind !== 'task');
    $('#inbox-count').textContent = `${active.length} ${active.length === 1 ? 'item' : 'items'}`;
    $$('#inbox-filters .segment').forEach(button => button.classList.toggle('active', button.dataset.filter === inboxFilter));
    $('#inbox-list').innerHTML = filtered.length ? filtered.map(e => renderEntry(e)).join('') : emptyState('<svg viewBox="0 0 24 24"><path d="M4 4.5h16v15H4z"/><path d="M4 13h4l1.5 2h5L16 13h4"/></svg>', inboxFilter === 'open' ? 'No open tasks.' : inboxFilter === 'tasks' ? 'No tasks yet.' : inboxFilter === 'notes' ? 'No notes or ideas yet.' : 'Your inbox is clear.', inboxFilter === 'open' ? 'A clear list is a good thing. Keep capturing as life happens.' : 'Capture something on the Today tab. It will be waiting here when you are ready.');
  }

  function renderProjects() {
    const entries = visibleEntries();
    $('#projects-list').innerHTML = appState.projects.length ? appState.projects.map(project => {
      const count = entries.filter(e => e.projectId === project.id).length;
      const open = entries.filter(e => e.projectId === project.id && e.kind === 'task' && !e.done).length;
      return `<button type="button" class="project-card" data-action="open-project" data-id="${html(project.id)}"><span class="project-emoji">${html(project.emoji)}</span><span class="project-title">${html(project.name)}</span><span class="project-count">${count} ${count === 1 ? 'item' : 'items'}${open ? ` · ${open} open` : ''}</span><span class="project-arrow">↗</span></button>`;
    }).join('') : emptyState('<svg viewBox="0 0 24 24"><path d="M3 7.5h7l2 2H21v10H3z"/><path d="M3 7.5v-2h7l2 2"/></svg>', 'Give your work a home.', 'Create a project when a set of ideas or next steps needs a little context.', 'Create a project', 'new-project');
    const detail = $('#project-detail');
    if (!activeProjectId) { detail.classList.add('hidden'); detail.innerHTML = ''; return; }
    const p = projectById(activeProjectId);
    if (!p) { activeProjectId = null; detail.classList.add('hidden'); return; }
    const linked = entries.filter(e => e.projectId === p.id);
    detail.classList.remove('hidden');
    detail.innerHTML = `<div class="project-detail-head"><div><h2>${html(p.emoji)} ${html(p.name)}</h2><p>${html(p.description || 'A little context for this thread.')}</p></div><div class="project-detail-actions"><button class="button button-secondary small-button" data-action="edit-project" data-id="${html(p.id)}">Edit</button><button class="button button-secondary small-button" data-action="close-project">Close</button></div></div><button class="button button-primary small-button" data-action="capture-to-project" data-id="${html(p.id)}" style="margin-bottom:13px">＋ Capture for this project</button><div class="entry-list">${linked.length ? linked.map(e => renderEntry(e)).join('') : '<p class="welcome-subtitle">Nothing linked to this project yet.</p>'}</div>`;
  }

  function renderSearch() {
    const input = $('#search-input');
    if (!input) return;
    const term = input.value.trim().toLowerCase();
    $('#clear-search').classList.toggle('hidden', !term);
    if (!term) {
      $('#search-meta').textContent = 'Everything stays on this device.';
      $('#search-results').innerHTML = emptyState('<svg viewBox="0 0 24 24"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.2 4.2"/></svg>', 'Find the thread again.', 'Search for a project, a phrase in a note, or a next step.');
      return;
    }
    const results = visibleEntries().filter(e => {
      const project = projectById(e.projectId);
      return e.text.toLowerCase().includes(term) || (e.attachment?.name || '').toLowerCase().includes(term) || (project?.name || '').toLowerCase().includes(term);
    }).slice(0, 100);
    const matchingProjects = appState.projects.filter(p => p.name.toLowerCase().includes(term));
    $('#search-meta').textContent = `${results.length} ${results.length === 1 ? 'capture' : 'captures'} found${matchingProjects.length ? ` · ${matchingProjects.length} projects` : ''}`;
    let htmlContent = results.length ? results.map(e => renderEntry(e)).join('') : emptyState('<svg viewBox="0 0 24 24"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.2 4.2"/></svg>', 'No matches yet.', 'Try fewer words or another phrase.');
    if (matchingProjects.length) htmlContent = `<div class="projects-grid" style="margin-bottom:12px">${matchingProjects.map(p => `<button class="project-card" data-action="open-project" data-id="${html(p.id)}"><span class="project-emoji">${html(p.emoji)}</span><span class="project-title">${html(p.name)}</span><span class="project-count">Project</span></button>`).join('')}</div>` + htmlContent;
    $('#search-results').innerHTML = htmlContent;
  }

  function renderSettings() {
    $('#storage-mode-copy').textContent = nativeMode ? 'Android Keystore + AES-GCM' : 'Passphrase + AES-GCM (256-bit)';
    $('#vault-status-copy').textContent = nativeMode ? 'Device authentication required to unlock' : 'Encrypted while stored; key held in memory while unlocked';
    const attachmentCount = appState.entries.filter(e => e.attachment).length;
    $('#data-footprint').textContent = `${appState.entries.length} captures · ${appState.projects.length} projects${attachmentCount ? ` · ${attachmentCount} attachments` : ''}`;
  }

  function updateActivePage() {
    $$('.page').forEach(page => page.classList.toggle('active', page.dataset.page === activePage));
    $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.nav === activePage));
    if (activePage === 'home') renderHome();
    if (activePage === 'inbox') renderInbox();
    if (activePage === 'projects') renderProjects();
    if (activePage === 'search') renderSearch();
    if (activePage === 'settings') renderSettings();
  }

  function navigate(page) {
    if (!['home', 'inbox', 'projects', 'search', 'settings'].includes(page)) return;
    activePage = page;
    updateActivePage();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function updateDetection() {
    const text = $('#capture-input').value.trim();
    const hint = $('#capture-detection');
    if (!text) { hint.classList.add('hidden'); return; }
    const inferred = parseKind(text);
    if (inferred === 'task' || inferred === 'idea' || forceNote) {
      hint.classList.remove('hidden');
      if (forceNote) {
        $('#detection-copy').textContent = 'This will be kept as a note.';
        $('#detection-toggle').textContent = 'Use suggestion';
      } else {
        $('#detection-copy').textContent = inferred === 'task' ? 'This sounds like a next action.' : 'This looks like an idea worth keeping.';
        $('#detection-toggle').textContent = inferred === 'task' ? 'Save as note' : 'Save as note';
      }
    } else hint.classList.add('hidden');
  }

  function onDetectionToggle() {
    forceNote = !forceNote;
    updateDetection();
  }

  function totalAttachmentBytes() {
    return appState.entries.reduce((sum, entry) => sum + (entry.attachment?.size || 0), 0);
  }

  async function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('Could not read this file.'));
      reader.onabort = () => reject(new Error('File reading was cancelled.'));
      reader.readAsDataURL(file);
    });
  }

  async function prepareAttachment(file) {
    if (!file) return null;
    let usable = file;
    if (file.type.startsWith('image/') && file.size > 450_000 && typeof createImageBitmap === 'function') {
      try {
        const bitmap = await createImageBitmap(file);
        const scale = Math.min(1, 1400 / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        const ctx = canvas.getContext('2d', { alpha: false });
        ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        bitmap.close();
        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', .72));
        if (blob && blob.size < file.size) usable = new File([blob], `${file.name.replace(/\.[^.]+$/, '') || 'photo'}.jpg`, { type: 'image/jpeg', lastModified: Date.now() });
      } catch { /* Keep the original when the browser cannot resize the image. */ }
    }
    if (usable.size > MAX_ATTACHMENT_BYTES) throw new Error('Keep each attachment under 1.8 MB. Large photos are resized automatically when supported.');
    if (totalAttachmentBytes() + (pendingAttachment?.size || 0) + usable.size > MAX_TOTAL_ATTACHMENT_BYTES) throw new Error('This vault is approaching its 8 MB attachment limit. Export a backup or remove an old attachment first.');
    const mime = (usable.type || 'application/octet-stream').split(';')[0].toLowerCase();
    let data = await readFileAsDataUrl(usable);
    data = data.replace(/^data:[^,]*,/, `data:${mime};base64,`);
    return { name: usable.name || 'voice-note.webm', mime, data, size: usable.size };
  }

  function showAttachmentPreview() {
    const root = $('#attachment-preview');
    if (!pendingAttachment) { root.classList.add('hidden'); root.innerHTML = ''; return; }
    root.classList.remove('hidden');
    const icon = pendingAttachment.mime.startsWith('image/') ? '▧' : pendingAttachment.mime.startsWith('audio/') ? '♫' : '↗';
    root.innerHTML = `<span class="file-mark">${icon}</span><span class="file-name">${html(pendingAttachment.name)} <span style="color:#9aa193">· ${formatBytes(pendingAttachment.size)}</span></span><button class="remove-file" id="remove-attachment" type="button" aria-label="Remove attachment">×</button>`;
  }

  function formatBytes(size) {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(0)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  }

  async function chooseAttachment(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      pendingAttachment = await prepareAttachment(file);
      showAttachmentPreview();
      if (!$('#capture-input').value.trim()) $('#capture-input').focus();
      showToast('Attachment is ready to capture.');
    } catch (error) { showToast(error?.message || 'Could not attach that file.', 'error'); }
  }

  async function startRecording() {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      showToast('Voice recording is not available in this browser. Attach an audio file instead.', 'error');
      return;
    }
    try {
      recordStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 } });
      recordingChunks = [];
      const preferred = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].find(type => MediaRecorder.isTypeSupported?.(type));
      mediaRecorder = preferred ? new MediaRecorder(recordStream, { mimeType: preferred, audioBitsPerSecond: 48000 }) : new MediaRecorder(recordStream);
      mediaRecorder.ondataavailable = event => { if (event.data?.size) recordingChunks.push(event.data); };
      mediaRecorder.onerror = () => { stopRecordingSilently(); showToast('The recording stopped unexpectedly.', 'error'); };
      mediaRecorder.onstop = async () => {
        const blob = new Blob(recordingChunks, { type: mediaRecorder?.mimeType || 'audio/webm' });
        releaseRecordingStream();
        if (!blob.size) { showToast('The recording was empty. Try again.', 'error'); return; }
        const ext = blob.type.includes('mp4') ? 'm4a' : 'webm';
        try {
          const file = new File([blob], `voice-note-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.${ext}`, { type: blob.type || 'audio/webm' });
          pendingAttachment = await prepareAttachment(file);
          if (!$('#capture-input').value.trim()) $('#capture-input').placeholder = 'Add a note about this voice recording (optional)…';
          showAttachmentPreview();
          showToast('Voice note attached. Add context or capture it now.');
        } catch (error) { showToast(error?.message || 'Could not save this recording.', 'error'); }
      };
      mediaRecorder.start(400);
      recordingStartedAt = Date.now();
      $('#recording-panel').classList.remove('hidden');
      $('#record-button').disabled = true;
      updateRecordingClock();
      recordingInterval = setInterval(updateRecordingClock, 500);
      clearTimeout(recordingLimitTimeout);
      recordingLimitTimeout = setTimeout(() => { if (mediaRecorder?.state === 'recording') finishRecording(); }, 90 * 1000);
    } catch (error) {
      releaseRecordingStream();
      const message = error?.name === 'NotAllowedError' ? 'Microphone access was denied. You can still capture text or attach an audio file.' : 'Could not start voice recording on this device.';
      showToast(message, 'error');
    }
  }

  function updateRecordingClock() {
    const seconds = Math.floor((Date.now() - recordingStartedAt) / 1000);
    $('#recording-time').textContent = `Recording · ${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  }

  function finishRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    cleanupRecordingUi();
  }

  function stopRecordingSilently() {
    clearTimeout(recordingLimitTimeout);
    if (mediaRecorder) mediaRecorder.onstop = null;
    try { if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop(); } catch { /* ignored */ }
    recordingChunks = [];
    releaseRecordingStream();
    cleanupRecordingUi();
  }

  function releaseRecordingStream() {
    try { recordStream?.getTracks().forEach(track => track.stop()); } catch { /* ignored */ }
    recordStream = null;
  }

  function cleanupRecordingUi() {
    clearInterval(recordingInterval);
    clearTimeout(recordingLimitTimeout);
    recordingInterval = null;
    $('#recording-panel')?.classList.add('hidden');
    if ($('#record-button')) $('#record-button').disabled = false;
  }

  function captureEntry(event) {
    event.preventDefault();
    const text = $('#capture-input').value.trim();
    if (!text && !pendingAttachment) { $('#capture-input').focus(); return; }
    const inferred = text ? parseKind(text) : 'note';
    const kind = forceNote ? (inferred === 'task' ? 'note' : inferred === 'idea' ? 'note' : 'note') : inferred;
    const entry = {
      id: makeId(), text: text || (pendingAttachment?.mime.startsWith('audio/') ? 'Voice note' : pendingAttachment?.name || 'Attachment'),
      kind, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      dueDate: kind === 'task' ? dueDateFromText(text) : null,
      projectId: captureProjectId || (activePage === 'projects' ? activeProjectId : null),
      done: false, attachment: pendingAttachment, source: pendingAttachment?.mime.startsWith('audio/') ? 'voice' : pendingAttachment ? 'file' : 'text'
    };
    appState.entries.unshift(entry);
    appState.settings.captureCount = (appState.settings.captureCount || 0) + 1;
    $('#capture-input').value = '';
    $('#capture-input').placeholder = 'What\'s on your mind? Paste a message, dump a thought, note a next step…';
    pendingAttachment = null;
    captureProjectId = null;
    forceNote = false;
    showAttachmentPreview();
    updateDetection();
    requestSave(true);
    renderAll();
    navigate(activePage);
    showToast(kind === 'task' ? 'Captured as a next action.' : kind === 'idea' ? 'Idea saved privately.' : 'Saved to your inbox.');
    $('#capture-input').focus({ preventScroll: true });
  }

  function toggleTask(id) {
    const entry = appState.entries.find(e => e.id === id);
    if (!entry || entry.kind !== 'task') return;
    entry.done = !entry.done;
    entry.updatedAt = new Date().toISOString();
    requestSave(true);
    renderAll();
    showToast(entry.done ? 'One less thing to carry.' : 'Task reopened.');
  }

  function showModal(content) {
    $('#modal-root').innerHTML = `<div class="modal-backdrop" data-dismiss-modal><section class="modal" role="dialog" aria-modal="true">${content}</section></div>`;
    const modal = $('.modal', $('#modal-root'));
    $('.modal-backdrop', $('#modal-root'))?.addEventListener('click', event => { if (event.target === event.currentTarget) closeModal(); });
    setTimeout(() => $('input:not([type=file]),textarea,select,button', modal)?.focus({ preventScroll: true }), 60);
  }

  function closeModal() { $('#modal-root').innerHTML = ''; }

  function newProjectModal(project = null) {
    const editing = !!project;
    const p = project || { name: '', description: '', emoji: '✳' };
    showModal(`<div class="modal-close-row"><div><h2>${editing ? 'Edit project' : 'Start a project'}</h2><p>${editing ? 'Change the name or context.' : 'Keep related thoughts and actions connected.'}</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="project-form"><label for="project-name">Project name</label><input id="project-name" maxlength="100" value="${html(p.name)}" placeholder="e.g. Troy, Job search, Personal site" required><label for="project-description">Context (optional)</label><textarea id="project-description" maxlength="500" rows="2" placeholder="What is this project trying to do?">${html(p.description || '')}</textarea><label for="project-emoji">Marker</label><select id="project-emoji"><option value="✳" ${p.emoji === '✳' ? 'selected' : ''}>✳  Idea / general</option><option value="⌘" ${p.emoji === '⌘' ? 'selected' : ''}>⌘  Software / systems</option><option value="↗" ${p.emoji === '↗' ? 'selected' : ''}>↗  Work / growth</option><option value="◇" ${p.emoji === '◇' ? 'selected' : ''}>◇  Personal</option><option value="⚙" ${p.emoji === '⚙' ? 'selected' : ''}>⚙  Build / operations</option><option value="▤" ${p.emoji === '▤' ? 'selected' : ''}>▤  Research</option><option value="✦" ${p.emoji === '✦' ? 'selected' : ''}>✦  Creative</option></select><p id="project-error" class="form-error" role="alert"></p><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button type="submit" class="button button-primary">${editing ? 'Save changes' : 'Create project'}</button></div></form>`);
    $('#project-form').addEventListener('submit', event => {
      event.preventDefault();
      const name = $('#project-name').value.trim();
      if (!name) { $('#project-error').textContent = 'Give your project a name.'; return; }
      if (appState.projects.some(x => x.name.toLowerCase() === name.toLowerCase() && x.id !== project?.id)) { $('#project-error').textContent = 'You already have a project with that name.'; return; }
      if (editing) {
        project.name = name; project.description = $('#project-description').value.trim(); project.emoji = $('#project-emoji').value;
        project.updatedAt = new Date().toISOString();
      } else {
        const created = { id: makeId(), name, description: $('#project-description').value.trim(), emoji: $('#project-emoji').value, createdAt: new Date().toISOString() };
        appState.projects.push(created); activeProjectId = created.id;
      }
      requestSave(true); closeModal(); renderAll(); navigate('projects'); showToast(editing ? 'Project updated.' : 'Project created.');
    });
  }

  function editEntryModal(entry) {
    const linkedId = entry.projectId || '';
    showModal(`<div class="modal-close-row"><div><h2>Edit capture</h2><p>Make it clearer now; you can change it again later.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="entry-edit-form"><label for="edit-entry-text">Your capture</label><textarea id="edit-entry-text" maxlength="6000" required>${html(entry.text)}</textarea><label for="edit-entry-kind">Type</label><select id="edit-entry-kind"><option value="task" ${entry.kind === 'task' ? 'selected' : ''}>Next action</option><option value="note" ${entry.kind === 'note' ? 'selected' : ''}>Note</option><option value="idea" ${entry.kind === 'idea' ? 'selected' : ''}>Idea</option></select><label for="edit-entry-due">Due date (optional)</label><input id="edit-entry-due" type="date" value="${html(entry.dueDate || '')}"><label for="edit-entry-project">Project</label><select id="edit-entry-project"><option value="">No project</option>${appState.projects.map(p => `<option value="${html(p.id)}" ${linkedId === p.id ? 'selected' : ''}>${html(p.emoji)} ${html(p.name)}</option>`).join('')}</select><p id="edit-entry-error" class="form-error" role="alert"></p><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button type="submit" class="button button-primary">Save</button></div></form>`);
    $('#entry-edit-form').addEventListener('submit', event => {
      event.preventDefault();
      const text = $('#edit-entry-text').value.trim();
      if (!text && !entry.attachment) { $('#edit-entry-error').textContent = 'Add a little text or keep the attachment.'; return; }
      const due = $('#edit-entry-due').value || null;
      if (due && !/^\d{4}-\d{2}-\d{2}$/.test(due)) { $('#edit-entry-error').textContent = 'Choose a valid due date.'; return; }
      entry.text = text || entry.attachment.name; entry.kind = $('#edit-entry-kind').value; entry.dueDate = entry.kind === 'task' ? due : null;
      entry.done = entry.kind === 'task' ? entry.done : false;
      entry.projectId = $('#edit-entry-project').value || null; entry.updatedAt = new Date().toISOString();
      requestSave(true); closeModal(); renderAll(); showToast('Capture updated.');
    });
  }

  function entryActionsModal(entry) {
    const hasProjects = appState.projects.length > 0;
    showModal(`<div class="modal-close-row"><div><h2>Capture actions</h2><p>Keep the useful bit, change the shape, or remove it.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><div class="entry-action-menu"><button class="button button-secondary" data-action="edit-from-menu" data-id="${html(entry.id)}" style="width:100%;justify-content:flex-start;margin-bottom:8px">✎ Edit text, type, date, or project</button><button class="button button-secondary" data-action="convert-entry" data-id="${html(entry.id)}" style="width:100%;justify-content:flex-start;margin-bottom:8px">↗ ${entry.kind === 'task' ? 'Keep as a note' : 'Turn into a next action'}</button>${hasProjects ? `<button class="button button-secondary" data-action="assign-project" data-id="${html(entry.id)}" style="width:100%;justify-content:flex-start;margin-bottom:8px">◇ Move to a project</button>` : ''}<button class="button button-secondary" data-action="delete-entry" data-id="${html(entry.id)}" style="width:100%;justify-content:flex-start;color:#b26049">⌫ Delete capture</button></div>`);
  }

  function assignProjectModal(entry) {
    showModal(`<div class="modal-close-row"><div><h2>Connect to a project</h2><p>Give this capture a little context.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="assign-project-form"><label for="assign-project">Project</label><select id="assign-project"><option value="">No project</option>${appState.projects.map(p => `<option value="${html(p.id)}" ${entry.projectId === p.id ? 'selected' : ''}>${html(p.emoji)} ${html(p.name)}</option>`).join('')}</select><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button type="submit" class="button button-primary">Save</button></div></form>`);
    $('#assign-project-form').addEventListener('submit', event => { event.preventDefault(); entry.projectId = $('#assign-project').value || null; entry.updatedAt = new Date().toISOString(); requestSave(true); closeModal(); renderAll(); showToast('Project connection updated.'); });
  }

  function convertEntry(entry) {
    if (entry.kind === 'task') { entry.kind = 'note'; entry.done = false; entry.dueDate = null; }
    else { entry.kind = 'task'; entry.done = false; if (!entry.dueDate) entry.dueDate = dueDateFromText(entry.text); }
    entry.updatedAt = new Date().toISOString(); requestSave(true); closeModal(); renderAll(); showToast(entry.kind === 'task' ? 'Added to your next actions.' : 'Kept as a note.');
  }

  function deleteEntry(entry) {
    showModal(`<div class="modal-close-row"><div><h2>Delete this capture?</h2><p>This removes it from the encrypted vault. There is no trash folder.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><div class="modal-note">${html(entry.text.slice(0, 220))}${entry.text.length > 220 ? '…' : ''}</div><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Keep it</button><button type="button" class="button button-primary" data-action="confirm-delete-entry" data-id="${html(entry.id)}" style="background:#f4e6df;border-color:#e6cfc3;color:#994f3a">Delete</button></div>`);
  }

  function deleteProject(project) {
    showModal(`<div class="modal-close-row"><div><h2>Remove this project?</h2><p>Its captures will stay safe in your inbox; they will just be unlinked.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><div class="modal-note">${html(project.emoji)} ${html(project.name)}</div><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Keep project</button><button type="button" class="button button-primary" data-action="confirm-delete-project" data-id="${html(project.id)}" style="background:#f4e6df;border-color:#e6cfc3;color:#994f3a">Remove</button></div>`);
  }

  function showExportModal() {
    showModal(`<div class="modal-close-row"><div><h2>Export encrypted backup</h2><p>Your backup is portable and protected by a separate passphrase.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="export-form"><label for="backup-password">Backup passphrase</label><input id="backup-password" type="password" minlength="12" autocomplete="new-password" placeholder="At least 12 characters" required><label for="backup-password-confirm">Confirm backup passphrase</label><input id="backup-password-confirm" type="password" minlength="12" autocomplete="new-password" placeholder="Enter it again" required><p id="backup-error" class="form-error" role="alert"></p><p class="modal-note">The file contains encrypted data, not a readable copy of your captures. Keep the passphrase somewhere separate and safe.</p><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button id="backup-create" type="submit" class="button button-primary">Create backup</button></div></form>`);
    $('#export-form').addEventListener('submit', async event => {
      event.preventDefault();
      const pass = $('#backup-password').value;
      if (pass.length < 12) { $('#backup-error').textContent = 'Use at least 12 characters.'; return; }
      if (pass !== $('#backup-password-confirm').value) { $('#backup-error').textContent = 'Those passphrases do not match.'; return; }
      $('#backup-create').disabled = true; $('#backup-create').textContent = 'Encrypting…';
      try {
        const backup = await createBackup(appState, pass);
        const payload = JSON.stringify(backup);
        if (nativeMode) window.ThreadlineAndroid.exportBackup(payload);
        else {
          const blob = new Blob([payload], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a'); link.href = url; link.download = `threadline-backup-${toDateKey(new Date())}.threadline`;
          document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1200);
        }
        closeModal(); showToast('Encrypted backup created.');
      } catch (error) {
        $('#backup-error').textContent = error?.message || 'Could not create the backup.';
        $('#backup-create').disabled = false; $('#backup-create').textContent = 'Create backup';
      }
    });
  }

  async function createBackup(state, passphrase) {
    const salt = randomBytes(16);
    const key = await deriveKey(passphrase, salt);
    const encrypted = await encryptObject(sanitizeState(state), key);
    return { format: BACKUP_FORMAT, createdAt: new Date().toISOString(), kdf: { name: 'PBKDF2-SHA-256', iterations: PBKDF2_ITERATIONS, salt: bytesToBase64(salt) }, ...encrypted };
  }

  async function decryptBackup(backup, passphrase) {
    if (!backup || backup.format !== BACKUP_FORMAT || backup.kdf?.name !== 'PBKDF2-SHA-256' || !Number.isInteger(backup.kdf.iterations) || backup.kdf.iterations < 100000 || backup.kdf.iterations > 2_000_000) throw new Error('This is not a recognized Threadline backup file.');
    const salt = base64ToBytes(backup.kdf.salt);
    const key = await deriveKeyWithIterations(passphrase, salt, backup.kdf.iterations);
    let data;
    try { data = await decryptObject(backup, key); } catch { throw new Error('That backup passphrase is incorrect, or the file is damaged.'); }
    if (!data || !Array.isArray(data.entries) || !Array.isArray(data.projects)) throw new Error('The backup file does not contain a valid vault.');
    return sanitizeState(data);
  }

  async function deriveKeyWithIterations(passphrase, salt, iterations) {
    const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }

  function chooseBackup() { $('#backup-input').click(); }

  async function loadBackupFile(event) {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) { showToast('The backup is larger than the 20 MB safety limit.', 'error'); return; }
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      restoreDraft = { fileName: file.name, payload: parsed };
      showRestorePasswordModal();
    } catch { showToast('That file is not a valid backup JSON file.', 'error'); }
  }

  function showRestorePasswordModal() {
    showModal(`<div class="modal-close-row"><div><h2>Unlock the backup</h2><p>Enter the passphrase you used when exporting it.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="restore-form"><label for="restore-password">Backup passphrase</label><input id="restore-password" type="password" autocomplete="current-password" minlength="12" placeholder="Backup passphrase" required><p id="restore-error" class="form-error" role="alert"></p><p class="modal-note">File: ${html(restoreDraft?.fileName || 'Threadline backup')}</p><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button id="restore-check" type="submit" class="button button-primary">Verify backup</button></div></form>`);
    $('#restore-form').addEventListener('submit', async event => {
      event.preventDefault(); $('#restore-check').disabled = true; $('#restore-check').textContent = 'Verifying…';
      try {
        const imported = await decryptBackup(restoreDraft.payload, $('#restore-password').value);
        closeModal(); showRestoreConfirmModal(imported);
      } catch (error) { $('#restore-error').textContent = error?.message || 'Could not unlock the backup.'; $('#restore-check').disabled = false; $('#restore-check').textContent = 'Verify backup'; }
    });
  }

  function showRestoreConfirmModal(importedState) {
    const lockedRecovery = !sessionOpen;
    showModal(`<div class="modal-close-row"><div><h2>${lockedRecovery ? 'Recover this vault?' : 'Replace this vault?'}</h2><p>The verified backup contains ${importedState.entries.length} captures and ${importedState.projects.length} projects.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><p class="modal-note">${lockedRecovery ? 'The current vault is locked. This verified backup will replace it; keep the backup file and its passphrase safe.' : 'This replaces the current local vault. Export a backup of the current data first if you need to keep it.'}</p><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button type="button" id="confirm-restore" class="button button-primary">${lockedRecovery ? 'Recover vault' : 'Replace vault'}</button></div>`);
    $('#confirm-restore').addEventListener('click', async () => {
      $('#confirm-restore').disabled = true; $('#confirm-restore').textContent = 'Restoring…';
      const sanitized = sanitizeState(importedState);
      if (!sessionOpen && !nativeMode) {
        closeModal();
        showNewVaultPassphraseModal(sanitized);
        return;
      }
      if (!sessionOpen && nativeMode) {
        closeModal();
        showLoading('Restoring your private vault', 'Authenticate to create a new protected vault from the verified backup.');
        window.ThreadlineAndroid.replaceVaultWithBackup(JSON.stringify(sanitized));
        window.__threadlinePendingRestore = sanitized;
        return;
      }
      try {
        appState = sanitized;
        if (nativeMode) {
          await new Promise((resolve, reject) => {
            let completed = false;
            const old = window.ThreadlineNative?.onVaultSaved;
            window.ThreadlineNative.onVaultSaved = (ok, message) => {
              if (completed) return; completed = true; window.ThreadlineNative.onVaultSaved = old;
              if (ok) resolve(); else reject(new Error(message || 'Could not restore the vault.'));
            };
            window.ThreadlineAndroid.writeVault(JSON.stringify(appState));
            setTimeout(() => { if (!completed) { completed = true; window.ThreadlineNative.onVaultSaved = old; reject(new Error('The restore save did not finish. Try again.')); } }, 15000);
          });
        } else {
          requestSave(true);
          await saveQueue;
        }
        restoreDraft = null; closeModal(); renderAll(); showToast('Backup restored successfully.');
      } catch (error) { $('#confirm-restore').disabled = false; $('#confirm-restore').textContent = 'Replace vault'; showToast(error?.message || 'Could not restore the backup.', 'error'); }
    });
  }

  function showNewVaultPassphraseModal(importedState) {
    showModal(`<div class="modal-close-row"><div><h2>Protect the restored vault</h2><p>The backup is verified. Create a new passphrase for this browser on this device.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div><form id="new-vault-pass-form"><label for="new-vault-pass">New vault passphrase</label><input id="new-vault-pass" type="password" minlength="12" autocomplete="new-password" placeholder="At least 12 characters" required><label for="new-vault-pass-confirm">Confirm passphrase</label><input id="new-vault-pass-confirm" type="password" minlength="12" autocomplete="new-password" placeholder="Enter it again" required><p id="new-vault-pass-error" class="form-error" role="alert"></p><p class="modal-note">This passphrase protects the restored local vault. It is separate from the backup passphrase.</p><div class="modal-buttons"><button type="button" class="button button-secondary" data-action="close-modal">Cancel</button><button id="new-vault-pass-submit" type="submit" class="button button-primary">Protect and restore</button></div></form>`);
    $('#new-vault-pass-form').addEventListener('submit', async event => {
      event.preventDefault();
      const passphrase = $('#new-vault-pass').value;
      if (passphrase.length < 12) { $('#new-vault-pass-error').textContent = 'Use at least 12 characters.'; return; }
      if (passphrase !== $('#new-vault-pass-confirm').value) { $('#new-vault-pass-error').textContent = 'Those passphrases do not match.'; return; }
      $('#new-vault-pass-submit').disabled = true; $('#new-vault-pass-submit').textContent = 'Encrypting…';
      try {
        const salt = randomBytes(16);
        const key = await deriveKey(passphrase, salt);
        const record = await makePwaRecord(importedState, key, salt);
        await dbPut(record);
        pwaKey = key; pwaRecord = record; appState = sanitizeState(importedState); restoreDraft = null;
        closeModal(); showWorkspace(); showToast('Backup restored and protected with your new passphrase.');
      } catch (error) {
        $('#new-vault-pass-error').textContent = error?.message || 'Could not protect the restored vault.';
        $('#new-vault-pass-submit').disabled = false; $('#new-vault-pass-submit').textContent = 'Protect and restore';
      }
    });
  }

  function handleClick(event) {
    const nav = event.target.closest('[data-nav]');
    if (nav) { navigate(nav.dataset.nav); return; }
    const go = event.target.closest('[data-go]');
    if (go) { navigate(go.dataset.go); return; }
    const actionElement = event.target.closest('[data-action]');
    if (!actionElement) return;
    const { action, id } = actionElement.dataset;
    if (action === 'open-attachment') {
      if (nativeMode) {
        event.preventDefault();
        if (typeof window.ThreadlineAndroid.exportAttachment !== 'function') showToast('Attachment export is unavailable in this build.', 'error');
        else window.ThreadlineAndroid.exportAttachment(actionElement.getAttribute('href'), actionElement.getAttribute('download'));
      }
      return;
    }
    if (action === 'toggle') { toggleTask(id); return; }
    if (action === 'edit') { const e = appState.entries.find(x => x.id === id); if (e) editEntryModal(e); return; }
    if (action === 'more') { const e = appState.entries.find(x => x.id === id); if (e) entryActionsModal(e); return; }
    if (action === 'open-project') { activeProjectId = id; navigate('projects'); return; }
    if (action === 'new-project') { newProjectModal(); return; }
    if (action === 'edit-project') { const p = projectById(id); if (p) newProjectModal(p); return; }
    if (action === 'close-project') { activeProjectId = null; renderProjects(); return; }
    if (action === 'close-modal') { closeModal(); return; }
    if (action === 'edit-from-menu') { const e = appState.entries.find(x => x.id === id); if (e) editEntryModal(e); return; }
    if (action === 'convert-entry') { const e = appState.entries.find(x => x.id === id); if (e) convertEntry(e); return; }
    if (action === 'assign-project') { const e = appState.entries.find(x => x.id === id); if (e) assignProjectModal(e); return; }
    if (action === 'delete-entry') { const e = appState.entries.find(x => x.id === id); if (e) deleteEntry(e); return; }
    if (action === 'confirm-delete-entry') {
      appState.entries = appState.entries.filter(x => x.id !== id); requestSave(true); closeModal(); renderAll(); showToast('Capture deleted.'); return;
    }
    if (action === 'confirm-delete-project') {
      appState.entries.forEach(e => { if (e.projectId === id) e.projectId = null; });
      appState.projects = appState.projects.filter(p => p.id !== id); if (activeProjectId === id) activeProjectId = null;
      requestSave(true); closeModal(); renderAll(); showToast('Project removed; captures kept.'); return;
    }
    if (action === 'capture-to-project') {
      activeProjectId = id; captureProjectId = id; navigate('home'); $('#capture-input').focus({ preventScroll: true }); showToast('Your next capture will link to this project.'); return;
    }
  }

  function refreshActivity() {
    if (!sessionOpen) return;
    resetInactivityLock();
  }

  function initializeEvents() {
    $('#gate-form').addEventListener('submit', onGateSubmit);
    $('#capture-form').addEventListener('submit', captureEntry);
    $('#capture-input').addEventListener('input', updateDetection);
    $('#capture-input').addEventListener('keydown', event => { if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); $('#capture-form').requestSubmit(); } });
    $('#detection-toggle').addEventListener('click', onDetectionToggle);
    $('#attach-button').addEventListener('click', () => $('#attachment-input').click());
    $('#attachment-input').addEventListener('change', chooseAttachment);
    $('#record-button').addEventListener('click', startRecording);
    $('#stop-recording').addEventListener('click', finishRecording);
    $('#cancel-recording').addEventListener('click', stopRecordingSilently);
    $('#attachment-preview').addEventListener('click', event => { if (event.target.closest('#remove-attachment')) { pendingAttachment = null; showAttachmentPreview(); } });
    $('#add-project-button').addEventListener('click', () => newProjectModal());
    $('#inbox-filters').addEventListener('click', event => { const button = event.target.closest('[data-filter]'); if (!button) return; inboxFilter = button.dataset.filter; renderInbox(); });
    $('#sort-button').addEventListener('click', () => { newestFirst = !newestFirst; $('#sort-button').title = newestFirst ? 'Sort newest first' : 'Sort oldest first'; renderAll(); });
    $('#search-input').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(renderSearch, 100); });
    $('#clear-search').addEventListener('click', () => { $('#search-input').value = ''; renderSearch(); $('#search-input').focus(); });
    $('#export-button').addEventListener('click', showExportModal);
    $('#import-button').addEventListener('click', chooseBackup);
    $('#backup-input').addEventListener('change', loadBackupFile);
    $('#lock-button').addEventListener('click', () => lockApp());
    $('#settings-lock-button').addEventListener('click', () => lockApp());
    $('#retry-native').addEventListener('click', nativeLoad);
    $('#restore-native').addEventListener('click', chooseBackup);
    $('#restore-from-gate').addEventListener('click', chooseBackup);
    $('#modal-root').addEventListener('click', handleClick);
    $('#bottom-nav').addEventListener('click', handleClick);
    $('#main-content').addEventListener('click', handleClick);
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && $('#modal-root').innerHTML.trim().length > 0) closeModal(); });
    document.addEventListener('pointerdown', refreshActivity, { passive: true });
    document.addEventListener('keydown', refreshActivity);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden' && sessionOpen) {
        clearTimeout(hiddenLockTimer);
        hiddenLockTimer = setTimeout(() => { if (document.visibilityState === 'hidden') lockApp({ background: true }); }, 3 * 60 * 1000);
      } else if (document.visibilityState === 'visible') {
        clearTimeout(hiddenLockTimer);
        if (sessionOpen) resetInactivityLock();
      }
    });
    window.addEventListener('beforeunload', () => { if (sessionOpen && !nativeMode) void saveStateNow(); });
  }

  // Called by MainActivity after biometric/device-credential verification and disk I/O.
  window.ThreadlineNative = {
    onVaultLoaded: nativeLoaded,
    onVaultError: nativeFailed,
    onVaultSaved: nativeSaved,
    onVaultExported: (ok, message) => { if (ok) showToast('Encrypted backup saved.'); else showToast(message || 'Backup export was cancelled.', 'error'); },
    onAttachmentExported: (ok, message) => { if (ok) showToast('Attachment exported.'); else showToast(message || 'Attachment export was cancelled.', 'error'); },
    onVaultReplaced: (ok, message) => {
      if (!ok) { nativeFailed(message || 'Could not restore the encrypted vault.'); return; }
      appState = sanitizeState(window.__threadlinePendingRestore || freshState());
      window.__threadlinePendingRestore = null; restoreDraft = null; showWorkspace(); showToast('Backup restored into a new protected vault.');
    }
  };
  window.ThreadlineUI = {
    lockFromNative: () => lockApp({ background: true }),
    resumeFromNative: () => { if (nativeMode && !sessionOpen) nativeLoad(); },
    isOpen: () => sessionOpen
  };

  initializeEvents();
  if (nativeMode) nativeLoad(); else {
    void initPwa();
    if ('serviceWorker' in navigator && location.protocol !== 'file:') {
      window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
    }
  }
})();
