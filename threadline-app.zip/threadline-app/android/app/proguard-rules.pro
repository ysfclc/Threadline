# JavaScript interface methods are kept by Android's @JavascriptInterface annotation.
# This project currently ships an unminified release to keep web/native bridge behavior auditable.
