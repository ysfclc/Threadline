# Threadline 1.3.0 — verification report

## Performed in this environment

- ZIP archive will be rebuilt and checked with `unzip -t`.
- `Domain.kt` compiles with the available standalone Kotlin compiler (Kotlin 1.9). A custom smoke test passed capture, project creation, private Studio draft creation, explicit public-safe review, validation and deletion.
- MainActivity, PulseOrbView, AssistantModels, OnDeviceAi and StateCodec were passed through the Kotlin parser using `kotlinc`; no syntax/parse errors were reported. The standalone compiler cannot resolve Android/AndroidX/LiteRT-LM dependencies because this environment does not include the Android SDK or Gradle project dependencies.
- Reviewed the schema migration path: decoder accepts state schema 1 or 2, defaults missing `contentDrafts` to an empty array, and returns a schema 2 `ThreadState`; `SecureVault.readState()` detects an older schema and rewrites the migrated state after decryption; encoding writes schema 2.
- Reviewed the Studio privacy flow: new drafts default to `PRIVATE`; an explicit user confirmation is required to mark a draft `PUBLIC_SAFE`; no publication action exists.
- Ran all 14 existing/domain unit-test methods (`DomainTest` and `BackupCryptoTest`) using the standalone Kotlin compiler and a minimal local JUnit-compatible runner: 14 passed. This is not a substitute for the Android Gradle test task.

## Not verified

- Full Android Gradle compile, lint or unit-test execution.
- Device-level biometric unlock, overlay lifecycle, speech recognition, offline TTS, LiteRT-LM initialization, model switching or speed.
- Real migration of an existing encrypted v1 vault and backup restore on Android.
- Studio generation quality on the installed model, backgrounding while generation is in flight, clipboard behavior and large draft UI.
- Floating quick actions, daily nudge reliability, low-storage handling, memory pressure, thermal behavior, accessibility and battery usage on the target device.

## Required next gate

Run `gradle --no-daemon testDebugUnitTest lintDebug assembleDebug` in GitHub Actions. The workflow file inside this source archive uses Gradle 8.14.4, but uploading this ZIP as a single file does **not** replace the separate `.github/workflows/android.yml` already stored in the GitHub repository. If the repository's active workflow still installs Gradle 8.13, update that separate workflow to 8.14.4 as well.

Then test the APK on the actual phone:

1. Unlock the existing vault and confirm all old tasks, projects and reviews are still present.
2. Open Studio, create a private draft from typed source material, edit it, copy it, archive it, restore it and delete a test draft.
3. Close and reopen Threadline; confirm drafts persist.
4. Export an encrypted backup, restore it, and confirm both old records and Studio drafts survive.
5. Ask Talk to create a content draft; confirm it appears as a proposal and is saved only after approval.
6. Check offline voice with airplane mode enabled; document which speech/TTS provider actually works offline.
7. Enable the floating button, use Studio and Capture from another app, then disable it from the app and notification.
8. Test model latency with the small and larger model, including cold start and warm turns.

Do not label this a production release until the required gate and target-device tests pass.
