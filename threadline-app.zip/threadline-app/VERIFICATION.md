# Threadline 1.6.0 — verification report

## Source and resource checks performed in this environment

- Parsed all 12 Android XML resources and the manifest successfully.
- Confirmed the manifest declares the floating overlay and the opt-in screen-capture Accessibility service.
- Ran a Kotlin parser pass over the changed Kotlin files. No syntax/parser diagnostics were reported; Android/AndroidX/LiteRT-LM symbols cannot be resolved by the standalone compiler without the Android SDK and Gradle dependencies.
- Verified the model download configuration against the published LiteRT Community artifact metadata: Qwen3-1.7B INT4 is 977,184,032 bytes with SHA-256 `2a72330b504a6596d53a2c00923c57173b10f1b83e6a541213ffec08d1fc5de8`; Qwen3-4B Thinking `model.litertlm` is 2,477,192,112 bytes with SHA-256 `8a8a6a419a5570b3f4814d358fb795c0dcb6931206c7dae29480f47564c3f04d`.
- Reviewed the 4B model's context/output budget against the model card: bounded thinking plus 2,048 output tokens, smaller state context, RAM preflight and CPU fallback only when Android reports about 4.3 GB free RAM.
- Added rollback handling so a new model replaces the old model only after successful engine initialization; initialization failure attempts to restore the previous model and label.
- Added deterministic explicit task/project/reminder execution and optional off-by-default auto-apply for supported model proposals.
- Added an explicit-tap screenshot bridge, on-device OCR, overlay-only transformations and clipboard output. No passive screenshot collection is implemented.
- Reduced speech-triggered view rebuilds and preserved scroll position for same-tab renders.
- Rebuilt the source ZIP and verified archive integrity.

## Not verified here

- Full Android Gradle compile, lint and unit tests: no Android SDK/Gradle build environment is available in this session.
- Successful APK installation, Accessibility settings flow, screenshot behavior, secure-screen rejection, overlay focus/keyboard, or behavior across Android app switches.
- Runtime initialization of Qwen3-4B Thinking on the target phone, real available-memory behavior, GPU delegation, inference speed, thermal throttling or battery usage.
- Voice recognition/TTS providers and voice selection on the phone.
- Encrypted vault persistence, rollback under storage failure, or concurrent overlay/main-app generation on the physical device.
- Sustained 60fps, haptic quality, accessibility/TalkBack and all device lifecycle transitions.

## Required release gate

Run the repository's GitHub Actions workflow with `gradle --no-daemon testDebugUnitTest lintDebug assembleDebug`. Install the resulting `threadline-debug-apk` artifact and test on the actual phone before treating this as a verified release.

### Target-device test sequence

1. Verify the existing encrypted vault unlocks and old tasks/projects remain.
2. Download Qwen3-1.7B first and confirm normal chat works; only then try the 4B model if Android reports at least 2.4 GB available RAM and several GB free storage.
3. Force a model initialization failure if safely possible and confirm the previous model is restored.
4. Execute `add task ...`, `create project ...`, `complete task ...`, `move ... to today`, and `remind me in 30 minutes to ...`; confirm the vault updates and reminders fire.
5. Enable auto-apply, ask for one clearly scoped internal action, and verify only validated local changes apply; disable it and verify review is required again.
6. Enable the Accessibility service. From another app, tap Capture this screen, summarize, extract action items, translate, use voice input, and copy the result. Verify the main Threadline activity does not open for these actions.
7. Test with a secure screen and confirm Threadline reports that capture was blocked rather than attempting a workaround.
8. Adjust speech language, installed voice, speed and pitch; confirm settings persist after reopening.
9. Scroll through Talk, trigger voice status changes and model streaming; confirm the scroll position and input focus do not jump unexpectedly.
