# Threadline 1.2.0 — verification status

## Checks performed in this environment

- Inspected the complete source tree and checked the ZIP source structure.
- Parsed every Android XML resource and the manifest successfully.
- Ran a Kotlin syntax-oriented pass over all Kotlin source files; it reported no syntax errors. This environment lacks Android SDK/project dependencies, so the pass cannot type-check the Android application.
- Compiled `Domain.kt` and ran a smoke test covering capture, reminder creation, completing a task, and clearing expired reminders. The smoke test passed.
- Type-checked the domain and assistant-action parser against minimal JSON API stubs. This is not a replacement for the Android Gradle build.
- Added unit tests for setting/completing tasks with reminders and clearing expired reminders. Those Gradle tests have not been run here.
- Reviewed the LiteRT-LM 0.18.1 Kotlin API forms used for GPU/CPU backend setup, thinking configuration, streaming callbacks and cancellation against the official source.
- Verified the optional Qwen3-1.7B dynamic quantized model file name, pinned revision, approximate size and SHA-256 against its Hugging Face file page.

## Not verified here

- `testDebugUnitTest`, `lintDebug`, and `assembleDebug` have **not** been run in this environment because Gradle and the Android SDK are unavailable.
- GPU acceleration, CPU fallback, inference speed and memory use require a real device.
- The floating overlay requires user permission and needs device testing across Android/MIUI background restrictions.
- Offline speech recognition, TTS language packs, camera, shared file intake, notification permissions and alarm delivery need real-device testing.
- ML Kit OCR is wired as an offline bundled dependency but needs a device test with photos and screenshots.
- Local image generation is not part of this build.

## Run the authoritative check

In GitHub Actions, run:

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug
```

Use Gradle 8.14.4 or newer compatible with Android Gradle Plugin 8.13.2. Download the `threadline-debug-apk` artifact only after all steps pass. A passing compile is necessary but not sufficient; test the app's voice, overlay and reminders on the actual phone before relying on them.
