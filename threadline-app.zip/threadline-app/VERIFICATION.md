# Threadline 1.1.0 — build and device verification

## Implemented in source

- A Talk screen with text conversation and a hands-free, turn-taking voice-session flow.
- On-device Android speech recognition, plus offline Android text-to-speech when a matching local voice pack is installed.
- Optional in-app download of the public Qwen3-0.6B LiteRT-LM model (roughly 345 MB decimal / 329 MiB) to private app storage; compatible `.litertlm` files can also be imported.
- Context-bounded local orchestration proposals for creating, moving, completing and connecting tasks, and creating/updating projects. The user must review and approve proposals before they change Threadline data.
- The earlier encrypted vault, capture/edit/delete, camera/file attachments, search, project management, review and backup surfaces remain part of the project.
- Added Android speech-recognition service visibility in the manifest and Android Internet permission for the public model download only. The source code does not upload personal notes, transcripts or projects.

## CI compile fixes applied after the reported GitHub Actions failure

- Replaced the nonexistent `Settings.ACTION_TEXT_TO_SPEECH_SETTINGS` reference with the Android Settings TTS action and a public Accessibility Settings fallback.
- Updated LiteRT-LM response handling to use `Message.toString()`, which returns the response contents in LiteRT-LM 0.18.1, instead of a nonexistent `Message.text` property.
- Changed `CHAT_SYSTEM_PROMPT` from `const val` to `val` because `trimIndent()` is not a compile-time constant expression.

These edits directly address the five unresolved-reference/constant-expression errors in the supplied CI log. They are not a substitute for rerunning GitHub Actions; the full Android build remains unverified in this environment.

## Checks performed in this environment

- Reviewed the modified Kotlin source, model-loading/download path, Android manifest and documented privacy boundary.
- Reviewed model setup against the Google LiteRT-LM Android integration and the selected LiteRT Community Qwen3-0.6B artifact.
- Confirmed the new assistant action parser only emits supported action types, limits each response to three proposals, validates task/project IDs against the current state, and does not execute changes automatically.
- Confirmed the project ZIP should preserve the top-level `threadline-app/` directory required by the existing GitHub Actions ZIP-extraction workflow.
- **A full Android build was not run here.** This environment has no installed Gradle executable or configured Android SDK build environment, and its network access does not permit downloading build dependencies. No claim is made that this source has compiled or that the new voice/model flow has been tested on a physical phone.

## Required verification after building the APK in GitHub Actions

1. Install the APK and unlock the existing vault.
2. Open **Talk**, download the model over Wi-Fi, and confirm it finishes and can be loaded.
3. Send a text prompt such as `What should I focus on now?`; then ask a follow-up question that depends on earlier conversation.
4. Ask Threadline to add a specific next task or connect an existing task to a project. Confirm it presents a proposal, and that nothing changes until **Review & apply changes** is tapped.
5. Install an offline Android text-to-speech voice and offline speech-recognition language pack. Start a voice session, speak, wait for the spoken reply, and confirm it listens again. End the session explicitly.
6. Test photo/file capture, edit, search, lock/unlock and encrypted backup before relying on it for important data.

## Known limitations

- Qwen3-0.6B is a small model; answers and structured proposals may be weak or malformed. Invalid proposals are discarded, but review every proposed change.
- Voice capabilities depend on the phone's on-device speech recognizer and installed offline language/voice packs. Availability for Kurdish and other languages is device-dependent.
- The default Qwen3 model is text-only. A saved photo can be stored in Threadline, but this model does not provide image understanding.
- The first model download needs Internet; model inference is intended to run locally afterward. The initial download size is approximately 345 MB before caches/temporary storage.
- This has not received a physical-device security review and is not certified security software. Keep an independent encrypted backup.
