# Threadline 1.5.0 — verification report

## Performed in this environment

- Parsed `AndroidManifest.xml`, `styles.xml` and all icon vector XML resources, including the Talk shortcut.
- Compiled `ThreadlineDesignSystem.kt` with the available standalone Kotlin compiler.
- Added JVM unit tests for minimum 4.5:1 contrast across the principal light/dark text and action color pairs.
- Ran static source-marker checks for persistent theme selection, navigation motion, reusable press feedback and warm-up shimmer.
- Reviewed that entrance stagger is limited to screen/tab transitions rather than every save/stream refresh, and that shimmer animation stops when detached.
- Checked in-place system `uiMode` handling, vault-lock surface contrast, five-item primary navigation and live Reduce Motion propagation to the floating overlay.
- Ran a Kotlin parser pass over the changed Android source; no syntax/parser diagnostics were reported, but unresolved Android/AndroidX/LiteRT symbols prevent a real module compilation here.

- The final source ZIP was rebuilt and passed `unzip -t`; its SHA-256 checksum is published alongside it.
- `Domain.kt` compiles with the available standalone Kotlin compiler (Kotlin 1.9). A custom smoke test passed capture, project creation, private Studio draft creation, explicit public-safe review, validation and deletion.
- MainActivity, PulseOrbView, AssistantModels, OnDeviceAi and StateCodec were passed through the Kotlin parser using `kotlinc`; no syntax/parse errors were reported. The standalone compiler cannot resolve Android/AndroidX/LiteRT-LM dependencies because this environment does not include the Android SDK or Gradle project dependencies.
- Reviewed the schema migration path: decoder accepts state schema 1 or 2, defaults missing `contentDrafts` to an empty array, and returns a schema 2 `ThreadState`; `SecureVault.readState()` detects an older schema and rewrites the migrated state after decryption; encoding writes schema 2.
- Reviewed the Studio privacy flow: new drafts default to `PRIVATE`; an explicit user confirmation is required to mark a draft `PUBLIC_SAFE`; no publication action exists.
- Ran 17 JVM test methods (11 `DomainTest`, 3 `BackupCryptoTest`, 3 `ThreadlineDesignSystemTest`) using compiled project logic and a local JUnit-compatible runner: 17 passed. The three new theme tests cover light/dark text and action contrast. This is not a substitute for the Android Gradle test task.

## Not verified

- Full Android Gradle compile/test/lint: unavailable in this container because the Android SDK, Gradle installation and external dependency network access are not available.
- Physical-device frame pacing, CPU/GPU thermal behavior, haptic quality, color contrast under all display settings, dark-mode dialogs, and TalkBack interaction.

- Device-level biometric unlock, overlay lifecycle, speech recognition, offline TTS, LiteRT-LM initialization, model switching or speed.
- Real migration of an existing encrypted v1 vault and backup restore on Android.
- Studio generation quality on the installed model, backgrounding while generation is in flight, clipboard behavior and large draft UI.
- Floating quick actions, daily nudge reliability, low-storage handling, memory pressure, thermal behavior, accessibility and battery usage on the target device.

## Required next gate

Run `gradle --no-daemon testDebugUnitTest lintDebug assembleDebug` in GitHub Actions. The workflow file inside this source archive uses Gradle 8.14.4, but uploading this ZIP as a single file does **not** replace the separate `.github/workflows/android.yml` already stored in the GitHub repository. If the repository's active workflow still installs Gradle 8.13, update that separate workflow to 8.14.4 as well.

Then test the APK on the actual phone:

1. Unlock the existing vault and confirm all old tasks, projects and reviews are still present.
2. Open Studio, create a private draft from typed source material, edit it, copy it, archive it, restore it and delete a test draft.
3. Close and reopen Threadline; confirm drafts persist.
4. Export an encrypted backup, restore it, and confirm both old records and Studio drafts survive.
5. Ask Talk to create a content draft; confirm it appears as a proposal and is saved only after approval.
6. Check offline voice with airplane mode enabled; document which speech/TTS provider actually works offline.
7. Enable the floating button, use Studio and Capture from another app, then disable it from the app and notification.
8. Test model latency with the small and larger model, including cold start and warm turns.

Do not label this a production release until the required gate and target-device tests pass.
