plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.threadline.privateplanner"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.threadline.privateplanner"
        minSdk = 30
        targetSdk = 34
        versionCode = 1800
        versionName = "1.8.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    // On-device language-model inference; user imports a compatible .litertlm model.
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
    // Bundled on-device Latin OCR model. Images are processed locally.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
