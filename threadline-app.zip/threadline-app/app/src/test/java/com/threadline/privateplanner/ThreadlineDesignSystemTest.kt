package com.threadline.privateplanner

import org.junit.Assert.assertTrue
import org.junit.Test

class ThreadlineDesignSystemTest {
    @Test
    fun lightThemeHasReadableMainAndSecondaryText() {
        assertContrastAtLeast(ThreadlineTokens.INK, ThreadlineTokens.BG, 4.5)
        assertContrastAtLeast(ThreadlineTokens.MUTED, ThreadlineTokens.WHITE, 4.5)
        assertContrastAtLeast(ThreadlineTokens.TEAL, ThreadlineTokens.WHITE, 4.5)
    }

    @Test
    fun darkThemeMapsMainAndSecondaryTextToReadableValues() {
        val canvas = ThreadlinePalette.resolve(ThreadlineTokens.BG, dark = true)
        val main = ThreadlinePalette.resolve(ThreadlineTokens.INK, dark = true)
        val secondary = ThreadlinePalette.resolve(ThreadlineTokens.MUTED, dark = true)
        val accent = ThreadlinePalette.resolve(ThreadlineTokens.TEAL, dark = true)
        assertContrastAtLeast(main, canvas, 4.5)
        assertContrastAtLeast(secondary, canvas, 4.5)
        assertContrastAtLeast(accent, canvas, 4.5)
    }

    @Test
    fun primaryActionLabelRemainsReadableInBothThemes() {
        // Primary buttons deliberately keep the same mint fill across appearances.
        assertContrastAtLeast(ThreadlineTokens.NAVY, ThreadlineTokens.MINT, 4.5)
        assertContrastAtLeast(ThreadlinePalette.resolve(ThreadlineTokens.NAVY, dark = true), ThreadlineTokens.MINT, 4.5)
    }

    private fun assertContrastAtLeast(foreground: Int, background: Int, threshold: Double) {
        val foregroundLuminance = luminance(foreground)
        val backgroundLuminance = luminance(background)
        val ratio = (maxOf(foregroundLuminance, backgroundLuminance) + 0.05) /
            (minOf(foregroundLuminance, backgroundLuminance) + 0.05)
        assertTrue("Expected contrast >= $threshold:1, got ${"%.2f".format(ratio)}:1", ratio >= threshold)
    }

    private fun luminance(color: Int): Double {
        fun channel(shift: Int): Double {
            val value = ((color shr shift) and 0xff) / 255.0
            return if (value <= 0.04045) value / 12.92 else Math.pow((value + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * channel(16) + 0.7152 * channel(8) + 0.0722 * channel(0)
    }
}
