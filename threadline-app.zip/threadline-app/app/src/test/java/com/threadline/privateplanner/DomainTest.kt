package com.threadline.privateplanner

import org.junit.Assert.*
import org.junit.Test

class DomainTest {
    @Test fun captureTrimsWhitespaceAndRejectsEmptyInput() {
        val captured = Domain.capture(ThreadState(), "  check   the   build  ")!!
        assertEquals("check the build", captured.tasks.single().text)
        assertNull(Domain.capture(captured, "  \n "))
        assertNull(Domain.capture(captured, "x".repeat(MAX_TASK_TEXT + 1)))
    }

    @Test fun dailyFocusNeverExceedsThreeItems() {
        var state = ThreadState()
        repeat(4) { index -> state = Domain.capture(state, "task $index")!! }
        state = Domain.moveTask(state, state.tasks[0].id, TaskStatus.TODAY)!!
        state = Domain.moveTask(state, state.tasks[1].id, TaskStatus.TODAY)!!
        state = Domain.moveTask(state, state.tasks[2].id, TaskStatus.TODAY)!!
        assertNull(Domain.moveTask(state, state.tasks[3].id, TaskStatus.TODAY))
        assertEquals(3, state.tasks.count { it.status == TaskStatus.TODAY })
    }

    @Test fun completingTaskRecordsCompletionAndRollDayPreservesOpenWork() {
        var state = Domain.capture(ThreadState(), "finish the README")!!
        val id = state.tasks.single().id
        state = Domain.moveTask(state, id, TaskStatus.TODAY)!!
        state = Domain.moveTask(state, id, TaskStatus.DONE)!!
        assertNotNull(state.tasks.single().completedAt)

        state = Domain.capture(state, "follow up tomorrow")!!
        val secondId = state.tasks.last().id
        state = Domain.moveTask(state, secondId, TaskStatus.TODAY)!!
        val nextDay = Domain.rollDay(state)
        assertEquals(TaskStatus.DONE, nextDay.tasks.first { it.id == id }.status)
        assertEquals(TaskStatus.NEXT, nextDay.tasks.first { it.id == secondId }.status)
    }

    @Test fun projectTitlesAreUniqueIgnoringCase() {
        var state = Domain.addProject(ThreadState(), "Troy", "Understand signals", "Review source data")!!
        assertNull(Domain.addProject(state, " tRoY ", "", ""))
        state = Domain.addProject(state, "Kovan", "A usable CAD workflow", "Inspect the sketch" )!!
        assertEquals(2, state.projects.size)
    }

    @Test fun reviewUpsertsTheSameDayAndCapsHistory() {
        var state = Domain.saveReview(ThreadState(), "Did work", "One next step", "One parked thing", "2026-10-23")
        state = Domain.saveReview(state, "Updated", "Next", "Later", "2026-10-23")
        assertEquals(1, state.reviews.size)
        assertEquals("Updated", state.reviews.single().movedForward)
    }
}
