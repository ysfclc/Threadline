package com.threadline.privateplanner

import org.junit.Assert.*
import org.junit.Test

class DomainTest {
    @Test fun captureTrimsWhitespaceAndRejectsEmptyInput() {
        val captured = Domain.capture(ThreadState(), "  check   the   build  ")!!
        assertEquals("check the build", captured.tasks.single().text)
        assertNull(Domain.capture(captured, "  \n "))
        assertNull(Domain.capture(captured, "x".repeat(MAX_TASK_TEXT + 1)))
    }

    @Test fun dailyFocusNeverExceedsThreeItems() {
        var state = ThreadState()
        repeat(4) { index -> state = Domain.capture(state, "task $index")!! }
        state = Domain.moveTask(state, state.tasks[0].id, TaskStatus.TODAY)!!
        state = Domain.moveTask(state, state.tasks[1].id, TaskStatus.TODAY)!!
        state = Domain.moveTask(state, state.tasks[2].id, TaskStatus.TODAY)!!
        assertNull(Domain.moveTask(state, state.tasks[3].id, TaskStatus.TODAY))
        assertEquals(3, state.tasks.count { it.status == TaskStatus.TODAY })
    }

    @Test fun completingTaskRecordsCompletionAndRollDayPreservesOpenWork() {
        var state = Domain.capture(ThreadState(), "finish the README")!!
        val id = state.tasks.single().id
        state = Domain.moveTask(state, id, TaskStatus.TODAY)!!
        state = Domain.moveTask(state, id, TaskStatus.DONE)!!
        assertNotNull(state.tasks.single().completedAt)

        state = Domain.capture(state, "follow up tomorrow")!!
        val secondId = state.tasks.last().id
        state = Domain.moveTask(state, secondId, TaskStatus.TODAY)!!
        val nextDay = Domain.rollDay(state)
        assertEquals(TaskStatus.DONE, nextDay.tasks.first { it.id == id }.status)
        assertEquals(TaskStatus.NEXT, nextDay.tasks.first { it.id == secondId }.status)
    }

    @Test fun projectTitlesAreUniqueIgnoringCase() {
        var state = Domain.addProject(ThreadState(), "Troy", "Understand signals", "Review source data")!!
        assertNull(Domain.addProject(state, " tRoY ", "", ""))
        state = Domain.addProject(state, "Kovan", "A usable CAD workflow", "Inspect the sketch" )!!
        assertEquals(2, state.projects.size)
    }

    @Test fun attachmentStaysWithCaptureWhenEditingAndIsRemovedWithCapture() {
        val original = Domain.capture(
            ThreadState(), "Meeting photo", "board.jpg", "image/jpeg", "YWJj"
        )!!
        val task = original.tasks.single()
        val updated = Domain.updateTask(original, task.id, "Meeting whiteboard")!!
        assertEquals("Meeting whiteboard", updated.tasks.single().text)
        assertEquals("board.jpg", updated.tasks.single().attachmentName)
        assertEquals("YWJj", updated.tasks.single().attachmentBase64)
        assertTrue(Domain.validate(updated).tasks.single().attachmentMime == "image/jpeg")
        assertTrue(Domain.deleteTask(updated, task.id).tasks.isEmpty())
    }

    @Test fun longerVoiceStyleCapturesAreAcceptedAndStillBounded() {
        val longTranscript = "word ".repeat(220).trim()
        val captured = Domain.capture(ThreadState(), longTranscript)!!
        assertEquals(longTranscript.length, captured.tasks.single().text.length)
        assertNull(Domain.capture(ThreadState(), "x".repeat(MAX_TASK_TEXT + 1)))
    }

    @Test fun reminderCanBeSetAndCompletionClearsIt() {
        var state = Domain.capture(ThreadState(), "Send the Troy demo")!!
        val id = state.tasks.single().id
        val remindAt = System.currentTimeMillis() + 60 * 60 * 1000L
        state = Domain.setReminder(state, id, remindAt)!!
        assertEquals(remindAt, state.tasks.single().reminderAt)
        state = Domain.moveTask(state, id, TaskStatus.DONE)!!
        assertNull(state.tasks.single().reminderAt)
        assertNotNull(state.tasks.single().completedAt)
    }

    @Test fun expiredReminderIsClearedWhenWorkspaceOpensAgain() {
        val state = ThreadState(tasks = listOf(TaskItem(text = "Follow up", reminderAt = 2_000L)))
        val cleaned = Domain.clearExpiredReminders(state, now = 3_000L)
        assertNull(cleaned.tasks.single().reminderAt)
    }

    @Test fun reviewUpsertsTheSameDayAndCapsHistory() {
        var state = Domain.saveReview(ThreadState(), "Did work", "One next step", "One parked thing", "2026-10-23")
        state = Domain.saveReview(state, "Updated", "Next", "Later", "2026-10-23")
        assertEquals(1, state.reviews.size)
        assertEquals("Updated", state.reviews.single().movedForward)
    }
}
