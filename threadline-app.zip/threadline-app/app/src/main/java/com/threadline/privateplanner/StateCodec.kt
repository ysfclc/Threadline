package com.threadline.privateplanner

import org.json.JSONArray
import org.json.JSONObject

internal object StateCodec {
    fun encode(state: ThreadState): ByteArray {
        Domain.validate(state)
        val root = JSONObject()
            .put("schemaVersion", state.schemaVersion)
            .put("tasks", JSONArray().apply {
                state.tasks.forEach { t ->
                    put(JSONObject()
                        .put("id", t.id)
                        .put("text", t.text)
                        .put("createdAt", t.createdAt)
                        .put("updatedAt", t.updatedAt)
                        .put("status", t.status.name)
                        .put("projectId", t.projectId ?: JSONObject.NULL)
                        .put("completedAt", t.completedAt ?: JSONObject.NULL))
                }
            })
            .put("projects", JSONArray().apply {
                state.projects.forEach { p ->
                    put(JSONObject()
                        .put("id", p.id)
                        .put("title", p.title)
                        .put("outcome", p.outcome)
                        .put("nextAction", p.nextAction)
                        .put("status", p.status.name)
                        .put("createdAt", p.createdAt)
                        .put("updatedAt", p.updatedAt))
                }
            })
            .put("reviews", JSONArray().apply {
                state.reviews.forEach { r ->
                    put(JSONObject()
                        .put("day", r.day)
                        .put("movedForward", r.movedForward)
                        .put("nextStep", r.nextStep)
                        .put("parked", r.parked)
                        .put("updatedAt", r.updatedAt))
                }
            })
        return root.toString().toByteArray(Charsets.UTF_8)
    }

    fun decode(bytes: ByteArray): ThreadState {
        require(bytes.isNotEmpty() && bytes.size <= 10 * 1024 * 1024) { "Data file is empty or too large." }
        val root = JSONObject(bytes.toString(Charsets.UTF_8))
        val version = root.getInt("schemaVersion")
        require(version == 1) { "This data file uses an unsupported version." }
        val tasksJson = root.getJSONArray("tasks")
        val projectsJson = root.getJSONArray("projects")
        val reviewsJson = root.getJSONArray("reviews")
        require(tasksJson.length() <= MAX_TASKS) { "Too many tasks in data file." }
        require(projectsJson.length() <= MAX_PROJECTS) { "Too many projects in data file." }
        require(reviewsJson.length() <= MAX_REVIEWS) { "Too many reviews in data file." }

        val tasks = (0 until tasksJson.length()).map { i ->
            val o = tasksJson.getJSONObject(i)
            TaskItem(
                id = o.getString("id").bounded(100),
                text = o.getString("text").bounded(MAX_TASK_TEXT),
                createdAt = o.getLong("createdAt"),
                updatedAt = o.getLong("updatedAt"),
                status = enumValueOf<TaskStatus>(o.getString("status")),
                projectId = o.optString("projectId").takeUnless { it.isBlank() || it == "null" },
                completedAt = if (o.isNull("completedAt")) null else o.getLong("completedAt")
            )
        }
        val projects = (0 until projectsJson.length()).map { i ->
            val o = projectsJson.getJSONObject(i)
            ProjectItem(
                id = o.getString("id").bounded(100),
                title = o.getString("title").bounded(MAX_PROJECT_TITLE),
                outcome = o.optString("outcome").bounded(MAX_PROJECT_TEXT),
                nextAction = o.optString("nextAction").bounded(MAX_PROJECT_TEXT),
                status = enumValueOf<ProjectStatus>(o.getString("status")),
                createdAt = o.getLong("createdAt"),
                updatedAt = o.getLong("updatedAt")
            )
        }
        val reviews = (0 until reviewsJson.length()).map { i ->
            val o = reviewsJson.getJSONObject(i)
            DayReview(
                day = o.getString("day").bounded(10),
                movedForward = o.optString("movedForward").bounded(800),
                nextStep = o.optString("nextStep").bounded(800),
                parked = o.optString("parked").bounded(800),
                updatedAt = o.getLong("updatedAt")
            )
        }
        return Domain.validate(ThreadState(version, tasks, projects, reviews))
    }

    private fun String.bounded(max: Int): String {
        require(length <= max) { "A field exceeds its permitted length." }
        return this
    }
}
