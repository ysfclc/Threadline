package com.threadline.privateplanner

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Device-local AES-256-GCM vault. The random data key is wrapped by an auth-bound Android Keystore key. */
internal class SecureVault(context: Context) {
    private val appContext = context.applicationContext
    private val wrapFile = File(appContext.filesDir, "threadline.keywrap")
    private val stateFile = File(appContext.filesDir, "threadline.vault")
    private val alias = "com.threadline.privateplanner.wrap.v1"
    private var sessionKey: ByteArray? = null

    fun isInitialized(): Boolean = wrapFile.exists() && stateFile.exists()
    fun isUnlocked(): Boolean = sessionKey != null

    fun setup(activity: FragmentActivity, callback: (ThreadState?, String?) -> Unit) {
        try {
            if (wrapFile.exists() || stateFile.exists()) {
                callback(null, "A vault already exists. Unlock it or reset it first.")
                return
            }
            deleteMasterKey()
            val masterKey = createMasterKey()
            val rawDataKey = ByteArray(32).also { SecureRandom().nextBytes(it) }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, masterKey)
            authenticate(activity, cipher, "Create your private vault") { authenticatedCipher, error ->
                if (error != null || authenticatedCipher == null) {
                    rawDataKey.fill(0)
                    callback(null, error ?: "Biometric setup was cancelled.")
                    return@authenticate
                }
                try {
                    val wrapped = authenticatedCipher.doFinal(rawDataKey)
                    atomicWrite(wrapFile, packet(authenticatedCipher.iv, wrapped))
                    sessionKey = rawDataKey.copyOf()
                    val emptyState = ThreadState()
                    save(emptyState)
                    rawDataKey.fill(0)
                    callback(emptyState, null)
                } catch (e: Exception) {
                    rawDataKey.fill(0)
                    clearSession()
                    wrapFile.delete()
                    stateFile.delete()
                    deleteMasterKey()
                    callback(null, safeMessage(e, "Could not create the encrypted vault."))
                }
            }
        } catch (e: Exception) {
            callback(null, safeMessage(e, "Secure storage could not be initialized."))
        }
    }

    fun unlock(activity: FragmentActivity, callback: (ThreadState?, String?) -> Unit) {
        try {
            if (!wrapFile.exists() || !stateFile.exists()) {
                callback(null, "No complete vault was found on this device.")
                return
            }
            val wrappedPacket = unpack(wrapFile.readBytes())
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(128, wrappedPacket.first))
            authenticate(activity, cipher, "Unlock Threadline") { authenticatedCipher, error ->
                if (error != null || authenticatedCipher == null) {
                    callback(null, error ?: "Unlock was cancelled.")
                    return@authenticate
                }
                try {
                    val dataKey = authenticatedCipher.doFinal(wrappedPacket.second)
                    require(dataKey.size == 32) { "The vault key has an invalid length." }
                    sessionKey?.fill(0)
                    sessionKey = dataKey
                    val state = readState()
                    callback(state, null)
                } catch (e: Exception) {
                    clearSession()
                    callback(null, safeMessage(e, "Could not decrypt local data. Try restoring an encrypted backup."))
                }
            }
        } catch (e: Exception) {
            callback(null, safeMessage(e, "Secure storage could not be opened. Your encrypted files have not been deleted."))
        }
    }

    /** Authenticate and unwrap the data key without reading the current state file; supports recovery from a damaged vault file. */
    fun unlockForRestore(activity: FragmentActivity, callback: (Boolean, String?) -> Unit) {
        try {
            if (!wrapFile.exists()) {
                callback(false, "No secure vault key was found on this device.")
                return
            }
            val wrappedPacket = unpack(wrapFile.readBytes())
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(128, wrappedPacket.first))
            authenticate(activity, cipher, "Authorize backup restore") { authenticatedCipher, error ->
                if (error != null || authenticatedCipher == null) {
                    callback(false, error ?: "Restore authorization was cancelled.")
                    return@authenticate
                }
                try {
                    val key = authenticatedCipher.doFinal(wrappedPacket.second)
                    require(key.size == 32) { "The vault key has an invalid length." }
                    sessionKey?.fill(0)
                    sessionKey = key
                    callback(true, null)
                } catch (e: Exception) {
                    clearSession()
                    callback(false, safeMessage(e, "Could not unlock the secure vault key."))
                }
            }
        } catch (e: Exception) {
            callback(false, safeMessage(e, "Could not access the secure vault key."))
        }
    }

    fun readState(): ThreadState {
        val key = sessionKey ?: error("Unlock the vault before reading data.")
        val packet = unpack(stateFile.readBytes())
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, packet.first))
        val plaintext = cipher.doFinal(packet.second)
        return try {
            val sourceVersion = runCatching { JSONObject(plaintext.toString(Charsets.UTF_8)).optInt("schemaVersion", 1) }.getOrDefault(1)
            val decoded = StateCodec.decode(plaintext)
            if (sourceVersion < decoded.schemaVersion) save(decoded)
            decoded
        } finally {
            plaintext.fill(0)
        }
    }

    fun save(state: ThreadState) {
        val key = sessionKey ?: error("Unlock the vault before saving data.")
        val validated = Domain.validate(state)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
        val encrypted = cipher.doFinal(StateCodec.encode(validated))
        atomicWrite(stateFile, packet(cipher.iv, encrypted))
    }

    fun clearSession() {
        sessionKey?.fill(0)
        sessionKey = null
    }

    fun resetLocalVault() {
        clearSession()
        wrapFile.delete()
        stateFile.delete()
        deleteMasterKey()
    }

    private fun authenticate(
        activity: FragmentActivity,
        cipher: Cipher,
        title: String,
        callback: (Cipher?, String?) -> Unit
    ) {
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    callback(result.cryptoObject?.cipher, null)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    callback(null, errString.toString().take(180))
                }

                override fun onAuthenticationFailed() {
                    // The system biometric prompt allows another attempt; don't dismiss it here.
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("Your planning data is encrypted on this phone")
            .setDescription("Authenticate to access your private workspace.")
            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancel")
            .build()
        prompt.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    private fun createMasterKey(): SecretKey {
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            // Prevent a new fingerprint enrollment from silently making the only local copy inaccessible.
            .setInvalidatedByBiometricEnrollment(false)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun masterKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return (keyStore.getKey(alias, null) as? SecretKey)
            ?: throw IllegalStateException("The secure vault key is missing. Restore an encrypted backup if available.")
    }

    private fun deleteMasterKey() {
        runCatching {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply {
                load(null)
                if (containsAlias(alias)) deleteEntry(alias)
            }
        }
    }

    private fun packet(iv: ByteArray, ciphertext: ByteArray): ByteArray {
        require(iv.size == 12 && ciphertext.isNotEmpty()) { "Invalid encrypted packet." }
        return byteArrayOf(iv.size.toByte()) + iv + ciphertext
    }

    private fun unpack(bytes: ByteArray): Pair<ByteArray, ByteArray> {
        require(bytes.size >= 1 + 12 + 16) { "Encrypted file is incomplete." }
        val ivLength = bytes[0].toInt() and 0xff
        require(ivLength == 12 && bytes.size > 1 + ivLength + 15) { "Encrypted file has an invalid format." }
        return bytes.copyOfRange(1, 1 + ivLength) to bytes.copyOfRange(1 + ivLength, bytes.size)
    }

    private fun atomicWrite(destination: File, bytes: ByteArray) {
        val temp = File(appContext.filesDir, destination.name + ".tmp")
        try {
            FileOutputStream(temp).use { out -> out.write(bytes); out.fd.sync() }
            if (!temp.renameTo(destination)) {
                FileOutputStream(destination).use { out -> out.write(bytes); out.fd.sync() }
                temp.delete()
            }
        } finally {
            temp.delete()
        }
    }

    private fun safeMessage(error: Exception, fallback: String): String =
        (error.message?.takeIf { it.isNotBlank() } ?: fallback).take(240)

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
