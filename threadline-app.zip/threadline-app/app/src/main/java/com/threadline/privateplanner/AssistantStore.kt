package com.threadline.privateplanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Shared encrypted bridge between the floating assistant and the full workspace.
 * Conversations are separate, persistent sessions. Both surfaces operate on the active session.
 */
internal object AssistantStore {
    private const val PREFS = "threadline-assistant-state"
    private const val KEY_HISTORY = "history_enc" // legacy single-conversation key; migrated below
    private const val KEY_SESSIONS = "chat_sessions_enc"
    private const val KEY_ACTIVE_CHAT = "active_chat_id"
    private const val KEY_ACTIONS = "pending_actions_enc"
    private const val KEY_CONTEXT = "workspace_context_enc"
    private const val MAX_HISTORY = 80
    private const val MAX_SESSIONS = 60
    private const val MAX_ACTIONS = 80

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun readEncrypted(raw: String?, fallback: String): String = LiveFeedStorage.read(raw, fallback)
    private fun seal(raw: String): String = LiveFeedStorage.seal(raw)
    private fun timestamp() = System.currentTimeMillis()
    private fun newId() = "chat_" + timestamp().toString(36) + "_" + (1000..9999).random()

    /** Loads sessions and migrates the old global history without dropping existing messages. */
    private fun sessionsInternal(context: Context): JSONArray {
        val p = prefs(context)
        val stored = p.getString(KEY_SESSIONS, null)
        if (!stored.isNullOrBlank()) {
            return try { JSONArray(readEncrypted(stored, "[]")) } catch (_: Exception) { JSONArray() }
        }
        val sessions = JSONArray()
        val legacyRaw = readEncrypted(p.getString(KEY_HISTORY, null), "[]")
        val legacy = try { JSONArray(legacyRaw) } catch (_: Exception) { JSONArray() }
        if (legacy.length() > 0) {
            val messages = JSONArray()
            for (i in 0 until legacy.length()) legacy.optJSONObject(i)?.let { messages.put(JSONObject(it.toString())) }
            val firstUser = (0 until messages.length()).mapNotNull { messages.optJSONObject(it) }
                .firstOrNull { it.optString("role") == "user" }?.optString("content").orEmpty()
            val createdAt = messages.optJSONObject(0)?.optLong("createdAt", timestamp()) ?: timestamp()
            sessions.put(JSONObject()
                .put("id", newId())
                .put("title", deriveTitle(firstUser))
                .put("createdAt", createdAt)
                .put("updatedAt", messages.optJSONObject(messages.length() - 1)?.optLong("createdAt", createdAt) ?: createdAt)
                .put("messages", capMessages(messages)))
        }
        if (sessions.length() == 0) sessions.put(newSession())
        persistSessions(context, sessions)
        p.edit().remove(KEY_HISTORY).apply()
        val firstId = sessions.optJSONObject(0)?.optString("id").orEmpty()
        p.edit().putString(KEY_ACTIVE_CHAT, firstId).apply()
        return sessions
    }

    private fun newSession(title: String = "New conversation"): JSONObject = JSONObject()
        .put("id", newId()).put("title", title).put("createdAt", timestamp()).put("updatedAt", timestamp()).put("messages", JSONArray())

    private fun persistSessions(context: Context, sessions: JSONArray) {
        val capped = JSONArray()
        val start = (sessions.length() - MAX_SESSIONS).coerceAtLeast(0)
        for (i in start until sessions.length()) sessions.optJSONObject(i)?.let { capped.put(JSONObject(it.toString())) }
        prefs(context).edit().putString(KEY_SESSIONS, seal(capped.toString())).apply()
    }

    private fun capMessages(messages: JSONArray): JSONArray {
        val capped = JSONArray()
        val start = (messages.length() - MAX_HISTORY).coerceAtLeast(0)
        for (i in start until messages.length()) messages.optJSONObject(i)?.let { capped.put(JSONObject(it.toString())) }
        return capped
    }

    private fun deriveTitle(firstMessage: String): String {
        val clean = firstMessage.trim().replace(Regex("\\s+"), " ")
        if (clean.isBlank()) return "New conversation"
        return if (clean.length > 44) clean.take(41).trimEnd() + "…" else clean
    }

    private fun activeSessionInternal(context: Context, sessions: JSONArray = sessionsInternal(context)): JSONObject {
        val p = prefs(context)
        val activeId = p.getString(KEY_ACTIVE_CHAT, null)
        for (i in 0 until sessions.length()) {
            val session = sessions.optJSONObject(i) ?: continue
            if (session.optString("id") == activeId) return session
        }
        val created = newSession()
        sessions.put(created)
        persistSessions(context, sessions)
        p.edit().putString(KEY_ACTIVE_CHAT, created.optString("id")).apply()
        return created
    }

    @Synchronized
    fun history(context: Context): JSONArray {
        val sessions = sessionsInternal(context)
        return try { JSONArray(activeSessionInternal(context, sessions).optJSONArray("messages")?.toString() ?: "[]") }
        catch (_: Exception) { JSONArray() }
    }

    @Synchronized
    fun appendMessage(context: Context, role: String, content: String) {
        if (role !in setOf("user", "assistant", "system") || content.isBlank()) return
        val safe = content.trim().take(12000)
        val sessions = sessionsInternal(context)
        val session = activeSessionInternal(context, sessions)
        val messages = try { JSONArray(session.optJSONArray("messages")?.toString() ?: "[]") } catch (_: Exception) { JSONArray() }
        messages.put(JSONObject().put("role", role).put("content", safe).put("createdAt", timestamp()))
        session.put("messages", capMessages(messages)).put("updatedAt", timestamp())
        if (role == "user" && (session.optString("title").isBlank() || session.optString("title") == "New conversation")) {
            session.put("title", deriveTitle(safe))
        }
        persistSessions(context, sessions)
    }

    @Synchronized
    fun createChat(context: Context): String {
        val sessions = sessionsInternal(context)
        val active = activeSessionInternal(context, sessions)
        val activeMessages = active.optJSONArray("messages")
        // A second tap while already in a blank conversation should not create a pile of empty rows.
        if (activeMessages == null || activeMessages.length() == 0) return active.optString("id")
        val created = newSession()
        sessions.put(created)
        persistSessions(context, sessions)
        prefs(context).edit().putString(KEY_ACTIVE_CHAT, created.optString("id")).apply()
        return created.optString("id")
    }

    @Synchronized
    fun switchChat(context: Context, id: String): Boolean {
        if (!id.matches(Regex("chat_[A-Za-z0-9_]+"))) return false
        val sessions = sessionsInternal(context)
        val exists = (0 until sessions.length()).any { sessions.optJSONObject(it)?.optString("id") == id }
        if (!exists) return false
        prefs(context).edit().putString(KEY_ACTIVE_CHAT, id).apply()
        return true
    }

    @Synchronized
    fun renameChat(context: Context, id: String, title: String): Boolean {
        val clean = title.trim().take(80)
        if (clean.isBlank()) return false
        val sessions = sessionsInternal(context)
        for (i in 0 until sessions.length()) {
            val item = sessions.optJSONObject(i) ?: continue
            if (item.optString("id") == id) { item.put("title", clean); persistSessions(context, sessions); return true }
        }
        return false
    }

    @Synchronized
    fun deleteChat(context: Context, id: String): Boolean {
        val sessions = sessionsInternal(context)
        val retained = JSONArray()
        var removed = false
        for (i in 0 until sessions.length()) {
            val item = sessions.optJSONObject(i) ?: continue
            if (item.optString("id") == id) removed = true else retained.put(JSONObject(item.toString()))
        }
        if (!removed) return false
        if (retained.length() == 0) retained.put(newSession())
        val p = prefs(context)
        val active = p.getString(KEY_ACTIVE_CHAT, null)
        persistSessions(context, retained)
        if (active == id || (0 until retained.length()).none { retained.optJSONObject(it)?.optString("id") == active }) {
            p.edit().putString(KEY_ACTIVE_CHAT, retained.optJSONObject(retained.length() - 1)?.optString("id")).apply()
        }
        return true
    }

    @Synchronized
    fun activeChat(context: Context): JSONObject {
        val sessions = sessionsInternal(context)
        val session = activeSessionInternal(context, sessions)
        return summary(session)
    }

    @Synchronized
    fun sessions(context: Context): JSONArray {
        val all = sessionsInternal(context)
        val result = JSONArray()
        val activeId = prefs(context).getString(KEY_ACTIVE_CHAT, null)
        val items = (0 until all.length()).mapNotNull { all.optJSONObject(it) }
            .sortedByDescending { it.optLong("updatedAt", it.optLong("createdAt", 0L)) }
        for (session in items) {
            val messages = session.optJSONArray("messages") ?: JSONArray()
            if (messages.length() == 0 && session.optString("id") != activeId) continue
            result.put(summary(session))
        }
        return result
    }

    private fun summary(session: JSONObject): JSONObject {
        val messages = session.optJSONArray("messages") ?: JSONArray()
        val last = messages.optJSONObject(messages.length() - 1)
        return JSONObject().put("id", session.optString("id")).put("title", session.optString("title", "New conversation"))
            .put("createdAt", session.optLong("createdAt", 0L)).put("updatedAt", session.optLong("updatedAt", 0L))
            .put("messageCount", messages.length()).put("lastMessage", last?.optString("content").orEmpty().take(110))
    }

    @Synchronized
    fun workspaceContext(context: Context): String = readEncrypted(prefs(context).getString(KEY_CONTEXT, null), "").take(9000)

    @Synchronized
    fun setWorkspaceContext(context: Context, value: String) {
        prefs(context).edit().putString(KEY_CONTEXT, seal(value.take(9000))).apply()
    }

    /** Queue actions while Threadline is closed; the workspace imports them when it next runs. */
    @Synchronized
    fun queueAction(context: Context, type: String, title: String, detail: String = "", provenance: JSONObject? = null): String {
        if (type !in setOf("task", "project", "capture", "screenObservation")) return ""
        val safeTitle = title.trim().take(240)
        if (safeTitle.isBlank()) return ""
        val p = prefs(context)
        val raw = readEncrypted(p.getString(KEY_ACTIONS, null), "[]")
        val current = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val id = "assistant_" + timestamp().toString(36) + "_" + (1000..9999).random()
        val item = JSONObject().put("id", id).put("type", type).put("title", safeTitle).put("detail", detail.take(12000)).put("createdAt", timestamp())
        if (provenance != null) item.put("provenance", JSONObject(provenance.toString()))
        current.put(item)
        val capped = JSONArray()
        for (i in (current.length() - MAX_ACTIONS).coerceAtLeast(0) until current.length()) current.optJSONObject(i)?.let { capped.put(JSONObject(it.toString())) }
        p.edit().putString(KEY_ACTIONS, seal(capped.toString())).apply()
        return id
    }

    @Synchronized
    fun pendingActions(context: Context): JSONArray {
        val raw = readEncrypted(prefs(context).getString(KEY_ACTIONS, null), "[]")
        return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    }

    @Synchronized
    fun acknowledgeActions(context: Context, acknowledgedIds: Set<String>): Boolean {
        if (acknowledgedIds.isEmpty()) return true
        val p = prefs(context)
        val current = pendingActions(context)
        val retained = JSONArray()
        for (i in 0 until current.length()) {
            val item = current.optJSONObject(i) ?: continue
            if (!acknowledgedIds.contains(item.optString("id"))) retained.put(JSONObject(item.toString()))
        }
        p.edit().putString(KEY_ACTIONS, seal(retained.toString())).apply()
        return true
    }

    @Synchronized
    fun clearHistory(context: Context) {
        prefs(context).edit().remove(KEY_HISTORY).remove(KEY_SESSIONS).remove(KEY_ACTIVE_CHAT).apply()
    }
}
