package com.threadline.privateplanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Shared encrypted bridge between the always-available overlay and the full Threadline workspace. */
internal object AssistantStore {
    private const val PREFS = "threadline-assistant-state"
    private const val KEY_HISTORY = "history_enc"
    private const val KEY_ACTIONS = "pending_actions_enc"
    private const val KEY_CONTEXT = "workspace_context_enc"
    private const val MAX_HISTORY = 80
    private const val MAX_ACTIONS = 80

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun readEncrypted(raw: String?, fallback: String): String = LiveFeedStorage.read(raw, fallback)
    private fun seal(raw: String): String = LiveFeedStorage.seal(raw)

    @Synchronized
    fun history(context: Context): JSONArray {
        val raw = readEncrypted(prefs(context).getString(KEY_HISTORY, null), "[]")
        return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    }

    @Synchronized
    fun appendMessage(context: Context, role: String, content: String) {
        if (role !in setOf("user", "assistant", "system") || content.isBlank()) return
        val safe = content.trim().take(12000)
        val array = history(context)
        array.put(JSONObject().put("role", role).put("content", safe).put("createdAt", System.currentTimeMillis()))
        val capped = JSONArray()
        for (i in (array.length() - MAX_HISTORY).coerceAtLeast(0) until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            capped.put(JSONObject(item.toString()))
        }
        prefs(context).edit().putString(KEY_HISTORY, seal(capped.toString())).apply()
    }

    @Synchronized
    fun workspaceContext(context: Context): String =
        readEncrypted(prefs(context).getString(KEY_CONTEXT, null), "").take(9000)

    @Synchronized
    fun setWorkspaceContext(context: Context, value: String) {
        prefs(context).edit().putString(KEY_CONTEXT, seal(value.take(9000))).apply()
    }

    /** Queue actions while Threadline is closed; the workspace imports them when it next runs. */
    @Synchronized
    fun queueAction(context: Context, type: String, title: String, detail: String = "", provenance: JSONObject? = null): String {
        if (type !in setOf("task", "project", "capture", "screenObservation")) return ""
        val safeTitle = title.trim().take(240)
        if (safeTitle.isBlank()) return ""
        val p = prefs(context)
        val raw = readEncrypted(p.getString(KEY_ACTIONS, null), "[]")
        val current = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val id = "assistant_" + System.currentTimeMillis().toString(36) + "_" + (1000..9999).random()
        val item = JSONObject()
            .put("id", id)
            .put("type", type)
            .put("title", safeTitle)
            .put("detail", detail.take(12000))
            .put("createdAt", System.currentTimeMillis())
        if (provenance != null) item.put("provenance", JSONObject(provenance.toString()))
        current.put(item)
        val capped = JSONArray()
        for (i in (current.length() - MAX_ACTIONS).coerceAtLeast(0) until current.length()) {
            current.optJSONObject(i)?.let { capped.put(JSONObject(it.toString())) }
        }
        p.edit().putString(KEY_ACTIONS, seal(capped.toString())).apply()
        return id
    }

    @Synchronized
    fun pendingActions(context: Context): JSONArray {
        val raw = readEncrypted(prefs(context).getString(KEY_ACTIONS, null), "[]")
        return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    }

    /** Acknowledge only after the workspace has saved the imported records. */
    @Synchronized
    fun acknowledgeActions(context: Context, acknowledgedIds: Set<String>): Boolean {
        if (acknowledgedIds.isEmpty()) return true
        val p = prefs(context)
        val current = pendingActions(context)
        val retained = JSONArray()
        for (i in 0 until current.length()) {
            val item = current.optJSONObject(i) ?: continue
            if (!acknowledgedIds.contains(item.optString("id"))) retained.put(JSONObject(item.toString()))
        }
        p.edit().putString(KEY_ACTIONS, seal(retained.toString())).apply()
        return true
    }

    @Synchronized
    fun clearHistory(context: Context) {
        prefs(context).edit().remove(KEY_HISTORY).apply()
    }
}
