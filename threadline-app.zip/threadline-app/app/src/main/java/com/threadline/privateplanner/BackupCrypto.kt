package com.threadline.privateplanner

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Portable backups are encrypted separately with a passphrase; never export plaintext by default. */
internal object BackupCrypto {
    private val magic = byteArrayOf(0x54, 0x4c, 0x42, 0x4b, 0x01) // TLBK + format version 1
    private const val SALT_BYTES = 16
    private const val IV_BYTES = 12
    private const val TAG_BITS = 128
    private const val ITERATIONS = 600_000
    private const val MAX_BACKUP_BYTES = 10 * 1024 * 1024

    fun encrypt(plaintext: ByteArray, passphrase: CharArray): ByteArray {
        require(passphrase.size >= 12) { "Use a backup passphrase of at least 12 characters." }
        require(plaintext.isNotEmpty() && plaintext.size <= MAX_BACKUP_BYTES) { "Backup content is empty or too large." }
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val keyBytes = deriveKey(passphrase, salt)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"))
            val encrypted = cipher.doFinal(plaintext)
            return magic + salt + cipher.iv + encrypted
        } finally {
            keyBytes.fill(0)
            passphrase.fill('\u0000')
        }
    }

    fun decrypt(blob: ByteArray, passphrase: CharArray): ByteArray {
        require(passphrase.size >= 12) { "The backup passphrase must contain at least 12 characters." }
        require(blob.size in (magic.size + SALT_BYTES + IV_BYTES + 16)..MAX_BACKUP_BYTES) { "Backup file size is invalid." }
        require(blob.copyOfRange(0, magic.size).contentEquals(magic)) { "This is not a supported Threadline backup." }
        val saltStart = magic.size
        val ivStart = saltStart + SALT_BYTES
        val dataStart = ivStart + IV_BYTES
        val salt = blob.copyOfRange(saltStart, ivStart)
        val iv = blob.copyOfRange(ivStart, dataStart)
        val ciphertext = blob.copyOfRange(dataStart, blob.size)
        val keyBytes = deriveKey(passphrase, salt)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(TAG_BITS, iv))
            cipher.doFinal(ciphertext)
        } catch (_: Exception) {
            throw IllegalArgumentException("Could not decrypt this backup. Check the passphrase and file.")
        } finally {
            keyBytes.fill(0)
            passphrase.fill('\u0000')
            salt.fill(0)
            ciphertext.fill(0)
        }
    }

    private fun deriveKey(passphrase: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(passphrase, salt, ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }
}
