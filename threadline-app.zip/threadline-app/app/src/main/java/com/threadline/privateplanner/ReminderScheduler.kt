package com.threadline.privateplanner

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar
import android.os.Build
import androidx.core.app.NotificationCompat

/** Local, content-free nudges. Reminder text never appears on the lock screen. */
internal object ReminderScheduler {
    private const val PREFS = "threadline_reminder_schedule"
    private const val CHANNEL_ID = "threadline_reminders"
    private const val ACTION_REMIND = "com.threadline.privateplanner.REMIND"
    private const val EXTRA_TASK_ID = "threadline_reminder_task_id"

    fun sync(context: Context, tasks: List<TaskItem>) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val taskKeys = prefs.all.keys.filterNot { it in setOf(DAILY_ENABLED, DAILY_HOUR, DAILY_MINUTE) }
        taskKeys.forEach { cancelAlarm(app, it) }
        prefs.edit().also { edit -> taskKeys.forEach { edit.remove(it) } }.apply()
        val now = System.currentTimeMillis()
        tasks.filter { it.status != TaskStatus.DONE && (it.reminderAt ?: 0L) > now }.forEach { task ->
            schedule(app, task.id, task.reminderAt!!)
        }
    }

    fun isDailyEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getBoolean(DAILY_ENABLED, false)

    fun dailyTime(context: Context): Pair<Int, Int> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(DAILY_HOUR, 9) to prefs.getInt(DAILY_MINUTE, 0)
    }

    fun setDailyNudge(context: Context, hour: Int, minute: Int) {
        val app = context.applicationContext
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(DAILY_ENABLED, true).putInt(DAILY_HOUR, hour).putInt(DAILY_MINUTE, minute).apply()
        scheduleNextDaily(app)
    }

    fun disableDailyNudge(context: Context) {
        val app = context.applicationContext
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(DAILY_ENABLED, false).apply()
        (app.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pendingIntent(app, DAILY_ID))
    }

    fun schedule(context: Context, taskId: String, atMillis: Long) {
        val app = context.applicationContext
        if (atMillis <= System.currentTimeMillis()) return
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(taskId, atMillis).apply()
        val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pendingIntent(app, taskId)
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pending)
    }

    fun cancel(context: Context, taskId: String) {
        val app = context.applicationContext
        cancelAlarm(app, taskId)
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(taskId).apply()
    }

    fun rescheduleAfterBoot(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        prefs.all.forEach { (id, value) ->
            if (id in setOf(DAILY_ENABLED, DAILY_HOUR, DAILY_MINUTE)) return@forEach
            val time = value as? Long ?: return@forEach
            if (time > now) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pendingIntent(app, id))
            else prefs.edit().remove(id).apply()
        }
        if (prefs.getBoolean(DAILY_ENABLED, false)) scheduleNextDaily(app)
    }

    internal fun fire(context: Context, taskId: String) {
        val app = context.applicationContext
        if (taskId == DAILY_ID) {
            if (!isDailyEnabled(app)) return
            showNotification(app, DAILY_ID, "A gentle Threadline nudge", "Take one small step that moves something important forward.", daily = true)
            scheduleNextDaily(app)
            return
        }
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(taskId).apply()
        showNotification(app, taskId, "A Threadline nudge", "You asked to be reminded. Open Threadline when you're ready.", daily = false)
    }

    private fun showNotification(app: Context, id: String, title: String, body: String, daily: Boolean) {
        val manager = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Threadline nudges", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Private reminders scheduled by you inside Threadline."
                setShowBadge(true)
            })
        }
        val open = PendingIntent.getActivity(
            app, id.hashCode(),
            Intent(app, MainActivity::class.java).apply {
                putExtra("threadline_quick_action", "open")
                if (!daily) putExtra(EXTRA_TASK_ID, id)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        manager.notify(id.hashCode(), NotificationCompat.Builder(app, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build())
    }

    private fun scheduleNextDaily(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(DAILY_ENABLED, false)) return
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, prefs.getInt(DAILY_HOUR, 9))
            set(Calendar.MINUTE, prefs.getInt(DAILY_MINUTE, 0))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent(app, DAILY_ID))
    }

    private fun pendingIntent(context: Context, taskId: String): PendingIntent = PendingIntent.getBroadcast(
        context, taskId.hashCode(),
        Intent(context, ReminderReceiver::class.java).setAction(ACTION_REMIND).putExtra(EXTRA_TASK_ID, taskId),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun cancelAlarm(context: Context, taskId: String) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingIntent(context, taskId))
    }

    internal const val BOOT_ACTION = "android.intent.action.BOOT_COMPLETED"
    internal const val ACTION_REMINDER = ACTION_REMIND
    internal const val TASK_ID_EXTRA = EXTRA_TASK_ID
    private const val DAILY_ID = "__threadline_daily_nudge__"
    private const val DAILY_ENABLED = "daily_enabled"
    private const val DAILY_HOUR = "daily_hour"
    private const val DAILY_MINUTE = "daily_minute"
}

internal class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ReminderScheduler.ACTION_REMINDER) return
        val taskId = intent.getStringExtra(ReminderScheduler.TASK_ID_EXTRA) ?: return
        ReminderScheduler.fire(context, taskId)
    }
}

internal class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == ReminderScheduler.BOOT_ACTION) ReminderScheduler.rescheduleAfterBoot(context)
    }
}
