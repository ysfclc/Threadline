package com.threadline.privateplanner

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** One proposed change from the local assistant. All proposals remain inert until the user approves them. */
internal data class AssistantAction(
    val type: String,
    val text: String = "",
    val status: String = "NEXT",
    val taskId: String = "",
    val projectId: String = "",
    val title: String = "",
    val outcome: String = "",
    val nextAction: String = "",
    val reminderMinutes: Int = 0
) {
    fun description(state: ThreadState): String = when (type) {
        "create_task" -> "Add ${status.lowercase(Locale.ROOT)}: $text" + state.projects.firstOrNull { it.id == projectId }?.let { " · ${it.title}" }.orEmpty() + reminderSuffix()
        "move_task" -> state.tasks.firstOrNull { it.id == taskId }?.let { "Move ‘${it.text.take(72)}’ to ${status.lowercase(Locale.ROOT)}" } ?: "Move an existing task"
        "link_task" -> state.tasks.firstOrNull { it.id == taskId }?.let { task ->
            if (projectId.isBlank()) "Unlink ‘${task.text.take(72)}’ from its project"
            else "Link ‘${task.text.take(72)}’ to ${state.projects.firstOrNull { it.id == projectId }?.title ?: "a project"}"
        } ?: "Connect task to a project"
        "complete_task" -> state.tasks.firstOrNull { it.id == taskId }?.let { "Complete ‘${it.text.take(72)}’" } ?: "Complete an existing task"
        "set_reminder" -> state.tasks.firstOrNull { it.id == taskId }?.let { "Remind you about ‘${it.text.take(60)}’ at " + java.time.Instant.ofEpochMilli(System.currentTimeMillis() + reminderMinutes * 60_000L).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("EEE HH:mm")) } ?: "Set a reminder for an existing task"
        "clear_reminder" -> state.tasks.firstOrNull { it.id == taskId }?.let { "Clear reminder for ‘${it.text.take(65)}’" } ?: "Clear a task reminder"
        "create_project" -> "Create project: $title"
        "update_project" -> state.projects.firstOrNull { it.id == projectId }?.let { "Update ${it.title}" } ?: "Update project"
        else -> "Review suggested change"
    }

    private fun reminderSuffix(): String = if (reminderMinutes in 5..10_080) {
        " · reminder " + java.time.Instant.ofEpochMilli(System.currentTimeMillis() + reminderMinutes * 60_000L)
            .atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("EEE HH:mm"))
    } else ""

    companion object {
        private val taskStatuses = setOf("INBOX", "TODAY", "NEXT", "LATER")
        private val projectStatuses = setOf("ACTIVE", "PARKED", "DONE")

        fun fromJsonArray(array: JSONArray, state: ThreadState): List<AssistantAction> {
            val actions = mutableListOf<AssistantAction>()
            for (i in 0 until minOf(array.length(), 3)) {
                val item = array.optJSONObject(i) ?: continue
                val type = item.optString("type").lowercase(Locale.ROOT)
                val status = item.optString("status", "NEXT").uppercase(Locale.ROOT)
                val projectId = item.optString("project_id")
                val taskId = item.optString("task_id")
                val safeProjectId = projectId.takeIf { id -> id.isNotBlank() && state.projects.any { it.id == id } }.orEmpty()
                val safeTaskId = taskId.takeIf { id -> id.isNotBlank() && state.tasks.any { it.id == id } }.orEmpty()
                val action = when (type) {
                    "create_task" -> {
                        val text = item.optString("text").trim().take(MAX_TASK_TEXT)
                        val reminderMinutes = item.optInt("reminder_minutes_from_now", 0)
                        if (text.isBlank() || status !in taskStatuses || (reminderMinutes != 0 && reminderMinutes !in 5..10_080)) continue
                        AssistantAction(type, text = text, status = status, projectId = safeProjectId, reminderMinutes = reminderMinutes)
                    }
                    "move_task" -> {
                        if (safeTaskId.isBlank() || status !in taskStatuses + "DONE") continue
                        AssistantAction(type, status = status, taskId = safeTaskId)
                    }
                    "link_task" -> {
                        if (safeTaskId.isBlank() || (projectId.isNotBlank() && safeProjectId.isBlank())) continue
                        AssistantAction(type, taskId = safeTaskId, projectId = safeProjectId)
                    }
                    "complete_task" -> {
                        if (safeTaskId.isBlank()) continue
                        AssistantAction(type, taskId = safeTaskId)
                    }
                    "set_reminder" -> {
                        val minutes = item.optInt("minutes_from_now", 0)
                        if (safeTaskId.isBlank() || minutes !in 5..10_080) continue
                        AssistantAction(type, taskId = safeTaskId, reminderMinutes = minutes)
                    }
                    "clear_reminder" -> {
                        if (safeTaskId.isBlank()) continue
                        AssistantAction(type, taskId = safeTaskId)
                    }
                    "create_project" -> {
                        val title = item.optString("title").trim().take(MAX_PROJECT_TITLE)
                        if (title.isBlank()) continue
                        AssistantAction(
                            type,
                            title = title,
                            outcome = item.optString("outcome").trim().take(MAX_PROJECT_TEXT),
                            nextAction = item.optString("next_action").trim().take(MAX_PROJECT_TEXT)
                        )
                    }
                    "update_project" -> {
                        if (safeProjectId.isBlank()) continue
                        val newStatus = item.optString("status").uppercase(Locale.ROOT)
                        AssistantAction(
                            type,
                            projectId = safeProjectId,
                            outcome = item.optString("outcome").trim().take(MAX_PROJECT_TEXT),
                            nextAction = item.optString("next_action").trim().take(MAX_PROJECT_TEXT),
                            status = newStatus.takeIf { it in projectStatuses }.orEmpty()
                        )
                    }
                    else -> continue
                }
                if (action !in actions) actions.add(action)
            }
            return actions
        }
    }
}

internal data class AssistantResponse(val reply: String, val actions: List<AssistantAction>) {
    companion object {
        fun parse(raw: String, state: ThreadState): AssistantResponse {
            val cleaned = raw.replace(Regex("(?s)<think>.*?</think>"), "").trim()
            val start = cleaned.indexOf('{')
            val end = cleaned.lastIndexOf('}')
            if (start >= 0 && end > start) {
                runCatching {
                    val json = JSONObject(cleaned.substring(start, end + 1))
                    val reply = json.optString("reply").trim()
                    val actions = AssistantAction.fromJsonArray(json.optJSONArray("actions") ?: JSONArray(), state)
                    if (reply.isNotBlank()) return AssistantResponse(reply.take(1800), actions)
                }
            }
            // Older/smaller models sometimes ignore JSON instructions. Keep that response usable,
            // but never attempt to infer or execute actions from unstructured prose.
            val fallback = cleaned
                .replace(Regex("(?m)^```(?:json)?\\s*"), "")
                .replace(Regex("(?m)^```\\s*$"), "")
                .trim()
                .take(1800)
                .ifBlank { "I couldn't form a useful answer from that. Try asking in a different way." }
            return AssistantResponse(fallback, emptyList())
        }
    }
}

internal data class AssistantBubble(val fromUser: Boolean, val text: String)
