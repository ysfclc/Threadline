package com.threadline.privateplanner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.util.Base64
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets

/** User-enabled live UI bridge. Only exposed accessibility text is observed; passwords are omitted. */
class LiveAppAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_VIEW_SCROLLED or AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or AccessibilityEvent.TYPE_WINDOWS_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 250
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (!isFeedEnabled()) return
        val pkg = e.packageName?.toString().orEmpty()
        if (pkg.isBlank() || pkg == applicationContext.packageName) return
        val root = rootForPackage(pkg) ?: try { e.source } catch (_: Exception) { null } ?: return
        try { recordSnapshot(pkg, AccessibilityEvent.eventTypeToString(e.eventType), root) }
        catch (_: Throwable) { /* Keep the service resilient to apps with unusual/rapidly changing UI trees. */ }
    }

    /** Refresh on demand from the floating controller; does not require opening Threadline over the app. */
    fun captureCurrentScreenNow(): Boolean {
        if (!isFeedEnabled()) return false
        val root = externalRoot() ?: return false
        val pkg = root.packageName?.toString().orEmpty()
        if (pkg.isBlank() || pkg == packageName) return false
        return try { recordSnapshot(pkg, "User requested screen read", root); true } catch (_: Exception) { false }
    }

    private fun recordSnapshot(pkg: String, eventType: String, root: AccessibilityNodeInfo) {
        val nodes = JSONArray()
        walk(root, nodes, 0)
        val now = System.currentTimeMillis()
        val snapshot = JSONObject()
            .put("packageName", pkg)
            .put("eventType", eventType)
            .put("eventAt", now)
            .put("windowText", nodes)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit().putString("snapshot", LiveFeedStorage.seal(snapshot.toString())).apply()

        val preview = nodes.optJSONObject(0)?.optString("text").orEmpty().take(120)
        val signature = "$pkg|$eventType|$preview"
        val historyText = LiveFeedStorage.read(prefs.getString("events", null), "[]")
        val history = try { JSONArray(historyText) } catch (_: Exception) { JSONArray() }
        val last = history.optJSONObject(history.length() - 1)
        if (last?.optString("signature").orEmpty() != signature || now - (last?.optLong("eventAt", 0L) ?: 0L) >= 1500L) {
            history.put(JSONObject().put("packageName", pkg).put("eventType", eventType)
                .put("eventAt", now).put("preview", preview).put("signature", signature))
        }
        val capped = JSONArray()
        for (i in (history.length() - 80).coerceAtLeast(0) until history.length()) {
            capped.put(JSONObject(history.getJSONObject(i).toString()).apply { remove("signature") })
        }
        prefs.edit().putString("events", LiveFeedStorage.seal(capped.toString())).apply()
    }

    private fun rootForPackage(expectedPackage: String): AccessibilityNodeInfo? {
        return try {
            windows.asReversed().firstNotNullOfOrNull { window ->
                val root = try { window.root } catch (_: Exception) { null }
                if (root?.packageName?.toString() == expectedPackage) root else null
            } ?: rootInActiveWindow?.takeIf { it.packageName?.toString() == expectedPackage }
        } catch (_: Exception) { null }
    }

    /** Choose a non-Threadline app window so the floating controller can act without covering focus. */
    private fun externalRoot(): AccessibilityNodeInfo? {
        return try {
            windows.asReversed().firstNotNullOfOrNull { window ->
                val root = try { window.root } catch (_: Exception) { null }
                val pkg = root?.packageName?.toString().orEmpty()
                if (root != null && pkg.isNotBlank() && pkg != packageName) root else null
            } ?: rootInActiveWindow?.takeIf { it.packageName?.toString()?.let { pkg -> pkg != packageName } == true }
        } catch (_: Exception) { null }
    }

    private fun walk(node: AccessibilityNodeInfo?, output: JSONArray, depth: Int) {
        if (node == null || depth > 12 || output.length() >= 120) return
        if (node.isPassword) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isScrollable) {
            val r = Rect(); node.getBoundsInScreen(r)
            output.put(JSONObject()
                .put("text", (text.ifBlank { desc }).take(220))
                .put("contentDescription", desc.take(160))
                .put("viewId", node.viewIdResourceName.orEmpty().take(200))
                .put("clickable", node.isClickable)
                .put("scrollable", node.isScrollable)
                .put("enabled", node.isEnabled)
                .put("bounds", JSONArray().put(r.left).put(r.top).put(r.right).put(r.bottom)))
        }
        for (i in 0 until node.childCount) walk(try { node.getChild(i) } catch (_: Exception) { null }, output, depth + 1)
    }

    fun visibleControlLabels(): List<String> {
        if (!isFeedEnabled()) return emptyList()
        val root = externalRoot() ?: return emptyList()
        val output = JSONArray()
        walk(root, output, 0)
        val labels = linkedSetOf<String>()
        for (i in 0 until output.length()) {
            val node = output.optJSONObject(i) ?: continue
            if (!node.optBoolean("clickable") || !node.optBoolean("enabled")) continue
            node.optString("text").trim().takeIf { it.length in 1..72 }?.let(labels::add)
            if (labels.size >= 6) break
        }
        return labels.toList()
    }

    fun performThreadlineAction(action: String, target: String = ""): Boolean {
        if (!isFeedEnabled()) return false
        if (action == "back") return performGlobalAction(GLOBAL_ACTION_BACK)
        val root = externalRoot() ?: return false
        if (action == "scroll") {
            val node = findScrollable(root) ?: return false
            return node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        }
        if (action == "tap") {
            if (target.isBlank()) return false
            val node = findExactText(root, target.trim()) ?: return false
            return if (node.isClickable) node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                else node.parent?.takeIf { it.isClickable }?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
        }
        return false
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isVisibleToUser && node.isScrollable && node.isEnabled) return node
        for (i in 0 until node.childCount) findScrollable(try { node.getChild(i) } catch (_: Exception) { null })?.let { return it }
        return null
    }

    private fun findExactText(node: AccessibilityNodeInfo?, target: String): AccessibilityNodeInfo? {
        if (node == null || node.isPassword) return null
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (node.isVisibleToUser && node.isEnabled && (text.equals(target, true) || desc.equals(target, true))) return node
        for (i in 0 until node.childCount) findExactText(try { node.getChild(i) } catch (_: Exception) { null }, target)?.let { return it }
        return null
    }

    private fun isFeedEnabled() = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("feed_enabled", false)
    override fun onInterrupt() { }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    companion object {
        const val PREFS = "threadline-live-feed"
        @Volatile var instance: LiveAppAccessibilityService? = null
    }
}

/** Encrypts live cross-app observations at rest, and reads older plaintext entries for migration. */
internal object LiveFeedStorage {
    fun seal(value: String): String = "enc:" + Base64.encodeToString(
        MirrorCrypto.encrypt(value.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP
    )

    fun read(stored: String?, fallback: String): String {
        if (stored.isNullOrBlank()) return fallback
        if (!stored.startsWith("enc:")) return stored
        return try {
            MirrorCrypto.decrypt(Base64.decode(stored.removePrefix("enc:"), Base64.NO_WRAP)).toString(StandardCharsets.UTF_8)
        } catch (_: Exception) { fallback }
    }
}
