package com.threadline.privateplanner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.graphics.Path
import android.os.Bundle
import android.accessibilityservice.GestureDescription
import android.util.Base64
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

/** User-enabled live UI bridge. Only exposed accessibility text is observed; passwords are omitted. */
class LiveAppAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_VIEW_SCROLLED or AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or AccessibilityEvent.TYPE_WINDOWS_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 250
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (!isFeedEnabled()) return
        val pkg = e.packageName?.toString().orEmpty()
        if (pkg.isBlank() || pkg == applicationContext.packageName) return
        val root = rootForPackage(pkg) ?: try { e.source } catch (_: Exception) { null } ?: return
        try { recordSnapshot(pkg, AccessibilityEvent.eventTypeToString(e.eventType), root) }
        catch (_: Throwable) { /* Keep the service resilient to apps with unusual/rapidly changing UI trees. */ }
    }

    /** Refresh on demand from the floating controller; does not require opening Threadline over the app. */
    fun captureCurrentScreenNow(): Boolean {
        if (!isFeedEnabled()) return false
        val root = externalRoot() ?: return false
        val pkg = root.packageName?.toString().orEmpty()
        if (pkg.isBlank() || pkg == packageName) return false
        return try { recordSnapshot(pkg, "User requested screen read", root); true } catch (_: Exception) { false }
    }

    private fun recordSnapshot(pkg: String, eventType: String, root: AccessibilityNodeInfo) {
        val nodes = JSONArray()
        walk(root, nodes, 0)
        val now = System.currentTimeMillis()
        val snapshot = JSONObject()
            .put("packageName", pkg)
            .put("eventType", eventType)
            .put("eventAt", now)
            .put("windowText", nodes)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit().putString("snapshot", LiveFeedStorage.seal(snapshot.toString())).apply()

        val preview = nodes.optJSONObject(0)?.optString("text").orEmpty().take(120)
        val signature = "$pkg|$eventType|$preview"
        val historyText = LiveFeedStorage.read(prefs.getString("events", null), "[]")
        val history = try { JSONArray(historyText) } catch (_: Exception) { JSONArray() }
        val last = history.optJSONObject(history.length() - 1)
        if (last?.optString("signature").orEmpty() != signature || now - (last?.optLong("eventAt", 0L) ?: 0L) >= 1500L) {
            history.put(JSONObject().put("packageName", pkg).put("eventType", eventType)
                .put("eventAt", now).put("preview", preview).put("signature", signature))
        }
        val capped = JSONArray()
        for (i in (history.length() - 80).coerceAtLeast(0) until history.length()) {
            capped.put(JSONObject(history.getJSONObject(i).toString()))
        }
        prefs.edit().putString("events", LiveFeedStorage.seal(capped.toString())).apply()
        if (prefs.getBoolean("feed_auto_mirror", false)) mirrorMeaningfulChange(pkg, eventType, now, nodes, prefs)
    }

    /** An on-device live feed: mirror only changed, meaningful screen text, with source provenance and rate limiting. */
    private fun mirrorMeaningfulChange(pkg: String, eventType: String, now: Long, nodes: JSONArray, prefs: android.content.SharedPreferences) {
        val body = buildString {
            val seen = linkedSetOf<String>()
            for (i in 0 until nodes.length()) {
                val node = nodes.optJSONObject(i) ?: continue
                val value = node.optString("text").ifBlank { node.optString("contentDescription") }.trim()
                if (value.isNotBlank() && seen.add(value)) append(value).append('\n')
                if (length >= 14000) break
            }
        }.trim().take(12000)
        if (body.length < 35) return
        val signature = try {
            MessageDigest.getInstance("SHA-256").digest(body.toByteArray(StandardCharsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { body.hashCode().toString() }
        val pkgKey = try {
            MessageDigest.getInstance("SHA-256").digest(pkg.toByteArray(StandardCharsets.UTF_8))
                .take(10).joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { pkg.hashCode().toString().replace('-', 'n') }
        val signatureKey = "auto_mirror_sig_$pkgKey"
        val timeKey = "auto_mirror_ms_$pkgKey"
        val previous = prefs.getString(signatureKey, "").orEmpty()
        val previousAt = prefs.getLong(timeKey, 0L)
        if (signature == previous || now - previousAt < 1800L) return
        val label = pkg.substringAfterLast('.').replace('_', ' ').take(90).ifBlank { pkg }
        val provenance = JSONObject()
            .put("type", "live-accessibility-observation")
            .put("packageName", pkg)
            .put("eventType", eventType)
            .put("eventAt", now)
            .put("contentHash", signature)
        val queued = AssistantStore.queueAction(applicationContext, "screenObservation", "Live screen · $label", body, provenance)
        if (queued.isNotBlank()) prefs.edit().putString(signatureKey, signature).putLong(timeKey, now).apply()
    }

    /** A small, current decoded snapshot for the overlay; encrypted storage remains the source of truth. */
    fun currentSnapshot(): JSONObject? {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        return try { JSONObject(LiveFeedStorage.read(prefs.getString("snapshot", null), "{}")) }
        catch (_: Exception) { null }
    }

    private fun rootForPackage(expectedPackage: String): AccessibilityNodeInfo? {
        return try {
            windows.asReversed().firstNotNullOfOrNull { window ->
                val root = try { window.root } catch (_: Exception) { null }
                if (root?.packageName?.toString() == expectedPackage) root else null
            } ?: rootInActiveWindow?.takeIf { it.packageName?.toString() == expectedPackage }
        } catch (_: Exception) { null }
    }

    /** Choose a non-Threadline app window so the floating controller can act without covering focus. */
    private fun externalRoot(): AccessibilityNodeInfo? {
        return try {
            windows.asReversed().firstNotNullOfOrNull { window ->
                val root = try { window.root } catch (_: Exception) { null }
                val pkg = root?.packageName?.toString().orEmpty()
                if (root != null && pkg.isNotBlank() && pkg != packageName) root else null
            } ?: rootInActiveWindow?.takeIf { it.packageName?.toString()?.let { pkg -> pkg != packageName } == true }
        } catch (_: Exception) { null }
    }

    private fun walk(node: AccessibilityNodeInfo?, output: JSONArray, depth: Int) {
        if (node == null || depth > 12 || output.length() >= 120) return
        if (node.isPassword) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isScrollable) {
            val r = Rect(); node.getBoundsInScreen(r)
            output.put(JSONObject()
                .put("text", (text.ifBlank { desc }).take(220))
                .put("contentDescription", desc.take(160))
                .put("viewId", node.viewIdResourceName.orEmpty().take(200))
                .put("clickable", node.isClickable)
                .put("scrollable", node.isScrollable)
                .put("enabled", node.isEnabled)
                .put("bounds", JSONArray().put(r.left).put(r.top).put(r.right).put(r.bottom)))
        }
        for (i in 0 until node.childCount) walk(try { node.getChild(i) } catch (_: Exception) { null }, output, depth + 1)
    }

    fun visibleControlLabels(): List<String> {
        if (!isFeedEnabled()) return emptyList()
        val root = externalRoot() ?: return emptyList()
        val output = JSONArray()
        walk(root, output, 0)
        val labels = linkedSetOf<String>()
        for (i in 0 until output.length()) {
            val node = output.optJSONObject(i) ?: continue
            if (!node.optBoolean("clickable") || !node.optBoolean("enabled")) continue
            node.optString("text").trim().takeIf { it.length in 1..72 }?.let(labels::add)
            if (labels.size >= 6) break
        }
        return labels.toList()
    }

    fun performThreadlineAction(action: String, target: String = ""): Boolean {
        if (!isFeedEnabled()) return false
        if (action == "back") return performGlobalAction(GLOBAL_ACTION_BACK)
        val root = externalRoot() ?: return false
        if (action == "scroll") {
            val node = findScrollable(root)
            if (node?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true) return true
            return dispatchSwipe(up = true)
        }
        if (action == "scroll_up" || action == "swipe_up") return dispatchSwipe(up = true)
        if (action == "swipe_down") return dispatchSwipe(up = false)
        if (action == "tap") {
            if (target.isBlank()) return false
            val node = findExactText(root, target.trim()) ?: return false
            return if (node.isClickable) node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                else node.parent?.takeIf { it.isClickable }?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
        }
        if (action == "type") {
            if (target.isEmpty() || target.length > 4000) return false
            val focused = findFocusedEditable(root) ?: return false
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, target) }
            return try { focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) } catch (_: Exception) { false }
        }
        return false
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null || node.isPassword) return null
        if (node.isVisibleToUser && node.isEnabled && node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) {
            findFocusedEditable(try { node.getChild(i) } catch (_: Exception) { null })?.let { return it }
        }
        return null
    }

    private fun dispatchSwipe(up: Boolean): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) return false
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels / 2f
        val startY = if (up) metrics.heightPixels * 0.82f else metrics.heightPixels * 0.24f
        val endY = if (up) metrics.heightPixels * 0.25f else metrics.heightPixels * 0.82f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 320))
            .build()
        return try { dispatchGesture(gesture, null, null) } catch (_: Exception) { false }
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isVisibleToUser && node.isScrollable && node.isEnabled) return node
        for (i in 0 until node.childCount) findScrollable(try { node.getChild(i) } catch (_: Exception) { null })?.let { return it }
        return null
    }

    private fun findExactText(node: AccessibilityNodeInfo?, target: String): AccessibilityNodeInfo? {
        if (node == null || node.isPassword) return null
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (node.isVisibleToUser && node.isEnabled && (text.equals(target, true) || desc.equals(target, true))) return node
        for (i in 0 until node.childCount) findExactText(try { node.getChild(i) } catch (_: Exception) { null }, target)?.let { return it }
        return null
    }

    private fun isFeedEnabled() = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("feed_enabled", false)
    override fun onInterrupt() { }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    companion object {
        const val PREFS = "threadline-live-feed"
        @Volatile var instance: LiveAppAccessibilityService? = null
    }
}

/** Encrypts live cross-app observations at rest, and reads older plaintext entries for migration. */
internal object LiveFeedStorage {
    fun seal(value: String): String = "enc:" + Base64.encodeToString(
        MirrorCrypto.encrypt(value.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP
    )

    fun read(stored: String?, fallback: String): String {
        if (stored.isNullOrBlank()) return fallback
        if (!stored.startsWith("enc:")) return stored
        return try {
            MirrorCrypto.decrypt(Base64.decode(stored.removePrefix("enc:"), Base64.NO_WRAP)).toString(StandardCharsets.UTF_8)
        } catch (_: Exception) { fallback }
    }
}
