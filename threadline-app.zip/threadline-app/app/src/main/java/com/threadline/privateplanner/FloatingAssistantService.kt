package com.threadline.privateplanner

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.IntentFilter
import android.graphics.Color
import android.text.InputType
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.ScrollView
import android.widget.ProgressBar
import android.widget.TextView
import java.util.concurrent.Executors

/** User-enabled, local-only quick-action bubble. It never records audio until the user chooses voice. */
internal class FloatingAssistantService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var menu: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var pulseAnimator: ValueAnimator? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var screenText: String = ""
    private var screenPackage: String = ""
    private var screenResultView: TextView? = null
    private var screenInput: EditText? = null
    private var overlaySpeechRecognizer: SpeechRecognizer? = null
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_SCREEN_TEXT) return
            screenText = intent.getStringExtra(EXTRA_SCREEN_TEXT).orEmpty()
            screenPackage = intent.getStringExtra(EXTRA_SCREEN_PACKAGE).orEmpty()
            val error = intent.getStringExtra(EXTRA_SCREEN_ERROR).orEmpty()
            showScreenAssistantPanel(screenText, error)
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        val filter = IntentFilter(ACTION_SCREEN_TEXT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(screenReceiver, filter)
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this))) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_REFRESH_MOTION) {
            refreshPulseAnimation()
            return START_STICKY
        }
        if (bubble == null) showBubble()
        if (intent?.action == ACTION_SHOW_MENU) {
            if (menu == null) toggleMenu()
            return START_STICKY
        }
        return START_STICKY
    }

    private fun showBubble() {
        val fab = TextView(this).apply {
            text = "T"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xffb8f5d4.toInt())
            gravity = Gravity.CENTER
            contentDescription = "Threadline quick actions"
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xff163b33.toInt(), 0xff235f4d.toInt())).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0xffb8f5d4.toInt())
            }
            elevation = dp(12).toFloat()
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(240)
        }
        fab.setOnClickListener {
            ThreadlineMotion.tapHaptic(fab)
            toggleMenu()
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        fab.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    pulseAnimator?.pause()
                    if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                        view.animate().cancel()
                        view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(85).start()
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        params.x = (startX - dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(dp(40))
                        runCatching { windowManager.updateViewLayout(view, params) }
                        menu?.let { runCatching { windowManager.removeView(it) }; menu = null }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) view.performClick()
                    if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
                    } else {
                        view.animate().cancel()
                        view.scaleX = 1f
                        view.scaleY = 1f
                    }
                    if (menu == null) pulseAnimator?.resume()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
                    } else {
                        view.animate().cancel()
                        view.scaleX = 1f
                        view.scaleY = 1f
                    }
                    if (menu == null) pulseAnimator?.resume()
                    true
                }
                else -> true
            }
        }
        try {
            windowManager.addView(fab, params)
            bubble = fab
            bubbleParams = params
            refreshPulseAnimation()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun refreshPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        val fab = bubble ?: return
        val reduceMotion = getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false)
        if (!ThreadlineMotion.enabled(reduceMotion)) {
            fab.animate().cancel()
            fab.scaleX = 1f
            fab.scaleY = 1f
            return
        }
        pulseAnimator = ValueAnimator.ofFloat(1f, 1.045f).apply {
            duration = 1_450L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val scale = it.animatedValue as Float
                fab.scaleX = scale
                fab.scaleY = scale
            }
            start()
            if (menu != null) pause()
        }
    }

    private fun toggleMenu() {
        if (menu != null) {
            removeMenu()
            pulseAnimator?.resume()
            return
        }
        pulseAnimator?.pause()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(0xff142521.toInt())
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0xff3b6556.toInt())
            }
            elevation = dp(18).toFloat()
            addView(TextView(this@FloatingAssistantService).apply {
                text = "THREADLINE  /  QUICK ACTIONS"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xffb8f5d4.toInt())
                setPadding(dp(8), dp(4), dp(8), dp(10))
            })
            action("▣   Capture this screen", "capture_screen")
            action("＋   Format a thought", "capture")
            action("◉   Ask Threadline", "talk")
            action("✦   Create content / personal brand", "studio")
            action("🎙   Record a voice note", "voice")
            action("文   Translate / rewrite", "translate")
            action("▤   Use clipboard text", "clipboard")
            action("Hide floating button", "stop")
        }
        val params = WindowManager.LayoutParams(
            dp(252), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = ((bubbleParams?.y ?: dp(240)) + dp(68)).coerceAtMost(resources.displayMetrics.heightPixels - dp(400)).coerceAtLeast(dp(48))
        }
        params.height = minOf(resources.displayMetrics.heightPixels - dp(100), dp(560)).coerceAtLeast(dp(260))
        try {
            val container = ScrollView(this).apply { isFillViewport = true; addView(panel, ScrollView.LayoutParams(-1, -2)) }
            windowManager.addView(container, params)
            menu = container
            if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                container.alpha = 0f
                container.translationY = dp(8).toFloat()
                container.animate().alpha(1f).translationY(0f).setDuration(210).start()
                for (index in 1 until panel.childCount) {
                    val child = panel.getChildAt(index)
                    child.alpha = 0f
                    child.translationY = dp(6).toFloat()
                    child.animate().alpha(1f).translationY(0f).setStartDelay((index - 1) * 22L).setDuration(190).start()
                }
            }
        } catch (_: Exception) {
            menu = null
        }
    }

    private fun LinearLayout.action(label: String, action: String) {
        addView(TextView(this@FloatingAssistantService).apply {
            text = label
            textSize = 14f
            setTextColor(0xfff2f7f3.toInt())
            setPadding(dp(12), dp(13), dp(12), dp(13))
            isClickable = true
            isFocusable = true
            background = GradientDrawable().apply { setColor(0xff203b33.toInt()); cornerRadius = dp(12).toFloat() }
            ThreadlineMotion.installPressFeedback(this) {
                getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false)
            }
            setOnClickListener {
                ThreadlineMotion.tapHaptic(this)
                removeMenu()
                when (action) {
                    "stop" -> stopSelf()
                    "capture_screen" -> requestScreenCapture()
                    "capture" -> showQuickComposer("Capture a thought", "Turn this raw note into a clear, concise private capture. Preserve the user's meaning; do not add facts.", "")
                    "talk" -> showQuickComposer("Ask Threadline", "Answer directly and use concrete steps. Do not repeat the question. If the screen context is available, use it as evidence.", screenText)
                    "studio" -> showQuickComposer("Create from this context", "Create a useful draft from the source below. Be specific, natural and evidence-led. Do not invent claims. Return a strong first draft, not a description of what you will write.", screenText)
                    "translate" -> showQuickComposer("Translate / transform", "Translate the source text into English unless the user specifies another language. Return only the transformed text.", screenText)
                    "voice" -> showQuickComposer("Voice note", "Turn this transcript into a clean private note. Preserve all facts and uncertainty.", "", voiceInput = true)
                    "clipboard" -> {
                        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = clipboard.primaryClip
                        val copied = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this@FloatingAssistantService)?.toString().orEmpty() else ""
                        showQuickComposer("Clipboard context", "Transform or analyze this clipboard text as requested. Preserve facts; do not claim to save it anywhere.", copied)
                    }
                    else -> showQuickComposer("Quick action", "Work directly with the supplied text. Return a useful result and do not claim an external action was performed.", screenText)
                }
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
    }

    private fun requestScreenCapture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            showQuickComposer("Screen capture unavailable", "This Android version does not support the current-screen capture bridge. You can still paste text into the assistant.", "")
            return
        }
        val enabled = runCatching {
            val setting = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            setting.split(":").any { it.contains("${packageName}/.ScreenCaptureAccessibilityService", true) || it.contains("${packageName}/${ScreenCaptureAccessibilityService::class.java.name}", true) }
        }.getOrDefault(false)
        if (!enabled) {
            showScreenPermissionPanel()
            return
        }
        removeMenu()
        bubble?.visibility = View.INVISIBLE
        val request = Intent(ACTION_SCREEN_CAPTURE_REQUEST).setPackage(packageName)
        sendBroadcast(request)
        Handler(Looper.getMainLooper()).postDelayed({
            if (menu == null && bubble?.visibility != View.VISIBLE) {
                bubble?.visibility = View.VISIBLE
                showQuickComposer("Screen capture status", "No screenshot result arrived. Check that Threadline screen capture is enabled in Android Accessibility settings and try again.", "")
            }
        }, 3_500L)
    }

    private fun showScreenPermissionPanel() {
        removeMenu()
        val panel = newPanel()
        panel.addView(heading("ONE-TAP SCREEN CAPTURE"))
        panel.addView(body("To read the screen behind Threadline, enable Threadline screen capture in Android Accessibility settings. Threadline does not inspect screens in the background; the screenshot is requested only when you tap Capture this screen."))
        panel.addView(panelButton("Open Accessibility settings") {
            val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(intent) }
        })
        panel.addView(panelButton("Cancel") { removeMenu() })
        attachPanel(panel, focusable = false)
    }

    private fun showScreenAssistantPanel(ocrText: String, error: String = "") {
        bubble?.visibility = View.VISIBLE
        removeMenu()
        val panel = newPanel()
        panel.addView(heading("THREADLINE / SCREEN CONTEXT"))
        panel.addView(body(if (error.isNotBlank()) error else if (ocrText.isBlank()) "No text was extracted. You can still ask a general question below." else "Captured ${ocrText.length} characters from the current screen. Content stays on this device."))
        val captured = TextView(this).apply {
            text = ocrText.ifBlank { "No readable text yet." }
            textSize = 12f
            setTextColor(0xffd9e7e0.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
            maxLines = 7
            background = roundedOverlay(0xff0b1714.toInt(), 12)
        }
        panel.addView(captured, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        screenInput = EditText(this).apply {
            hint = "What do you want to do with this screen?"
            setHintTextColor(0xff94a9a0.toInt())
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 2
            maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = roundedOverlay(0xff20352e.toInt(), 12)
        }
        panel.addView(screenInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val result = TextView(this).apply {
            text = "Choose an action, or ask a specific question."
            textSize = 13f
            setTextColor(0xfff2f7f3.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = roundedOverlay(0xff14231e.toInt(), 12)
        }
        screenResultView = result
        panel.addView(result, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        panel.addView(panelButton("Summarize", true) { runScreenAction("Summarize the screen. Give key points and the most important implication.", result) })
        panel.addView(panelButton("Extract action items", true) { runScreenAction("Extract concrete action items visible on this screen. Return a checklist; do not invent tasks or claim they were created.", result) })
        panel.addView(panelButton("Translate to English", false) { runScreenAction("Translate the visible text into English. Preserve names, numbers and meaning. Return only the translation.", result) })
        panel.addView(panelButton("Ask / do this", true) {
            val ask = screenInput?.text?.toString()?.trim().orEmpty()
            if (ask.isBlank()) result.text = "Type what you want done first."
            else runScreenAction(ask, result)
        })
        panel.addView(panelButton("Copy extracted text", false) { copyText(ocrText, result) })
        panel.addView(panelButton("Copy result", false) { copyText(result.text.toString(), result) })
        panel.addView(panelButton("Close overlay", false) { removeMenu() })
        attachPanel(panel, focusable = true)
    }

    private fun showQuickComposer(title: String, instruction: String, initial: String, voiceInput: Boolean = false) {
        screenText = initial.take(12_000)
        removeMenu()
        val panel = newPanel()
        panel.addView(heading("THREADLINE / ${title.uppercase()}"))
        panel.addView(body("Local-only. Results stay in this floating panel until you choose to copy them."))
        val input = EditText(this).apply {
            hint = "Paste context or enter a request…"
            setHintTextColor(0xff94a9a0.toInt())
            setTextColor(Color.WHITE)
            textSize = 14f
            minLines = 3
            maxLines = 7
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setText(initial)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = roundedOverlay(0xff20352e.toInt(), 12)
        }
        panel.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val result = TextView(this).apply { text = "Ready."; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(10), dp(10), dp(10), dp(10)); background = roundedOverlay(0xff14231e.toInt(), 12) }
        screenInput = input
        screenResultView = result
        panel.addView(result, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        if (voiceInput) panel.addView(panelButton("Start on-device voice input", false) { startOverlaySpeech(input, result) })
        panel.addView(panelButton("Run locally", true) {
            val request = input.text.toString().trim()
            if (request.isBlank()) result.text = "Enter some context or a request first."
            else runScreenAction(instruction, result)
        })
        panel.addView(panelButton("Copy result", false) { copyText(result.text.toString(), result) })
        panel.addView(panelButton("Capture current screen", false) { requestScreenCapture() })
        panel.addView(panelButton("Close overlay", false) { removeMenu() })
        attachPanel(panel, focusable = true)
    }

    private fun startOverlaySpeech(input: EditText, status: TextView) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            status.text = "This phone has no on-device speech-recognition service available. You can type or paste a transcript instead."
            return
        }
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            status.text = "Microphone permission has not been granted. Open Threadline Talk once to grant permission, then return to the floating assistant."
            return
        }
        runCatching { overlaySpeechRecognizer?.cancel(); overlaySpeechRecognizer?.destroy() }
        try {
            val recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            overlaySpeechRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… speak now." }
                override fun onBeginningOfSpeech() { status.text = "Listening…" }
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() { status.text = "Transcribing on-device…" }
                override fun onError(error: Int) { status.text = "Voice input stopped (code $error). Try again or type the text."; runCatching { recognizer.destroy() }; if (overlaySpeechRecognizer === recognizer) overlaySpeechRecognizer = null }
                override fun onResults(results: Bundle?) {
                    val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (transcript.isNotBlank()) {
                        input.setText(transcript)
                        input.setSelection(input.text.length)
                        status.text = "Transcript ready. Review it, then choose Run locally."
                    } else status.text = "No speech recognized. Try again or type the text."
                    runCatching { recognizer.destroy() }; if (overlaySpeechRecognizer === recognizer) overlaySpeechRecognizer = null
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) status.text = partial
                }
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer.startListening(intent)
        } catch (e: Exception) {
            status.text = "Couldn't start on-device voice input: ${(e.message ?: "speech service unavailable").take(120)}"
        }
    }

    private fun runScreenAction(instruction: String, resultView: TextView) {
        val ai = OnDeviceAi.shared(this)
        val source = screenText.take(if (ai.isLargeReasoningModel()) 5_000 else 12_000)
        val rawUserText = screenInput?.text?.toString()?.trim().orEmpty()
        val userText = rawUserText.takeIf { it != source }.orEmpty()
        resultView.text = "Working on-device…"
        resultView.isEnabled = false
        worker.execute {
            val answer = try {
                if (!ai.isReady()) "No local model is installed. Open Threadline once to download a model, then return here.\n\nExtracted text is still available to copy."
                else ai.complete("You are Threadline, a precise local screen assistant. Never claim to click buttons, save records, send messages or change another app. Work only with the supplied screen text. Do not repeat the user's request. If asked for an action that requires an external app, give the result or steps, not a false completion.\nTASK: $instruction\n\nSCREEN TEXT:\n$source\n\nADDITIONAL USER INPUT:\n$userText\n\nReturn the useful result directly, with concise structure.", if (ai.isLargeReasoningModel()) 2048 else 640)
            } catch (e: Exception) { "Couldn't run local reasoning: ${(e.message ?: "model unavailable").take(220)}" }
            runOnUiThread {
                resultView.isEnabled = true
                resultView.text = answer
            }
        }
    }

    private fun copyText(value: String, resultView: TextView) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Threadline", value))
        resultView.text = "Copied to clipboard. You can paste it into the app you're using."
    }

    private fun newPanel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply { setColor(0xff142521.toInt()); cornerRadius = dp(22).toFloat(); setStroke(dp(1), 0xff3b6556.toInt()) }
        elevation = dp(18).toFloat()
    }

    private fun heading(text: String) = TextView(this).apply { this.text = text; textSize = 10f; setTypeface(typeface, Typeface.BOLD); setTextColor(0xffb8f5d4.toInt()); setPadding(dp(6), dp(4), dp(6), dp(8)) }
    private fun body(text: String) = TextView(this).apply { this.text = text; textSize = 12f; setTextColor(0xffc3d4cb.toInt()); setPadding(dp(6), 0, dp(6), dp(8)) }
    private fun panelButton(text: String, primary: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 13f; setTypeface(typeface, Typeface.BOLD); setTextColor(if (primary) 0xff0d211a.toInt() else 0xfff2f7f3.toInt())
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(11), dp(12), dp(11)); isClickable = true; isFocusable = true
        background = roundedOverlay(if (primary) 0xffb8f5d4.toInt() else 0xff203b33.toInt(), 12)
        ThreadlineMotion.installPressFeedback(this) { getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false) }
        setOnClickListener { ThreadlineMotion.tapHaptic(this); onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) }
    }

    private fun roundedOverlay(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun attachPanel(panel: View, focusable: Boolean) {
        val params = WindowManager.LayoutParams(
            dp(300), minOf(resources.displayMetrics.heightPixels - dp(80), dp(680)).coerceAtLeast(dp(320)),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                (if (focusable) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = ((bubbleParams?.y ?: dp(160)) + dp(66)).coerceAtMost(resources.displayMetrics.heightPixels - dp(560)).coerceAtLeast(dp(36))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            val scroll = ScrollView(this).apply {
                isFillViewport = true
                clipToPadding = false
                addView(panel, ScrollView.LayoutParams(-1, -2))
            }
            windowManager.addView(scroll, params)
            menu = scroll
            if (focusable) panel.post { screenInput?.requestFocus() }
        } catch (_: Exception) { menu = null }
    }

    private fun removeMenu() {
        menu?.let { runCatching { windowManager.removeView(it) } }
        menu = null
        pulseAnimator?.resume()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Threadline floating button", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the optional quick-action button available across apps. No audio is recorded in the background."
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getService(
            this, 2, Intent(this, FloatingAssistantService::class.java).setAction(ACTION_SHOW_MENU),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingAssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
        return builder.setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Threadline quick actions are on")
            .setContentText("Tap the floating T to capture the screen, ask locally, use voice input, transform text or copy results.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Hide button", stop).build())
            .build()
    }

    override fun onDestroy() {
        removeMenu()
        runCatching { unregisterReceiver(screenReceiver) }
        runCatching { overlaySpeechRecognizer?.cancel(); overlaySpeechRecognizer?.destroy() }
        overlaySpeechRecognizer = null
        worker.shutdownNow()
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        bubbleParams = null
        pulseAnimator?.cancel()
        pulseAnimator = null
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        @Volatile var isRunning: Boolean = false
        private const val CHANNEL_ID = "threadline_floating"
        private const val NOTIFICATION_ID = 8402
        private const val ACTION_STOP = "com.threadline.privateplanner.STOP_FLOATING"
        private const val ACTION_SHOW_MENU = "com.threadline.privateplanner.SHOW_FLOATING_MENU"
        const val ACTION_REFRESH_MOTION = "com.threadline.privateplanner.REFRESH_MOTION"
        const val ACTION_SCREEN_CAPTURE_REQUEST = "com.threadline.privateplanner.SCREEN_CAPTURE_REQUEST"
        const val ACTION_SCREEN_TEXT = "com.threadline.privateplanner.SCREEN_TEXT"
        const val EXTRA_SCREEN_TEXT = "screen_text"
        const val EXTRA_SCREEN_ERROR = "screen_error"
        const val EXTRA_SCREEN_PACKAGE = "screen_package"
    }
}
