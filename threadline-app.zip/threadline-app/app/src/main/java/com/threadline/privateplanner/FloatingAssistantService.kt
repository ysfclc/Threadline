package com.threadline.privateplanner

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout

/** User-enabled overlay: quick capture on tap; explicit live UI controls on long-press when accessibility is enabled. */
class FloatingAssistantService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var controlPanel: View? = null
    private var controlPanelParams: WindowManager.LayoutParams? = null
    private var downAt = 0L
    private var downX = 0f
    private var downY = 0f
    private var initialX = 0
    private var initialY = 0
    private var moved = false

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        attachBubble()
    }

    private fun buildNotification(): Notification {
        val channelId = "threadline-floating-assistant"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Threadline floating assistant", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the user-enabled floating capture bubble and optional live controls available across apps"
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_QUICK_CAPTURE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(this, 6419, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else legacyNotificationBuilder()
        return builder.setContentTitle("Threadline is ready")
            .setContentText("Tap T to capture; long-press T for opt-in Live App Feed controls")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun legacyNotificationBuilder(): Notification.Builder = Notification.Builder(this)

    @Suppress("ClickableViewAccessibility")
    private fun attachBubble() {
        if (bubble != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val text = TextView(this).apply {
            text = "T"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(23, 36, 29))
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(184, 243, 107))
                setStroke(dp(2), Color.rgb(23, 36, 29))
            }
            contentDescription = "Threadline quick capture. Drag to move; tap to capture; long-press for Live App Feed controls."
            elevation = dp(8).toFloat()
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else legacyWindowType()
        val p = WindowManager.LayoutParams(dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18)
            y = dp(220)
        }
        text.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    downAt = android.os.SystemClock.uptimeMillis()
                    initialX = p.x; initialY = p.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        p.x = (initialX - dx).coerceAtLeast(0)
                        p.y = (initialY + dy).coerceAtLeast(0)
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val held = android.os.SystemClock.uptimeMillis() - downAt
                        if (held >= 550L) toggleControlPanel() else openQuickCapture()
                    }
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(text, p)
            bubble = text
            params = p
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun toggleControlPanel() {
        val wm = windowManager ?: return
        controlPanel?.let { existing ->
            try { wm.removeView(existing) } catch (_: Exception) { }
            controlPanel = null
            controlPanelParams = null
            return
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply { setColor(Color.rgb(250, 251, 248)); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.rgb(190, 200, 184)) }
            elevation = dp(10).toFloat()
        }
        fun control(label: String, action: () -> Unit, primary: Boolean = false) {
            val button = TextView(this).apply {
                text = label
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(if (primary) Color.rgb(25, 48, 31) else Color.rgb(44, 58, 47))
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = GradientDrawable().apply {
                    setColor(if (primary) Color.rgb(209, 245, 164) else Color.rgb(239, 243, 235))
                    cornerRadius = dp(10).toFloat()
                }
                contentDescription = label
            }
            val lp = LinearLayout.LayoutParams(dp(250), LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
            panel.addView(button, lp)
            button.setOnClickListener { action() }
        }
        val service = LiveAppAccessibilityService.instance
        panel.addView(TextView(this).apply {
            text = "THREADLINE · LIVE CONTROLS"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(75, 95, 75))
            setPadding(dp(4), dp(2), dp(4), dp(8))
        })
        control("Read current screen", {
            val ok = LiveAppAccessibilityService.instance?.captureCurrentScreenNow() == true
            if (ok) { android.widget.Toast.makeText(this, "Current exposed screen text captured locally.", android.widget.Toast.LENGTH_SHORT).show(); refreshControlPanel() }
            else android.widget.Toast.makeText(this, "Enable Live App Feed and allow accessibility first.", android.widget.Toast.LENGTH_SHORT).show()
        }, true)
        control("Scroll down ↓", {
            val ok = LiveAppAccessibilityService.instance?.performThreadlineAction("scroll") == true
            if (!ok) android.widget.Toast.makeText(this, "No accessible scroll container found.", android.widget.Toast.LENGTH_SHORT).show()
            refreshControlPanel()
        })
        control("Back ←", {
            val ok = LiveAppAccessibilityService.instance?.performThreadlineAction("back") == true
            if (!ok) android.widget.Toast.makeText(this, "Enable Live App Feed to use Back here.", android.widget.Toast.LENGTH_SHORT).show()
            refreshControlPanel()
        })
        val labels = service?.visibleControlLabels().orEmpty()
        if (labels.isNotEmpty()) {
            panel.addView(TextView(this).apply {
                text = "VISIBLE CONTROLS · TAP TO ACT"
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(90, 105, 90))
                setPadding(dp(4), dp(7), dp(4), dp(7))
            })
            labels.forEach { label -> control("Tap · " + label.take(42), {
                val ok = LiveAppAccessibilityService.instance?.performThreadlineAction("tap", label) == true
                if (!ok) android.widget.Toast.makeText(this, "That control is no longer available.", android.widget.Toast.LENGTH_SHORT).show()
                refreshControlPanel()
            }) }
        } else {
            panel.addView(TextView(this).apply { text = "Open another app, then long-press T again. Some apps hide their controls."; textSize = 12f; setTextColor(Color.DKGRAY); setPadding(dp(4), dp(4), dp(4), dp(8)) })
        }
        control("Capture / open Threadline", { closeControlPanel(); openQuickCapture() }, true)
        control("Close controls", { closeControlPanel() })
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else legacyWindowType()
        val panelParams = WindowManager.LayoutParams(dp(280), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18)
            y = (params?.y ?: dp(220)) + dp(66)
        }
        try {
            wm.addView(panel, panelParams)
            controlPanel = panel
            controlPanelParams = panelParams
        } catch (_: Exception) {
            android.widget.Toast.makeText(this, "Android denied the floating control panel.", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshControlPanel() {
        if (controlPanel == null) return
        closeControlPanel()
        toggleControlPanel()
    }

    private fun closeControlPanel() {
        try { controlPanel?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        controlPanel = null
        controlPanelParams = null
    }

    private fun openQuickCapture() {
        val intent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_QUICK_CAPTURE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        try { startActivity(intent) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun legacyWindowType(): Int = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        closeControlPanel()
        try { bubble?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        bubble = null
        params = null
        getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).edit().putBoolean("floating_enabled", false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_QUICK_CAPTURE = "com.threadline.privateplanner.CAPTURE_QUICK"
        private const val NOTIFICATION_ID = 6419
    }
}
