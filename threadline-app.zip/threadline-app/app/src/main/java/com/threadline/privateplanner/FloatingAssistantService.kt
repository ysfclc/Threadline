package com.threadline.privateplanner

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** A user-enabled, draggable launcher bubble. It never reads the foreground app or screen. */
class FloatingAssistantService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var initialX = 0
    private var initialY = 0
    private var moved = false

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        attachBubble()
    }

    private fun buildNotification(): Notification {
        val channelId = "threadline-floating-assistant"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Threadline floating assistant", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps your user-enabled quick-capture bubble available across apps"
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_QUICK_CAPTURE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(this, 6419, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else legacyNotificationBuilder()
        return builder.setContentTitle("Threadline is ready")
            .setContentText("Tap the floating T to capture a thought or link")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun legacyNotificationBuilder(): Notification.Builder = Notification.Builder(this)

    @Suppress("ClickableViewAccessibility")
    private fun attachBubble() {
        if (bubble != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val text = TextView(this).apply {
            text = "T"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(23, 36, 29))
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(184, 243, 107))
                setStroke(dp(2), Color.rgb(23, 36, 29))
            }
            contentDescription = "Threadline quick capture. Drag to move; tap to capture."
            elevation = dp(8).toFloat()
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else legacyWindowType()
        val p = WindowManager.LayoutParams(dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18)
            y = dp(220)
        }
        text.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    initialX = p.x; initialY = p.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        p.x = (initialX - dx).coerceAtLeast(0)
                        p.y = (initialY + dy).coerceAtLeast(0)
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openQuickCapture()
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(text, p)
            bubble = text
            params = p
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun openQuickCapture() {
        val intent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_QUICK_CAPTURE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        try { startActivity(intent) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun legacyWindowType(): Int = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { bubble?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        bubble = null
        params = null
        getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).edit().putBoolean("floating_enabled", false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_QUICK_CAPTURE = "com.threadline.privateplanner.CAPTURE_QUICK"
        private const val NOTIFICATION_ID = 6419
    }
}
