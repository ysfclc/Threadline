package com.threadline.privateplanner

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView

/** User-enabled, local-only quick-action bubble. It never records audio until the user chooses voice. */
internal class FloatingAssistantService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var menu: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var pulseAnimator: ValueAnimator? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this))) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_REFRESH_MOTION) {
            refreshPulseAnimation()
            return START_STICKY
        }
        if (bubble == null) showBubble()
        return START_STICKY
    }

    private fun showBubble() {
        val fab = TextView(this).apply {
            text = "T"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xffb8f5d4.toInt())
            gravity = Gravity.CENTER
            contentDescription = "Threadline quick actions"
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xff163b33.toInt(), 0xff235f4d.toInt())).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0xffb8f5d4.toInt())
            }
            elevation = dp(12).toFloat()
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(240)
        }
        fab.setOnClickListener {
            ThreadlineMotion.tapHaptic(fab)
            toggleMenu()
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        fab.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    pulseAnimator?.pause()
                    if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                        view.animate().cancel()
                        view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(85).start()
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        params.x = (startX - dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(dp(40))
                        runCatching { windowManager.updateViewLayout(view, params) }
                        menu?.let { runCatching { windowManager.removeView(it) }; menu = null }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) view.performClick()
                    if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
                    } else {
                        view.animate().cancel()
                        view.scaleX = 1f
                        view.scaleY = 1f
                    }
                    if (menu == null) pulseAnimator?.resume()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(170).start()
                    } else {
                        view.animate().cancel()
                        view.scaleX = 1f
                        view.scaleY = 1f
                    }
                    if (menu == null) pulseAnimator?.resume()
                    true
                }
                else -> true
            }
        }
        try {
            windowManager.addView(fab, params)
            bubble = fab
            bubbleParams = params
            refreshPulseAnimation()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun refreshPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        val fab = bubble ?: return
        val reduceMotion = getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false)
        if (!ThreadlineMotion.enabled(reduceMotion)) {
            fab.animate().cancel()
            fab.scaleX = 1f
            fab.scaleY = 1f
            return
        }
        pulseAnimator = ValueAnimator.ofFloat(1f, 1.045f).apply {
            duration = 1_450L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val scale = it.animatedValue as Float
                fab.scaleX = scale
                fab.scaleY = scale
            }
            start()
            if (menu != null) pause()
        }
    }

    private fun toggleMenu() {
        if (menu != null) {
            removeMenu()
            pulseAnimator?.resume()
            return
        }
        pulseAnimator?.pause()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(0xff142521.toInt())
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0xff3b6556.toInt())
            }
            elevation = dp(18).toFloat()
            addView(TextView(this@FloatingAssistantService).apply {
                text = "THREADLINE  /  QUICK ACTIONS"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xffb8f5d4.toInt())
                setPadding(dp(8), dp(4), dp(8), dp(10))
            })
            action("＋   Capture a thought", "capture")
            action("◉   Talk to your agent", "talk")
            action("✦   Create content / personal brand", "studio")
            action("🎙   Record a voice note", "voice")
            action("文   Translate text", "translate")
            action("▧   Take a photo", "photo")
            action("↗   Attach a file", "file")
            action("Hide floating button", "stop")
        }
        val params = WindowManager.LayoutParams(
            dp(252), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = ((bubbleParams?.y ?: dp(240)) + dp(68)).coerceAtMost(resources.displayMetrics.heightPixels - dp(400)).coerceAtLeast(dp(48))
        }
        try {
            windowManager.addView(panel, params)
            menu = panel
            if (ThreadlineMotion.enabled(getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false))) {
                panel.alpha = 0f
                panel.translationY = dp(8).toFloat()
                panel.animate().alpha(1f).translationY(0f).setDuration(210).start()
                for (index in 1 until panel.childCount) {
                    val child = panel.getChildAt(index)
                    child.alpha = 0f
                    child.translationY = dp(6).toFloat()
                    child.animate().alpha(1f).translationY(0f).setStartDelay((index - 1) * 22L).setDuration(190).start()
                }
            }
            } catch (_: Exception) {
            menu = null
        }
    }

    private fun LinearLayout.action(label: String, action: String) {
        addView(TextView(this@FloatingAssistantService).apply {
            text = label
            textSize = 14f
            setTextColor(0xfff2f7f3.toInt())
            setPadding(dp(12), dp(13), dp(12), dp(13))
            isClickable = true
            isFocusable = true
            background = GradientDrawable().apply { setColor(0xff203b33.toInt()); cornerRadius = dp(12).toFloat() }
            ThreadlineMotion.installPressFeedback(this) {
                getSharedPreferences("threadline_preferences", MODE_PRIVATE).getBoolean("reduce_motion", false)
            }
            setOnClickListener {
                ThreadlineMotion.tapHaptic(this)
                removeMenu()
                if (action == "stop") {
                    stopSelf()
                } else {
                    val intent = Intent(this@FloatingAssistantService, MainActivity::class.java).apply {
                        putExtra("threadline_quick_action", action)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    runCatching { startActivity(intent) }
                }
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
    }

    private fun removeMenu() {
        menu?.let { runCatching { windowManager.removeView(it) } }
        menu = null
        pulseAnimator?.resume()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Threadline floating button", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the optional quick-action button available across apps. No audio is recorded in the background."
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingAssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
        return builder.setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Threadline quick actions are on")
            .setContentText("Tap the floating T to capture, talk, create, translate or attach a file.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Hide button", stop).build())
            .build()
    }

    override fun onDestroy() {
        removeMenu()
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        bubbleParams = null
        pulseAnimator?.cancel()
        pulseAnimator = null
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        @Volatile var isRunning: Boolean = false
        private const val CHANNEL_ID = "threadline_floating"
        private const val NOTIFICATION_ID = 8402
        private const val ACTION_STOP = "com.threadline.privateplanner.STOP_FLOATING"
        const val ACTION_REFRESH_MOTION = "com.threadline.privateplanner.REFRESH_MOTION"
    }
}
