package com.threadline.privateplanner

import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

/** Always-available, user-enabled assistant overlay. Tapping the bubble opens a conversational panel, not the app. */
class FloatingAssistantService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val inferenceExecutor = Executors.newSingleThreadExecutor()
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelRoot: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var messagesBox: LinearLayout? = null
    private var messagesScroll: ScrollView? = null
    private var promptInput: EditText? = null
    private var statusLabel: TextView? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null
    private var voiceOutputEnabled = true
    private var downAt = 0L
    private var downX = 0f
    private var downY = 0f
    private var initialX = 0
    private var initialY = 0
    private var moved = false
    @Volatile private var inferenceRunning = false

    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences(ASSISTANT_PREFS, MODE_PRIVATE)
        voiceOutputEnabled = prefs.getBoolean(KEY_VOICE_OUTPUT, true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Threadline to display over other apps, then enable the assistant again.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Enable microphone permission from Threadline to use voice conversations.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        startAssistantForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        initializeTts()
        attachBubble()
    }

    private fun startAssistantForeground() {
        val channelId = "threadline-assistant-session"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Threadline assistant", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the user-enabled assistant bubble available. The microphone is used only after you tap Talk."
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_OPEN_ASSISTANT
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(this, 6420, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else legacyNotificationBuilder()
        val notification = builder.setContentTitle("Threadline assistant is available")
            .setContentText("Tap the floating Threadline bubble to chat. Microphone is used only when you tap Talk.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIFICATION_ID, notification, types)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun legacyNotificationBuilder(): Notification.Builder = Notification.Builder(this)

    @Suppress("ClickableViewAccessibility")
    private fun attachBubble() {
        if (bubble != null) return
        val wm = windowManager ?: return
        val text = TextView(this).apply {
            text = "T"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(23, 36, 29))
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(184, 243, 107))
                setStroke(dp(2), Color.rgb(23, 36, 29))
            }
            contentDescription = "Threadline voice assistant. Tap to open chat over the current app; drag to move."
            elevation = dp(8).toFloat()
        }
        val p = WindowManager.LayoutParams(dp(58), dp(58), overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18)
            y = dp(220)
        }
        text.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    downAt = android.os.SystemClock.uptimeMillis()
                    initialX = p.x; initialY = p.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        p.x = (initialX - dx).coerceAtLeast(0)
                        p.y = (initialY + dy).coerceAtLeast(0)
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleAssistantPanel()
                    true
                }
                else -> true
            }
        }
        try {
            wm.addView(text, p)
            bubble = text
            bubbleParams = p
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun toggleAssistantPanel() {
        if (panelRoot != null) closeAssistantPanel() else openAssistantPanel()
    }

    private fun openAssistantPanel() {
        val wm = windowManager ?: return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.rgb(249, 250, 247))
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.rgb(210, 218, 207))
            }
            elevation = dp(14).toFloat()
            isFocusableInTouchMode = true
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val identity = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        identity.addView(TextView(this).apply {
            text = "Threadline"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(23, 36, 29))
        })
        statusLabel = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.rgb(87, 101, 86))
            text = assistantStatus()
            setPadding(0, dp(2), 0, 0)
        }
        identity.addView(statusLabel)
        header.addView(identity, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(panelButton("${if (voiceOutputEnabled) "🔊" else "🔇"}", "Toggle spoken replies") {
            voiceOutputEnabled = !voiceOutputEnabled
            getSharedPreferences(ASSISTANT_PREFS, MODE_PRIVATE).edit().putBoolean(KEY_VOICE_OUTPUT, voiceOutputEnabled).apply()
            showToast(if (voiceOutputEnabled) "Spoken replies on" else "Spoken replies muted")
            refreshHeaderButtons()
        })
        header.addView(panelButton("×", "Close assistant") { closeAssistantPanel() })
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "Talk naturally. Ask questions, capture something, or make a task or project."
            textSize = 12f
            setTextColor(Color.rgb(104, 115, 103))
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(subtitle)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            setPadding(dp(1), dp(2), dp(1), dp(6))
        }
        val messageColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        scroll.addView(messageColumn, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        messagesScroll = scroll
        messagesBox = messageColumn

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(6), dp(5), dp(6), dp(5))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(17).toFloat(); setStroke(dp(1), Color.rgb(222, 228, 219)) }
        }
        promptInput = EditText(this).apply {
            hint = "Ask Threadline anything…"
            textSize = 14f
            setTextColor(Color.rgb(23, 36, 29))
            setHintTextColor(Color.rgb(139, 148, 138))
            setPadding(dp(8), dp(7), dp(6), dp(7))
            background = null
            minLines = 1
            maxLines = 4
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendComposerMessage(); true } else false
            }
        }
        composer.addView(promptInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        composer.addView(panelButton("➤", "Send message") { sendComposerMessage() })
        root.addView(composer)

        val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, 0) }
        quickRow.addView(panelButton("🎙 Talk", "Speak a message") { startVoiceInput() }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        quickRow.addView(panelButton("Read screen", "Read and capture exposed text from the current app") { captureVisibleScreen() }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        quickRow.addView(panelButton("More", "Live feed, screen navigation, and settings") { panelRoot?.let { root -> showMoreActions(root) } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(quickRow)

        val type = overlayWindowType()
        val screen = resources.displayMetrics
        val width = minOf(dp(380), screen.widthPixels - dp(20)).coerceAtLeast(dp(280))
        val height = minOf(dp(590), screen.heightPixels - dp(90)).coerceAtLeast(dp(360))
        val p = WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(76)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        }
        try {
            wm.addView(root, p)
            panelRoot = root
            panelParams = p
            renderStoredConversation()
            updateStatus()
        } catch (_: Exception) {
            Toast.makeText(this, "Android did not allow the chat panel to appear. Check Display over other apps for Threadline.", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderStoredConversation() {
        val messages = messagesBox ?: return
        messages.removeAllViews()
        val history = AssistantStore.history(this)
        if (history.length() == 0) {
            addMessageBubble("assistant", "I'm here. We can talk through an idea, shape a project, make a task, or bring what is on your current screen into Threadline.", persist = false)
            val active = activeModelName()
            if (active.isBlank()) addMessageBubble("assistant", "Free-form AI conversation needs a local model. Open Threadline → You → Local intelligence to install or import one. I can still save tasks, projects, and captures from clear commands.", persist = false)
        } else {
            for (i in (history.length() - 24).coerceAtLeast(0) until history.length()) {
                val item = history.optJSONObject(i) ?: continue
                val role = item.optString("role")
                if (role == "user" || role == "assistant") addMessageBubble(role, item.optString("content"), persist = false)
            }
        }
        scrollConversationToBottom()
    }

    private fun addMessageBubble(role: String, raw: String, persist: Boolean) {
        val column = messagesBox ?: return
        val user = role == "user"
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (user) Gravity.END else Gravity.START
            setPadding(dp(2), dp(3), dp(2), dp(3))
        }
        val bubbleView = TextView(this).apply {
            text = raw.trim().take(12000)
            textSize = 13.5f
            setTextColor(if (user) Color.WHITE else Color.rgb(32, 46, 35))
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = GradientDrawable().apply {
                setColor(if (user) Color.rgb(38, 65, 43) else Color.WHITE)
                cornerRadius = dp(16).toFloat()
                if (!user) setStroke(dp(1), Color.rgb(229, 233, 225))
            }
            maxWidth = dp(294)
            setTextIsSelectable(true)
        }
        row.addView(bubbleView)
        column.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        if (persist) AssistantStore.appendMessage(this, role, raw)
        scrollConversationToBottom()
    }

    private fun panelButton(label: String, description: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        contentDescription = description
        textSize = if (label.length > 5) 11f else 14f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(Color.rgb(36, 58, 39))
        setPadding(dp(9), dp(10), dp(9), dp(10))
        background = GradientDrawable().apply { setColor(Color.rgb(238, 244, 232)); cornerRadius = dp(12).toFloat() }
        setOnClickListener { action() }
    }

    private fun refreshHeaderButtons() {
        // Rebuild the compact panel to update the speaker state without disturbing the message history.
        val inputText = promptInput?.text?.toString().orEmpty()
        closeAssistantPanel()
        openAssistantPanel()
        promptInput?.setText(inputText)
    }

    private fun closeAssistantPanel() {
        try { panelRoot?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        panelRoot = null
        panelParams = null
        messagesBox = null
        messagesScroll = null
        promptInput = null
        statusLabel = null
    }

    private fun sendComposerMessage() {
        val text = promptInput?.text?.toString()?.trim().orEmpty()
        if (text.isBlank()) return
        promptInput?.setText("")
        try { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(promptInput?.windowToken, 0) } catch (_: Exception) { }
        handleUserMessage(text)
    }

    private fun handleUserMessage(text: String) {
        addMessageBubble("user", text, persist = true)
        AssistantCommands.parse(text)?.let { action ->
            val queued = AssistantStore.queueAction(this, action.type, action.title, action.detail)
            val reply = when (action.type) {
                "task" -> "I added the task to Threadline's action queue: ${action.title}. It will appear in your workspace when Threadline next syncs its local queue."
                "project" -> "I created a project entry for ${action.title}. It will appear in Projects when Threadline imports the local queue."
                "capture" -> "I saved that to your capture queue with the original wording preserved."
                else -> "I saved it for Threadline."
            }
            if (queued.isBlank()) addSpokenAssistantMessage("I couldn't queue that action. Please try phrasing it as ‘create a task …’ or ‘create a project …’.")
            else addSpokenAssistantMessage(reply)
            updateStatus()
            return
        }
        if (inferenceRunning) {
            addSpokenAssistantMessage("I’m still working on the previous reply. Give me a moment, or save a task or project with a clear command.")
            return
        }
        if (activeModelName().isBlank()) {
            addSpokenAssistantMessage("I can save structured actions, but free-form discussion needs a local model. Open Threadline → You → Local intelligence to install or import a LiteRT-LM model. Your messages stay encrypted on this device.")
            updateStatus()
            return
        }
        inferenceRunning = true
        updateStatus("Thinking…")
        val prompt = buildPrompt()
        inferenceExecutor.execute {
            val answer = try { AssistantRuntime.generate(this@FloatingAssistantService, prompt) }
            catch (e: Throwable) { "I couldn't get a reply from the local model. ${e.message ?: "Check the model and try again."}" }
            mainHandler.post {
                inferenceRunning = false
                if (panelRoot != null) addMessageBubble("assistant", answer, true) else AssistantStore.appendMessage(this@FloatingAssistantService, "assistant", answer)
                if (voiceOutputEnabled) speak(answer)
                updateStatus()
            }
        }
    }

    private fun buildPrompt(): String {
        val history = AssistantStore.history(this)
        val conversation = StringBuilder()
        val start = (history.length() - 14).coerceAtLeast(0)
        for (i in start until history.length()) {
            val item = history.optJSONObject(i) ?: continue
            val role = item.optString("role")
            if (role == "assistant" || role == "user") conversation.append(if (role == "user") "User: " else "Threadline: ")
                .append(item.optString("content").take(2200)).append('\n')
        }
        return """You are Threadline, the user's private, practical conversational assistant. Speak naturally, directly, and warmly, as in a real conversation. Do not sound like a CRM or dashboard. Avoid generic productivity advice and avoid long bullet lists unless the user asks for them. Use the workspace context below when relevant and say honestly when information is missing. Do not claim you changed data unless a tool/action confirms it. If the user expresses an idea, discuss it; ask one useful follow-up only when necessary. Avoid reading punctuation symbols aloud; write natural spoken language.

WORKSPACE CONTEXT (local only):
${AssistantStore.workspaceContext(this).ifBlank { "No workspace summary has been synced yet." }}

RECENT CONVERSATION:
$conversation
Respond to the latest user message in a conversational tone. Keep the reply useful and usually under 180 words.""".take(18000)
    }

    private fun assistantStatus(): String {
        val model = activeModelName()
        return when {
            inferenceRunning -> "Thinking · local model"
            model.isNotBlank() -> "Ready · ${model.removeSuffix(".litertlm").take(30)}"
            else -> "Capture and organize · AI model not set up"
        }
    }

    private fun updateStatus(custom: String? = null) { statusLabel?.text = custom ?: assistantStatus() }
    private fun activeModelName(): String = getSharedPreferences("threadline-local-ai", MODE_PRIVATE).getString("active_model", "").orEmpty()

    private fun initializeTts() {
        if (tts != null) return
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.let { ConversationalVoice.configure(it, this) }
                val pending = pendingSpeech
                pendingSpeech = null
                if (!pending.isNullOrBlank() && voiceOutputEnabled) speak(pending)
            }
        }
    }

    private fun speak(text: String) {
        val plain = ConversationalVoice.cleanText(text)
        if (plain.isBlank()) return
        initializeTts()
        if (!ttsReady) {
            pendingSpeech = plain
            return
        }
        try { tts?.speak(plain, TextToSpeech.QUEUE_FLUSH, null, "threadline-${System.currentTimeMillis()}") }
        catch (_: Exception) { }
    }

    private fun addSpokenAssistantMessage(text: String) {
        addMessageBubble("assistant", text, persist = true)
        if (voiceOutputEnabled) speak(text)
    }

    private fun startVoiceInput() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            showToast("Microphone permission is required. Open Threadline and enable voice in Settings.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showToast("No speech recognition service is installed. Text chat still works.")
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) { mainHandler.post { updateStatus("Listening… tap Stop by closing the panel") } }
                override fun onBeginningOfSpeech() { }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { mainHandler.post { updateStatus("Working with your words…") } }
                override fun onError(error: Int) {
                    mainHandler.post { updateStatus(); showToast(speechError(error)) }
                    try { speechRecognizer?.destroy() } catch (_: Exception) { }
                    speechRecognizer = null
                }
                override fun onResults(results: android.os.Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    mainHandler.post {
                        updateStatus()
                        if (spoken.isNotBlank()) handleUserMessage(spoken) else showToast("I didn't catch that. Tap Talk to try again.")
                    }
                    try { speechRecognizer?.destroy() } catch (_: Exception) { }
                    speechRecognizer = null
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) mainHandler.post { updateStatus("Hearing: ${partial.take(38)}") }
                }
                override fun onEvent(eventType: Int, params: android.os.Bundle?) { }
            })
            val locale = ConversationalVoice.localeFor(this)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Threadline")
            }
            updateStatus("Listening…")
            speechRecognizer?.startListening(intent)
        } catch (e: Throwable) {
            updateStatus()
            showToast("Voice input could not start: ${e.message ?: "speech service unavailable"}")
        }
    }

    private fun speechError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Microphone audio failed."
        SpeechRecognizer.ERROR_CLIENT -> "Voice input stopped. Tap Talk to try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Android did not grant microphone access."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs a connection on this device."
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Tap Talk to try again."
        else -> "Speech recognition failed. Tap Talk to try again."
    }

    private fun captureVisibleScreen() {
        val feedPrefs = getSharedPreferences(LiveAppAccessibilityService.PREFS, MODE_PRIVATE)
        val feedOn = feedPrefs.getBoolean("feed_enabled", false)
        if (!feedOn) {
            showToast("Enable Live App Feed first from Threadline → You → Live app feed.")
            return
        }
        val service = LiveAppAccessibilityService.instance
        if (service == null || !service.captureCurrentScreenNow()) {
            showToast("Android did not expose a readable screen. Some apps hide their UI by design.")
            return
        }
        val snapshot = service.currentSnapshot() ?: return
        val nodes = snapshot.optJSONArray("windowText") ?: JSONArray()
        val body = buildString {
            for (i in 0 until nodes.length()) {
                val node = nodes.optJSONObject(i) ?: continue
                val text = node.optString("text").ifBlank { node.optString("contentDescription") }.trim()
                if (text.isNotBlank()) append(text).append('\n')
            }
        }.trim().take(12000)
        if (body.isBlank()) { showToast("This app exposes no readable text."); return }
        val pkg = snapshot.optString("packageName", "unknown app")
        val provenance = JSONObject().put("packageName", pkg).put("eventAt", snapshot.optLong("eventAt", System.currentTimeMillis())).put("type", "accessibility-snapshot")
        AssistantStore.queueAction(this, "screenObservation", "Screen from ${pkg.substringAfterLast('.')}", body, provenance)
        addMessageBubble("assistant", "I read the screen exposed by ${pkg.substringAfterLast('.')}. Its text is queued for your Threadline library. Here's what I can see:\n\n${body.take(1700)}", true)
    }

    private fun toggleFeedControls() {
        val prefs = getSharedPreferences(LiveAppAccessibilityService.PREFS, MODE_PRIVATE)
        val currentlyEnabled = prefs.getBoolean("feed_enabled", false)
        val serviceEnabled = LiveAppAccessibilityService.instance != null || isAccessibilityServiceEnabled()
        if (!serviceEnabled) {
            showToast("Android must enable the accessibility service manually. Open Threadline → You → Live app feed for setup steps.")
            try { startActivity(Intent(this, MainActivity::class.java).apply { action = ACTION_OPEN_LIVE_FEED; addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP) }) } catch (_: Exception) { }
            return
        }
        prefs.edit().putBoolean("feed_enabled", !currentlyEnabled).putBoolean("feed_auto_mirror", !currentlyEnabled).apply()
        if (!currentlyEnabled) showToast("Live screen mirroring started. Meaningful screen-text changes will be queued locally.") else showToast("Live screen mirroring paused.")
        updateStatus()
    }


    private fun showMoreActions(anchor: View) {
        val menu = PopupMenu(this, anchor)
        val prefs = getSharedPreferences(LiveAppAccessibilityService.PREFS, MODE_PRIVATE)
        val enabled = prefs.getBoolean("feed_enabled", false)
        menu.menu.add(if (enabled) "Pause live feed" else "Start live feed").setOnMenuItemClickListener { toggleFeedControls(); true }
        menu.menu.add("Read this screen into Threadline").setOnMenuItemClickListener { captureVisibleScreen(); true }
        menu.menu.add("Scroll down in current app").setOnMenuItemClickListener {
            val service = LiveAppAccessibilityService.instance
            val ok = service?.performThreadlineAction("scroll") == true
            showToast(if (ok) "Scrolled the current app." else "Could not scroll. Enable the live feed and open a scrollable screen first.")
            true
        }
        menu.menu.add("Go back in current app").setOnMenuItemClickListener {
            val service = LiveAppAccessibilityService.instance
            val ok = service?.performThreadlineAction("back") == true
            showToast(if (ok) "Back action sent." else "Enable the live feed to control the current app.")
            true
        }
        menu.menu.add("Swipe up") .setOnMenuItemClickListener {
            val ok = LiveAppAccessibilityService.instance?.performThreadlineAction("swipe_up") == true
            showToast(if (ok) "Swiped up in the current app." else "Could not send the swipe gesture.")
            true
        }
        menu.menu.add("Swipe down").setOnMenuItemClickListener {
            val ok = LiveAppAccessibilityService.instance?.performThreadlineAction("swipe_down") == true
            showToast(if (ok) "Swiped down in the current app." else "Could not send the swipe gesture.")
            true
        }
        menu.menu.add("Type text into the focused field…").setOnMenuItemClickListener {
            showTypeTextDialog()
            true
        }
        val service = LiveAppAccessibilityService.instance
        val labels = service?.visibleControlLabels().orEmpty()
        if (labels.isNotEmpty()) {
            val submenu = menu.menu.addSubMenu("Tap a visible control")
            labels.forEach { label ->
                submenu.add(label).setOnMenuItemClickListener {
                    val ok = LiveAppAccessibilityService.instance?.performThreadlineAction("tap", label) == true
                    showToast(if (ok) "Tapped “$label”." else "That control could not be tapped.")
                    true
                }
            }
        }
        menu.menu.add("Install better voice data…").setOnMenuItemClickListener {
            try {
                val engine = tts?.defaultEngine
                if (engine.isNullOrBlank()) {
                    showToast("Open Android Settings → Accessibility → Text-to-speech output and choose an installed voice.")
                } else {
                    startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).setPackage(engine).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            } catch (_: Exception) {
                showToast("Open Android Settings → Accessibility → Text-to-speech output and choose an installed voice.")
            }
            true
        }
        menu.menu.add("Open live feed setup").setOnMenuItemClickListener {
            try { startActivity(Intent(this, MainActivity::class.java).apply { action = ACTION_OPEN_LIVE_FEED; addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP) }) } catch (_: Exception) { }
            true
        }
        menu.show()
    }


    private fun showTypeTextDialog() {
        val editor = EditText(this).apply {
            hint = "Text to enter in the current app"
            minLines = 2
            maxLines = 5
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Type into the current app")
            .setMessage("Threadline will enter this text only into the app's currently focused, editable field. Review it before continuing.")
            .setView(editor)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Type text") { _, _ ->
                val value = editor.text?.toString().orEmpty()
                val ok = value.isNotBlank() && LiveAppAccessibilityService.instance?.performThreadlineAction("type", value) == true
                showToast(if (ok) "Text entered into the focused field." else "No accessible, focused text field was available. Nothing was entered.")
            }
            .show()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val component = android.content.ComponentName(this, LiveAppAccessibilityService::class.java)
        val enabled = android.provider.Settings.Secure.getString(contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        return enabled.split(':').any { it.equals(component.flattenToString(), true) || it.equals(component.flattenToShortString(), true) }
    }

    private fun showToast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun scrollConversationToBottom() { messagesScroll?.post { messagesScroll?.fullScroll(View.FOCUS_DOWN) } }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else legacyWindowType()
    @Suppress("DEPRECATION") private fun legacyWindowType(): Int = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { speechRecognizer?.cancel(); speechRecognizer?.destroy() } catch (_: Exception) { }
        speechRecognizer = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        ttsReady = false
        pendingSpeech = null
        tts = null
        closeAssistantPanel()
        try { bubble?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        bubble = null
        bubbleParams = null
        getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).edit().putBoolean("floating_enabled", false).apply()
        inferenceExecutor.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    data class Action(val type: String, val title: String, val detail: String = "")

    private object AssistantCommands {
        fun parse(raw: String): Action? {
            val text = raw.trim().replace(Regex("\\s+"), " ")
            val project = Regex("(?i)^(?:(?:please|i want to|i'd like to|could you|can you|help me)\\s+)?(?:create|start|set up|add|make)\\s+(?:a\\s+)?project(?:\\s+(?:called|named|for))?\\s*[:—-]?\\s+(.+)$").find(text)
            if (project != null) return Action("project", cleanTitle(project.groupValues[1]), "Created from assistant conversation")
            val task = Regex("(?i)^(?:(?:please|i want to|i'd like to|could you|can you|help me)\\s+)?(?:create|add|make|set up)\\s+(?:a\\s+)?(?:task|todo|to-do|action)\\s*(?:(?:to|for|called|named)\\s+|[:—-]\\s*|\\s+)(.+)$").find(text)
            if (task != null) return Action("task", cleanTitle(task.groupValues[1]), "Created from assistant conversation")
            val reminder = Regex("(?i)^remind me to\\s+(.+)$").find(text)
            if (reminder != null) return Action("task", cleanTitle(reminder.groupValues[1]), "Reminder captured from assistant conversation")
            val capture = Regex("(?i)^(?:(?:please|i want to|i'd like to|could you|can you|help me)\\s+)?(?:capture|save|keep)\\s+(?:this|that|for later)?\\s*[:—-]?\\s+(.+)$").find(text)
            if (capture != null) return Action("capture", cleanTitle(capture.groupValues[1]).take(160), text.take(12000))
            return null
        }
        private fun cleanTitle(raw: String): String = raw.trim().trim('"', '\'', '.', '!', '?', ':', ';').take(240)
    }

    companion object {
        const val ACTION_QUICK_CAPTURE = "com.threadline.privateplanner.CAPTURE_QUICK"
        const val ACTION_OPEN_ASSISTANT = "com.threadline.privateplanner.OPEN_ASSISTANT"
        const val ACTION_OPEN_LIVE_FEED = "com.threadline.privateplanner.OPEN_LIVE_FEED"
        const val ASSISTANT_PREFS = "threadline-assistant-state"
        const val KEY_VOICE_OUTPUT = "voice_output_enabled"
        private const val NOTIFICATION_ID = 6420
    }
}
