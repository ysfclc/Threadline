package com.threadline.privateplanner

import java.time.LocalDate
import java.util.UUID

internal const val MAX_TASKS = 3_000
internal const val MAX_PROJECTS = 200
internal const val MAX_REVIEWS = 1_000
internal const val MAX_TODAY_TASKS = 3
internal const val MAX_TASK_TEXT = 240
internal const val MAX_PROJECT_TITLE = 80
internal const val MAX_PROJECT_TEXT = 240

internal enum class TaskStatus { INBOX, TODAY, NEXT, LATER, DONE }
internal enum class ProjectStatus { ACTIVE, PARKED, DONE }

internal data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt,
    val status: TaskStatus = TaskStatus.INBOX,
    val projectId: String? = null,
    val completedAt: Long? = null
)

internal data class ProjectItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val outcome: String = "",
    val nextAction: String = "",
    val status: ProjectStatus = ProjectStatus.ACTIVE,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt
)

internal data class DayReview(
    val day: String = LocalDate.now().toString(),
    val movedForward: String = "",
    val nextStep: String = "",
    val parked: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

internal data class ThreadState(
    val schemaVersion: Int = 1,
    val tasks: List<TaskItem> = emptyList(),
    val projects: List<ProjectItem> = emptyList(),
    val reviews: List<DayReview> = emptyList()
)

internal object Domain {
    fun capture(state: ThreadState, rawText: String): ThreadState? {
        val text = rawText.trim().replace(Regex("\\s+"), " ")
        if (text.isBlank() || text.length > MAX_TASK_TEXT || state.tasks.size >= MAX_TASKS) return null
        return state.copy(tasks = state.tasks + TaskItem(text = text))
    }

    fun addProject(
        state: ThreadState,
        rawTitle: String,
        rawOutcome: String,
        rawNextAction: String
    ): ThreadState? {
        val title = clean(rawTitle, MAX_PROJECT_TITLE)
        val outcome = clean(rawOutcome, MAX_PROJECT_TEXT)
        val nextAction = clean(rawNextAction, MAX_PROJECT_TEXT)
        if (title.isBlank() || state.projects.size >= MAX_PROJECTS) return null
        if (state.projects.any { it.title.equals(title, ignoreCase = true) && it.status != ProjectStatus.DONE }) return null
        return state.copy(projects = state.projects + ProjectItem(title = title, outcome = outcome, nextAction = nextAction))
    }

    fun addProjectNextAction(state: ThreadState, projectId: String): ThreadState? {
        val project = state.projects.firstOrNull { it.id == projectId && it.status == ProjectStatus.ACTIVE } ?: return null
        val text = clean(project.nextAction, MAX_TASK_TEXT)
        if (text.isBlank() || state.tasks.size >= MAX_TASKS) return null
        if (state.tasks.any { it.projectId == project.id && it.text.equals(text, ignoreCase = true) && it.status != TaskStatus.DONE }) return null
        val updatedProject = project.copy(updatedAt = System.currentTimeMillis())
        return state.copy(
            tasks = state.tasks + TaskItem(text = text, status = TaskStatus.NEXT, projectId = project.id),
            projects = state.projects.map { if (it.id == project.id) updatedProject else it }
        )
    }

    fun moveTask(state: ThreadState, taskId: String, target: TaskStatus): ThreadState? {
        val task = state.tasks.firstOrNull { it.id == taskId } ?: return null
        if (task.status == target) return state
        if (target == TaskStatus.TODAY && state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS) return null
        val now = System.currentTimeMillis()
        val updated = task.copy(status = target, updatedAt = now, completedAt = if (target == TaskStatus.DONE) now else null)
        return state.copy(tasks = state.tasks.map { if (it.id == taskId) updated else it })
    }

    fun deleteTask(state: ThreadState, taskId: String): ThreadState =
        state.copy(tasks = state.tasks.filterNot { it.id == taskId })

    fun updateProject(state: ThreadState, projectId: String, outcome: String, nextAction: String, status: ProjectStatus? = null): ThreadState? {
        if (state.projects.none { it.id == projectId }) return null
        val safeOutcome = clean(outcome, MAX_PROJECT_TEXT)
        val safeNext = clean(nextAction, MAX_PROJECT_TEXT)
        return state.copy(projects = state.projects.map {
            if (it.id == projectId) it.copy(
                outcome = safeOutcome,
                nextAction = safeNext,
                status = status ?: it.status,
                updatedAt = System.currentTimeMillis()
            ) else it
        })
    }

    fun saveReview(state: ThreadState, movedForward: String, nextStep: String, parked: String, day: String = LocalDate.now().toString()): ThreadState {
        val review = DayReview(
            day = day,
            movedForward = clean(movedForward, 800),
            nextStep = clean(nextStep, 800),
            parked = clean(parked, 800)
        )
        val reviews = (state.reviews.filterNot { it.day == day } + review)
            .sortedByDescending { it.day }
            .take(MAX_REVIEWS)
        return state.copy(reviews = reviews)
    }

    fun rollDay(state: ThreadState): ThreadState {
        val now = System.currentTimeMillis()
        return state.copy(tasks = state.tasks.map {
            if (it.status == TaskStatus.TODAY) it.copy(status = TaskStatus.NEXT, updatedAt = now) else it
        })
    }

    fun validate(state: ThreadState): ThreadState {
        require(state.schemaVersion == 1) { "This backup uses an unsupported data version." }
        require(state.tasks.size <= MAX_TASKS) { "The backup contains too many tasks." }
        require(state.projects.size <= MAX_PROJECTS) { "The backup contains too many projects." }
        require(state.reviews.size <= MAX_REVIEWS) { "The backup contains too many reviews." }
        require(state.tasks.map { it.id }.distinct().size == state.tasks.size) { "Duplicate task IDs found." }
        require(state.projects.map { it.id }.distinct().size == state.projects.size) { "Duplicate project IDs found." }
        require(state.tasks.all { it.id.isNotBlank() && it.text.isNotBlank() && it.text.length <= MAX_TASK_TEXT }) { "A task is empty or too long." }
        require(state.projects.all { it.id.isNotBlank() && it.title.isNotBlank() && it.title.length <= MAX_PROJECT_TITLE }) { "A project is invalid." }
        require(state.tasks.count { it.status == TaskStatus.TODAY } <= MAX_TODAY_TASKS) { "The backup has more than three focus tasks." }
        val projectIds = state.projects.map { it.id }.toSet()
        require(state.tasks.all { it.projectId == null || it.projectId in projectIds }) { "A task refers to a missing project." }
        return state
    }

    private fun clean(value: String, max: Int): String = value.trim().replace(Regex("\\s+"), " ").take(max)
}
