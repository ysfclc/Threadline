package com.threadline.privateplanner

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.documentfile.provider.DocumentFile
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.util.concurrent.TimeUnit

/**
 * Mirrors a user-selected Storage Access Framework folder to encrypted app-private storage.
 * Files are read-only from Threadline's perspective; source originals are never modified.
 */
class SourceMirrorWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val tree = prefs.getString(KEY_TREE_URI, null) ?: return Result.failure()
        val root = try { DocumentFile.fromTreeUri(applicationContext, Uri.parse(tree)) } catch (_: Exception) { null }
            ?: return reportFailure("The selected source folder is no longer available. Choose it again.")
        if (!root.canRead()) return reportFailure("Android no longer grants read access to the selected source folder. Choose it again.")

        val mirrorDir = File(applicationContext.filesDir, "source-mirror").apply { mkdirs() }
        val manifestFile = File(mirrorDir, "manifest.enc")
        val legacyManifestFile = File(mirrorDir, "manifest.json")
        val manifest = try {
            when {
                manifestFile.isFile -> JSONObject(MirrorCrypto.decrypt(manifestFile.readBytes()).toString(Charsets.UTF_8))
                legacyManifestFile.isFile -> JSONObject(legacyManifestFile.readText())
                else -> JSONObject()
            }
        } catch (_: Exception) { JSONObject() }
        val oldEntries = linkedMapOf<String, JSONObject>()
        val entries = manifest.optJSONArray("entries") ?: JSONArray()
        for (i in 0 until entries.length()) {
            val entry = entries.optJSONObject(i) ?: continue
            val path = entry.optString("path")
            if (path.isNotBlank()) oldEntries[path] = entry
        }

        val presentFiles = mutableListOf<SourceFile>()
        val counters = Counters()
        val errors = JSONArray()
        val scanComplete = booleanArrayOf(true)
        try {
            collectFiles(root, "", presentFiles, errors, scanComplete)
        } catch (e: Throwable) {
            scanComplete[0] = false
            errors.put((e.message ?: "Mirror interrupted").take(240))
        }

        // A complete directory listing tells us what exists even when we process the content in
        // batches. This avoids both false deletions and repeatedly scanning only the first 200 files.
        val seen = presentFiles.map { it.path }.toSet()
        if (scanComplete[0] && !isStopped) {
            oldEntries.forEach { (path, entry) -> entry.put("sourcePresent", seen.contains(path)) }
            if (presentFiles.isEmpty()) prefs.edit().remove("mirror_cursor").apply()
            else {
                val previousCursor = prefs.getString("mirror_cursor", null)
                val priorIndex = presentFiles.indexOfFirst { it.path == previousCursor }
                // Process a contiguous batch and chain the next batch if the selected tree is larger.
                // Once the end is reached, the next independent sync starts a fresh full pass.
                val candidateStart = if (priorIndex < 0) 0 else priorIndex + 1
                val startIndex = if (candidateStart >= presentFiles.size) 0 else candidateStart
                val count = minOf(MAX_FILES, presentFiles.size - startIndex)
                val batch = presentFiles.subList(startIndex, startIndex + count)
                var lastProcessedPath: String? = null
                for (source in batch) {
                    if (isStopped) break
                    mirrorFile(source, oldEntries, errors, counters)
                    lastProcessedPath = source.path
                }
                if (lastProcessedPath != null) prefs.edit().putString("mirror_cursor", lastProcessedPath).apply()
                if (!isStopped && startIndex + count < presentFiles.size) {
                    val followOn = OneTimeWorkRequestBuilder<SourceMirrorWorker>().build()
                    WorkManager.getInstance(applicationContext).enqueueUniqueWork("threadline-source-mirror-now", ExistingWorkPolicy.APPEND_OR_REPLACE, followOn)
                }
            }
        }
        if (isStopped) scanComplete[0] = false

        val finalEntries = JSONArray()
        oldEntries.values.sortedBy { it.optString("path") }.forEach { finalEntries.put(it) }
        val syncedAt = System.currentTimeMillis()
        val out = JSONObject().put("treeUri", tree).put("syncedAt", syncedAt)
            .put("scanComplete", scanComplete[0] && !isStopped)
            .put("scanned", counters.scanned).put("copied", counters.copied).put("skipped", counters.skipped)
            .put("copiedBytes", counters.copiedBytes).put("errors", errors).put("entries", finalEntries)
        val tmp = File(mirrorDir, "manifest.json.tmp")
        return try {
            FileOutputStream(tmp).use { it.write(MirrorCrypto.encrypt(out.toString().toByteArray(Charsets.UTF_8))); it.fd.sync() }
            Files.move(tmp.toPath(), manifestFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            // Remove the prior pre-encryption manifest only after the encrypted replacement is committed.
            legacyManifestFile.delete()
            prefs.edit()
                .putLong("mirror_last_sync", syncedAt)
                .putString("mirror_last_result", JSONObject().put("ok", errors.length() == 0 && scanComplete[0])
                    .put("scanComplete", scanComplete[0]).put("scanned", counters.scanned).put("copied", counters.copied)
                    .put("skipped", counters.skipped).put("copiedBytes", counters.copiedBytes).put("errors", errors).toString())
                .apply()
            if (errors.length() > 0 || !scanComplete[0]) Result.success(DataHolder.toData(counters.scanned, counters.copied, counters.skipped))
            else Result.success(DataHolder.toData(counters.scanned, counters.copied, counters.skipped))
        } catch (e: Throwable) {
            tmp.delete()
            reportFailure("Could not commit the source mirror manifest: ${(e.message ?: "unknown error").take(120)}")
        }
    }

    private data class Counters(var scanned: Int = 0, var copied: Int = 0, var skipped: Int = 0, var copiedBytes: Long = 0L)
    private data class SourceFile(val file: DocumentFile, val path: String, val name: String)

    private fun collectFiles(
        directory: DocumentFile,
        parentPath: String,
        output: MutableList<SourceFile>,
        errors: JSONArray,
        scanComplete: BooleanArray
    ) {
        if (isStopped) { scanComplete[0] = false; return }
        val children = try { directory.listFiles().sortedBy { it.name.orEmpty().lowercase() } } catch (e: Throwable) {
            scanComplete[0] = false
            errors.put("Could not list ${parentPath.ifBlank { "selected folder" }}: ${(e.message ?: "access denied").take(120)}")
            return
        }
        for (child in children) {
            if (isStopped) { scanComplete[0] = false; return }
            val rawName = child.name?.takeIf { it.isNotBlank() } ?: "unnamed"
            val name = rawName.replace("/", "_").replace("\\", "_").take(180)
            val path = if (parentPath.isBlank()) name else "$parentPath/$name"
            if (child.isDirectory) collectFiles(child, path, output, errors, scanComplete)
            else if (child.isFile) output.add(SourceFile(child, path, name))
            if (!scanComplete[0]) return
        }
    }

    private fun mirrorFile(source: SourceFile, entries: MutableMap<String, JSONObject>, errors: JSONArray, counters: Counters) {
        val child = source.file
        val path = source.path
        val name = source.name
        counters.scanned++
        entries[path]?.put("sourcePresent", true)
        val size = child.length().coerceAtLeast(0L)
        if (size > MAX_FILE_BYTES) {
            errors.put("Skipped $path: files larger than 25 MB are not mirrored by this build.")
            counters.skipped++
            return
        }
        val available = StatFs(applicationContext.filesDir.absolutePath).availableBytes
        if (size > available - 32L * 1024 * 1024) {
            errors.put("Stopped before $path: not enough free device storage.")
            counters.skipped++
            return
        }
        try {
            // Hash every file in the current batch. Size + mtime alone isn't a reliable change detector.
            val bytes = applicationContext.contentResolver.openInputStream(child.uri)?.use { input ->
                val buffer = ByteArray(16 * 1024)
                val output = ByteArrayOutputStream(minOf(size.toInt().coerceAtLeast(0), 256 * 1024))
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    output.write(buffer, 0, n)
                    if (output.size() > MAX_FILE_BYTES) throw IllegalArgumentException("File exceeded 25 MB mirror limit")
                }
                output.toByteArray()
            } ?: throw IllegalArgumentException("Provider returned no readable stream")
            val digest = sha256(bytes)
            val old = entries[path]
            val oldBlob = old?.optString("blob").orEmpty()
            val blobDir = File(applicationContext.filesDir, "source-mirror/blobs").apply { mkdirs() }
            if (old != null && old.optString("sha256") == digest && File(blobDir, oldBlob).isFile) {
                old.put("sourcePresent", true).put("sourceUri", child.uri.toString())
                    .put("lastModified", child.lastModified()).put("size", bytes.size).put("mime", child.type ?: "application/octet-stream")
                counters.skipped++
                return
            }
            val pathKey = "src_" + sha256(path.toByteArray(Charsets.UTF_8)).take(16)
            val id = "${pathKey}_${digest.take(16)}"
            val blobName = "$id.bin"
            val target = File(blobDir, blobName)
            if (!target.isFile) {
                val tmpBlob = File(blobDir, "$blobName.tmp")
                FileOutputStream(tmpBlob).use { it.write(MirrorCrypto.encrypt(bytes)); it.fd.sync() }
                try {
                    Files.move(tmpBlob.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
                } catch (e: Throwable) {
                    tmpBlob.delete()
                    throw e
                }
            }
            val versions = JSONArray()
            if (old != null) {
                val priorVersions = old.optJSONArray("versions")
                if (priorVersions != null) for (i in 0 until priorVersions.length()) {
                    priorVersions.optJSONObject(i)?.let { versions.put(JSONObject(it.toString())) }
                }
                if (oldBlob.isNotBlank() && File(blobDir, oldBlob).isFile) {
                    val prior = JSONObject(old.toString())
                    prior.remove("versions")
                    prior.put("historicalVersion", true)
                    versions.put(prior)
                }
            }
            val mime = child.type ?: "application/octet-stream"
            val record = JSONObject()
                .put("id", id).put("name", name).put("path", path).put("sourceUri", child.uri.toString())
                .put("mime", mime).put("size", bytes.size).put("lastModified", child.lastModified())
                .put("sha256", digest).put("blob", blobName).put("copiedAt", System.currentTimeMillis())
                .put("sourcePresent", true).put("versions", versions)
            if (isTextLike(name, mime) && bytes.size <= 160_000) record.put("previewText", bytes.toString(Charsets.UTF_8).take(4000))
            entries[path] = record
            counters.copied++
            counters.copiedBytes += bytes.size
        } catch (e: Throwable) {
            errors.put("$path: ${(e.message ?: "could not mirror").take(160)}")
            counters.skipped++
        }
    }

    private fun isTextLike(name: String, mime: String): Boolean {
        return mime.startsWith("text/") || name.endsWith(".md", true) || name.endsWith(".txt", true) ||
            name.endsWith(".json", true) || name.endsWith(".kt", true) || name.endsWith(".java", true) ||
            name.endsWith(".py", true) || name.endsWith(".js", true) || name.endsWith(".ts", true) ||
            name.endsWith(".html", true) || name.endsWith(".css", true) || name.endsWith(".xml", true) ||
            name.endsWith(".yaml", true) || name.endsWith(".yml", true) || name.endsWith(".toml", true) ||
            name.endsWith(".csv", true) || name.endsWith(".sql", true) || name.endsWith(".sh", true)
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    private fun reportFailure(message: String): Result {
        applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("mirror_last_result", JSONObject().put("ok", false).put("errors", JSONArray().put(message)).toString())
            .apply()
        return Result.failure()
    }

    private object DataHolder {
        fun toData(scanned: Int, copied: Int, skipped: Int) = androidx.work.Data.Builder()
            .putInt("scanned", scanned).putInt("copied", copied).putInt("skipped", skipped).build()
    }

    companion object {
        const val PREFS = "threadline-sources"
        const val KEY_TREE_URI = "source_tree_uri"
        private const val MAX_FILES = 200
        private const val MAX_FILE_BYTES = 25L * 1024 * 1024

        fun syncNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<SourceMirrorWorker>().build()
            WorkManager.getInstance(context).enqueueUniqueWork("threadline-source-mirror-now", ExistingWorkPolicy.KEEP, request)
        }

        fun schedule(context: Context) {
            val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build()
            val request = PeriodicWorkRequestBuilder<SourceMirrorWorker>(6, TimeUnit.HOURS).setConstraints(constraints).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("threadline-source-mirror", ExistingPeriodicWorkPolicy.UPDATE, request)
        }
    }
}

/** AES-GCM encrypted blob format shared with the app's local vault key. */
internal object MirrorCrypto {
    private fun secretKey(): SecretKey {
        val alias = "threadline_local_vault_v1_7"
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun encrypt(value: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        return byteArrayOf(iv.size.toByte()) + iv + cipher.doFinal(value)
    }

    fun decrypt(value: ByteArray): ByteArray {
        require(value.isNotEmpty())
        val ivSize = value[0].toInt() and 0xff
        require(ivSize in 12..16 && value.size > ivSize + 1)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, value.copyOfRange(1, ivSize + 1)))
        return cipher.doFinal(value.copyOfRange(ivSize + 1, value.size))
    }
}
