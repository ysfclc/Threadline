package com.threadline.privateplanner

import android.animation.ValueAnimator
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.view.animation.PathInterpolator

/** Shared native property-animation system; view transforms animate without relaying out the tree. */
internal object ThreadlineMotion {
    fun enabled(reduceMotion: Boolean): Boolean = !reduceMotion && ValueAnimator.areAnimatorsEnabled()

    fun animateScreenIn(view: View, reduceMotion: Boolean) {
        if (!enabled(reduceMotion)) {
            view.alpha = 1f
            view.translationY = 0f
            return
        }
        view.alpha = 0f
        view.translationY = dp(view, 7).toFloat()
        view.animate().alpha(1f).translationY(0f).setDuration(230)
            .setInterpolator(PathInterpolator(0.16f, 1f, 0.3f, 1f)).start()
    }

    fun animateChildrenEntrance(container: LinearLayout, reduceMotion: Boolean) {
        if (!enabled(reduceMotion)) return
        container.post {
            val count = container.childCount.coerceAtMost(9)
            for (index in 0 until count) {
                val child = container.getChildAt(index) ?: continue
                if (child.visibility != View.VISIBLE) continue
                child.alpha = 0f
                child.translationY = dp(child, 10).toFloat()
                child.animate().alpha(1f).translationY(0f)
                    .setStartDelay(index * 28L)
                    .setDuration(235)
                    .setInterpolator(PathInterpolator(0.16f, 1f, 0.3f, 1f))
                    .start()
            }
        }
    }

    /** Subtle 0.965 press scale and release spring, with a reduced-motion escape hatch. */
    fun installPressFeedback(view: View, reduceMotion: () -> Boolean) {
        view.setOnTouchListener { pressedView, event ->
            if (enabled(reduceMotion())) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        pressedView.animate().cancel()
                        pressedView.animate().scaleX(0.965f).scaleY(0.965f).setDuration(85)
                            .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f)).start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        pressedView.animate().scaleX(1f).scaleY(1f).setDuration(170)
                            .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f)).start()
                    }
                }
            }
            false
        }
    }

    fun tapHaptic(view: View) {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun dp(view: View, value: Int): Int = (value * view.resources.displayMetrics.density).toInt()
}
