package com.threadline.privateplanner

import android.app.AlertDialog
import android.content.Intent
import android.content.ClipData
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.content.res.Configuration
import android.view.HapticFeedbackConstants
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.Calendar
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

internal class MainActivity : FragmentActivity() {
    private lateinit var vault: SecureVault
    private lateinit var localAi: OnDeviceAi
    private var appState: ThreadState? = null
    private var activeTab = Tab.TODAY
    private var themeMode = "system"
    private var darkMode = false
    private var modelWarming = false
    private var lastRenderedTab: Tab? = null
    private var currentScrollView: ScrollView? = null
    private var scrollToBottomAfterRender = false
    private var forceNextEntrance = true
    private var latestError: String? = null
    private var pendingBackup: ByteArray? = null
    private val background = Executors.newSingleThreadExecutor()
    private var externalFlowActive = false
    private var pendingCameraFile: File? = null
    private var pendingCameraUri: Uri? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var transientViewerFile: File? = null

    private enum class Tab { TODAY, INBOX, PROJECTS, REVIEW, TALK, STUDIO, AGENTICS }

    private val chatBubbles = mutableListOf<AssistantBubble>()
    private var pendingAssistantActions: List<AssistantAction> = emptyList()
    private var chatBusy = false
    private var aiStreamPreview = ""
    private var aiStreamingPreviewView: TextView? = null
    private var voiceSessionActive = false
    private var assistantListening = false
    private var assistantSpeaking = false
    private var voiceStatus = "Ready when you are."
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var offlineTtsAvailable = false
    private var offlineVoices: List<Voice> = emptyList()
    private var assistantRecognitionLocale: Locale = Locale.getDefault()
    private var voiceRate = 1.0f
    private var voicePitch = 1.0f
    private var selectedTtsVoiceName: String? = null
    private var modelDownloadRunning = false
    private var studioBusy = false
    private var studioIncludeContext = false
    private var reduceMotion = false
    private var autoApplyAgentActions = false
    private var studioChannel = "LinkedIn"
    private var studioFormat = "Post"
    private var studioTone = "Natural, specific, evidence-led"
    private var studioBrandRules = "Document, don't brag. Be direct, natural, concise and evidence-led. Prefer real work, decisions, trade-offs, failures and changed opinions over generic thought leadership. Avoid AI clichés, hype, engagement bait, unsupported claims and inflated results. Never invent metrics, credentials or outcomes. Keep unfinished work clearly unfinished. For iBuild, never connect the anonymous identity to the owner's real identity in public output."
    private var studioTitleInput = ""
    private var studioSourceInput = ""
    private val modelDownloadCancelled = AtomicBoolean(false)
    @Volatile private var modelWarmupStarted = false
    private var pendingQuickAction: String? = null
    private var pendingSharedText: String? = null
    private var pendingSharedUri: Uri? = null
    private var pendingReminderTaskId: String? = null
    private var overlaySettingsPending = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeMode = userPreferences().getString("theme_mode", "system") ?: "system"
        darkMode = resolveDarkMode(themeMode)
        setTheme(if (darkMode) R.style.AppTheme_Dark else R.style.AppTheme)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        applySystemBars()
        vault = SecureVault(this)
        localAi = OnDeviceAi.shared(this)
        loadUserPreferences()
        readQuickAction(intent)
        initializeOfflineSpeech()
        renderLocked()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // The manifest handles uiMode changes in-place so a system theme flip does not
        // unnecessarily tear down a running model session or force the vault to relock.
        if (themeMode == "system") {
            val nextDark = (newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            if (nextDark != darkMode) {
                darkMode = nextDark
                setTheme(if (darkMode) R.style.AppTheme_Dark else R.style.AppTheme)
                applySystemBars()
                forceNextEntrance = true
                if (appState != null && vault.isUnlocked()) renderHome() else renderLocked()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readQuickAction(intent)
        if (appState != null && vault.isUnlocked()) handlePendingQuickAction()
    }

    @Suppress("DEPRECATION")
    private fun readQuickAction(source: Intent?) {
        if (source == null) return
        val streamUri = if (source.action == Intent.ACTION_SEND) {
            if (Build.VERSION.SDK_INT >= 33) source.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else source.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        } else null
        pendingQuickAction = source.getStringExtra(EXTRA_QUICK_ACTION) ?: when (source.action) {
            Intent.ACTION_PROCESS_TEXT -> "translate"
            Intent.ACTION_SEND -> if (source.type == "text/plain") "capture" else if (streamUri != null) "shared_file" else null
            else -> null
        }
        pendingReminderTaskId = source.getStringExtra("threadline_reminder_task_id")
        pendingSharedUri = streamUri
        pendingSharedText = when (source.action) {
            Intent.ACTION_PROCESS_TEXT -> source.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            Intent.ACTION_SEND -> if (source.type == "text/plain") source.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString() else null
            else -> source.getStringExtra(EXTRA_QUICK_TEXT)
        }?.take(MAX_TASK_TEXT)
    }

    override fun onStop() {
        // System document/camera pickers temporarily cover the app. Keep the vault open only for
        // that explicit hand-off; ordinary backgrounding still drops the in-memory vault key.
        if (!externalFlowActive) {
            localAi.cancelActiveGeneration()
            endVoiceSession(render = false)
            runCatching { tts?.stop() }
            // Keep the public model warm across ordinary app switches; only the encrypted
            // personal vault and conversation are cleared here. This avoids a cold model load
            // every time the user returns from another app.
            vault.clearSession()
            appState = null
            chatBubbles.clear()
            pendingAssistantActions = emptyList()
            aiStreamPreview = ""
            aiStreamingPreviewView = null
            chatBusy = false
            voiceStatus = "Ready when you are."
            if (!isChangingConfigurations) renderLocked()
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        // Decrypted preview files exist only while a system viewer is using them.
        transientViewerFile?.delete()
        transientViewerFile = null
        refreshOfflineVoices()
        if (overlaySettingsPending) {
            overlaySettingsPending = false
            externalFlowActive = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startFloatingAssistantService()
                mainHandler.postDelayed({ renderHomeIfUnlocked() }, 500)
                showToast("Threadline's floating button is enabled. Tap it from any app for quick actions.")
            } else {
                showToast("Floating button wasn't enabled. You can enable it later from Threadline.")
            }
            renderHomeIfUnlocked()
        }
    }

    private fun refreshOfflineVoices() {
        val speech = tts ?: return
        if (!ttsReady) return
        val voices = runCatching { speech.voices.orEmpty().toList() }.getOrDefault(emptyList())
        offlineVoices = voices.filterNot { it.isNetworkConnectionRequired }
        offlineTtsAvailable = offlineVoices.isNotEmpty()
    }

    private fun openOfflineVoiceSettings() {
        try {
            externalFlowActive = true
            // Android does not expose a public ACTION_TEXT_TO_SPEECH_SETTINGS constant.
            // Try the Settings app's established TTS action, then fall back to public Accessibility settings.
            try {
                startActivityForResult(Intent("com.android.settings.TTS_SETTINGS"), REQUEST_TTS_SETTINGS)
            } catch (_: Exception) {
                startActivityForResult(
                    Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS),
                    REQUEST_TTS_SETTINGS
                )
            }
        } catch (_: Exception) {
            externalFlowActive = false
            showToast("Open Android Settings → Accessibility → Text-to-speech output and install offline voice data.")
        }
    }

    override fun onDestroy() {
        modelDownloadCancelled.set(true)
        endVoiceSession(render = false)
        speechRecognizer?.destroy()
        speechRecognizer = null
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
        localAi.cancelActiveGeneration()
        runCatching { background.execute { localAi.close() } }
        background.shutdown()
        pendingCameraFile?.delete()
        transientViewerFile?.delete(); transientViewerFile = null
        pendingBackup?.fill(0)
        pendingBackup = null
        vault.clearSession()
        super.onDestroy()
    }

    private fun userPreferences() = getSharedPreferences("threadline_preferences", MODE_PRIVATE)

    private fun loadUserPreferences() {
        val prefs = userPreferences()
        studioChannel = prefs.getString("studio_channel", studioChannel) ?: studioChannel
        studioFormat = prefs.getString("studio_format", studioFormat) ?: studioFormat
        studioTone = prefs.getString("studio_tone", studioTone) ?: studioTone
        studioBrandRules = prefs.getString("studio_brand_rules", studioBrandRules) ?: studioBrandRules
        studioIncludeContext = prefs.getBoolean("studio_include_context", studioIncludeContext)
        reduceMotion = prefs.getBoolean("reduce_motion", false)
        autoApplyAgentActions = prefs.getBoolean("auto_apply_agent_actions", false)
        voiceRate = prefs.getFloat("voice_rate", 1.0f).coerceIn(0.65f, 1.5f)
        voicePitch = prefs.getFloat("voice_pitch", 1.0f).coerceIn(0.75f, 1.3f)
        selectedTtsVoiceName = prefs.getString("speech_voice_name", null)
        val language = prefs.getString("speech_language", null)
        if (!language.isNullOrBlank()) assistantRecognitionLocale = runCatching { Locale.forLanguageTag(language) }.getOrDefault(Locale.getDefault())
    }

    private fun saveStudioPreferences() {
        userPreferences().edit()
            .putString("studio_channel", studioChannel)
            .putString("studio_format", studioFormat)
            .putString("studio_tone", studioTone)
            .putString("studio_brand_rules", studioBrandRules)
            .putBoolean("studio_include_context", studioIncludeContext)
            .apply()
    }

    private fun renderLocked() {
        val available = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        val initialized = ::vault.isInitialized && vault.isInitialized()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(color(ThreadlineTokens.NAVY))
        }
        root.addView(label("T /", 22, ThreadlineTokens.MINT, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })
        root.addView(label("THREADLINE", 28, ThreadlineTokens.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(label("A quieter place for the next action.", 16, ThreadlineTokens.LIGHT_MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })
        root.addView(card().apply {
            // The locked screen sits on an evergreen canvas; keep this surface evergreen too
            // so its light text never becomes white-on-white under the new shared card tokens.
            background = premiumPanel(20)
            elevation = 0f
            addView(label("PRIVATE BY DEFAULT", 11, ThreadlineTokens.MINT, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            addView(label("Your tasks and project notes stay encrypted on this phone. No account or analytics. Internet is used only to download an optional public AI model.", 15, ThreadlineTokens.WHITE))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        val authReady = available == BiometricManager.BIOMETRIC_SUCCESS
        val mainText = when {
            !authReady -> "Set up a strong biometric unlock in your phone's settings to use the secure vault. Threadline requires biometric authentication."
            initialized -> "Your vault is locked. Authenticate to continue."
            else -> "Create your private vault. New data is encrypted before it is written to storage."
        }
        root.addView(label(mainText, 14, ThreadlineTokens.LIGHT_MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        val action = when {
            !authReady -> "Biometrics unavailable"
            initialized -> "Unlock with biometrics"
            else -> "Create secure vault"
        }
        root.addView(button(action, true, enabled = authReady) {
            latestError = null
            if (initialized) vault.unlock(this) { state, error -> onVaultResult(state, error) }
            else vault.setup(this) { state, error -> onVaultResult(state, error) }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        root.addView(button("Restore encrypted backup", false) { launchImportPicker() },
            LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(12) })
        if (latestError != null) {
            root.addView(label(latestError!!, 13, ThreadlineTokens.ERROR), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }
        if (initialized || latestError != null) {
            root.addView(button("Reset / erase local vault", false) {
                AlertDialog.Builder(this)
                    .setTitle("Erase this vault?")
                    .setMessage("This permanently deletes this phone's encrypted Threadline data and its key. It cannot be undone. An encrypted backup can be imported after you create a new vault.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Erase permanently") { _, _ ->
                        vault.resetLocalVault()
                        latestError = null
                        renderLocked()
                    }.show()
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        setContentView(root)
        animateScreenIn(root)
        animateChildrenEntrance(root)
    }

    private fun onVaultResult(state: ThreadState?, error: String?) {
        if (state == null) {
            latestError = error ?: "Authentication did not complete."
            renderLocked()
            return
        }
        val normalizedState = runCatching {
            val cleaned = Domain.clearExpiredReminders(state)
            if (cleaned != state) vault.save(cleaned)
            cleaned
        }.getOrElse { state }
        appState = normalizedState
        latestError = null
        // A successful unlock is a real screen transition even when the previously selected
        // tab is unchanged. Give the reopened workspace its entrance once, not on every save.
        forceNextEntrance = true
        ReminderScheduler.sync(this, normalizedState.tasks)
        val shouldWarmModel = localAi.isReady() && !modelWarmupStarted
        if (shouldWarmModel) {
            modelWarmupStarted = true
            modelWarming = true
        }
        renderHome()
        if (shouldWarmModel) {
            background.execute {
                val warmed = runCatching { localAi.warmUp() }.isSuccess
                modelWarmupStarted = warmed
                mainHandler.post {
                    modelWarming = false
                    if (!warmed && appState != null && vault.isUnlocked()) showToast("Local model couldn't start. Try the compact model or import a compatible model.")
                    renderHomeIfUnlocked()
                }
            }
        }
        handlePendingQuickAction()
    }

    private fun renderHome() {
        val state = appState ?: run { renderLocked(); return }
        // Rebuild data-backed native views, but only play navigation motion when the tab changes.
        // Record saves and stream updates should not repeatedly animate the whole screen.
        val previousTab = lastRenderedTab
        val previousScrollY = currentScrollView?.scrollY ?: 0
        val shouldAnimateEntrance = forceNextEntrance || previousTab != activeTab
        val shouldScrollToBottom = scrollToBottomAfterRender || (activeTab == Tab.TALK && previousTab != activeTab && chatBubbles.isNotEmpty())
        forceNextEntrance = false
        lastRenderedTab = activeTab
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(ThreadlineTokens.BG))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(12), dp(14))
            setBackgroundColor(color(ThreadlineTokens.NAVY))
        }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brandLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandLine.addView(PulseOrbView(this@MainActivity, active = localAi.isReady() && !reduceMotion), LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(7) })
        brandLine.addView(label("THREADLINE  /  ${if (localAi.isReady()) "LOCAL AGENT" else "PRIVATE"}", 10, ThreadlineTokens.MINT, true))
        titleColumn.addView(brandLine)
        titleColumn.addView(label("Your personal system", 17, ThreadlineTokens.WHITE, true).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val headerActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        headerActions.addView(iconButton(R.drawable.ic_search, "Search Threadline") { showGlobalSearch() }, LinearLayout.LayoutParams(dp(38), dp(40)).apply { marginEnd = dp(4) })
        headerActions.addView(iconButton(R.drawable.ic_auto_awesome, "Toggle floating quick actions", active = FloatingAssistantService.isRunning) { toggleFloatingAssistant() }, LinearLayout.LayoutParams(dp(38), dp(40)).apply { marginEnd = dp(4) })
        if (activeTab != Tab.TALK) headerActions.addView(iconButton(R.drawable.ic_mic, "Talk to your local agent", active = voiceSessionActive) { activeTab = Tab.TALK; renderHome() }, LinearLayout.LayoutParams(dp(38), dp(40)).apply { marginEnd = dp(4) })
        headerActions.addView(iconButton(R.drawable.ic_settings, "Settings and appearance") { showSettings() }, LinearLayout.LayoutParams(dp(38), dp(40)))
        header.addView(headerActions)
        root.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        when (activeTab) {
            Tab.TODAY -> renderToday(content, state)
            Tab.INBOX -> renderInbox(content, state)
            Tab.PROJECTS -> renderProjects(content, state)
            Tab.REVIEW -> renderReview(content, state)
            Tab.TALK -> renderTalk(content, state)
            Tab.STUDIO -> renderStudio(content, state)
            Tab.AGENTICS -> renderAgentics(content, state)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        currentScrollView = scroll

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(color(ThreadlineTokens.NAVY))
        }
        listOf(Tab.TODAY to "Today", Tab.INBOX to "Inbox", Tab.PROJECTS to "Projects", Tab.AGENTICS to "Agent", Tab.STUDIO to "Studio").forEach { (tab, text) ->
            val label = when (tab) {
                Tab.INBOX -> if (state.tasks.count { it.status == TaskStatus.INBOX } > 0) "$text · ${state.tasks.count { it.status == TaskStatus.INBOX }}" else text
                Tab.STUDIO -> if (state.contentDrafts.count { it.stage != "ARCHIVED" } > 0) "$text · ${state.contentDrafts.count { it.stage != "ARCHIVED" }}" else text
                Tab.AGENTICS -> if (pendingAssistantActions.isNotEmpty()) "$text · ${pendingAssistantActions.size}" else text
                else -> text
            }
            nav.addView(button(label, tab == activeTab, compact = true) {
                activeTab = tab
                renderHome()
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        root.addView(nav)
        setContentView(root)
        if (shouldAnimateEntrance) {
            animateScreenIn(root)
            animateChildrenEntrance(content)
        }
        scroll.post {
            if (shouldScrollToBottom) scroll.fullScroll(View.FOCUS_DOWN)
            else if (previousTab == activeTab) scroll.scrollTo(0, previousScrollY)
        }
        scrollToBottomAfterRender = false
    }

    /** A truthful orchestration surface: one local model proposes, deterministic code validates, and the user approves. */
    private fun renderAgentics(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("THREADLINE  /  AGENT WORKSPACE", 10, ThreadlineTokens.TEAL, true), bottom(7))
        parent.addView(label("From intention to action.", 28, ThreadlineTokens.INK, true), bottom(6))
        parent.addView(label("A governed workflow, not a fake team of agents. The local model interprets your request; Threadline checks proposed changes against real records; nothing is applied without your approval.", 14, ThreadlineTokens.MUTED), bottom(16))
        if (modelWarming) {
            parent.addView(card().apply {
                addView(label("PREPARING YOUR LOCAL MODEL", 10, ThreadlineTokens.TEAL, true), bottom(6))
                addView(label("First startup can take a moment. Your model is initializing on this phone.", 12, ThreadlineTokens.MUTED), bottom(8))
                addView(ShimmerSkeletonView(this@MainActivity, darkMode, animated = motionEnabled()).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(46)) })
            }, bottom(12))
        }

        parent.addView(card().apply {
            background = premiumPanel(24)
            elevation = if (darkMode) 0f else dp(3).toFloat()
            setPadding(dp(18), dp(18), dp(18), dp(18))
            addView(label("ORCHESTRATION PIPELINE", 10, ThreadlineTokens.MINT, true), bottom(10))
            val stages = listOf(
                "01  Understand" to "Your request + selected local context",
                "02  Inspect" to "Existing tasks, projects and evidence",
                "03  Propose" to "Structured changes with real record IDs",
                "04  Validate" to "Unknown IDs and unsupported actions rejected",
                "05  Approve" to "You review each proposed change",
                "06  Apply" to "Only approved actions change your vault"
            )
            stages.forEachIndexed { index, stage ->
                val line = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(if (index == 5) 0xff1e4036.toInt() else 0xff1b302b.toInt(), 12, 0xff315146.toInt())
                    addView(label(stage.first, 12, ThreadlineTokens.MINT, true), LinearLayout.LayoutParams(dp(112), -2))
                    addView(label(stage.second, 12, ThreadlineTokens.LIGHT_MUTED))
                }
                addView(line, bottom(5))
            }
            addView(label(if (localAi.isReady()) "MODEL READY  ·  ${localAi.modelLabel()}  ·  ${localAi.runtimeLabel()}" else "MODEL NOT INSTALLED  ·  download to enable local reasoning", 10, ThreadlineTokens.MINT, true), top(8))
        }, bottom(14))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(statCard("${state.tasks.count { it.status != TaskStatus.DONE }}", "open tasks"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        row.addView(statCard("${state.projects.count { it.status == ProjectStatus.ACTIVE }}", "active projects"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        row.addView(statCard("${pendingAssistantActions.size}", "pending approvals"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        parent.addView(row, bottom(14))

        if (pendingAssistantActions.isNotEmpty()) {
            parent.addView(sectionTitle("Waiting for your approval", "These are proposals, not actions already taken."), bottom(8))
            parent.addView(button("Review ${pendingAssistantActions.size} proposed change(s)  →", true) { applyAssistantActions() }, bottom(14))
        }

        parent.addView(card().apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(label("START A RUN", 10, ThreadlineTokens.TEAL, true), bottom(6))
            addView(label("Tell the agent what is happening. It can propose task and project changes, reminders, or a private content draft from the source you give it.", 14, ThreadlineTokens.MUTED), bottom(12))
            addView(button(if (localAi.isReady()) "Start a conversation" else "Install local AI to start", true) {
                if (localAi.isReady()) { activeTab = Tab.TALK; renderHome() } else confirmModelDownload(useBetterModel = false)
            }, bottom(7))
            addView(button("Turn real work into public proof", false) { activeTab = Tab.STUDIO; renderHome() }, bottom(7))
            addView(button("Review today / reset priorities", false) { activeTab = Tab.REVIEW; renderHome() })
        }, bottom(14))

        parent.addView(sectionTitle("Guardrails", "What the current build actually does."), bottom(8))
        listOf(
            "Local inference after the model is downloaded; no AI API call.",
            "The model does not get unrestricted access to the phone or other apps.",
            "Actions are parsed into a limited schema and checked against existing IDs.",
            "No external sending, posting, purchases or calendar edits are performed.",
            "A small on-device model can be slow and may misunderstand; review every proposal."
        ).forEach { item ->
            parent.addView(label("•  $item", 13, ThreadlineTokens.MUTED), bottom(7))
        }
    }

    private fun renderStudio(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("STUDIO  /  FROM REAL WORK TO PUBLIC PROOF", 10, ThreadlineTokens.TEAL, true), bottom(7))
        parent.addView(label("Make something worth sharing.", 28, ThreadlineTokens.INK, true), bottom(6))
        parent.addView(label("Turn a real build, decision, failure, discovery or conversation into a post, carousel, video script or case study. One source of truth; different outputs.", 14, ThreadlineTokens.MUTED), bottom(16))

        parent.addView(card().apply {
            background = premiumPanel(24)
            elevation = if (darkMode) 0f else dp(3).toFloat()
            addView(label("PRIVATE BY DEFAULT  ·  LOCAL AI", 10, ThreadlineTokens.MINT, true), bottom(8))
            addView(label("Start with what actually happened.", 21, ThreadlineTokens.WHITE, true), bottom(6))
            addView(label("No invented metrics. No fake expertise. No generic AI voice. Drafts stay private until you explicitly mark them public-safe.", 13, ThreadlineTokens.LIGHT_MUTED), bottom(12))
            addView(button(if (localAi.isReady()) "Local model · ${localAi.modelLabel()}" else "Set up local AI to generate", true) {
                if (localAi.isReady()) showAiSetup() else chooseModelToDownload()
            })
        }, bottom(14))

        val title = textField("Draft name (optional)", 120).apply { setText(studioTitleInput); minLines = 1; maxLines = 2 }
        title.addTextChangedListener(simpleTextWatcher { studioTitleInput = it })
        parent.addView(sectionLabel("WHAT ARE WE MAKING?"), bottom(6))
        parent.addView(title, bottom(8))

        val source = textField("Tell the truth first: what happened, what changed, what surprised you, what failed, or what did you build? Paste notes or transcript here…", MAX_CONTENT_TEXT).apply {
            setText(studioSourceInput); minLines = 5; maxLines = 10; gravity = Gravity.TOP
        }
        source.addTextChangedListener(simpleTextWatcher { studioSourceInput = it })
        parent.addView(source, bottom(8))
        val sourceActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sourceActions.addView(button("Use recent capture", false, compact = true) { chooseStudioSource(state, completedOnly = false) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        sourceActions.addView(button("Use completed work", false, compact = true) { chooseStudioSource(state, completedOnly = true) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })
        parent.addView(sourceActions, bottom(10))

        val selectors = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        selectors.addView(button("Channel  ·  $studioChannel  ▾", false) {
            chooseStudioValue("Where should this live?", arrayOf("LinkedIn", "Personal website", "iBuild · anonymous", "Portfolio / case study", "Private journal", "Email / message", "Other"), studioChannel) { studioChannel = it; saveStudioPreferences(); renderHome() }
        }, bottom(7))
        selectors.addView(button("Format  ·  $studioFormat  ▾", false) {
            chooseStudioValue("What should it become?", arrayOf("Post", "Carousel outline", "Short video script", "Build-log episode", "Case study", "Technical breakdown", "Diagram / infographic brief", "Website story", "CV / portfolio proof", "Comment / reply", "Email draft", "Multiple angles"), studioFormat) { studioFormat = it; saveStudioPreferences(); renderHome() }
        }, bottom(7))
        selectors.addView(button("Voice  ·  ${studioTone.take(42)}  ▾", false) {
            chooseStudioValue("Choose a writing voice", arrayOf("Natural, specific, evidence-led", "Blunt and conversational", "Technical but understandable", "Reflective / changed my mind", "Dry humor, no hype", "Cinematic but credible", "Concise and professional", "Explain like I'm showing a friend"), studioTone) { studioTone = it; saveStudioPreferences(); renderHome() }
        }, bottom(7))
        parent.addView(selectors, bottom(8))

        val includeContext = android.widget.CheckBox(this).apply {
            text = "Include selected Threadline context (active projects and recent proof)"
            textSize = 13f
            setTextColor(color(ThreadlineTokens.INK))
            buttonTintList = android.content.res.ColorStateList.valueOf(color(ThreadlineTokens.TEAL))
            isChecked = studioIncludeContext
            setOnCheckedChangeListener { _, checked -> studioIncludeContext = checked; saveStudioPreferences() }
        }
        parent.addView(includeContext, bottom(10))
        parent.addView(button(if (studioBusy) "Working locally…" else "✦  Create a grounded first draft", true, enabled = localAi.isReady() && !studioBusy) {
            val raw = source.text.toString().trim()
            if (raw.length < 12) {
                source.error = "Give it a little real material first. Even a rough note is enough."
                return@button
            }
            val context = if (studioIncludeContext) buildString {
                append("\n\nSELECTED PRIVATE CONTEXT — use only when relevant; do not reveal unrelated personal data:\n")
                state.projects.filter { it.status == ProjectStatus.ACTIVE }.take(6).forEach { project ->
                    append("Project: ").append(project.title).append("; outcome: ").append(project.outcome.take(180)).append("; next action: ").append(project.nextAction.take(140)).append('\n')
                }
                state.tasks.filter { it.status == TaskStatus.DONE }.sortedByDescending { it.completedAt ?: it.updatedAt }.take(4).forEach { append("Completed work: ").append(it.text.take(180)).append('\n') }
            } else ""
            val titleValue = studioTitleInput.trim().ifBlank { raw.lineSequence().first().take(72).ifBlank { "${studioFormat} · ${LocalDate.now()}" } }
            val prompt = buildString {
                append("Create a useful, publication-quality draft from the source below.\n")
                append("DESTINATION: ").append(studioChannel).append("\nFORMAT: ").append(studioFormat).append("\nVOICE: ").append(studioTone).append("\nBRAND / PRIVACY RULES: ").append(studioBrandRules.take(1_500)).append("\n")
                append("SOURCE MATERIAL (the factual boundary):\n").append(raw.take(4_000)).append(context.take(1_200)).append("\n\n")
                append("Rules: do not invent results, metrics, dates, quotes, people, credentials, or completed features. Do not turn an unfinished experiment into a claimed success. Preserve uncertainty. Avoid generic AI clichés, exaggerated claims, engagement bait, and 'AI enthusiast' language. Prefer concrete details, the actual problem, the decision, trade-offs, what changed, and what remains unresolved. Make it sound human and specific. If the source is too thin, write a modest draft rather than inventing facts. For iBuild, do not reveal the owner's real identity or connect it to the owner's other identity. Keep the output focused on the requested format. Return the draft only, no preamble or analysis.")
            }
            studioBusy = true
            renderHome()
            background.execute {
                val generated = runCatching { localAi.complete(prompt, if (studioFormat.contains("Carousel")) 480 else 360) }
                runOnUiThread {
                    studioBusy = false
                    val result = generated.getOrNull()
                    if (appState == null || !vault.isUnlocked() || isFinishing) {
                        // Do not write into a locked vault. The user can rerun after unlocking.
                        return@runOnUiThread
                    }
                    if (result.isNullOrBlank()) {
                        showToast("Local generation failed: ${(generated.exceptionOrNull()?.message ?: "unknown error").take(120)}")
                        renderHome()
                    } else {
                        val next = Domain.addContentDraft(requireState(), titleValue, studioChannel, studioFormat, studioTone, raw, result)
                        if (next == null) showToast("Couldn't save this draft. The draft limit may have been reached.")
                        else commit(next, "Draft created and saved privately. Source kept so you can make another format.")
                    }
                }
            }
        }, bottom(14))

        parent.addView(sectionTitle("Your studio shelf", "Saved drafts remain private. Copy, edit, or explicitly mark a reviewed draft public-safe."), bottom(10))
        if (state.contentDrafts.isEmpty()) {
            parent.addView(emptyCard("Nothing published. Nothing lost.", "Your first draft will appear here. You can create several formats from the same underlying work and keep each source attached."), bottom(12))
        }
        state.contentDrafts.filter { it.stage != "ARCHIVED" }.sortedByDescending { it.updatedAt }.forEach { draft ->
            parent.addView(contentDraftCard(draft), bottom(10))
        }
        val archived = state.contentDrafts.count { it.stage == "ARCHIVED" }
        if (archived > 0) parent.addView(button("Show archived drafts · $archived", false) {
            AlertDialog.Builder(this).setTitle("Archived drafts").setItems(state.contentDrafts.filter { it.stage == "ARCHIVED" }.map { "${it.title} · ${it.channel}" }.toTypedArray()) { _, which ->
                val item = state.contentDrafts.filter { it.stage == "ARCHIVED" }[which]
                val restored = Domain.updateContentDraft(requireState(), item.id, item.title, item.channel, item.format, item.tone, item.sourceMaterial, item.body, stage = "DRAFT")
                if (restored != null) commit(restored, "Draft restored.")
            }.setNegativeButton("Close", null).show()
        }, bottom(12))
    }

    private fun chooseStudioSource(state: ThreadState, completedOnly: Boolean) {
        val taskItems = state.tasks.filter { if (completedOnly) it.status == TaskStatus.DONE else it.status != TaskStatus.DONE }
            .sortedByDescending { it.updatedAt }.take(12)
        val projectItems = if (completedOnly) state.projects.filter { it.status == ProjectStatus.DONE }.take(4) else emptyList()
        val labels = buildList {
            taskItems.forEach { add("${if (it.status == TaskStatus.DONE) "PROOF" else "CAPTURE"} · ${it.text.take(100)}") }
            projectItems.forEach { add("PROJECT · ${it.title} — ${it.outcome.ifBlank { it.nextAction }.take(100)}") }
        }
        if (labels.isEmpty()) { showToast(if (completedOnly) "No completed work to pull from yet." else "No recent captures yet. Add a rough note first."); return }
        AlertDialog.Builder(this).setTitle(if (completedOnly) "Build from completed work" else "Start from a recent capture")
            .setMessage("This copies selected source material into Studio. It does not publish anything.")
            .setItems(labels.toTypedArray()) { _, which ->
                val sourceText = if (which < taskItems.size) {
                    val task = taskItems[which]
                    listOf(
                        "Source: ${task.text}",
                        "Status: ${task.status}",
                        "Captured/updated: ${java.time.Instant.ofEpochMilli(task.updatedAt)}",
                        "Attachment: ${task.attachmentName ?: "none"}"
                    ).joinToString("\n")
                } else {
                    val project = projectItems[which - taskItems.size]
                    listOf(
                        "Project: ${project.title}",
                        "Outcome: ${project.outcome}",
                        "Next action: ${project.nextAction}",
                        "Status: ${project.status}"
                    ).joinToString("\n")
                }
                studioSourceInput = if (studioSourceInput.isBlank()) sourceText else "${studioSourceInput.trim()}\n\n--- Added source ---\n$sourceText"
                if (studioTitleInput.isBlank()) studioTitleInput = if (which < taskItems.size) taskItems[which].text.take(72) else projectItems[which - taskItems.size].title
                renderHome()
                showToast("Source added. Review it before generating.")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun contentDraftCard(draft: ContentDraft): View = card().apply {
        val privacyLabel = when (draft.privacy) { "PUBLIC_SAFE" -> "PUBLIC-SAFE · REVIEWED"; "PUBLIC" -> "PUBLIC"; else -> "PRIVATE" }
        val stageLabel = draft.stage.replace('_', ' ')
        addView(label("${draft.channel.uppercase(Locale.ROOT)}  /  ${draft.format.uppercase(Locale.ROOT)}", 10, ThreadlineTokens.TEAL, true), bottom(5))
        addView(label(draft.title, 18, ThreadlineTokens.INK, true), bottom(5))
        val bodyPreview = draft.body.take(500) + if (draft.body.length > 500) "…" else ""
        addView(label(bodyPreview, 13, ThreadlineTokens.MUTED), bottom(8))
        val metadata = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        metadata.addView(label("$privacyLabel  ·  $stageLabel", 10, if (draft.privacy == "PRIVATE") ThreadlineTokens.MUTED else ThreadlineTokens.TEAL, true), LinearLayout.LayoutParams(0, -2, 1f))
        metadata.addView(button("Copy", false, compact = true) {
            val clipboard = getSystemService(android.content.ClipboardManager::class.java)
            clipboard?.setPrimaryClip(ClipData.newPlainText(draft.title, draft.body))
            showToast("Draft copied. Review before publishing.")
        })
        addView(metadata, bottom(7))
        val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Edit", false, compact = true) { editContentDraft(draft) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
        actions.addView(button(if (draft.privacy == "PUBLIC_SAFE") "Mark private" else "Review → public-safe", true, compact = true) {
            if (draft.privacy == "PUBLIC_SAFE") {
                val updated = Domain.updateContentDraft(requireState(), draft.id, draft.title, draft.channel, draft.format, draft.tone, draft.sourceMaterial, draft.body, privacy = "PRIVATE")
                if (updated != null) commit(updated, "Draft returned to private.")
            } else {
                AlertDialog.Builder(this@MainActivity).setTitle("Mark this draft public-safe?")
                    .setMessage("You are changing the privacy boundary. Check names, client details, unpublished product information, credentials, personal information and every factual claim. This does not publish anything.")
                    .setNegativeButton("Not yet", null).setPositiveButton("I've reviewed it") { _, _ ->
                        val updated = Domain.updateContentDraft(requireState(), draft.id, draft.title, draft.channel, draft.format, draft.tone, draft.sourceMaterial, draft.body, privacy = "PUBLIC_SAFE", stage = "READY")
                        if (updated != null) commit(updated, "Marked public-safe. Nothing was published.")
                    }.show()
            }
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
        addView(actions, bottom(5))
        val bottomActions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        bottomActions.addView(button("Archive", false, compact = true) {
            val updated = Domain.updateContentDraft(requireState(), draft.id, draft.title, draft.channel, draft.format, draft.tone, draft.sourceMaterial, draft.body, stage = "ARCHIVED")
            if (updated != null) commit(updated, "Draft archived.")
        }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
        bottomActions.addView(button("Delete", false, compact = true) {
            AlertDialog.Builder(this@MainActivity).setTitle("Delete this draft?").setMessage("This cannot be undone unless you have an encrypted backup.")
                .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> commit(Domain.deleteContentDraft(requireState(), draft.id), "Draft deleted.") }.show()
        }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4) })
        addView(bottomActions)
    }

    private fun editContentDraft(draft: ContentDraft) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val title = textField("Draft title", 120).apply { setText(draft.title) }
        val source = textField("Original source / evidence", MAX_CONTENT_TEXT).apply { setText(draft.sourceMaterial); minLines = 3; maxLines = 6; gravity = Gravity.TOP }
        val body = textField("Draft content", MAX_CONTENT_TEXT).apply { setText(draft.body); minLines = 8; maxLines = 14; gravity = Gravity.TOP }
        panel.addView(label("TITLE", 10, ThreadlineTokens.TEAL, true), bottom(4)); panel.addView(title, bottom(8))
        panel.addView(label("SOURCE MATERIAL", 10, ThreadlineTokens.TEAL, true), bottom(4)); panel.addView(source, bottom(8))
        panel.addView(label("OUTPUT", 10, ThreadlineTokens.TEAL, true), bottom(4)); panel.addView(body, bottom(8))
        AlertDialog.Builder(this).setTitle("Edit studio draft").setView(panel).setNegativeButton("Cancel", null)
            .setNeutralButton("Save as review", null).setPositiveButton("Save changes", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                        val updated = Domain.updateContentDraft(requireState(), draft.id, title.text.toString(), draft.channel, draft.format, draft.tone, source.text.toString(), body.text.toString(), privacy = "PRIVATE", stage = "REVIEW")
                        if (updated == null) showToast("Draft title and output are required.") else { dialog.dismiss(); commit(updated, "Saved as private review.") }
                    }
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val updated = Domain.updateContentDraft(requireState(), draft.id, title.text.toString(), draft.channel, draft.format, draft.tone, source.text.toString(), body.text.toString())
                        if (updated == null) showToast("Draft title and output are required.") else { dialog.dismiss(); commit(updated, "Draft updated.") }
                    }
                }
                dialog.show()
            }
    }

    private fun chooseStudioValue(title: String, choices: Array<String>, selected: String, apply: (String) -> Unit) {
        val index = choices.indexOf(selected).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(choices, index) { dialog, which ->
            dialog.dismiss(); apply(choices[which])
        }.setNegativeButton("Cancel", null).show()
    }

    private fun showSettings() {
        var settingsDialog: AlertDialog? = null
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        panel.addView(label("APPEARANCE", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(button("Theme · ${themeModeLabel(themeMode)}", false) {
            settingsDialog?.dismiss()
            val modes = arrayOf("System default", "Light", "Dark")
            val values = arrayOf("system", "light", "dark")
            AlertDialog.Builder(this)
                .setTitle("Appearance")
                .setSingleChoiceItems(modes, values.indexOf(themeMode).coerceAtLeast(0)) { dialog, which ->
                    dialog.dismiss()
                    applyThemeMode(values[which])
                }
                .setNegativeButton("Cancel", null)
                .show()
        }, bottom(10))
        panel.addView(label("CONTENT STUDIO DEFAULTS", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(button("Default channel · $studioChannel", false) {
            settingsDialog?.dismiss()
            chooseStudioValue("Default publishing destination", arrayOf("LinkedIn", "Personal website", "iBuild · anonymous", "Portfolio / case study", "Private journal", "Email / message", "Other"), studioChannel) { studioChannel = it; saveStudioPreferences(); showSettings() }
        }, bottom(7))
        panel.addView(button("Default format · $studioFormat", false) {
            settingsDialog?.dismiss()
            chooseStudioValue("Default output format", arrayOf("Post", "Carousel outline", "Short video script", "Build-log episode", "Case study", "Technical breakdown", "Diagram / infographic brief", "Website story", "CV / portfolio proof", "Comment / reply", "Email draft", "Multiple angles"), studioFormat) { studioFormat = it; saveStudioPreferences(); showSettings() }
        }, bottom(7))
        panel.addView(button("Default voice · ${studioTone.take(36)}", false) {
            settingsDialog?.dismiss()
            chooseStudioValue("Default writing voice", arrayOf("Natural, specific, evidence-led", "Blunt and conversational", "Technical but understandable", "Reflective / changed my mind", "Dry humor, no hype", "Cinematic but credible", "Concise and professional", "Explain like I'm showing a friend"), studioTone) { studioTone = it; saveStudioPreferences(); showSettings() }
        }, bottom(8))
        panel.addView(button("Edit brand, voice and privacy rules", false) {
            settingsDialog?.dismiss()
            val rules = textField("Rules used by local content generation", 2_000).apply { setText(studioBrandRules); minLines = 6; maxLines = 10; gravity = Gravity.TOP }
            AlertDialog.Builder(this).setTitle("Studio brand profile")
                .setMessage("These rules guide generated drafts. They do not override the factual source or automatically change privacy labels.")
                .setView(rules).setNegativeButton("Cancel", null)
                .setPositiveButton("Save rules") { _, _ ->
                    studioBrandRules = rules.text.toString().trim().take(2_000).ifBlank { "Document real work. Do not invent claims." }
                    saveStudioPreferences()
                    showToast("Studio brand profile saved locally.")
                    showSettings()
                }.show()
        }, bottom(8))
        panel.addView(label("AGENT AUTONOMY", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(label("Direct, explicit commands like ‘add task…’ execute immediately. This optional setting lets the model apply validated local task, project, reminder and private-draft proposals without a second confirmation. It never sends messages or publishes content.", 12, ThreadlineTokens.MUTED), bottom(7))
        val autonomyToggle = android.widget.CheckBox(this).apply {
            text = "Auto-apply validated local agent actions"
            textSize = 13f
            setTextColor(color(ThreadlineTokens.INK))
            buttonTintList = android.content.res.ColorStateList.valueOf(color(ThreadlineTokens.TEAL))
            isChecked = autoApplyAgentActions
            setOnCheckedChangeListener { _, checked ->
                autoApplyAgentActions = checked
                userPreferences().edit().putBoolean("auto_apply_agent_actions", checked).apply()
                showToast(if (checked) "Agent autonomy enabled for internal Threadline actions." else "Agent proposals require your review again.")
            }
        }
        panel.addView(autonomyToggle, bottom(10))
        panel.addView(label("LOCAL AI", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(button(if (localAi.isReady()) "${localAi.modelLabel()} · ${localAi.runtimeLabel()}" else "No local model installed", false) { settingsDialog?.dismiss(); showAiSetup() }, bottom(8))
        panel.addView(label("VOICE", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(button("Speech language · ${assistantRecognitionLocale.getDisplayName(assistantRecognitionLocale)}", false) { settingsDialog?.dismiss(); selectSpeechLanguage() }, bottom(8))
        panel.addView(button("Voice controls · speed ${voiceRate}× · pitch ${voicePitch}×", false) { settingsDialog?.dismiss(); showVoiceControls() }, bottom(8))
        panel.addView(button(if (FloatingAssistantService.isRunning) "Disable floating quick actions" else "Enable floating quick actions", false) { settingsDialog?.dismiss(); toggleFloatingAssistant() }, bottom(8))
        panel.addView(label("BACKUP & OWNERSHIP", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(button("Export encrypted backup", false) { settingsDialog?.dismiss(); promptExportPassword() }, bottom(8))
        panel.addView(button("Restore encrypted backup", false) { settingsDialog?.dismiss(); launchImportPicker() }, bottom(8))
        val motionToggle = android.widget.CheckBox(this).apply {
            text = "Reduce motion / disable pulsing effects"
            textSize = 13f
            setTextColor(color(ThreadlineTokens.INK))
            buttonTintList = android.content.res.ColorStateList.valueOf(color(ThreadlineTokens.TEAL))
            isChecked = reduceMotion
            setOnCheckedChangeListener { _, checked ->
                reduceMotion = checked
                userPreferences().edit().putBoolean("reduce_motion", checked).apply()
                // Recreate the visible native view tree and refresh the independent overlay service.
                if (appState != null && vault.isUnlocked()) renderHome()
                if (FloatingAssistantService.isRunning) {
                    runCatching {
                        startService(Intent(this@MainActivity, FloatingAssistantService::class.java).apply {
                            action = FloatingAssistantService.ACTION_REFRESH_MOTION
                        })
                    }
                }
            }
        }
        panel.addView(motionToggle, bottom(8))
        panel.addView(label("PRIVACY RULES", 10, ThreadlineTokens.TEAL, true), bottom(4))
        panel.addView(label("""• Local drafts are private by default.
• Marking a draft public-safe never publishes it.
• Local model output is a suggestion, not verified truth.
• No email, calendar or social action is performed by this build.
• The floating button does not listen until you start a voice action.""", 13, ThreadlineTokens.MUTED), bottom(10))
        panel.addView(button("Daily nudge settings", false) { settingsDialog?.dismiss(); showDailyNudgePicker() }, bottom(8))
        panel.addView(button("Close vault now", false) { settingsDialog?.dismiss(); lockNow() })
        settingsDialog = AlertDialog.Builder(this).setTitle("Threadline settings").setView(panel).setNegativeButton("Done", null).create()
        settingsDialog?.show()
    }

    private fun simpleTextWatcher(onChanged: (String) -> Unit): android.text.TextWatcher = object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChanged(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: android.text.Editable?) = Unit
    }

    private fun renderToday(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("${LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))}", 13, ThreadlineTokens.MUTED))
        parent.addView(label("Your mind, in motion.", 29, ThreadlineTokens.INK, true), bottom(5))
        parent.addView(label("Less managing your life. More actually living it.", 14, ThreadlineTokens.MUTED), bottom(16))
        parent.addView(card().apply {
            background = premiumPanel(24)
            elevation = if (darkMode) 0f else dp(3).toFloat()
            setPadding(dp(20), dp(20), dp(20), dp(20))
            val heroEyebrow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(label("THREADLINE  /  YOUR PRIVATE AGENT", 10, ThreadlineTokens.MINT, true), LinearLayout.LayoutParams(0, -2, 1f))
                addView(PulseOrbView(this@MainActivity, active = localAi.isReady() && !reduceMotion), LinearLayout.LayoutParams(dp(34), dp(34)))
            }
            addView(heroEyebrow, bottom(10))
            addView(label(if (localAi.isReady()) "Tell me what’s going on." else "Make room for what’s on your mind.", 23, ThreadlineTokens.WHITE, true), bottom(7))
            addView(label(if (localAi.isReady()) "I’ll connect it to your projects, find the next useful move, and prepare changes for your approval." else "Capture first. Your data stays on this phone. Add a local model when you’re ready for private AI orchestration." , 14, ThreadlineTokens.LIGHT_MUTED), bottom(16))
            if (modelWarming) {
                addView(label("WAKING THE LOCAL MODEL", 10, ThreadlineTokens.MINT, true), bottom(5))
                addView(ShimmerSkeletonView(this@MainActivity, dark = true, animated = motionEnabled()).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(42)) }, bottom(12))
            }
            addView(button(if (localAi.isReady()) "Open your agent  ↗" else "Download local AI · 345 MB", true) {
                if (localAi.isReady()) { activeTab = Tab.AGENTICS; renderHome() } else confirmModelDownload(useBetterModel = false)
            }, bottom(8))
            if (!localAi.isReady()) {
                addView(label("One tap starts the compact model download. Nothing is bundled in the APK; once installed, inference runs on this phone.", 12, ThreadlineTokens.LIGHT_MUTED), bottom(8))
                addView(button("Choose a different model / import file", false, compact = true) { chooseModelToDownload() }, bottom(8))
            }
            val quickRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            quickRow.addView(button("🎙  Speak", false, compact = true) { startVoiceCapture() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
            quickRow.addView(button("▧  Camera", false, compact = true) { startCameraCapture() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
            quickRow.addView(button("＋  File", false, compact = true) { launchAttachmentPicker() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4) })
            addView(quickRow)
        }, bottom(18))

        val todayTasks = state.tasks.filter { it.status == TaskStatus.TODAY }.sortedBy { it.createdAt }
        val doneToday = completedToday(state)
        val statRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        statRow.addView(statCard("${todayTasks.size}/3", "focus slots"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        statRow.addView(statCard("$doneToday", "done today"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        parent.addView(statRow, bottom(10))
        val dailyNudgeText = if (ReminderScheduler.isDailyEnabled(this)) {
            val (hour, minute) = ReminderScheduler.dailyTime(this)
            "◷  Daily nudge · %02d:%02d  ·  Change".format(Locale.ROOT, hour, minute)
        } else "◷  Set a daily nudge · give me a gentle push"
        parent.addView(button(dailyNudgeText, false) { showDailyNudgePicker() }, bottom(12))
        val activeProjectCount = state.projects.count { it.status == ProjectStatus.ACTIVE }
        if (activeProjectCount > 2) {
            parent.addView(card().apply {
                background = rounded(ThreadlineTokens.ATTENTION_BG, 18, ThreadlineTokens.ATTENTION_BORDER)
                addView(label("ATTENTION CHECK  /  NO GUILT", 10, ThreadlineTokens.TEAL, true), bottom(5))
                addView(label("$activeProjectCount active projects. Which one deserves your next real push?", 16, ThreadlineTokens.INK, true), bottom(5))
                addView(label("The others aren't lost if you park them. Keep the system honest: active means you're actually moving it.", 13, ThreadlineTokens.MUTED), bottom(9))
                addView(button("Review active threads", false) { activeTab = Tab.PROJECTS; renderHome() })
            }, bottom(14))
        }

        parent.addView(sectionLabel("QUICK CAPTURE"), bottom(8))
        parent.addView(captureCard(), bottom(18))

        parent.addView(sectionTitle("Your three moves", "A task only earns a slot if it matters today."), bottom(10))
        if (todayTasks.isEmpty()) {
            parent.addView(emptyCard("Nothing is locked in yet.", "Pick one useful next step from your inbox. You don't need a perfect plan."), bottom(12))
            parent.addView(button("Choose from inbox", true) { activeTab = Tab.INBOX; renderHome() }, bottom(18))
        } else {
            todayTasks.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.TODAY), bottom(10)) }
        }

        val nextTasks = state.tasks.filter { it.status == TaskStatus.NEXT }.sortedByDescending { it.updatedAt }.take(4)
        if (nextTasks.isNotEmpty()) {
            parent.addView(sectionTitle("Ready when you are", "Next actions, not a giant backlog."), bottom(10))
            nextTasks.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.NEXT), bottom(10)) }
        }
        val activeProjects = state.projects.filter { it.status == ProjectStatus.ACTIVE }
        if (activeProjects.isNotEmpty()) {
            parent.addView(sectionTitle("Active threads", "Keep each project pointed at one next action."), bottom(10))
            activeProjects.take(3).forEach { project ->
                parent.addView(projectSummary(project), bottom(10))
            }
        }
        parent.addView(button("Close the day / review", false) { activeTab = Tab.REVIEW; renderHome() }, top(6))
    }

    private fun renderInbox(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("CAPTURE WITHOUT SORTING", 11, ThreadlineTokens.TEAL, true), bottom(7))
        parent.addView(label("Inbox", 28, ThreadlineTokens.INK, true), bottom(6))
        parent.addView(label("Get it out of your head first. Decide what it means later.", 14, ThreadlineTokens.MUTED), bottom(16))
        parent.addView(captureCard(), bottom(18))
        val inbox = state.tasks.filter { it.status == TaskStatus.INBOX }.sortedByDescending { it.createdAt }
        parent.addView(sectionTitle("${inbox.size} uncategorized ${if (inbox.size == 1) "item" else "items"}", "Keep capture easy; sorting is optional."), bottom(10))
        if (inbox.isEmpty()) {
            parent.addView(emptyCard("Inbox is clear.", "Capture an idea the moment it shows up. It doesn't need to become a task."), bottom(12))
        }
        inbox.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.INBOX), bottom(10)) }

        val later = state.tasks.filter { it.status == TaskStatus.LATER }.sortedByDescending { it.updatedAt }
        parent.addView(sectionTitle("Parked for later · ${later.size}", "You can bring these back when the timing is right."), bottom(10))
        if (later.isEmpty()) parent.addView(emptyCard("Nothing parked.", "Move work to Later when it should stop competing for attention."), bottom(12))
        later.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.LATER), bottom(10)) }
    }

    private fun renderProjects(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("WORKSTREAMS, NOT MORE BOARDS", 11, ThreadlineTokens.TEAL, true), bottom(7))
        parent.addView(label("Projects", 28, ThreadlineTokens.INK, true), bottom(6))
        parent.addView(label("Give each important thread an outcome and a visible next step.", 14, ThreadlineTokens.MUTED), bottom(16))
        parent.addView(sectionLabel("START A PROJECT"), bottom(8))
        val title = textField("Project name (required)", MAX_PROJECT_TITLE)
        val outcome = textField("What does finished look like?", MAX_PROJECT_TEXT)
        val nextAction = textField("Next physical action (optional)", MAX_PROJECT_TEXT)
        parent.addView(card().apply {
            addView(title, bottom(8)); addView(outcome, bottom(8)); addView(nextAction, bottom(10))
            addView(button("Add project", true) {
                val next = Domain.addProject(requireState(), title.text.toString(), outcome.text.toString(), nextAction.text.toString())
                if (next == null) showToast("Add a unique project name. Keep it under ${MAX_PROJECT_TITLE} characters.")
                else commit(next, "Project added.")
            })
        }, bottom(18))

        val active = state.projects.filter { it.status == ProjectStatus.ACTIVE }
        val parked = state.projects.filter { it.status == ProjectStatus.PARKED }
        val done = state.projects.filter { it.status == ProjectStatus.DONE }
        parent.addView(sectionTitle("Active · ${active.size}", "No project needs more than one next action."), bottom(10))
        if (active.isEmpty()) parent.addView(emptyCard("No active projects yet.", "Keep this list deliberately short."), bottom(12))
        active.sortedByDescending { it.updatedAt }.forEach { parent.addView(projectCard(it), bottom(10)) }
        if (parked.isNotEmpty()) {
            parent.addView(sectionTitle("Parked · ${parked.size}", "Not abandoned. Just not active today."), bottom(10))
            parked.forEach { parent.addView(projectCard(it), bottom(10)) }
        }
        if (done.isNotEmpty()) {
            parent.addView(sectionTitle("Completed · ${done.size}", "Finished threads stay out of the way."), bottom(10))
            done.take(5).forEach { parent.addView(projectCard(it), bottom(10)) }
        }
    }

    private fun renderReview(parent: LinearLayout, state: ThreadState) {
        val today = LocalDate.now().toString()
        val existing = state.reviews.firstOrNull { it.day == today }
        parent.addView(label("A SMALL RESET", 11, ThreadlineTokens.TEAL, true), bottom(7))
        parent.addView(label("Review & reset", 28, ThreadlineTokens.INK, true), bottom(6))
        parent.addView(label("Close open loops without pretending you can finish everything.", 14, ThreadlineTokens.MUTED), bottom(16))
        val todayItems = state.tasks.filter { it.status == TaskStatus.TODAY }
        val completed = completedToday(state)
        val summary = card()
        summary.addView(label("TODAY'S RECEIPT", 11, ThreadlineTokens.TEAL, true), bottom(12))
        summary.addView(label("$completed tasks completed", 20, ThreadlineTokens.INK, true), bottom(4))
        summary.addView(label("${todayItems.size} focus items still open · ${state.tasks.count { it.status == TaskStatus.INBOX }} items in inbox", 13, ThreadlineTokens.MUTED))
        parent.addView(summary, bottom(18))

        parent.addView(sectionLabel("WHAT MOVED FORWARD?"), bottom(7))
        val moved = textField("One thing that actually moved", 800).apply { minLines = 2; maxLines = 4; setText(existing?.movedForward.orEmpty()) }
        val next = textField("The next visible step", 800).apply { minLines = 2; maxLines = 4; setText(existing?.nextStep.orEmpty()) }
        val parked = textField("What can wait without guilt?", 800).apply { minLines = 2; maxLines = 4; setText(existing?.parked.orEmpty()) }
        parent.addView(card().apply {
            addView(moved, bottom(8)); addView(next, bottom(8)); addView(parked, bottom(10))
            addView(button("Save today's review", true) {
                val updated = Domain.saveReview(requireState(), moved.text.toString(), next.text.toString(), parked.text.toString())
                commit(updated, "Review saved on this device.")
            })
        }, bottom(18))
        parent.addView(sectionTitle("Close the loop", "Unfinished focus items move to Next; nothing is deleted."), bottom(8))
        parent.addView(button("Move unfinished focus to Next", false) {
            if (requireState().tasks.none { it.status == TaskStatus.TODAY }) showToast("There are no open focus items to move.")
            else AlertDialog.Builder(this)
                .setTitle("Close today's focus?")
                .setMessage("Any unfinished Today items will move to Next. Completed work and your saved review stay unchanged.")
                .setNegativeButton("Keep today open", null)
                .setPositiveButton("Move open items") { _, _ -> commit(Domain.rollDay(requireState()), "Open focus items moved to Next.") }
                .show()
        }, bottom(18))

        parent.addView(sectionTitle("Private backup", "Exports are encrypted with a separate passphrase."), bottom(8))
        parent.addView(card().apply {
            addView(label("A backup file is useful if you change phones or reset your device. It is not stored by Threadline.", 14, ThreadlineTokens.MUTED), bottom(12))
            addView(button("Export encrypted backup", true) { promptExportPassword() }, bottom(8))
            addView(button("Import encrypted backup", false) { launchImportPicker() })
        }, bottom(18))
        val recentDone = state.tasks.filter { it.status == TaskStatus.DONE }.sortedByDescending { it.completedAt ?: it.updatedAt }.take(6)
        parent.addView(sectionTitle("Recent wins", "A short record of work that is actually finished."), bottom(8))
        if (recentDone.isEmpty()) parent.addView(emptyCard("No completed tasks yet.", "Small finishes count, too."), bottom(12))
        recentDone.forEach { task ->
            parent.addView(card().apply {
                addView(label(task.text, 14, ThreadlineTokens.INK, true), bottom(3))
                val doneAt = task.completedAt ?: task.updatedAt
                val doneDate = Instant.ofEpochMilli(doneAt).atZone(ZoneId.systemDefault()).toLocalDate()
                addView(label("Completed ${doneDate.format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", 12, ThreadlineTokens.MUTED))
            }, bottom(8))
        }
        val pastReviews = state.reviews.filterNot { it.day == today }.sortedByDescending { it.day }.take(5)
        if (pastReviews.isNotEmpty()) {
            parent.addView(sectionTitle("Previous reviews", "Your notes remain private on this device."), bottom(8))
            pastReviews.forEach { review ->
                parent.addView(card().apply {
                    addView(label(review.day, 12, ThreadlineTokens.TEAL, true), bottom(5))
                    if (review.movedForward.isNotBlank()) addView(label("Moved forward: ${review.movedForward}", 13, ThreadlineTokens.INK), bottom(4))
                    if (review.nextStep.isNotBlank()) addView(label("Next: ${review.nextStep}", 13, ThreadlineTokens.INK), bottom(4))
                    if (review.parked.isNotBlank()) addView(label("Parked: ${review.parked}", 13, ThreadlineTokens.MUTED))
                }, bottom(8))
            }
        }
        parent.addView(label("Privacy model", 14, ThreadlineTokens.INK, true), bottom(6))
        parent.addView(label("AES-256-GCM encrypted local vault · Android Keystore key protected by strong biometrics · app data excluded from Android backup · no analytics · internet used only for an optional public model download.", 13, ThreadlineTokens.MUTED))
    }

    private fun initializeOfflineSpeech() {
        tts = TextToSpeech(this) { status ->
            val speech = tts
            if (status == TextToSpeech.SUCCESS && speech != null) {
                val voices = runCatching { speech.voices.orEmpty().toList() }.getOrDefault(emptyList())
                offlineVoices = voices.filterNot { it.isNetworkConnectionRequired }
                offlineTtsAvailable = offlineVoices.isNotEmpty()
                val selected = offlineVoices.firstOrNull { it.name == selectedTtsVoiceName && it.locale.language == assistantRecognitionLocale.language }
                    ?: offlineVoices.firstOrNull { it.locale.language == assistantRecognitionLocale.language }
                    ?: offlineVoices.firstOrNull { it.locale.language == "en" }
                    ?: offlineVoices.firstOrNull()
                if (selected != null) {
                    offlineTtsAvailable = runCatching {
                        speech.voice = selected
                        val languageStatus = speech.setLanguage(selected.locale)
                        speech.setSpeechRate(voiceRate)
                        speech.setPitch(voicePitch)
                        languageStatus >= TextToSpeech.LANG_AVAILABLE
                    }.getOrDefault(false)
                }
                ttsReady = true
            } else {
                ttsReady = false
                offlineTtsAvailable = false
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread {
                    assistantSpeaking = true
                    assistantListening = false
                    voiceStatus = "Threadline is speaking."
                    if (appState != null && activeTab == Tab.TALK) updateVoiceStatusWithoutRebuild()
                }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    assistantSpeaking = false
                    if (voiceSessionActive && appState != null) {
                        voiceStatus = "Your turn — speak when ready."
                        mainHandler.postDelayed({ if (voiceSessionActive && appState != null) startAssistantListening() }, 280)
                    } else if (appState != null && activeTab == Tab.TALK) {
                        voiceStatus = "Reply spoken aloud."
                        updateVoiceStatusWithoutRebuild()
                    }
                }
            }

            @Deprecated("Deprecated by Android")
            override fun onError(utteranceId: String?) {
                runOnUiThread {
                    assistantSpeaking = false
                    if (voiceSessionActive) {
                        voiceSessionActive = false
                        voiceStatus = "Offline speech failed. Check Android text-to-speech settings."
                        renderHomeIfUnlocked()
                    }
                }
            }
        })
    }

    private fun renderTalk(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("YOUR PRIVATE AGENT  /  01", 10, ThreadlineTokens.TEAL, true), bottom(7))
        parent.addView(label("Talk it through.", 29, ThreadlineTokens.INK, true), bottom(5))
        parent.addView(label("A voice-first partner that knows your open threads, helps untangle decisions, and prepares useful moves. Not another list to maintain.", 14, ThreadlineTokens.MUTED), bottom(16))

        if (localAi.isReady()) {
            parent.addView(card().apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(12), dp(12))
                val statusDot = PulseOrbView(this@MainActivity, active = localAi.isReady() && !reduceMotion)
                addView(statusDot, LinearLayout.LayoutParams(dp(24), dp(30)))
                val modelText = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(label("ON-DEVICE BRAIN READY", 10, ThreadlineTokens.TEAL, true), bottom(3))
                    addView(label("${localAi.modelLabel()} · ${localAi.modelSizeBytes() / (1024 * 1024)} MiB", 13, ThreadlineTokens.INK, true), bottom(2))
                    addView(label("Runtime · ${localAi.runtimeLabel()}", 11, ThreadlineTokens.MUTED))
                }
                addView(modelText, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
                addView(button("Manage", false, compact = true) { showAiSetup() })
            }, bottom(12))
        } else {
            parent.addView(card().apply {
                background = premiumPanel(22)
                addView(label("A BRAIN THAT STAYS YOURS", 10, ThreadlineTokens.MINT, true), bottom(6))
                addView(label("Choose your local model", 20, ThreadlineTokens.WHITE, true), bottom(5))
                addView(label("Start compact at 345 MB or choose the stronger 977 MB model. Both run on this phone after download.", 13, ThreadlineTokens.LIGHT_MUTED), bottom(12))
                addView(button("Choose model  ↗", true) { chooseModelToDownload() }, bottom(7))
                addView(button("Import a compatible .litertlm file", false, compact = true) { launchModelPicker() })
            }, bottom(12))
        }

        parent.addView(card().apply {
            background = premiumPanel(26)
            setPadding(dp(20), dp(18), dp(20), dp(18))
            gravity = Gravity.CENTER_HORIZONTAL
            addView(label("${if (voiceSessionActive) "LIVE VOICE SESSION" else "VOICE  /  LOCAL"}", 10, ThreadlineTokens.MINT, true).apply { gravity = Gravity.CENTER }, bottom(8))
            val statusText = when {
                assistantListening -> "I'm listening."
                assistantSpeaking -> "Speaking to you."
                chatBusy -> "Connecting the dots…"
                voiceSessionActive -> "Your turn. Keep going."
                else -> "Say it out loud."
            }
            addView(label(statusText, 23, ThreadlineTokens.WHITE, true).apply { gravity = Gravity.CENTER; voiceStatusView = this }, bottom(5))
            addView(label(when {
                !localAi.isReady() -> "Install a local model to start a private conversation."
                !hasOfflineVoiceFor(assistantRecognitionLocale) -> "Offline listening may work; install a matching offline voice for spoken replies."
                voiceSessionActive -> "No need to tap again after each answer. Threadline will listen for your next turn."
                else -> "Tap once to start. Speak naturally, then let the conversation continue hands-free."
            }, 13, ThreadlineTokens.LIGHT_MUTED).apply { gravity = Gravity.CENTER }, bottom(14))
            val mic = TextView(this@MainActivity).apply {
                text = when {
                    assistantListening -> "Ⅱ"
                    assistantSpeaking -> "◖))"
                    voiceSessionActive -> "■"
                    else -> "●"
                }
                textSize = 30f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(color(ThreadlineTokens.NAVY))
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color(ThreadlineTokens.MINT))
                    setStroke(dp(2), color(ThreadlineTokens.WHITE))
                }
                elevation = dp(5).toFloat()
                contentDescription = if (voiceSessionActive) "End voice conversation" else "Start voice conversation"
                voiceControlButton = this
                isClickable = localAi.isReady() && !chatBusy || voiceSessionActive
                isFocusable = isClickable
                alpha = if (localAi.isReady() || voiceSessionActive) 1f else 0.45f
                if (isClickable) ThreadlineMotion.installPressFeedback(this) { reduceMotion }
                setOnClickListener {
                    ThreadlineMotion.tapHaptic(this)
                    toggleVoiceSession()
                }
            }
            addView(mic, LinearLayout.LayoutParams(dp(78), dp(78)).apply { bottomMargin = dp(10) })
            addView(label(if (voiceSessionActive) "TAP TO END" else "TAP TO TALK", 10, ThreadlineTokens.MINT, true).apply { gravity = Gravity.CENTER }, bottom(12))
            val controls = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            controls.addView(button("Language · ${assistantRecognitionLocale.getDisplayLanguage(assistantRecognitionLocale)}", false, compact = true) { selectSpeechLanguage() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            controls.addView(button("Voice · ${voiceRate}×", false, compact = true) { showVoiceControls() }, LinearLayout.LayoutParams(0, dp(40), 0.8f).apply { marginStart = dp(4) })
            addView(controls)
        }, bottom(16))

        if (chatBubbles.isEmpty()) {
            parent.addView(label("START WITH ANYTHING", 10, ThreadlineTokens.TEAL, true), bottom(8))
            val starters = listOf(
                "What is the one thing I should move forward today?",
                "Help me finish something instead of starting another project.",
                "Find the loose ends across my projects.",
                "Turn a real thing I did into a private post draft."
            )
            starters.forEach { prompt -> parent.addView(button(prompt, false) { sendAssistantTurn(prompt, speakResponse = false) }, bottom(7)) }
        }

        chatBubbles.takeLast(18).forEach { bubble -> parent.addView(assistantBubbleView(bubble), bottom(8)) }

        if (chatBusy) {
            parent.addView(card().apply {
                addView(label("THREADLINE  /  THINKING LOCALLY", 10, ThreadlineTokens.TEAL, true), bottom(6))
                val live = label(aiStreamPreview.ifBlank { "Connecting your question to the context you already have…" }, 14, ThreadlineTokens.INK)
                live.maxLines = 8
                aiStreamingPreviewView = live
                addView(live)
            }, bottom(8))
        } else aiStreamingPreviewView = null

        if (pendingAssistantActions.isNotEmpty()) {
            parent.addView(card().apply {
                background = rounded(ThreadlineTokens.VOICE_PANEL_BG, 20, ThreadlineTokens.VOICE_PANEL_BORDER)
                addView(label("PROPOSED MOVES  /  YOUR APPROVAL", 10, ThreadlineTokens.TEAL, true), bottom(6))
                addView(label("Nothing changes until you approve it.", 13, ThreadlineTokens.MUTED), bottom(8))
                pendingAssistantActions.forEachIndexed { index, action ->
                    addView(label("${index + 1}. ${action.description(state)}", 14, ThreadlineTokens.INK, true), bottom(7))
                }
                addView(button("Review & apply  →", true) { applyAssistantActions() }, bottom(6))
                addView(button("Dismiss suggestions", false, compact = true) {
                    pendingAssistantActions = emptyList()
                    renderHome()
                })
            }, bottom(12))
        }

        val input = textField("Tell Threadline what's happening…", 1_600).apply {
            minLines = 2
            maxLines = 5
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
        }
        parent.addView(card().apply {
            addView(label("OR TYPE. SAME PRIVATE BRAIN.", 10, ThreadlineTokens.TEAL, true), bottom(6))
            addView(input, bottom(8))
            addView(button(if (chatBusy) "Thinking…" else "Send to Threadline  ↗", true, enabled = !chatBusy) {
                sendAssistantTurn(input.text.toString(), speakResponse = false)
            }, bottom(8))
            val secondary = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            secondary.addView(button("Save conversation", false, compact = true) { saveAssistantConversation() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            secondary.addView(button("New conversation", false, compact = true) { clearAssistantConversation() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
            addView(secondary)
        }, bottom(12))
        parent.addView(label("Threadline can organize its own records and prepare next moves. It never sends messages or spends money without your explicit direction.", 11, ThreadlineTokens.MUTED))
    }

    private fun assistantBubbleView(bubble: AssistantBubble): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = if (bubble.fromUser) Gravity.END else Gravity.START
        val bubbleCard = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(if (bubble.fromUser) ThreadlineTokens.MINT else surfaceColor(), 18, if (bubble.fromUser) ThreadlineTokens.MINT else ThreadlineTokens.BORDER)
            addView(label(if (bubble.fromUser) "YOU" else "THREADLINE", 10, if (bubble.fromUser) ThreadlineTokens.NAVY else ThreadlineTokens.TEAL, true), bottom(4))
            addView(label(bubble.text, 15, ThreadlineTokens.INK))
        }
        addView(bubbleCard, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = if (bubble.fromUser) dp(28) else 0
            rightMargin = if (bubble.fromUser) 0 else dp(28)
        })
    }

    private fun toggleVoiceSession() {
        if (voiceSessionActive) {
            endVoiceSession(render = false)
            voiceStatus = "Voice conversation ended."
            renderHome()
            return
        }
        if (!localAi.isReady()) {
            showAiSetup()
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            showToast("Android 12 or newer is needed for on-device speech recognition.")
            return
        }
        if (!ttsReady) {
            showToast("The speech engine is still starting. Try again in a moment.")
            return
        }
        if (!offlineTtsAvailable || !hasOfflineVoiceFor(assistantRecognitionLocale)) {
            AlertDialog.Builder(this)
                .setTitle("Install an offline voice")
                .setMessage("Threadline will only speak through an offline voice. Open Android text-to-speech settings and install voice data, or continue with voice input and text replies only.")
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Voice settings") { _, _ ->
                    openOfflineVoiceSettings()
                }
                .setPositiveButton("Continue without spoken replies") { _, _ -> beginVoiceSession() }
                .show()
            return
        }
        beginVoiceSession()
    }

    private fun beginVoiceSession() {
        voiceSessionActive = true
        voiceStatus = "Starting a private voice conversation…"
        renderHome()
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            externalFlowActive = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_ASSISTANT_PERMISSION)
        } else startAssistantListening()
    }

    private fun startAssistantListening() {
        if (!voiceSessionActive || chatBusy || assistantSpeaking || appState == null) return
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceSessionActive = false
            voiceStatus = "Microphone permission is required for voice conversations."
            updateVoiceStatusWithoutRebuild()
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            voiceSessionActive = false
            voiceStatus = "No on-device speech recognition service is available on this phone."
            updateVoiceStatusWithoutRebuild()
            showToast("Voice conversation needs an on-device speech recognition service and offline language pack.")
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        assistantListening = true
                        voiceStatus = "Listening — speak naturally."
                        updateVoiceStatusWithoutRebuild()
                    }
                    override fun onBeginningOfSpeech() { }
                    override fun onRmsChanged(rmsdB: Float) { }
                    override fun onBufferReceived(buffer: ByteArray?) { }
                    override fun onEndOfSpeech() {
                        assistantListening = false
                        voiceStatus = "Understanding what you said…"
                        updateVoiceStatusWithoutRebuild()
                    }
                    override fun onError(error: Int) {
                        speechRecognizer?.destroy()
                        speechRecognizer = null
                        assistantListening = false
                        if (voiceSessionActive) {
                            val recoverableSilence = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            if (recoverableSilence) {
                                voiceStatus = if (error == SpeechRecognizer.ERROR_NO_MATCH) "I didn’t catch that — listening again." else "Still here. Speak when you’re ready."
                                updateVoiceStatusWithoutRebuild()
                                mainHandler.postDelayed({ if (voiceSessionActive && appState != null && !chatBusy) startAssistantListening() }, 650)
                            } else {
                                voiceSessionActive = false
                                voiceStatus = "Voice input stopped (code $error). Check your offline speech service and try again."
                                updateVoiceStatusWithoutRebuild()
                            }
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        speechRecognizer?.destroy()
                        speechRecognizer = null
                        assistantListening = false
                        if (transcript.isBlank()) {
                            voiceStatus = "No speech was recognized. Try again."
                            voiceSessionActive = false
                            updateVoiceStatusWithoutRebuild()
                        } else {
                            voiceStatus = "You said: ${transcript.take(100)}"
                            sendAssistantTurn(transcript, speakResponse = true)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) { }
                    override fun onEvent(eventType: Int, params: Bundle?) { }
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, assistantRecognitionLocale.toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) {
            speechRecognizer?.destroy()
            speechRecognizer = null
            assistantListening = false
            voiceSessionActive = false
            voiceStatus = "Could not start offline voice input. Check your speech-recognition settings."
            updateVoiceStatusWithoutRebuild()
            showToast((e.message ?: "Could not start voice input.").take(150))
        }
    }

    private fun hasOfflineVoiceFor(locale: Locale): Boolean =
        offlineVoices.any { it.locale.language == locale.language }

    private fun selectSpeechLanguage() {
        val choices = listOf(
            "English" to Locale.ENGLISH,
            "Polish" to Locale("pl"),
            "Turkish" to Locale("tr"),
            "Kurdish" to Locale("ku"),
            "System default · ${Locale.getDefault().displayLanguage}" to Locale.getDefault()
        ).distinctBy { it.second.language }
        val labels = choices.map { (name, locale) -> "$name · ${locale.toLanguageTag()}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Voice conversation language")
            .setMessage("Choose the language you plan to speak. It must be supported by an on-device speech-recognition pack. Offline spoken replies require a local text-to-speech voice in the same language.")
            .setItems(labels) { _, which ->
                assistantRecognitionLocale = choices[which].second
                userPreferences().edit().putString("speech_language", assistantRecognitionLocale.toLanguageTag()).apply()
                voiceStatus = "Speech language: ${assistantRecognitionLocale.getDisplayLanguage(assistantRecognitionLocale)}."
                renderHome()
                if (!hasOfflineVoiceFor(assistantRecognitionLocale)) {
                    showToast("No matching offline speaking voice is installed. Open Offline voice settings to add one.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendAssistantTurn(rawText: String, speakResponse: Boolean) {
        val userText = rawText.trim().take(1_600)
        if (userText.isBlank()) { showToast("Say or type something first."); return }
        if (chatBusy) { showToast("Threadline is still thinking about the previous turn."); return }
        val snapshot = appState ?: return
        if (executeExplicitCommand(userText, snapshot)) return
        if (!localAi.isReady()) { showAiSetup(); return }
        chatBubbles.add(AssistantBubble(true, userText))
        aiStreamPreview = ""
        aiStreamingPreviewView = null
        chatBusy = true
        assistantListening = false
        voiceStatus = "Thinking locally about your context…"
        scrollToBottomAfterRender = true
        renderHome()
        val historySnapshot = chatBubbles.dropLast(1).takeLast(6).toList()
        val autoApplySnapshot = autoApplyAgentActions
        background.execute {
            val response = try {
                AssistantResponse.parse(localAi.chat(userText, snapshot, historySnapshot, autoApplySnapshot) { raw ->
                    val preview = extractReplyPreview(raw)
                    if (preview.isNotBlank()) mainHandler.post {
                        aiStreamPreview = preview
                        aiStreamingPreviewView?.text = preview
                    }
                }, snapshot)
            } catch (e: Exception) {
                AssistantResponse("I couldn’t run the local model. ${(e.message ?: "Check that the imported model is compatible with LiteRT-LM.").take(220)}", emptyList())
            }
            runOnUiThread {
                if (isFinishing || appState == null || !vault.isUnlocked()) return@runOnUiThread
                chatBusy = false
                aiStreamPreview = ""
                aiStreamingPreviewView = null
                chatBubbles.add(AssistantBubble(false, response.reply))
                while (chatBubbles.size > 36) chatBubbles.removeAt(0)
                voiceStatus = if (voiceSessionActive) "Preparing spoken reply…" else "Reply ready."
                scrollToBottomAfterRender = true
                if (autoApplySnapshot && response.actions.isNotEmpty()) {
                    applyAssistantActions(response.actions, clearPending = false)
                } else {
                    if (response.actions.isNotEmpty()) pendingAssistantActions = (pendingAssistantActions + response.actions).takeLast(6)
                    renderHome()
                }
                if (speakResponse && voiceSessionActive) {
                    if (offlineTtsAvailable && hasOfflineVoiceFor(assistantRecognitionLocale)) speakAssistantReply(response.reply)
                    else {
                        voiceStatus = "Reply shown as text. Install a matching offline voice for spoken replies. Listening will continue."
                        updateVoiceStatusWithoutRebuild()
                        mainHandler.postDelayed({ if (voiceSessionActive && appState != null) startAssistantListening() }, 500)
                    }
                }
            }
        }
    }

    /** Deterministic execution for clear, explicit in-app commands. Ambiguous language still goes to the model. */
    private fun executeExplicitCommand(raw: String, state: ThreadState): Boolean {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        val commandText = text.replace(Regex("(?i)^(please\\s+|can you\\s+|could you\\s+|would you\\s+|i need you to\\s+|i want you to\\s+)+"), "").trim()
        val lower = commandText.lowercase(Locale.ROOT)
        val reminderPattern = Regex("(?i)^remind me in (\\d+) (minutes?|hours?|days?) to (.+)$").matchEntire(commandText)
        if (reminderPattern != null) {
            val amount = reminderPattern.groupValues[1].toIntOrNull() ?: 0
            val unit = reminderPattern.groupValues[2].lowercase(Locale.ROOT)
            val multiplier = when { unit.startsWith("hour") -> 60; unit.startsWith("day") -> 1440; else -> 1 }
            val minutes = amount * multiplier
            val taskText = reminderPattern.groupValues[3].trim().trimEnd('.', '!')
            if (minutes !in 5..10_080 || taskText.length < 3) {
                showToast("Use a reminder between 5 minutes and 7 days, with a clear task.")
                return true
            }
            val captured = Domain.capture(state, taskText)
            val newTask = captured?.tasks?.lastOrNull()
            val next = if (captured != null && newTask != null) Domain.setReminder(captured, newTask.id, System.currentTimeMillis() + minutes * 60_000L) else null
            completeExplicitTurn(text, if (next != null) "Done. I added ‘${taskText.take(100)}’ and set a reminder for ${amount} ${unit}." else "I couldn't save that task or reminder. Check the inbox limit and try again.", next,
                if (next != null) "Task and reminder saved." else "Task/reminder failed.")
            return true
        }
        val addPrefixes = listOf("add a task ", "add task ", "create a task to ", "create a task ", "create task ", "make a task ", "make task ", "remind me to ", "add to my tasks ")
        val prefix = addPrefixes.firstOrNull { lower.startsWith(it) }
        if (prefix != null) {
            val taskText = commandText.substring(prefix.length).trim().trimEnd('.', '!')
            if (taskText.length < 3) { showToast("Give the task a little more detail."); return true }
            val next = Domain.capture(state, taskText)
            completeExplicitTurn(text, if (next != null) "Done. I added ‘${taskText.take(110)}’ to your private inbox." else "I couldn't save that task. Check the inbox limit and try again.", next,
                if (next != null) "Task added directly: $taskText" else "Task could not be added.")
            return true
        }
        val createProjectPrefix = listOf("create project ", "create a project ", "start project ", "add project ").firstOrNull { lower.startsWith(it) }
        if (createProjectPrefix != null) {
            val title = commandText.substring(createProjectPrefix.length).trim().trimEnd('.', '!')
            if (title.length < 2) { showToast("Give the project a name."); return true }
            val next = Domain.addProject(state, title, "", "Define the first concrete outcome")
            completeExplicitTurn(text, if (next != null) "Done. I created ‘${title.take(110)}’ and set its next step to define the first outcome." else "I couldn't create that project. It may already exist or the project limit may be reached.", next,
                if (next != null) "Project created: $title" else "Project could not be created.")
            return true
        }
        val completePrefix = listOf("complete task ", "finish task ", "mark task done ", "complete ").firstOrNull { lower.startsWith(it) }
        val markCompletePattern = Regex("(?i)^mark (?:task )?(.+?) (?:done|complete)$").matchEntire(commandText)
        if (completePrefix != null || markCompletePattern != null) {
            val query = if (markCompletePattern != null) markCompletePattern.groupValues[1].trim() else commandText.substring(requireNotNull(completePrefix).length).trim().trimEnd('.', '!')
            val matches = state.tasks.filter { it.status != TaskStatus.DONE && (it.text.equals(query, true) || it.text.contains(query, true) || query.contains(it.text, true)) }
            if (matches.size != 1) {
                showToast(if (matches.isEmpty()) "I couldn't find an active task matching ‘${query.take(60)}’." else "More than one task matches. Use a more specific task name.")
                return true
            }
            val task = matches.single()
            val next = Domain.moveTask(state, task.id, TaskStatus.DONE)
            completeExplicitTurn(text, if (next != null) "Done. I marked ‘${task.text.take(110)}’ complete." else "I couldn't complete that task.", next,
                if (next != null) "Completed: ${task.text}" else "Task completion failed.")
            return true
        }
        val movePattern = Regex("(?i)^(move|put) (.+) to (today|next|later|inbox)$").matchEntire(commandText)
        if (movePattern != null) {
            val query = movePattern.groupValues[2].trim().removePrefix("task ").removePrefix("Task ").trim()
            val status = when (movePattern.groupValues[3].lowercase(Locale.ROOT)) {
                "today" -> TaskStatus.TODAY; "next" -> TaskStatus.NEXT; "later" -> TaskStatus.LATER; else -> TaskStatus.INBOX
            }
            val matches = state.tasks.filter { it.status != TaskStatus.DONE && (it.text.equals(query, true) || it.text.contains(query, true)) }
            if (matches.size != 1) { showToast(if (matches.isEmpty()) "I couldn't find that task." else "More than one task matches. Please use a more specific name."); return true }
            val task = matches.single(); val next = Domain.moveTask(state, task.id, status)
            completeExplicitTurn(text, if (next != null) "Done. ‘${task.text.take(100)}’ is now ${status.name.lowercase()}." else "I couldn't move that task.", next,
                if (next != null) "Moved ‘${task.text}’ to ${status.name.lowercase()}." else "Task move failed.")
            return true
        }
        val capturePrefix = listOf("capture ", "remember ", "save this thought: ").firstOrNull { lower.startsWith(it) }
        if (capturePrefix != null) {
            val capture = commandText.substring(capturePrefix.length).trim()
            if (capture.isBlank()) { showToast("Add the thought you want me to capture."); return true }
            val next = Domain.capture(state, capture)
            completeExplicitTurn(text, if (next != null) "Captured. I saved the thought to your private inbox." else "Capture failed: the inbox limit was reached.", next,
                if (next != null) "Captured to your private inbox." else "Capture failed.")
            return true
        }
        return false
    }

    private fun completeExplicitTurn(userText: String, reply: String, next: ThreadState?, toast: String) {
        chatBubbles.add(AssistantBubble(true, userText))
        chatBubbles.add(AssistantBubble(false, reply))
        while (chatBubbles.size > 36) chatBubbles.removeAt(0)
        scrollToBottomAfterRender = true
        if (next != null) {
            if (!commit(next, toast)) {
                chatBubbles[chatBubbles.lastIndex] = AssistantBubble(false, "I couldn't save that change, so it wasn't applied. Your previous data remains unchanged.")
                renderHomeIfUnlocked()
            }
        } else {
            renderHomeIfUnlocked()
            showToast(toast)
        }
    }

    private fun updateVoiceStatusWithoutRebuild() {
        // TTS callbacks must not replace the whole view tree while the user is speaking or adjusting controls.
        voiceStatusView?.text = when {
            assistantListening -> "I'm listening."
            assistantSpeaking -> "Speaking to you."
            chatBusy -> "Connecting the dots…"
            voiceSessionActive -> "Your turn. Keep going."
            else -> voiceStatus
        }
        voiceControlButton?.text = when {
            assistantListening -> "Ⅱ"
            assistantSpeaking -> "◖))"
            voiceSessionActive -> "■"
            else -> "●"
        }
        voiceControlButton?.contentDescription = if (voiceSessionActive) "End voice conversation" else "Start voice conversation"
        voiceControlButton?.isClickable = (localAi.isReady() && !chatBusy) || voiceSessionActive
    }

    private var voiceStatusView: TextView? = null
    private var voiceControlButton: TextView? = null

    private fun showVoiceControls() {
        val rates = arrayOf("0.7× · slow", "0.85×", "1.0× · natural", "1.15×", "1.3× · fast", "1.5× · very fast")
        val values = floatArrayOf(0.7f, 0.85f, 1f, 1.15f, 1.3f, 1.5f)
        val current = values.indices.minByOrNull { kotlin.math.abs(values[it] - voiceRate) } ?: 2
        AlertDialog.Builder(this).setTitle("Spoken voice controls")
            .setMessage("Choose the speaking speed. You can then adjust pitch and select an installed offline voice for your chosen language.")
            .setSingleChoiceItems(rates, current) { dialog, which ->
                voiceRate = values[which]
                userPreferences().edit().putFloat("voice_rate", voiceRate).apply()
                runCatching { tts?.setSpeechRate(voiceRate) }
                dialog.dismiss()
                showVoicePitchControl()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showVoicePitchControl() {
        val pitches = arrayOf("Lower · 0.8×", "Natural · 1.0×", "Higher · 1.2×")
        val values = floatArrayOf(0.8f, 1f, 1.2f)
        val current = values.indices.minByOrNull { kotlin.math.abs(values[it] - voicePitch) } ?: 1
        AlertDialog.Builder(this).setTitle("Voice pitch")
            .setSingleChoiceItems(pitches, current) { dialog, which ->
                voicePitch = values[which]
                userPreferences().edit().putFloat("voice_pitch", voicePitch).apply()
                runCatching { tts?.setPitch(voicePitch) }
                dialog.dismiss()
                showTtsVoicePicker()
            }.setNegativeButton("Skip voice selection") { dialog, _ ->
                dialog.dismiss()
                renderHomeIfUnlocked()
                showToast("Voice controls saved: ${voiceRate}× speed, ${voicePitch}× pitch.")
            }.show()
    }

    private fun showTtsVoicePicker() {
        val choices = offlineVoices.filter { it.locale.language == assistantRecognitionLocale.language }
        if (choices.isEmpty()) {
            renderHomeIfUnlocked()
            showToast("No offline TTS voices are installed for ${assistantRecognitionLocale.displayLanguage}. Install voice data in Android settings.")
            return
        }
        val labels = choices.map { voice ->
            val quality = when (voice.quality) {
                Voice.QUALITY_VERY_HIGH -> "very high"
                Voice.QUALITY_HIGH -> "high"
                Voice.QUALITY_NORMAL -> "normal"
                Voice.QUALITY_LOW -> "low"
                else -> ""
            }
            "${voice.name} · ${voice.locale.displayName}${if (quality.isNotBlank()) " · $quality" else ""}"
        }.toTypedArray()
        val selected = choices.indexOfFirst { it.name == selectedTtsVoiceName }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Choose offline speaking voice")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                selectedTtsVoiceName = choices[which].name
                userPreferences().edit().putString("speech_voice_name", selectedTtsVoiceName).apply()
                runCatching { tts?.voice = choices[which]; tts?.setLanguage(choices[which].locale); tts?.setSpeechRate(voiceRate); tts?.setPitch(voicePitch) }
                dialog.dismiss()
                renderHomeIfUnlocked()
                showToast("Offline voice selected: ${choices[which].name.take(48)}")
            }.setNegativeButton("Keep current", null).show()
    }

    private fun extractReplyPreview(raw: String): String {
        val key = raw.indexOf("\"reply\"")
        if (key < 0) return ""
        val colon = raw.indexOf(':', key + 7)
        if (colon < 0) return ""
        var valueStart = colon + 1
        while (valueStart < raw.length && raw[valueStart].isWhitespace()) valueStart++
        if (valueStart >= raw.length || raw[valueStart] != '\"') return ""
        val out = StringBuilder()
        var escaped = false
        for (ch in raw.substring(valueStart + 1)) {
            if (escaped) {
                out.append(when (ch) { 'n' -> '\n'; 'r' -> '\r'; 't' -> '\t'; else -> ch })
                escaped = false
            } else when (ch) {
                '\\' -> escaped = true
                '"' -> break
                else -> out.append(ch)
            }
            if (out.length >= 700) break
        }
        return out.toString()
    }

    private fun speakAssistantReply(reply: String) {
        val speech = tts
        val matchingVoice = offlineVoices.firstOrNull { it.name == selectedTtsVoiceName && it.locale.language == assistantRecognitionLocale.language }
            ?: offlineVoices.firstOrNull { it.locale.language == assistantRecognitionLocale.language }
        if (!ttsReady || !offlineTtsAvailable || speech == null || matchingVoice == null) {
            voiceSessionActive = false
            voiceStatus = "Offline spoken reply unavailable."
            renderHomeIfUnlocked()
            return
        }
        val languageStatus = runCatching {
            speech.voice = matchingVoice
            speech.setLanguage(matchingVoice.locale)
        }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
        if (languageStatus < TextToSpeech.LANG_AVAILABLE) {
            voiceSessionActive = false
            voiceStatus = "This offline voice cannot speak the selected language."
            renderHomeIfUnlocked()
            return
        }
        assistantSpeaking = true
        assistantListening = false
        voiceStatus = "Threadline is speaking…"
        runCatching { speech.setSpeechRate(voiceRate); speech.setPitch(voicePitch) }
        val result = speech.speak(reply.take(1_800), TextToSpeech.QUEUE_FLUSH, null, "threadline-${UUID.randomUUID()}")
        if (result == TextToSpeech.ERROR) {
            assistantSpeaking = false
            voiceSessionActive = false
            voiceStatus = "Offline text-to-speech failed. Check Android voice settings."
            renderHomeIfUnlocked()
        }
    }

    private fun endVoiceSession(render: Boolean) {
        voiceSessionActive = false
        assistantListening = false
        assistantSpeaking = false
        runCatching { speechRecognizer?.cancel() }
        runCatching { speechRecognizer?.destroy() }
        speechRecognizer = null
        runCatching { tts?.stop() }
        if (render && appState != null) renderHome()
    }

    private fun renderHomeIfUnlocked() {
        if (appState != null && vault.isUnlocked() && !isFinishing) renderHome()
    }

    private fun applyAssistantActions(
        actionsToApply: List<AssistantAction> = pendingAssistantActions,
        clearPending: Boolean = true
    ) {
        var next = requireState()
        var applied = 0
        val failed = mutableListOf<String>()
        val proposals = actionsToApply
        proposals.forEach { action ->
            val candidate: ThreadState? = when (action.type) {
                "create_task" -> {
                    val captured = Domain.capture(next, action.text)
                    val newTask = captured?.tasks?.lastOrNull()
                    if (captured == null || newTask == null) null else {
                        var linked = captured
                        if (action.projectId.isNotBlank()) {
                            linked = linked.copy(tasks = linked.tasks.map { if (it.id == newTask.id) it.copy(projectId = action.projectId) else it })
                        }
                        val target = runCatching { TaskStatus.valueOf(action.status) }.getOrNull() ?: TaskStatus.NEXT
                        var candidate = if (target == TaskStatus.INBOX) linked else Domain.moveTask(linked, newTask.id, target)
                        if (candidate != null && action.reminderMinutes in 5..10_080) {
                            candidate = Domain.setReminder(candidate, newTask.id, System.currentTimeMillis() + action.reminderMinutes * 60_000L)
                        }
                        candidate
                    }
                }
                "move_task" -> runCatching { Domain.moveTask(next, action.taskId, TaskStatus.valueOf(action.status)) }.getOrNull()
                "complete_task" -> Domain.moveTask(next, action.taskId, TaskStatus.DONE)
                "set_reminder" -> Domain.setReminder(next, action.taskId, System.currentTimeMillis() + action.reminderMinutes * 60_000L)
                "clear_reminder" -> Domain.setReminder(next, action.taskId, null)
                "link_task" -> {
                    val existing = next.tasks.firstOrNull { it.id == action.taskId }
                    if (existing == null) null else next.copy(tasks = next.tasks.map {
                        if (it.id == action.taskId) it.copy(projectId = action.projectId.takeIf { id -> id.isNotBlank() }, updatedAt = System.currentTimeMillis()) else it
                    })
                }
                "create_project" -> Domain.addProject(next, action.title, action.outcome, action.nextAction)
                "create_content_draft" -> Domain.addContentDraft(next, action.title, action.channel, action.format, action.tone, action.sourceMaterial, action.body)
                "update_project" -> {
                    val current = next.projects.firstOrNull { it.id == action.projectId }
                    if (current == null) null else {
                        val status = action.status.takeIf { it.isNotBlank() }?.let { runCatching { ProjectStatus.valueOf(it) }.getOrNull() }
                        Domain.updateProject(
                            next, current.id,
                            action.outcome.ifBlank { current.outcome },
                            action.nextAction.ifBlank { current.nextAction },
                            status
                        )
                    }
                }
                else -> null
            }
            if (candidate == null) failed.add(action.description(next))
            else {
                next = candidate
                applied++
            }
        }
        if (applied == 0) {
            if (clearPending) pendingAssistantActions = emptyList()
            renderHome()
            showToast("No proposed changes could be applied. Check the project/task limits and try again.")
        } else {
            val previousPending = pendingAssistantActions
            if (clearPending) pendingAssistantActions = emptyList()
            val saved = commit(next, "$applied proposed change${if (applied == 1) "" else "s"} applied to Threadline.")
            if (!saved) {
                pendingAssistantActions = if (clearPending) proposals else (previousPending + proposals).takeLast(6)
                renderHomeIfUnlocked()
                showToast("The proposed changes could not be saved. They remain available for review; no change was committed.")
            } else if (failed.isNotEmpty()) showToast("${failed.size} proposal${if (failed.size == 1) " was" else "s were"} skipped because the current state didn’t allow them.")
        }
    }

    private fun saveAssistantConversation() {
        val transcript = chatBubbles.joinToString("\n\n") { if (it.fromUser) "YOU: ${it.text}" else "THREADLINE: ${it.text}" }
            .take(MAX_TASK_TEXT)
        if (transcript.isBlank()) { showToast("There is no conversation to save yet."); return }
        val next = Domain.capture(requireState(), transcript)
        if (next == null) showToast("Could not save the conversation. Check the inbox limit.")
        else {
            activeTab = Tab.INBOX
            commit(next, "Conversation saved to your encrypted inbox.")
        }
    }

    private fun clearAssistantConversation() {
        if (chatBubbles.isEmpty() && pendingAssistantActions.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Start a new conversation?")
            .setMessage("This clears the current chat from memory and discards unapproved suggestions. Saved captures, tasks and projects remain unchanged.")
            .setNegativeButton("Keep chatting", null)
            .setPositiveButton("New conversation") { _, _ ->
                chatBubbles.clear()
                pendingAssistantActions = emptyList()
                voiceStatus = "Ready when you are."
                background.execute { localAi.resetConversation() }
                renderHome()
            }.show()
    }

    private fun chooseModelToDownload() {
        if (modelDownloadRunning) { showToast("A model download is already running."); return }
        AlertDialog.Builder(this)
            .setTitle("Choose your local brain")
            .setMessage("All models run locally after download. The 4B reasoning model is the most capable option here, but needs about 2.5 GB free RAM and may fail or run slowly on a 4 GB phone. Keep the current model until the replacement passes integrity checks.")
            .setItems(arrayOf("Quick · Qwen3 0.6B · 345 MB", "Balanced · Qwen3 1.7B · 977 MB", "Large reasoning · Qwen3 4B Thinking · 2.48 GB")) { _, which ->
                confirmModelDownload(useBetterModel = which == 1, useLargeModel = which == 2)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmModelDownload(useBetterModel: Boolean, useLargeModel: Boolean = false) {
        if (modelDownloadRunning) { showToast("A model download is already running."); return }
        val modelLabel = when { useLargeModel -> "Qwen3-4B Thinking (about 2.48 GB)"; useBetterModel -> "Qwen3-1.7B (about 977 MB)"; else -> "Qwen3-0.6B (about 345 MB)" }
        val largeWarning = if (useLargeModel) "\n\nIMPORTANT: this model may need about 2.5 GB free RAM at runtime. On phones with 4 GB RAM it can be slow or fail to initialize. Keep at least 4 GB of free storage for download, temporary file and runtime cache." else ""
        val description = label("Threadline downloads the public $modelLabel directly into private app storage and verifies its exact size and SHA-256 before replacing your current model. Your captures, voice transcripts and project data are not uploaded. Use Wi-Fi.$largeWarning", 13, ThreadlineTokens.MUTED)
        val progressText = label("No download started.", 12, ThreadlineTokens.MUTED).apply { setPadding(0, dp(8), 0, dp(4)) }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; progress = 0 }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(6), dp(20), dp(2))
            addView(description, bottom(8))
            addView(progress, bottom(2))
            addView(progressText)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Download $modelLabel")
            .setView(panel)
            .setNegativeButton("Close", null)
            .setPositiveButton("Download model", null)
            .create()
        dialog.setOnShowListener {
            val primary = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val secondary = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            secondary.setOnClickListener {
                if (modelDownloadRunning) {
                    modelDownloadCancelled.set(true)
                    progressText.text = "Stopping the download safely…"
                    secondary.isEnabled = false
                } else dialog.dismiss()
            }
            primary.setOnClickListener {
                if (modelDownloadRunning) return@setOnClickListener
                modelDownloadCancelled.set(false)
                modelDownloadRunning = true
                modelWarming = true
                primary.isEnabled = false
                primary.text = "Downloading…"
                secondary.text = "Cancel download"
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                progressText.text = "Connecting securely to the model host…"
                background.execute {
                    var warmupFailure: Exception? = null
                    val result: Exception? = try {
                        if (useLargeModel) localAi.downloadLargeModel({ modelDownloadCancelled.get() }) { downloaded, total ->
                            mainHandler.post {
                                if (total > 0L) {
                                    progress.isIndeterminate = false
                                    progress.progress = ((downloaded * 1000L) / total).toInt().coerceIn(0, 1000)
                                    progressText.text = "${downloaded / 1_000_000} / ${total / 1_000_000} MB downloaded"
                                } else {
                                    progress.isIndeterminate = true
                                    progressText.text = "${downloaded / 1_000_000} MB downloaded"
                                }
                            }
                        } else if (useBetterModel) localAi.downloadBetterModel({ modelDownloadCancelled.get() }) { downloaded, total ->
                            mainHandler.post {
                                if (total > 0L) {
                                    progress.isIndeterminate = false
                                    progress.progress = ((downloaded * 1000L) / total).toInt().coerceIn(0, 1000)
                                    progressText.text = "${downloaded / 1_000_000} / ${total / 1_000_000} MB downloaded"
                                } else {
                                    progress.isIndeterminate = true
                                    progressText.text = "${downloaded / 1_000_000} MB downloaded"
                                }
                            }
                        } else localAi.downloadDefaultModel({ modelDownloadCancelled.get() }) { downloaded, total ->
                            mainHandler.post {
                                if (total > 0L) {
                                    progress.isIndeterminate = false
                                    progress.progress = ((downloaded * 1000L) / total).toInt().coerceIn(0, 1000)
                                    progressText.text = "${downloaded / 1_000_000} / ${total / 1_000_000} MB downloaded"
                                } else {
                                    progress.isIndeterminate = true
                                    progressText.text = "${downloaded / 1_000_000} MB downloaded"
                                }
                            }
                        }
                        mainHandler.post { progressText.text = "Preparing the local model for faster first use…" }
                        try {
                            localAi.warmUp()
                            localAi.commitModelInstall()
                        } catch (e: Exception) {
                            warmupFailure = e
                            runCatching { localAi.rollbackModelInstall() }
                        }
                        null
                    } catch (e: Exception) { e }
                    mainHandler.post {
                        modelDownloadRunning = false
                        modelWarming = false
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        if (result == null) {
                            modelWarmupStarted = warmupFailure == null
                            dialog.dismiss()
                            if (warmupFailure == null) showToast("$modelLabel installed and prepared for local use.")
                            else AlertDialog.Builder(this)
                                .setTitle("Model downloaded, but couldn't start")
                                .setMessage("The file passed integrity checks, but this phone couldn't initialize it. Try the compact model or import a model compatible with this device.\n\n${(warmupFailure?.message ?: "Unknown runtime error").take(260)}")
                                .setPositiveButton("Choose another model") { _, _ -> chooseModelToDownload() }
                                .setNegativeButton("Close", null).show()
                            renderHomeIfUnlocked()
                        } else {
                            progressText.text = (result.message ?: "Download failed.").take(260)
                            primary.text = "Retry download"
                            primary.isEnabled = true
                            secondary.text = "Close"
                            secondary.isEnabled = true
                        }
                    }
                }
            }
        }
        dialog.show()
    }

    private fun toggleFloatingAssistant() {
        if (FloatingAssistantService.isRunning) {
            stopService(Intent(this, FloatingAssistantService::class.java))
            showToast("Floating button hidden.")
            mainHandler.postDelayed({ renderHomeIfUnlocked() }, 400)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            overlaySettingsPending = true
            externalFlowActive = true
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                overlaySettingsPending = false
                externalFlowActive = false
                showToast("Open Android Settings → Special app access → Display over other apps → Threadline.")
            }
            return
        }
        startFloatingAssistantService()
        showToast("Floating button enabled. It stays available over other apps until you turn it off.")
        mainHandler.postDelayed({ renderHomeIfUnlocked() }, 500)
    }

    private fun startFloatingAssistantService() {
        val service = Intent(this, FloatingAssistantService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, service) else startService(service)
    }

    private fun handlePendingQuickAction() {
        val action = pendingQuickAction ?: return
        val sharedText = pendingSharedText.orEmpty()
        val reminderTaskId = pendingReminderTaskId
        val sharedUri = pendingSharedUri
        pendingQuickAction = null
        pendingSharedText = null
        pendingSharedUri = null
        pendingReminderTaskId = null
        mainHandler.post {
            if (appState == null || !vault.isUnlocked()) return@post
            when (action.lowercase(Locale.ROOT)) {
                "capture" -> showQuickCaptureDialog(sharedText)
                "talk" -> {
                    activeTab = Tab.TALK
                    renderHome()
                    if (localAi.isReady()) toggleVoiceSession() else chooseModelToDownload()
                }
                "studio" -> { activeTab = Tab.STUDIO; renderHome() }
                "voice" -> startVoiceCapture()
                "photo" -> startCameraCapture()
                "file" -> launchAttachmentPicker()
                "shared_file" -> if (sharedUri != null) saveSelectedAttachment(sharedUri) else launchAttachmentPicker()
                "translate" -> showTranslationDialog(sharedText)
                "open" -> {
                    renderHome()
                    reminderTaskId?.let { showReminderAction(it) }
                }
            }
        }
    }

    private fun showReminderAction(taskId: String) {
        val task = appState?.tasks?.firstOrNull { it.id == taskId } ?: return
        AlertDialog.Builder(this)
            .setTitle("A nudge you asked for")
            .setMessage(task.text)
            .setNegativeButton("Later") { _, _ ->
                val updated = Domain.setReminder(requireState(), task.id, System.currentTimeMillis() + 60 * 60 * 1000L)
                if (updated != null) commit(updated, "Nudged again in one hour.")
            }
            .setNeutralButton("Open / edit") { _, _ -> editTask(task) }
            .setPositiveButton("Done") { _, _ ->
                val updated = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                if (updated != null) commit(updated, "Closed the loop. Reminder cleared.")
            }
            .show()
    }

    private fun showQuickCaptureDialog(prefill: String = "") {
        val input = textField("Capture anything. Don't organize it yet…", MAX_TASK_TEXT).apply {
            minLines = 3
            maxLines = 7
            setText(prefill)
            setSelection(text.length)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Quick capture")
            .setMessage("Private by default. You can connect it to a project later.")
            .setView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0); addView(input) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save to inbox", null)
            .setNeutralButton("Talk instead", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val next = Domain.capture(requireState(), input.text.toString())
                if (next == null) input.error = "Add a thought to save." else {
                    dialog.dismiss()
                    commit(next, "Captured. Threadline will keep it out of your way until you're ready.")
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                activeTab = Tab.TALK
                renderHome()
                if (localAi.isReady()) toggleVoiceSession() else chooseModelToDownload()
            }
        }
        dialog.show()
        input.requestFocus()
    }

    private fun showTranslationDialog(prefill: String = "") {
        val input = textField("Paste or share text to translate", MAX_TASK_TEXT).apply { minLines = 3; maxLines = 7; setText(prefill) }
        val language = textField("Translate into (e.g. Polish, English, Turkish)", 40).apply { setText("Polish"); setSingleLine(true) }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0); addView(input, bottom(8)); addView(language) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Translate privately")
            .setMessage("Translation runs on your downloaded local model. Nothing is sent to a translation service.")
            .setView(panel)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Translate on device", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val source = input.text.toString().trim()
                val target = language.text.toString().trim()
                if (source.isBlank()) { input.error = "Paste or share text first."; return@setOnClickListener }
                if (target.isBlank()) { language.error = "Choose a target language."; return@setOnClickListener }
                if (!localAi.isReady()) { dialog.dismiss(); chooseModelToDownload(); return@setOnClickListener }
                dialog.dismiss()
                showLocalTransform(source, "Translate into $target")
            }
        }
        dialog.show()
    }

    private fun showLocalTransform(source: String, instruction: String) {
        val output = label("Preparing local AI…", 14, ThreadlineTokens.INK).apply { setPadding(dp(20), dp(12), dp(20), dp(12)) }
        val dialog = AlertDialog.Builder(this).setTitle(instruction).setView(output).setPositiveButton("Done", null).create()
        dialog.show()
        background.execute {
            val result = try { localAi.complete("$instruction. Return only the result, no introduction. Preserve meaning and tone.\n\nText:\n${source.take(5_000)}", 384) }
            catch (e: Exception) { "Local translation failed: ${(e.message ?: "Check that the model is installed.").take(220)}" }
            runOnUiThread { if (!isFinishing) output.text = result }
        }
    }

    private fun captureCard(): View {
        val edit = textField("What's on your mind? Don't organize it yet…", MAX_TASK_TEXT).apply {
            minLines = 2
            maxLines = 4
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        return card().apply {
            addView(label("CAPTURE STUDIO", 10, ThreadlineTokens.TEAL, true), bottom(7))
            addView(label("Get it out of your head.", 19, ThreadlineTokens.INK, true), bottom(4))
            addView(label("Thoughts, conversations, photos and files. Keep the original; decide what it means later.", 13, ThreadlineTokens.MUTED), bottom(12))
            addView(edit, bottom(10))
            addView(button("Save to inbox  →", true) {
                val value = edit.text.toString()
                val next = Domain.capture(requireState(), value)
                if (next == null) showToast("Capture something up to $MAX_TASK_TEXT characters.")
                else commit(next, "Saved privately. You can decide what it means later.")
            }, bottom(10))
            val media = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            media.addView(button("🎙 Voice", false, compact = true) { startVoiceCapture() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
            media.addView(button("▧ Photo", false, compact = true) { startCameraCapture() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
            media.addView(button("＋ File", false, compact = true) { launchAttachmentPicker() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4) })
            addView(media)
            addView(label("Voice transcription runs on-device where supported. Attachments are stored inside your encrypted vault.", 11, ThreadlineTokens.MUTED).apply { setPadding(0, dp(9), 0, 0) })
        }
    }

    private fun taskCard(task: TaskItem, state: ThreadState, from: TaskStatus): View {
        val card = card()
        val associatedProject = state.projects.firstOrNull { it.id == task.projectId }
        if (associatedProject != null) card.addView(label(associatedProject.title.uppercase(), 10, ThreadlineTokens.TEAL, true), bottom(6))
        card.addView(label(task.text, 16, ThreadlineTokens.INK, true).apply {
            maxLines = 6
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, bottom(6))
        val created = Instant.ofEpochMilli(task.createdAt).atZone(ZoneId.systemDefault()).toLocalDate()
        card.addView(label("Added ${created.format(DateTimeFormatter.ofPattern("d MMM"))} · ${task.status.name.lowercase(Locale.ROOT).replace('_', ' ')}", 12, ThreadlineTokens.MUTED), bottom(10))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        when (from) {
            TaskStatus.TODAY -> {
                actions.addView(button("Done", true, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                    if (next != null) commit(next, "One less open loop.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Move to Next", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Moved out of today's focus.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.INBOX -> {
                val todayFull = state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS
                actions.addView(button("Today", true, compact = true, enabled = !todayFull) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next == null) showToast("Today already has three focus items. Move one to Next first.")
                    else commit(next, "Added to today's focus.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Next", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Promoted to Next.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
                actions.addView(button("Delete", false, compact = true) {
                    AlertDialog.Builder(this)
                        .setTitle("Delete this item?")
                        .setMessage("This removes it from your encrypted vault. It cannot be undone unless you have a backup.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ -> commit(Domain.deleteTask(requireState(), task.id), "Item deleted.") }
                        .show()
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.NEXT -> {
                val canFocus = state.tasks.count { it.status == TaskStatus.TODAY } < MAX_TODAY_TASKS
                actions.addView(button("Focus today", true, compact = true, enabled = canFocus) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next != null) commit(next, "Added to today's focus.")
                    else showToast("Today already has three focus items.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Later", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.LATER)
                    if (next != null) commit(next, "Parked for later.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
                actions.addView(button("Done", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                    if (next != null) commit(next, "Marked done.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.LATER -> {
                val canFocus = state.tasks.count { it.status == TaskStatus.TODAY } < MAX_TODAY_TASKS
                actions.addView(button("Bring to Next", true, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Brought back to Next.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Today", false, compact = true, enabled = canFocus) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next != null) commit(next, "Added to today's focus.")
                    else showToast("Today already has three focus items.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            else -> Unit
        }
        if (actions.childCount > 0) card.addView(actions, bottom(8))
        if (task.status != TaskStatus.DONE) {
            task.reminderAt?.let { whenAt ->
                val whenText = Instant.ofEpochMilli(whenAt).atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("EEE, d MMM · HH:mm"))
                card.addView(label("◷  Nudge scheduled · $whenText", 12, ThreadlineTokens.TEAL, true), bottom(7))
            }
            val reminderActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            reminderActions.addView(button(if (task.reminderAt == null) "◷  Remind me" else "Change reminder", false, compact = true) {
                showReminderPicker(task)
            }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
            if (task.reminderAt != null) reminderActions.addView(button("Clear", false, compact = true) {
                val updated = Domain.setReminder(requireState(), task.id, null)
                if (updated != null) commit(updated, "Reminder cleared.")
            }, LinearLayout.LayoutParams(0, dp(38), 0.45f).apply { marginStart = dp(4) })
            card.addView(reminderActions, bottom(8))
        }
        if (!task.attachmentName.isNullOrBlank()) {
            card.addView(label("▧  ${task.attachmentName}  ·  ${task.attachmentMime ?: "file"}", 12, ThreadlineTokens.TEAL, true), bottom(7))
            card.addView(button("View attachment", false, compact = true) { viewAttachment(task) }, bottom(8))
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(button("Edit", false, compact = true) { editTask(task) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
        tools.addView(button(if (localAi.isReady()) "✦ Think" else "AI setup", true, compact = true) {
            if (localAi.isReady()) processWithLocalAi(task) else showAiSetup()
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        tools.addView(button("Delete", false, compact = true) {
            AlertDialog.Builder(this).setTitle("Delete this capture?")
                .setMessage("The capture and its encrypted attachment will be removed from this phone. This cannot be undone unless you have a backup.")
                .setNegativeButton("Keep it", null)
                .setPositiveButton("Delete") { _, _ -> commit(Domain.deleteTask(requireState(), task.id), "Capture deleted.") }
                .show()
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3) })
        card.addView(tools)
        return card
    }

    private fun showDailyNudgePicker() {
        if (ReminderScheduler.isDailyEnabled(this)) {
            val (hour, minute) = ReminderScheduler.dailyTime(this)
            AlertDialog.Builder(this)
                .setTitle("Your daily nudge")
                .setMessage("Threadline will send a private, content-free reminder every day at %02d:%02d. You can turn it off any time.".format(Locale.ROOT, hour, minute))
                .setItems(arrayOf("Change time", "Turn off daily nudge")) { _, which ->
                    if (which == 0) showDailyNudgeTimePicker(hour, minute) else {
                        ReminderScheduler.disableDailyNudge(this)
                        showToast("Daily nudge turned off.")
                        renderHome()
                    }
                }
                .setNegativeButton("Close", null)
                .show()
        } else showDailyNudgeTimePicker(9, 0)
    }

    private fun showDailyNudgeTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            ReminderScheduler.setDailyNudge(this, selectedHour, selectedMinute)
            showToast("Daily nudge set for %02d:%02d. Android may delay it in battery-saving mode.".format(Locale.ROOT, selectedHour, selectedMinute))
            renderHome()
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            }
        }, hour, minute, true).show()
    }

    private fun showReminderPicker(task: TaskItem) {
        val initial = Calendar.getInstance().apply {
            timeInMillis = task.reminderAt?.takeIf { it > System.currentTimeMillis() }
                ?: (System.currentTimeMillis() + 60 * 60 * 1000L)
        }
        DatePickerDialog(
            this,
            { _, year, month, day ->
                val selected = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, initial.get(Calendar.HOUR_OF_DAY))
                    set(Calendar.MINUTE, initial.get(Calendar.MINUTE))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                TimePickerDialog(this, { _, hour, minute ->
                    selected.set(Calendar.HOUR_OF_DAY, hour)
                    selected.set(Calendar.MINUTE, minute)
                    val time = selected.timeInMillis
                    if (time <= System.currentTimeMillis()) {
                        showToast("Choose a time in the future.")
                        return@TimePickerDialog
                    }
                    val updated = Domain.setReminder(requireState(), task.id, time)
                    if (updated == null) {
                        showToast("Could not save that reminder.")
                        return@TimePickerDialog
                    }
                    commit(updated, "Nudge scheduled. Threadline will remind you locally.")
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
                    }
                }, initial.get(Calendar.HOUR_OF_DAY), initial.get(Calendar.MINUTE), true).show()
            },
            initial.get(Calendar.YEAR), initial.get(Calendar.MONTH), initial.get(Calendar.DAY_OF_MONTH)
        ).apply { datePicker.minDate = System.currentTimeMillis() - 1000 }.show()
    }

    private fun editTask(task: TaskItem) {
        val input = textField("Capture text", MAX_TASK_TEXT).apply { setText(task.text); minLines = 2; maxLines = 4 }
        AlertDialog.Builder(this)
            .setTitle("Edit capture")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save changes") { _, _ ->
                val next = Domain.updateTask(requireState(), task.id, input.text.toString())
                if (next == null) showToast("The capture cannot be empty or longer than $MAX_TASK_TEXT characters.")
                else commit(next, "Capture updated.")
            }
            .show()
    }

    private fun showGlobalSearch() {
        val input = textField("Search captures, projects, reviews and Studio drafts", 100).apply { setSingleLine(true) }
        AlertDialog.Builder(this)
            .setTitle("Find a thread")
            .setMessage("Search your encrypted captures, project context and private content drafts on this device.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Search", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val q = input.text.toString().trim()
                        if (q.isBlank()) { input.error = "Enter a search term"; return@setOnClickListener }
                        val state = requireState()
                        val matches = buildList {
                            state.tasks.filter { it.text.contains(q, true) || it.attachmentName.orEmpty().contains(q, true) }
                                .take(20).forEach { add("${it.status.name}  ·  ${it.text}${it.attachmentName?.let { name -> "\nAttachment: $name" }.orEmpty()}") }
                            state.projects.filter { it.title.contains(q, true) || it.outcome.contains(q, true) || it.nextAction.contains(q, true) }
                                .take(10).forEach { add("PROJECT  ·  ${it.title}\n${it.nextAction.ifBlank { it.outcome }}") }
                            state.reviews.filter { it.movedForward.contains(q, true) || it.nextStep.contains(q, true) || it.parked.contains(q, true) }
                                .take(5).forEach { add("REVIEW  ·  ${it.day}\n${it.movedForward} ${it.nextStep} ${it.parked}".trim()) }
                            state.contentDrafts.filter { it.title.contains(q, true) || it.body.contains(q, true) || it.sourceMaterial.contains(q, true) }
                                .take(10).forEach { add("STUDIO  ·  ${it.title} [${it.privacy.lowercase(Locale.ROOT)}]\n${it.body.take(220)}") }
                        }.take(25)
                        dialog.dismiss()
                        val body = if (matches.isEmpty()) "No matches yet. Try a different word." else matches.joinToString("\n\n────────────────\n\n")
                        AlertDialog.Builder(this).setTitle("${matches.size} result${if (matches.size == 1) "" else "s"}")
                            .setMessage(body).setPositiveButton("Done", null).show()
                    }
                }
                dialog.show()
            }
    }

    private fun showAiSetup() {
        val size = localAi.modelSizeBytes()
        val status = if (localAi.isReady()) {
            "${localAi.modelLabel()} is installed (${size / (1024 * 1024)} MB). The Talk screen can use it to reason about your actual projects and open tasks. Your personal data stays on this device."
        } else {
            "No local language model is installed yet. Threadline includes Google's LiteRT-LM runtime. Download a compact model or a stronger optional model, or import a compatible .litertlm file."
        }
        val guidance = if (localAi.isReady()) "\n\nSwitch to the 1.7B model (about 977 MB) or the large Qwen3-4B Thinking model (about 2.48 GB; may require about 2.5 GB free RAM), or import another compatible .litertlm file. Switching replaces the current model only after download verification." else "\n\nChoose Qwen3-0.6B (about 345 MB), Qwen3-1.7B (about 977 MB), or the large Qwen3-4B Thinking model (about 2.48 GB; substantial RAM required). Download requires internet once; inference then runs on-device. Spoken replies also need a matching offline voice in Android settings."
        val message = label(status + guidance, 14, ThreadlineTokens.INK)
        AlertDialog.Builder(this)
            .setTitle("Local AI setup")
            .setView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), dp(2)); addView(message) })
            .setNegativeButton(if (localAi.isReady()) "Switch model" else "Close", null)
            .setNeutralButton(if (localAi.isReady()) "Remove model" else "Choose model", null)
            .setPositiveButton(if (localAi.isReady()) "Import / replace" else "Import model") { _, _ -> launchModelPicker() }
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                        if (localAi.isReady()) { dialog.dismiss(); chooseModelToDownload() } else dialog.dismiss()
                    }
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                        if (localAi.isReady()) {
                            AlertDialog.Builder(this).setTitle("Remove local model?")
                                .setMessage("This deletes only the downloaded AI model. Your encrypted captures and projects remain unchanged.")
                                .setNegativeButton("Cancel", null)
                                .setPositiveButton("Remove") { _, _ ->
                                    background.execute {
                                        localAi.removeModel()
                                        modelWarmupStarted = false
                                        runOnUiThread { showToast("Local model removed."); if (appState != null) renderHome() else renderLocked() }
                                    }
                                }.show()
                        } else {
                            dialog.dismiss()
                            chooseModelToDownload()
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun launchModelPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Choose a .litertlm model")
        }
        try {
            externalFlowActive = true
            startActivityForResult(intent, REQUEST_MODEL)
        } catch (e: Exception) {
            externalFlowActive = false
            showToast("Could not open the file picker.")
        }
    }

    private fun processWithLocalAi(task: TaskItem) {
        if (!localAi.isReady()) { showAiSetup(); return }
        showToast(if (task.attachmentMime?.startsWith("image/") == true) "Reading image text locally…" else "Working locally on this phone…")
        if (task.attachmentMime?.startsWith("image/") == true) {
            val bytes = try { Base64.decode(task.attachmentBase64 ?: "", Base64.DEFAULT) } catch (_: Exception) { byteArrayOf() }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            bytes.fill(0)
            if (bitmap == null) {
                showToast("Could not open this image for local text recognition.")
                return
            }
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { visionText ->
                    val extracted = visionText.text.take(5_000)
                    bitmap.recycle()
                    recognizer.close()
                    background.execute {
                        val result = try {
                            if (extracted.isBlank()) "No readable text was found in this image. The current local model is text-only; try a clearer image containing text, or import a compatible vision-language model."
                            else localAi.complete(
                                "Analyze this private image capture using the OCR text below. Explain what it appears to contain, extract important facts, and suggest one practical next move. Do not invent details not present in the text. Use headings WHAT I HEAR, POSSIBLE NEXT MOVE, OPEN QUESTION.\n\nOCR TEXT:\n$extracted",
                                256
                            )
                        } catch (e: Exception) { "LOCAL AI COULD NOT PROCESS THIS CAPTURE\n\n${(e.message ?: "The model could not be loaded.").take(300)}" }
                        runOnUiThread { if (!isFinishing && appState != null && vault.isUnlocked()) showLocalAiResult(result) }
                    }
                }
                .addOnFailureListener { error ->
                    bitmap.recycle()
                    recognizer.close()
                    showToast("Local image text recognition failed: ${(error.message ?: "unknown error").take(100)}")
                }
            return
        }
        background.execute {
            val result = try { localAi.think(task) } catch (e: Exception) {
                "LOCAL AI COULD NOT PROCESS THIS CAPTURE\n\n${(e.message ?: "The model could not be loaded.").take(350)}"
            }
            runOnUiThread {
                if (isFinishing || appState == null || !vault.isUnlocked()) return@runOnUiThread
                showLocalAiResult(result)
            }
        }
    }

    private fun showLocalAiResult(result: String) {
        val isError = result.startsWith("LOCAL AI COULD NOT")
        val suggested = if (!isError) result.lineSequence()
            .firstOrNull { it.trim().startsWith("POSSIBLE NEXT MOVE", ignoreCase = true) }
            ?.substringAfter(':', "")?.trim()
            ?.takeIf { it.isNotBlank() && !it.equals("No action needed", true) && !it.equals("None", true) && !it.startsWith("No clear", true) }
            ?.replace(Regex("^[\\-•*\\s]+"), "")?.take(MAX_TASK_TEXT) else null
        AlertDialog.Builder(this)
            .setTitle(if (isError) "Local AI needs attention" else "A way forward")
            .setMessage(result)
            .setNegativeButton("Close", null)
            .setNeutralButton("Save insight") { _, _ ->
                val insight = result.lineSequence().firstOrNull { it.trim().startsWith("WHAT I HEAR", true) }
                    ?.substringAfter(':', "")?.trim().takeIf { !it.isNullOrBlank() } ?: result
                val next = Domain.capture(requireState(), insight.take(MAX_TASK_TEXT))
                if (next == null) showToast("Could not save that insight.") else commit(next, "Insight saved to inbox.")
            }
            .setPositiveButton(if (suggested != null) "Add next move" else "Save response") { _, _ ->
                if (suggested != null && !isError) {
                    val captured = Domain.capture(requireState(), suggested)
                    val newTask = captured?.tasks?.lastOrNull()
                    val next = if (captured != null && newTask != null) Domain.moveTask(captured, newTask.id, TaskStatus.NEXT) else null
                    if (next == null) showToast("Could not add the suggested move.") else commit(next, "Suggested next move added to Next. Review it before acting.")
                } else {
                    val note = Domain.capture(requireState(), result.take(MAX_TASK_TEXT))
                    if (note == null) showToast("Could not save that response.") else commit(note, "Response saved to inbox.")
                }
            }.show()
    }

    private fun startVoiceCapture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            showToast("On-device voice capture requires Android 12 or newer. Keyboard dictation is still available.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            externalFlowActive = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_VOICE_PERMISSION)
            return
        }
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            showToast("This phone does not currently have an offline speech-recognition service available. Text capture still works.")
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { showToast("Listening… speak naturally.") }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { showToast("Processing speech on-device…") }
                    override fun onError(error: Int) {
                        speechRecognizer?.destroy(); speechRecognizer = null
                        showToast("Voice capture stopped (code $error). Try again or type instead.")
                    }
                    override fun onResults(results: Bundle?) {
                        val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        speechRecognizer?.destroy(); speechRecognizer = null
                        saveVoiceTranscript(transcript)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) {
            speechRecognizer?.destroy(); speechRecognizer = null
            showToast("Could not start on-device speech recognition. ${e.message.orEmpty()}".take(160))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_VOICE_PERMISSION || requestCode == REQUEST_ASSISTANT_PERMISSION) externalFlowActive = false
        if (requestCode == REQUEST_NOTIFICATIONS) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) showToast("Local reminder notifications enabled.")
            else showToast("Reminder times are saved, but Android notifications are disabled. Enable notifications for Threadline in Settings.")
        } else if (requestCode == REQUEST_VOICE_PERMISSION) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceCapture()
            else showToast("Microphone permission was not granted. You can still capture text, photos and files.")
        } else if (requestCode == REQUEST_ASSISTANT_PERMISSION) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && voiceSessionActive) startAssistantListening()
            else {
                voiceSessionActive = false
                voiceStatus = "Microphone permission wasn't granted. You can still type to Threadline."
                renderHomeIfUnlocked()
            }
        }
    }

    private fun saveVoiceTranscript(raw: String) {
        val transcript = raw.trim().take(MAX_TASK_TEXT)
        if (transcript.isBlank()) { showToast("No speech was recognized. Try again."); return }
        val next = Domain.capture(requireState(), transcript)
        if (next == null) showToast("Could not save the transcript. Check the inbox limit.")
        else commit(next, "Voice transcript saved. No audio was uploaded or retained.")
    }

    private fun startCameraCapture() {
        try {
            val dir = File(cacheDir, "captures").apply { mkdirs() }
            val file = File(dir, "capture-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            pendingCameraFile = file
            pendingCameraUri = uri
            val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
                clipData = ClipData.newRawUri("Threadline photo", uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            externalFlowActive = true
            startActivityForResult(intent, REQUEST_CAMERA)
        } catch (e: Exception) {
            externalFlowActive = false
            pendingCameraFile?.delete(); pendingCameraFile = null; pendingCameraUri = null
            showToast("Could not open the camera. ${e.message.orEmpty()}".take(150))
        }
    }

    private fun launchAttachmentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        }
        try {
            externalFlowActive = true
            startActivityForResult(intent, REQUEST_ATTACHMENT)
        } catch (e: Exception) {
            externalFlowActive = false
            showToast("Could not open the file picker.")
        }
    }

    private fun saveCameraCapture(resultData: Intent? = null) {
        val file = pendingCameraFile
        pendingCameraFile = null; pendingCameraUri = null
        // Some camera apps ignore EXTRA_OUTPUT and return only a small thumbnail in the result.
        if (file != null && (!file.exists() || file.length() == 0L)) {
            val thumbnail = resultData?.extras?.get("data") as? Bitmap
            if (thumbnail != null) {
                runCatching {
                    file.outputStream().use { output ->
                        check(thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, output)) { "Could not save camera thumbnail." }
                    }
                }
            }
        }
        if (file == null || !file.exists() || file.length() == 0L) {
            file?.delete()
            showToast("No photo was captured.")
            return
        }
        showToast("Securing photo in your private vault…")
        background.execute {
            val result = try {
                val raw = file.inputStream().use { readLimited(it, 18 * 1024 * 1024) }
                normalizeImage(raw)
            } catch (e: Exception) { null } finally { file.delete() }
            runOnUiThread {
                if (result == null) { showToast("Could not process that image. Try another photo."); return@runOnUiThread }
                saveAttachmentBytes("Photo-${LocalDate.now()}.jpg", "image/jpeg", result)
            }
        }
    }

    private fun saveSelectedAttachment(uri: Uri) {
        showToast("Importing attachment into the encrypted vault…")
        background.execute {
            val name = try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: "attachment"
            } catch (_: Exception) { "attachment" }.take(180)
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val bytes = try {
                contentResolver.openInputStream(uri)?.use { readLimited(it, 12 * 1024 * 1024) }
                    ?: error("Could not read the selected file.")
            } catch (e: Exception) {
                runOnUiThread { showToast((e.message ?: "Could not read that file.").take(150)) }
                return@execute
            }
            val safeBytes = try { if (mime.startsWith("image/")) normalizeImage(bytes) else bytes.also { require(it.size <= MAX_ATTACHMENT_BYTES) { "This file is too large. Attachments are limited to 1.5 MB each in this build." } } }
                catch (e: Exception) {
                    bytes.fill(0)
                    runOnUiThread { showToast((e.message ?: "Could not process that file.").take(150)) }
                    return@execute
                }
            bytes.fill(0)
            runOnUiThread { saveAttachmentBytes(name, mime, safeBytes) }
        }
    }

    private fun saveAttachmentBytes(name: String, mime: String, bytes: ByteArray) {
        if (appState == null || !vault.isUnlocked()) {
            bytes.fill(0)
            showToast("Threadline locked before the attachment finished importing. Unlock and try again.")
            return
        }
        try {
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val text = "Review attachment: $name".take(MAX_TASK_TEXT)
            val next = Domain.capture(requireState(), text, name, mime, encoded)
            if (next == null) showToast("The attachment could not be saved. The encrypted vault has reached its attachment limit.")
            else commit(next, "Attachment saved inside your encrypted vault.")
        } finally { bytes.fill(0) }
    }

    private fun normalizeImage(raw: ByteArray): ByteArray {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(raw, 0, raw.size, options)
        require(options.outWidth > 0 && options.outHeight > 0) { "The selected file is not a readable image." }
        var sample = 1
        while (options.outWidth / sample > 1400 || options.outHeight / sample > 1400) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("Could not decode the image.")
        raw.fill(0)
        var working = bitmap
        var out: ByteArray
        var attempt = 0
        do {
            val stream = ByteArrayOutputStream()
            working.compress(Bitmap.CompressFormat.JPEG, if (attempt == 0) 76 else 64, stream)
            out = stream.toByteArray()
            if (out.size <= MAX_ATTACHMENT_BYTES || attempt >= 2) break
            val smaller = Bitmap.createScaledBitmap(working, (working.width * 0.72f).toInt().coerceAtLeast(1), (working.height * 0.72f).toInt().coerceAtLeast(1), true)
            if (smaller !== working) working.recycle()
            working = smaller
            attempt++
        } while (true)
        working.recycle()
        require(out.size <= MAX_ATTACHMENT_BYTES) { "Image could not be reduced below 1.5 MB." }
        return out
    }

    private fun viewAttachment(task: TaskItem) {
        val data = task.attachmentBase64 ?: return
        val bytes = try { Base64.decode(data, Base64.DEFAULT) } catch (_: Exception) { showToast("Attachment data is invalid."); return }
        val mime = task.attachmentMime ?: "application/octet-stream"
        if (mime.startsWith("image/")) {
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            bytes.fill(0)
            if (bitmap == null) { showToast("Could not preview this image."); return }
            val image = ImageView(this).apply {
                setImageBitmap(bitmap)
                adjustViewBounds = true
                maxHeight = dp(440)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            AlertDialog.Builder(this).setTitle(task.attachmentName ?: "Photo")
                .setView(image).setPositiveButton("Done") { _, _ -> bitmap.recycle() }.show()
        } else if (mime.startsWith("text/")) {
            val content = bytes.toString(Charsets.UTF_8).take(12_000)
            bytes.fill(0)
            val view = ScrollView(this).apply { addView(label(content.ifBlank { "This text file is empty." }, 14, ThreadlineTokens.INK).apply { setPadding(dp(18), dp(12), dp(18), dp(12)) }) }
            AlertDialog.Builder(this).setTitle(task.attachmentName ?: "Text attachment")
                .setView(view).setPositiveButton("Done", null).show()
        } else {
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(12), dp(20), 0)
                addView(label(task.attachmentName ?: "Attachment", 17, ThreadlineTokens.INK, true), bottom(6))
                addView(label("Type: $mime\nStored inside your encrypted vault.", 13, ThreadlineTokens.MUTED))
            }
            AlertDialog.Builder(this).setTitle("Attachment")
                .setView(panel).setNegativeButton("Close") { _, _ -> bytes.fill(0) }
                .setPositiveButton("Open in another app") { _, _ -> openAttachmentInViewer(task, bytes) }
                .show()
        }
    }

    private fun openAttachmentInViewer(task: TaskItem, bytes: ByteArray) {
        try {
            val dir = File(cacheDir, "captures").apply { mkdirs() }
            val file = File(dir, "preview-${System.currentTimeMillis()}-${task.attachmentName.orEmpty().replace(Regex("[^A-Za-z0-9._-]"), "_").take(40)}")
            file.writeBytes(bytes)
            transientViewerFile = file
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, task.attachmentMime ?: "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            transientViewerFile?.delete(); transientViewerFile = null
            showToast("No app could open this attachment, or access was denied. ${e.message.orEmpty()}".take(170))
        } finally { bytes.fill(0) }
    }

    private fun projectCard(project: ProjectItem): View {
        val card = card()
        val statusLine = project.status.name.lowercase(Locale.ROOT).replaceFirstChar { it.uppercaseChar() }
        card.addView(label(statusLine.uppercase(), 10, ThreadlineTokens.TEAL, true), bottom(5))
        card.addView(label(project.title, 18, ThreadlineTokens.INK, true), bottom(6))
        if (project.outcome.isNotBlank()) {
            card.addView(label("OUTCOME", 10, ThreadlineTokens.MUTED, true), bottom(2))
            card.addView(label(project.outcome, 14, ThreadlineTokens.INK), bottom(8))
        }
        card.addView(label("NEXT ACTION", 10, ThreadlineTokens.MUTED, true), bottom(2))
        card.addView(label(project.nextAction.ifBlank { "No next action recorded yet." }, 14, if (project.nextAction.isBlank()) ThreadlineTokens.MUTED else ThreadlineTokens.INK), bottom(12))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (project.status == ProjectStatus.ACTIVE) {
            row.addView(button("Add to Next", true, compact = true) {
                val current = requireState()
                val alreadyOpen = current.tasks.any {
                    it.projectId == project.id && it.text.equals(project.nextAction.trim(), ignoreCase = true) && it.status != TaskStatus.DONE
                }
                if (project.nextAction.isBlank()) showToast("Add a next action to this project first.")
                else if (alreadyOpen) showToast("This action already has an open task.")
                else {
                    val next = Domain.addProjectNextAction(current, project.id)
                    if (next == null) showToast("Could not add this action. Check the project and task limits.")
                    else commit(next, "Project action added to Next.")
                }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            row.addView(button("Focus", false, compact = true) { focusProject(project.id) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
            row.addView(button("Edit", false, compact = true) { editProject(project) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
            card.addView(row, bottom(8))
            card.addView(button("Park this project", false, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.PARKED)
                if (updated != null) commit(updated, "Project parked.")
            })
        } else if (project.status == ProjectStatus.PARKED) {
            card.addView(button("Reactivate project", true, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.ACTIVE)
                if (updated != null) commit(updated, "Project reactivated.")
            })
        } else {
            card.addView(button("Reopen project", false, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.ACTIVE)
                if (updated != null) commit(updated, "Project reopened.")
            })
        }
        return card
    }

    private fun projectSummary(project: ProjectItem): View = card().apply {
        addView(label(project.title, 16, ThreadlineTokens.INK, true), bottom(5))
        addView(label(project.nextAction.ifBlank { "Add a next action to get this moving." }, 13, ThreadlineTokens.MUTED), bottom(9))
        addView(button("Open projects", false, compact = true) { activeTab = Tab.PROJECTS; renderHome() })
    }

    private fun focusProject(projectId: String) {
        val state = requireState()
        if (state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS) {
            showToast("Today already has three focus items. Move one to Next first.")
            return
        }
        val project = state.projects.firstOrNull { it.id == projectId } ?: return
        if (project.nextAction.isBlank()) { showToast("Add a next action first."); return }
        val existing = state.tasks.firstOrNull { it.projectId == projectId && it.text == project.nextAction && it.status != TaskStatus.DONE }
        val next = if (existing != null) Domain.moveTask(state, existing.id, TaskStatus.TODAY)
        else state.copy(tasks = state.tasks + TaskItem(text = project.nextAction, status = TaskStatus.TODAY, projectId = project.id))
        if (next == null) showToast("Could not add that action to today.") else {
            activeTab = Tab.TODAY
            commit(next, "Project action is today's focus.")
        }
    }

    private fun editProject(project: ProjectItem) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val outcome = textField("Outcome", MAX_PROJECT_TEXT).apply { setText(project.outcome) }
        val next = textField("Next action", MAX_PROJECT_TEXT).apply { setText(project.nextAction) }
        panel.addView(outcome, bottom(8)); panel.addView(next)
        AlertDialog.Builder(this)
            .setTitle("Edit ${project.title}")
            .setView(panel)
            .setNegativeButton("Cancel", null)
            .setNeutralButton(if (project.status == ProjectStatus.DONE) "Keep done" else "Mark done") { _, _ ->
                val updated = Domain.updateProject(requireState(), project.id, outcome.text.toString(), next.text.toString(), ProjectStatus.DONE)
                if (updated != null) commit(updated, "Project marked completed.")
            }
            .setPositiveButton("Save") { _, _ ->
                val updated = Domain.updateProject(requireState(), project.id, outcome.text.toString(), next.text.toString())
                if (updated != null) commit(updated, "Project updated.")
            }.show()
    }

    private fun statCard(number: String, caption: String): View = card().apply {
        addView(label(number, 24, ThreadlineTokens.INK, true), bottom(3))
        addView(label(caption, 12, ThreadlineTokens.MUTED))
    }

    private fun emptyCard(title: String, body: String): View = card().apply {
        addView(label(title, 16, ThreadlineTokens.INK, true), bottom(5))
        addView(label(body, 13, ThreadlineTokens.MUTED))
    }

    private fun sectionTitle(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 18, ThreadlineTokens.INK, true), bottom(3))
        addView(label(subtitle, 12, ThreadlineTokens.MUTED))
    }

    private fun sectionLabel(text: String): View = label(text, 11, ThreadlineTokens.TEAL, true)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(surfaceColor(), 18, color(ThreadlineTokens.BORDER))
        elevation = if (darkMode) 0f else dp(1).toFloat()
    }

    private fun label(text: String, size: Int, textColor: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color(textColor))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        includeFontPadding = true
        setLineSpacing(dp(2).toFloat(), 1.0f)
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    private fun textField(hint: String, maxChars: Int): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 14f
        setTextColor(color(ThreadlineTokens.INK))
        setHintTextColor(color(ThreadlineTokens.MUTED))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = rounded(ThreadlineTokens.FIELD, 12, ThreadlineTokens.BORDER)
        filters = arrayOf(InputFilter.LengthFilter(maxChars))
        isSaveEnabled = false
        importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        setSingleLine(false)
        minHeight = dp(46)
    }

    private fun iconButton(
        iconRes: Int,
        description: String,
        active: Boolean = false,
        onClick: () -> Unit
    ): FrameLayout = FrameLayout(this).apply {
        background = rounded(
            if (active) ThreadlineTokens.MINT else 0xff203b33.toInt(),
            13,
            if (active) ThreadlineTokens.MINT else 0xff355548.toInt()
        )
        isClickable = true
        isFocusable = true
        contentDescription = description
        addView(ImageView(this@MainActivity).apply {
            setImageResource(iconRes)
            imageTintList = android.content.res.ColorStateList.valueOf(
                color(if (active) ThreadlineTokens.NAVY else ThreadlineTokens.MINT)
            )
            contentDescription = null
        }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER))
        ThreadlineMotion.installPressFeedback(this) { reduceMotion }
        setOnClickListener {
            ThreadlineMotion.tapHaptic(this)
            onClick()
        }
    }

    private fun button(
        text: String,
        primary: Boolean,
        compact: Boolean = false,
        enabled: Boolean = true,
        onClick: () -> Unit
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = if (compact) 12f else 14f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(if (compact) 7 else 14), dp(9), dp(if (compact) 7 else 14), dp(9))
        setTextColor(color(if (primary) ThreadlineTokens.NAVY else ThreadlineTokens.INK))
        background = rounded(if (primary) ThreadlineTokens.MINT else ThreadlineTokens.SECONDARY, 14, if (primary) ThreadlineTokens.MINT else ThreadlineTokens.BORDER)
        alpha = if (enabled) 1f else 0.45f
        isEnabled = enabled
        isClickable = enabled
        isFocusable = enabled
        contentDescription = text
        minHeight = dp(if (compact) 40 else 46)
        if (enabled) {
            ThreadlineMotion.installPressFeedback(this) { reduceMotion }
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
        }
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color(fill)); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), color(stroke))
    }

    private fun bottom(dpValue: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(dpValue) }
    private fun top(dpValue: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(dpValue) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun color(value: Int): Int = ThreadlinePalette.resolve(value, darkMode)

    private fun surfaceColor(): Int = ThreadlinePalette.surface(darkMode)
    private fun motionEnabled(): Boolean = ThreadlineMotion.enabled(reduceMotion)
    private fun animateScreenIn(view: View) = ThreadlineMotion.animateScreenIn(view, reduceMotion)

    private fun animateChildrenEntrance(container: LinearLayout) = ThreadlineMotion.animateChildrenEntrance(container, reduceMotion)

    private fun premiumPanel(radius: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        ThreadlinePalette.heroGradient(darkMode)
    ).apply {
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), ThreadlinePalette.heroBorder(darkMode))
    }

    private fun resolveDarkMode(mode: String): Boolean = when (mode) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun themeModeLabel(mode: String): String = when (mode) {
        "light" -> "Light"
        "dark" -> "Dark"
        else -> "System"
    }

    private fun applySystemBars() {
        val barColor = if (darkMode) 0xff101714.toInt() else ThreadlineTokens.NAVY
        window.statusBarColor = barColor
        window.navigationBarColor = barColor
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun applyThemeMode(mode: String) {
        themeMode = mode
        userPreferences().edit().putString("theme_mode", mode).apply()
        darkMode = resolveDarkMode(mode)
        setTheme(if (darkMode) R.style.AppTheme_Dark else R.style.AppTheme)
        applySystemBars()
        forceNextEntrance = true
        if (appState != null && vault.isUnlocked()) renderHome() else renderLocked()
        showToast("${themeModeLabel(mode)} appearance applied.")
    }

    private fun requireState(): ThreadState = appState ?: error("The vault is locked.")

    private fun commit(next: ThreadState, message: String): Boolean {
        return try {
            val validated = Domain.validate(Domain.clearExpiredReminders(next))
            vault.save(validated)
            appState = validated
            ReminderScheduler.sync(this, validated.tasks)
            latestError = null
            renderHome()
            showToast(message)
            true
        } catch (e: Exception) {
            showToast((e.message ?: "Could not save. Your previous data remains unchanged.").take(180))
            false
        }
    }

    private fun completedToday(state: ThreadState): Int {
        val today = LocalDate.now()
        return state.tasks.count { task ->
            task.status == TaskStatus.DONE && task.completedAt?.let {
                Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate() == today
            } == true
        }
    }

    private fun lockNow() {
        endVoiceSession(render = false)
        chatBubbles.clear()
        pendingAssistantActions = emptyList()
        chatBusy = false
        localAi.cancelActiveGeneration()
        runCatching { background.execute { localAi.close() } }
        modelWarmupStarted = false
        vault.clearSession()
        appState = null
        renderLocked()
    }

    private fun showToast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun promptExportPassword() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val first = textField("Backup passphrase (12+ characters)", 200).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        val second = textField("Repeat backup passphrase", 200).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        panel.addView(first, bottom(8)); panel.addView(second)
        val dialog = AlertDialog.Builder(this).setTitle("Encrypt a backup")
            .setMessage("Keep the passphrase separate from the backup file. Threadline cannot recover a forgotten passphrase.")
            .setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Encrypt backup", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = first.text.toString()
                val b = second.text.toString()
                if (a.length < 12) { first.error = "Use at least 12 characters"; return@setOnClickListener }
                if (a != b) { second.error = "Passphrases do not match"; return@setOnClickListener }
                val password = a.toCharArray()
                first.setText(""); second.setText(""); dialog.dismiss()
                val stateBytes = try { StateCodec.encode(requireState()) } catch (e: Exception) { showToast("Could not prepare backup."); return@setOnClickListener }
                showToast("Encrypting backup…")
                background.execute {
                    try {
                        val result = BackupCrypto.encrypt(stateBytes, password)
                        stateBytes.fill(0)
                        runOnUiThread {
                            pendingBackup?.fill(0)
                            pendingBackup = result
                            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "application/octet-stream"
                                putExtra(Intent.EXTRA_TITLE, "threadline-backup.tlb")
                            }
                            externalFlowActive = true
                            startActivityForResult(intent, REQUEST_EXPORT)
                        }
                    } catch (e: Exception) {
                        stateBytes.fill(0); password.fill('\u0000')
                        runOnUiThread { showToast((e.message ?: "Backup encryption failed.").take(180)) }
                    }
                }
            }
        }
        dialog.show()
    }

    private fun launchImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        externalFlowActive = true
        startActivityForResult(intent, REQUEST_IMPORT)
    }

    @Deprecated("Required for the Storage Access Framework and external camera picker.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode in setOf(REQUEST_EXPORT, REQUEST_IMPORT, REQUEST_MODEL, REQUEST_ATTACHMENT, REQUEST_CAMERA, REQUEST_TTS_SETTINGS)) externalFlowActive = false
        if (requestCode == REQUEST_TTS_SETTINGS) {
            refreshOfflineVoices()
            renderHomeIfUnlocked()
            return
        }
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == RESULT_OK) saveCameraCapture(data) else {
                pendingCameraFile?.delete(); pendingCameraFile = null; pendingCameraUri = null
                showToast("Photo capture cancelled.")
            }
            return
        }
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup?.fill(0); pendingBackup = null
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_EXPORT -> writeBackup(uri)
            REQUEST_IMPORT -> readBackup(uri)
            REQUEST_MODEL -> importSelectedModel(uri)
            REQUEST_ATTACHMENT -> saveSelectedAttachment(uri)
        }
    }

    private fun importSelectedModel(uri: Uri) {
        val name = try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            } ?: "model"
        } catch (_: Exception) { "model" }
        showToast("Importing model. This may take a few minutes…")
        background.execute {
            val result = try { localAi.importModel(contentResolver, uri, name) } catch (e: Exception) { e }
            runOnUiThread {
                if (result is Long) {
                    modelWarmupStarted = false
                    showToast("Local model imported (${result / (1024 * 1024)} MB). Preparing it for first use…")
                    background.execute {
                        modelWarmupStarted = runCatching { localAi.warmUp() }.isSuccess
                        runOnUiThread { renderHomeIfUnlocked() }
                    }
                    if (appState != null) renderHome() else renderLocked()
                } else {
                    val error = (result as? Exception)?.message ?: "Model import failed."
                    showToast(error.take(220))
                }
            }
        }
    }

    private fun writeBackup(uri: Uri) {
        val bytes = pendingBackup ?: run { showToast("No encrypted backup is ready."); return }
        try {
            contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes); it.flush() }
                ?: error("Could not open the selected destination.")
            showToast("Encrypted backup saved. Keep the passphrase safe.")
        } catch (e: Exception) {
            showToast((e.message ?: "Could not write backup file.").take(180))
        } finally {
            bytes.fill(0); pendingBackup = null
        }
    }

    private fun readBackup(uri: Uri) {
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { readLimited(it, 10 * 1024 * 1024) }
                ?: error("Could not open the selected file.")
        } catch (e: Exception) {
            showToast((e.message ?: "Could not read backup.").take(180)); return
        }
        promptImportPassword(bytes)
    }

    private fun promptImportPassword(bytes: ByteArray) {
        val input = textField("Backup passphrase", 200).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Restore encrypted backup")
            .setMessage("The current vault will be replaced after the backup is verified and you authenticate.")
            .setView(input).setNegativeButton("Cancel") { _, _ -> bytes.fill(0) }
            .setPositiveButton("Verify backup", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = input.text.toString()
                if (raw.length < 12) { input.error = "Enter your backup passphrase"; return@setOnClickListener }
                val password = raw.toCharArray()
                input.setText(""); dialog.dismiss()
                showToast("Verifying encrypted backup…")
                background.execute {
                    val imported = try {
                        val plaintext = BackupCrypto.decrypt(bytes, password)
                        bytes.fill(0)
                        try { StateCodec.decode(plaintext) } finally { plaintext.fill(0) }
                    } catch (e: Exception) {
                        bytes.fill(0); password.fill('\u0000')
                        runOnUiThread { showToast((e.message ?: "Backup verification failed.").take(180)) }
                        null
                    }
                    if (imported != null) runOnUiThread { authorizeAndRestore(imported) }
                }
            }
        }
        dialog.show()
    }

    private fun authorizeAndRestore(imported: ThreadState) {
        val finish: (ThreadState?, String?) -> Unit = { _, error ->
            if (error != null) {
                latestError = error
                appState = null
                vault.clearSession()
                renderLocked()
            } else {
                try {
                    vault.save(imported)
                    appState = imported
                    activeTab = Tab.TODAY
                    latestError = null
                    renderHome()
                    showToast("Backup restored successfully.")
                } catch (e: Exception) {
                    latestError = e.message ?: "Could not restore the backup."
                    appState = null
                    vault.clearSession()
                    renderLocked()
                }
            }
        }
        if (vault.isInitialized()) {
            vault.unlockForRestore(this) { authorized, error -> finish(if (authorized) imported else null, error) }
        } else {
            // On a clean install (or after explicitly erasing an inaccessible vault), establish a fresh key first.
            vault.setup(this) { newState, error ->
                if (newState == null) finish(null, error)
                else finish(imported, null)
            }
        }
    }

    private fun readLimited(input: InputStream, max: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= max) { "The selected file is larger than this operation allows." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }


    private companion object {
        const val REQUEST_EXPORT = 3001
        const val REQUEST_IMPORT = 3002
        const val REQUEST_VOICE_PERMISSION = 3003
        const val REQUEST_MODEL = 3004
        const val REQUEST_ATTACHMENT = 3005
        const val REQUEST_CAMERA = 3006
        const val REQUEST_ASSISTANT_PERMISSION = 3007
        const val REQUEST_TTS_SETTINGS = 3008
        const val REQUEST_OVERLAY_PERMISSION = 3009
        const val REQUEST_NOTIFICATIONS = 3010
        const val EXTRA_QUICK_ACTION = "threadline_quick_action"
        const val EXTRA_QUICK_TEXT = "threadline_quick_text"
    }
}
