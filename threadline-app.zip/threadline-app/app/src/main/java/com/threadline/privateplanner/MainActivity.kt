package com.threadline.privateplanner

import android.app.AlertDialog
import android.content.Intent
import android.content.ClipData
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

internal class MainActivity : FragmentActivity() {
    private lateinit var vault: SecureVault
    private lateinit var localAi: OnDeviceAi
    private var appState: ThreadState? = null
    private var activeTab = Tab.TODAY
    private var latestError: String? = null
    private var pendingBackup: ByteArray? = null
    private val background = Executors.newSingleThreadExecutor()
    private var externalFlowActive = false
    private var pendingCameraFile: File? = null
    private var pendingCameraUri: Uri? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var transientViewerFile: File? = null

    private enum class Tab { TODAY, INBOX, PROJECTS, REVIEW, TALK }

    private val chatBubbles = mutableListOf<AssistantBubble>()
    private var pendingAssistantActions: List<AssistantAction> = emptyList()
    private var chatBusy = false
    private var voiceSessionActive = false
    private var assistantListening = false
    private var assistantSpeaking = false
    private var voiceStatus = "Ready when you are."
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var offlineTtsAvailable = false
    private var offlineVoices: List<Voice> = emptyList()
    private var assistantRecognitionLocale: Locale = Locale.getDefault()
    private var modelDownloadRunning = false
    private val modelDownloadCancelled = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = color(C.NAVY)
        window.navigationBarColor = color(C.NAVY)
        window.decorView.systemUiVisibility = 0
        vault = SecureVault(this)
        localAi = OnDeviceAi(this)
        initializeOfflineSpeech()
        renderLocked()
    }

    override fun onStop() {
        // System document/camera pickers temporarily cover the app. Keep the vault open only for
        // that explicit hand-off; ordinary backgrounding still drops the in-memory vault key.
        if (!externalFlowActive) {
            endVoiceSession(render = false)
            runCatching { tts?.stop() }
            runCatching { background.execute { localAi.close() } }
            vault.clearSession()
            appState = null
            chatBubbles.clear()
            pendingAssistantActions = emptyList()
            chatBusy = false
            voiceStatus = "Ready when you are."
            if (!isChangingConfigurations) renderLocked()
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        // Decrypted preview files exist only while a system viewer is using them.
        transientViewerFile?.delete()
        transientViewerFile = null
        refreshOfflineVoices()
    }

    private fun refreshOfflineVoices() {
        val speech = tts ?: return
        if (!ttsReady) return
        val voices = runCatching { speech.voices.orEmpty().toList() }.getOrDefault(emptyList())
        offlineVoices = voices.filterNot { it.isNetworkConnectionRequired }
        offlineTtsAvailable = offlineVoices.isNotEmpty()
    }

    private fun openOfflineVoiceSettings() {
        try {
            externalFlowActive = true
            // Android does not expose a public ACTION_TEXT_TO_SPEECH_SETTINGS constant.
            // Try the Settings app's established TTS action, then fall back to public Accessibility settings.
            try {
                startActivityForResult(Intent("com.android.settings.TTS_SETTINGS"), REQUEST_TTS_SETTINGS)
            } catch (_: Exception) {
                startActivityForResult(
                    Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS),
                    REQUEST_TTS_SETTINGS
                )
            }
        } catch (_: Exception) {
            externalFlowActive = false
            showToast("Open Android Settings → Accessibility → Text-to-speech output and install offline voice data.")
        }
    }

    override fun onDestroy() {
        modelDownloadCancelled.set(true)
        endVoiceSession(render = false)
        speechRecognizer?.destroy()
        speechRecognizer = null
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
        localAi.close()
        background.shutdownNow()
        pendingCameraFile?.delete()
        transientViewerFile?.delete(); transientViewerFile = null
        pendingBackup?.fill(0)
        pendingBackup = null
        vault.clearSession()
        super.onDestroy()
    }

    private fun renderLocked() {
        val available = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        val initialized = ::vault.isInitialized && vault.isInitialized()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(color(C.NAVY))
        }
        root.addView(label("T /", 22, C.MINT, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })
        root.addView(label("THREADLINE", 28, C.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(label("A quieter place for the next action.", 16, C.LIGHT_MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })
        root.addView(card().apply {
            addView(label("PRIVATE BY DEFAULT", 11, C.MINT, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            addView(label("Your tasks and project notes stay encrypted on this phone. No account or analytics. Internet is used only to download an optional public AI model.", 15, C.WHITE))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        val authReady = available == BiometricManager.BIOMETRIC_SUCCESS
        val mainText = when {
            !authReady -> "Set up a strong biometric unlock in your phone's settings to use the secure vault. Threadline requires biometric authentication."
            initialized -> "Your vault is locked. Authenticate to continue."
            else -> "Create your private vault. New data is encrypted before it is written to storage."
        }
        root.addView(label(mainText, 14, C.LIGHT_MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        val action = when {
            !authReady -> "Biometrics unavailable"
            initialized -> "Unlock with biometrics"
            else -> "Create secure vault"
        }
        root.addView(button(action, true, enabled = authReady) {
            latestError = null
            if (initialized) vault.unlock(this) { state, error -> onVaultResult(state, error) }
            else vault.setup(this) { state, error -> onVaultResult(state, error) }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        root.addView(button("Restore encrypted backup", false) { launchImportPicker() },
            LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(12) })
        if (latestError != null) {
            root.addView(label(latestError!!, 13, C.ERROR), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }
        if (initialized || latestError != null) {
            root.addView(button("Reset / erase local vault", false) {
                AlertDialog.Builder(this)
                    .setTitle("Erase this vault?")
                    .setMessage("This permanently deletes this phone's encrypted Threadline data and its key. It cannot be undone. An encrypted backup can be imported after you create a new vault.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Erase permanently") { _, _ ->
                        vault.resetLocalVault()
                        latestError = null
                        renderLocked()
                    }.show()
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        setContentView(root)
    }

    private fun onVaultResult(state: ThreadState?, error: String?) {
        if (state == null) {
            latestError = error ?: "Authentication did not complete."
            renderLocked()
            return
        }
        appState = state
        latestError = null
        renderHome()
    }

    private fun renderHome() {
        val state = appState ?: run { renderLocked(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(C.BG))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(16), dp(16))
            setBackgroundColor(color(C.NAVY))
        }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(label("THREADLINE  /  PRIVATE", 11, C.MINT, true))
        titleColumn.addView(label("A private work companion", 19, C.WHITE, true).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val headerActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        headerActions.addView(button("Find", false, compact = true) { showGlobalSearch() }, LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(4) })
        headerActions.addView(button("Talk", true, compact = true) { activeTab = Tab.TALK; renderHome() }, LinearLayout.LayoutParams(-2, dp(40)).apply { marginEnd = dp(4) })
        headerActions.addView(button("Lock", false, compact = true) { lockNow() }, LinearLayout.LayoutParams(-2, dp(40)))
        header.addView(headerActions)
        root.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        when (activeTab) {
            Tab.TODAY -> renderToday(content, state)
            Tab.INBOX -> renderInbox(content, state)
            Tab.PROJECTS -> renderProjects(content, state)
            Tab.REVIEW -> renderReview(content, state)
            Tab.TALK -> renderTalk(content, state)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(color(C.NAVY))
        }
        listOf(Tab.TODAY to "Today", Tab.INBOX to "Inbox", Tab.PROJECTS to "Projects", Tab.TALK to "Talk").forEach { (tab, text) ->
            val label = when (tab) {
                Tab.INBOX -> if (state.tasks.count { it.status == TaskStatus.INBOX } > 0) "$text · ${state.tasks.count { it.status == TaskStatus.INBOX }}" else text
                else -> text
            }
            nav.addView(button(label, tab == activeTab, compact = true) {
                activeTab = tab
                renderHome()
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        root.addView(nav)
        setContentView(root)
        if (activeTab == Tab.TALK) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun renderToday(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("${LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))}", 13, C.MUTED))
        parent.addView(label("Today, not everything.", 27, C.INK, true), bottom(6))
        parent.addView(label("Choose a few real moves. Let the rest wait.", 14, C.MUTED), bottom(12))
        parent.addView(card().apply {
            background = rounded(C.NAVY, 18, C.NAVY)
            addView(label("THINK WITH THREADLINE", 10, C.MINT, true), bottom(7))
            addView(label("Talk it through. Connect the dots. Find the next move.", 18, C.WHITE, true), bottom(6))
            addView(label(if (localAi.isReady()) "Your local companion can use your current projects and open tasks." else "Set up a local model once, then talk and organize privately on this phone." , 13, C.LIGHT_MUTED), bottom(12))
            addView(button("Talk now  →", true) { activeTab = Tab.TALK; renderHome() })
        }, bottom(16))

        val todayTasks = state.tasks.filter { it.status == TaskStatus.TODAY }.sortedBy { it.createdAt }
        val doneToday = completedToday(state)
        val statRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        statRow.addView(statCard("${todayTasks.size}/3", "focus slots"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        statRow.addView(statCard("$doneToday", "done today"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        parent.addView(statRow, bottom(16))

        parent.addView(sectionLabel("QUICK CAPTURE"), bottom(8))
        parent.addView(captureCard(), bottom(18))

        parent.addView(sectionTitle("Your three moves", "A task only earns a slot if it matters today."), bottom(10))
        if (todayTasks.isEmpty()) {
            parent.addView(emptyCard("Nothing is locked in yet.", "Pick one useful next step from your inbox. You don't need a perfect plan."), bottom(12))
            parent.addView(button("Choose from inbox", true) { activeTab = Tab.INBOX; renderHome() }, bottom(18))
        } else {
            todayTasks.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.TODAY), bottom(10)) }
        }

        val nextTasks = state.tasks.filter { it.status == TaskStatus.NEXT }.sortedByDescending { it.updatedAt }.take(4)
        if (nextTasks.isNotEmpty()) {
            parent.addView(sectionTitle("Ready when you are", "Next actions, not a giant backlog."), bottom(10))
            nextTasks.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.NEXT), bottom(10)) }
        }
        val activeProjects = state.projects.filter { it.status == ProjectStatus.ACTIVE }
        if (activeProjects.isNotEmpty()) {
            parent.addView(sectionTitle("Active threads", "Keep each project pointed at one next action."), bottom(10))
            activeProjects.take(3).forEach { project ->
                parent.addView(projectSummary(project), bottom(10))
            }
        }
        parent.addView(button("Close the day / review", false) { activeTab = Tab.REVIEW; renderHome() }, top(6))
    }

    private fun renderInbox(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("CAPTURE WITHOUT SORTING", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Inbox", 28, C.INK, true), bottom(6))
        parent.addView(label("Get it out of your head first. Decide what it means later.", 14, C.MUTED), bottom(16))
        parent.addView(captureCard(), bottom(18))
        val inbox = state.tasks.filter { it.status == TaskStatus.INBOX }.sortedByDescending { it.createdAt }
        parent.addView(sectionTitle("${inbox.size} uncategorized ${if (inbox.size == 1) "item" else "items"}", "Keep capture easy; sorting is optional."), bottom(10))
        if (inbox.isEmpty()) {
            parent.addView(emptyCard("Inbox is clear.", "Capture an idea the moment it shows up. It doesn't need to become a task."), bottom(12))
        }
        inbox.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.INBOX), bottom(10)) }

        val later = state.tasks.filter { it.status == TaskStatus.LATER }.sortedByDescending { it.updatedAt }
        parent.addView(sectionTitle("Parked for later · ${later.size}", "You can bring these back when the timing is right."), bottom(10))
        if (later.isEmpty()) parent.addView(emptyCard("Nothing parked.", "Move work to Later when it should stop competing for attention."), bottom(12))
        later.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.LATER), bottom(10)) }
    }

    private fun renderProjects(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("WORKSTREAMS, NOT MORE BOARDS", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Projects", 28, C.INK, true), bottom(6))
        parent.addView(label("Give each important thread an outcome and a visible next step.", 14, C.MUTED), bottom(16))
        parent.addView(sectionLabel("START A PROJECT"), bottom(8))
        val title = textField("Project name (required)", MAX_PROJECT_TITLE)
        val outcome = textField("What does finished look like?", MAX_PROJECT_TEXT)
        val nextAction = textField("Next physical action (optional)", MAX_PROJECT_TEXT)
        parent.addView(card().apply {
            addView(title, bottom(8)); addView(outcome, bottom(8)); addView(nextAction, bottom(10))
            addView(button("Add project", true) {
                val next = Domain.addProject(requireState(), title.text.toString(), outcome.text.toString(), nextAction.text.toString())
                if (next == null) showToast("Add a unique project name. Keep it under ${MAX_PROJECT_TITLE} characters.")
                else commit(next, "Project added.")
            })
        }, bottom(18))

        val active = state.projects.filter { it.status == ProjectStatus.ACTIVE }
        val parked = state.projects.filter { it.status == ProjectStatus.PARKED }
        val done = state.projects.filter { it.status == ProjectStatus.DONE }
        parent.addView(sectionTitle("Active · ${active.size}", "No project needs more than one next action."), bottom(10))
        if (active.isEmpty()) parent.addView(emptyCard("No active projects yet.", "Keep this list deliberately short."), bottom(12))
        active.sortedByDescending { it.updatedAt }.forEach { parent.addView(projectCard(it), bottom(10)) }
        if (parked.isNotEmpty()) {
            parent.addView(sectionTitle("Parked · ${parked.size}", "Not abandoned. Just not active today."), bottom(10))
            parked.forEach { parent.addView(projectCard(it), bottom(10)) }
        }
        if (done.isNotEmpty()) {
            parent.addView(sectionTitle("Completed · ${done.size}", "Finished threads stay out of the way."), bottom(10))
            done.take(5).forEach { parent.addView(projectCard(it), bottom(10)) }
        }
    }

    private fun renderReview(parent: LinearLayout, state: ThreadState) {
        val today = LocalDate.now().toString()
        val existing = state.reviews.firstOrNull { it.day == today }
        parent.addView(label("A SMALL RESET", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Review & reset", 28, C.INK, true), bottom(6))
        parent.addView(label("Close open loops without pretending you can finish everything.", 14, C.MUTED), bottom(16))
        val todayItems = state.tasks.filter { it.status == TaskStatus.TODAY }
        val completed = completedToday(state)
        val summary = card()
        summary.addView(label("TODAY'S RECEIPT", 11, C.TEAL, true), bottom(12))
        summary.addView(label("$completed tasks completed", 20, C.INK, true), bottom(4))
        summary.addView(label("${todayItems.size} focus items still open · ${state.tasks.count { it.status == TaskStatus.INBOX }} items in inbox", 13, C.MUTED))
        parent.addView(summary, bottom(18))

        parent.addView(sectionLabel("WHAT MOVED FORWARD?"), bottom(7))
        val moved = textField("One thing that actually moved", 800).apply { minLines = 2; maxLines = 4; setText(existing?.movedForward.orEmpty()) }
        val next = textField("The next visible step", 800).apply { minLines = 2; maxLines = 4; setText(existing?.nextStep.orEmpty()) }
        val parked = textField("What can wait without guilt?", 800).apply { minLines = 2; maxLines = 4; setText(existing?.parked.orEmpty()) }
        parent.addView(card().apply {
            addView(moved, bottom(8)); addView(next, bottom(8)); addView(parked, bottom(10))
            addView(button("Save today's review", true) {
                val updated = Domain.saveReview(requireState(), moved.text.toString(), next.text.toString(), parked.text.toString())
                commit(updated, "Review saved on this device.")
            })
        }, bottom(18))
        parent.addView(sectionTitle("Close the loop", "Unfinished focus items move to Next; nothing is deleted."), bottom(8))
        parent.addView(button("Move unfinished focus to Next", false) {
            if (requireState().tasks.none { it.status == TaskStatus.TODAY }) showToast("There are no open focus items to move.")
            else AlertDialog.Builder(this)
                .setTitle("Close today's focus?")
                .setMessage("Any unfinished Today items will move to Next. Completed work and your saved review stay unchanged.")
                .setNegativeButton("Keep today open", null)
                .setPositiveButton("Move open items") { _, _ -> commit(Domain.rollDay(requireState()), "Open focus items moved to Next.") }
                .show()
        }, bottom(18))

        parent.addView(sectionTitle("Private backup", "Exports are encrypted with a separate passphrase."), bottom(8))
        parent.addView(card().apply {
            addView(label("A backup file is useful if you change phones or reset your device. It is not stored by Threadline.", 14, C.MUTED), bottom(12))
            addView(button("Export encrypted backup", true) { promptExportPassword() }, bottom(8))
            addView(button("Import encrypted backup", false) { launchImportPicker() })
        }, bottom(18))
        val recentDone = state.tasks.filter { it.status == TaskStatus.DONE }.sortedByDescending { it.completedAt ?: it.updatedAt }.take(6)
        parent.addView(sectionTitle("Recent wins", "A short record of work that is actually finished."), bottom(8))
        if (recentDone.isEmpty()) parent.addView(emptyCard("No completed tasks yet.", "Small finishes count, too."), bottom(12))
        recentDone.forEach { task ->
            parent.addView(card().apply {
                addView(label(task.text, 14, C.INK, true), bottom(3))
                val doneAt = task.completedAt ?: task.updatedAt
                val doneDate = Instant.ofEpochMilli(doneAt).atZone(ZoneId.systemDefault()).toLocalDate()
                addView(label("Completed ${doneDate.format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", 12, C.MUTED))
            }, bottom(8))
        }
        val pastReviews = state.reviews.filterNot { it.day == today }.sortedByDescending { it.day }.take(5)
        if (pastReviews.isNotEmpty()) {
            parent.addView(sectionTitle("Previous reviews", "Your notes remain private on this device."), bottom(8))
            pastReviews.forEach { review ->
                parent.addView(card().apply {
                    addView(label(review.day, 12, C.TEAL, true), bottom(5))
                    if (review.movedForward.isNotBlank()) addView(label("Moved forward: ${review.movedForward}", 13, C.INK), bottom(4))
                    if (review.nextStep.isNotBlank()) addView(label("Next: ${review.nextStep}", 13, C.INK), bottom(4))
                    if (review.parked.isNotBlank()) addView(label("Parked: ${review.parked}", 13, C.MUTED))
                }, bottom(8))
            }
        }
        parent.addView(label("Privacy model", 14, C.INK, true), bottom(6))
        parent.addView(label("AES-256-GCM encrypted local vault · Android Keystore key protected by strong biometrics · app data excluded from Android backup · no analytics · internet used only for an optional public model download.", 13, C.MUTED))
    }

    private fun initializeOfflineSpeech() {
        tts = TextToSpeech(this) { status ->
            val speech = tts
            if (status == TextToSpeech.SUCCESS && speech != null) {
                val voices = runCatching { speech.voices.orEmpty().toList() }.getOrDefault(emptyList())
                offlineVoices = voices.filterNot { it.isNetworkConnectionRequired }
                offlineTtsAvailable = offlineVoices.isNotEmpty()
                val selected = offlineVoices.firstOrNull { it.locale.language == assistantRecognitionLocale.language }
                    ?: offlineVoices.firstOrNull { it.locale.language == "en" }
                    ?: offlineVoices.firstOrNull()
                if (selected != null) {
                    offlineTtsAvailable = runCatching {
                        speech.voice = selected
                        val languageStatus = speech.setLanguage(selected.locale)
                        speech.setSpeechRate(1.0f)
                        languageStatus >= TextToSpeech.LANG_AVAILABLE
                    }.getOrDefault(false)
                }
                ttsReady = true
            } else {
                ttsReady = false
                offlineTtsAvailable = false
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread {
                    assistantSpeaking = true
                    assistantListening = false
                    voiceStatus = "Threadline is speaking."
                    if (appState != null && activeTab == Tab.TALK) renderHome()
                }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    assistantSpeaking = false
                    if (voiceSessionActive && appState != null) {
                        voiceStatus = "Your turn — speak when ready."
                        mainHandler.postDelayed({ if (voiceSessionActive && appState != null) startAssistantListening() }, 280)
                    } else if (appState != null && activeTab == Tab.TALK) {
                        voiceStatus = "Reply spoken aloud."
                        renderHome()
                    }
                }
            }

            @Deprecated("Deprecated by Android")
            override fun onError(utteranceId: String?) {
                runOnUiThread {
                    assistantSpeaking = false
                    if (voiceSessionActive) {
                        voiceSessionActive = false
                        voiceStatus = "Offline speech failed. Check Android text-to-speech settings."
                        renderHomeIfUnlocked()
                    }
                }
            }
        })
    }

    private fun renderTalk(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("PRIVATE VOICE COMPANION", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Talk to Threadline", 28, C.INK, true), bottom(6))
        parent.addView(label("Tell me what’s happening. I’ll use your actual projects and open work to help you think, connect context, and propose the next move.", 14, C.MUTED), bottom(14))

        parent.addView(card().apply {
            addView(label("ON-DEVICE BRAIN", 10, C.TEAL, true), bottom(5))
            if (localAi.isReady()) {
                addView(label("Local model ready · ${localAi.modelSizeBytes() / (1024 * 1024)} MiB", 16, C.INK, true), bottom(4))
                addView(label("Conversations run on this phone. Threadline downloads the model only; your messages and vault stay local.", 12, C.MUTED), bottom(10))
                addView(button("Manage local model", false, compact = true) { showAiSetup() })
            } else {
                addView(label("Give Threadline a local brain", 17, C.INK, true), bottom(4))
                addView(label("Download a free Qwen3 model once (about 345 MB). Afterward, chatting and organizing work can happen offline. Wi-Fi recommended.", 13, C.MUTED), bottom(10))
                addView(button(if (modelDownloadRunning) "Model download in progress…" else "Download local model · ~345 MB", true, enabled = !modelDownloadRunning) { confirmModelDownload() }, bottom(7))
                addView(button("Import a model file instead", false, compact = true) { launchModelPicker() })
            }
        }, bottom(12))

        val stateCard = card().apply {
            background = rounded(C.NAVY, 18, C.NAVY)
            addView(label("VOICE SESSION", 10, C.MINT, true), bottom(6))
            addView(label(when {
                assistantListening -> "Listening…"
                assistantSpeaking -> "Speaking…"
                chatBusy -> "Thinking locally…"
                voiceSessionActive -> "Ready for your next turn."
                else -> voiceStatus
            }, 19, C.WHITE, true), bottom(5))
            addView(label(if (hasOfflineVoiceFor(assistantRecognitionLocale)) "On-device listening + offline spoken replies in ${assistantRecognitionLocale.getDisplayLanguage(assistantRecognitionLocale)}." else "Choose a matching offline voice in Android text-to-speech settings for spoken replies." , 12, C.LIGHT_MUTED), bottom(8))
            addView(button("Speech language · ${assistantRecognitionLocale.getDisplayLanguage(assistantRecognitionLocale)}", false, compact = true) { selectSpeechLanguage() }, bottom(8))
            addView(button(if (voiceSessionActive) "■  End voice conversation" else "●  Start voice conversation", true, enabled = !chatBusy || voiceSessionActive) {
                toggleVoiceSession()
            }, bottom(6))
            if (!hasOfflineVoiceFor(assistantRecognitionLocale)) {
                addView(button("Offline voice settings", false, compact = true) {
                    openOfflineVoiceSettings()
                })
            }
        }
        parent.addView(stateCard, bottom(12))

        if (chatBubbles.isEmpty()) {
            parent.addView(sectionLabel("START WITH ANYTHING"), bottom(7))
            val starterPrompts = listOf("What should I focus on now?", "Help me untangle what’s on my mind.", "Look at my projects and find the best next move.")
            starterPrompts.forEach { prompt ->
                parent.addView(button(prompt, false) { sendAssistantTurn(prompt, speakResponse = false) }, bottom(7))
            }
        }

        chatBubbles.takeLast(18).forEach { bubble ->
            parent.addView(assistantBubbleView(bubble), bottom(8))
        }

        if (chatBusy) {
            parent.addView(card().apply {
                addView(label("THREADLINE IS THINKING", 10, C.TEAL, true), bottom(4))
                addView(label("Running the model locally. Larger models may take a moment.", 13, C.MUTED))
            }, bottom(8))
        }

        if (pendingAssistantActions.isNotEmpty()) {
            parent.addView(card().apply {
                addView(label("PROPOSED CHANGES · YOUR APPROVAL REQUIRED", 10, C.TEAL, true), bottom(6))
                addView(label("Threadline is suggesting these internal changes. Nothing has changed yet.", 13, C.MUTED), bottom(8))
                pendingAssistantActions.forEachIndexed { index, action ->
                    addView(label("${index + 1}. ${action.description(state)}", 14, C.INK, true), bottom(6))
                }
                addView(button("Review & apply changes", true) { applyAssistantActions() }, bottom(7))
                addView(button("Dismiss suggestions", false, compact = true) {
                    pendingAssistantActions = emptyList()
                    renderHome()
                })
            }, bottom(12))
        }

        val input = textField("Talk or type here…", 1_600).apply {
            minLines = 1
            maxLines = 4
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
        }
        parent.addView(card().apply {
            addView(label("YOUR TURN", 10, C.TEAL, true), bottom(6))
            addView(input, bottom(8))
            addView(button(if (chatBusy) "Thinking…" else "Send to Threadline  →", true, enabled = !chatBusy) {
                sendAssistantTurn(input.text.toString(), speakResponse = false)
            }, bottom(7))
            val secondary = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            secondary.addView(button("Save conversation", false, compact = true) { saveAssistantConversation() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            secondary.addView(button("New conversation", false, compact = true) { clearAssistantConversation() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
            addView(secondary)
        }, bottom(12))
        parent.addView(label("Guardrail: Threadline can propose changes to its own tasks and projects. It never sends a message, spends money, or takes an external action on its own.", 11, C.MUTED))
    }

    private fun assistantBubbleView(bubble: AssistantBubble): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = if (bubble.fromUser) Gravity.END else Gravity.START
        val bubbleCard = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(if (bubble.fromUser) C.MINT else C.WHITE, 18, if (bubble.fromUser) C.MINT else C.BORDER)
            addView(label(if (bubble.fromUser) "YOU" else "THREADLINE", 10, if (bubble.fromUser) C.NAVY else C.TEAL, true), bottom(4))
            addView(label(bubble.text, 15, C.INK))
        }
        addView(bubbleCard, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = if (bubble.fromUser) dp(28) else 0
            rightMargin = if (bubble.fromUser) 0 else dp(28)
        })
    }

    private fun toggleVoiceSession() {
        if (voiceSessionActive) {
            endVoiceSession(render = false)
            voiceStatus = "Voice conversation ended."
            renderHome()
            return
        }
        if (!localAi.isReady()) {
            showAiSetup()
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            showToast("Android 12 or newer is needed for on-device speech recognition.")
            return
        }
        if (!ttsReady) {
            showToast("The speech engine is still starting. Try again in a moment.")
            return
        }
        if (!offlineTtsAvailable || !hasOfflineVoiceFor(assistantRecognitionLocale)) {
            AlertDialog.Builder(this)
                .setTitle("Install an offline voice")
                .setMessage("Threadline will only speak through an offline voice. Open Android text-to-speech settings and install voice data, or continue with voice input and text replies only.")
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Voice settings") { _, _ ->
                    openOfflineVoiceSettings()
                }
                .setPositiveButton("Continue without spoken replies") { _, _ -> beginVoiceSession() }
                .show()
            return
        }
        beginVoiceSession()
    }

    private fun beginVoiceSession() {
        voiceSessionActive = true
        voiceStatus = "Starting a private voice conversation…"
        renderHome()
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            externalFlowActive = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_ASSISTANT_PERMISSION)
        } else startAssistantListening()
    }

    private fun startAssistantListening() {
        if (!voiceSessionActive || chatBusy || assistantSpeaking || appState == null) return
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceSessionActive = false
            voiceStatus = "Microphone permission is required for voice conversations."
            renderHomeIfUnlocked()
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            voiceSessionActive = false
            voiceStatus = "No on-device speech recognition service is available on this phone."
            renderHomeIfUnlocked()
            showToast("Voice conversation needs an on-device speech recognition service and offline language pack.")
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        assistantListening = true
                        voiceStatus = "Listening — speak naturally."
                        renderHomeIfUnlocked()
                    }
                    override fun onBeginningOfSpeech() { }
                    override fun onRmsChanged(rmsdB: Float) { }
                    override fun onBufferReceived(buffer: ByteArray?) { }
                    override fun onEndOfSpeech() {
                        assistantListening = false
                        voiceStatus = "Understanding what you said…"
                        renderHomeIfUnlocked()
                    }
                    override fun onError(error: Int) {
                        speechRecognizer?.destroy()
                        speechRecognizer = null
                        assistantListening = false
                        if (voiceSessionActive) {
                            val recoverableSilence = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            if (recoverableSilence) {
                                voiceStatus = if (error == SpeechRecognizer.ERROR_NO_MATCH) "I didn’t catch that — listening again." else "Still here. Speak when you’re ready."
                                renderHomeIfUnlocked()
                                mainHandler.postDelayed({ if (voiceSessionActive && appState != null && !chatBusy) startAssistantListening() }, 650)
                            } else {
                                voiceSessionActive = false
                                voiceStatus = "Voice input stopped (code $error). Check your offline speech service and try again."
                                renderHomeIfUnlocked()
                            }
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        speechRecognizer?.destroy()
                        speechRecognizer = null
                        assistantListening = false
                        if (transcript.isBlank()) {
                            voiceStatus = "No speech was recognized. Try again."
                            voiceSessionActive = false
                            renderHomeIfUnlocked()
                        } else {
                            voiceStatus = "You said: ${transcript.take(100)}"
                            sendAssistantTurn(transcript, speakResponse = true)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) { }
                    override fun onEvent(eventType: Int, params: Bundle?) { }
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, assistantRecognitionLocale.toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) {
            speechRecognizer?.destroy()
            speechRecognizer = null
            assistantListening = false
            voiceSessionActive = false
            voiceStatus = "Could not start offline voice input. Check your speech-recognition settings."
            renderHomeIfUnlocked()
            showToast((e.message ?: "Could not start voice input.").take(150))
        }
    }

    private fun hasOfflineVoiceFor(locale: Locale): Boolean =
        offlineVoices.any { it.locale.language == locale.language }

    private fun selectSpeechLanguage() {
        val choices = listOf(
            "English" to Locale.ENGLISH,
            "Polish" to Locale("pl"),
            "Turkish" to Locale("tr"),
            "Kurdish" to Locale("ku"),
            "System default · ${Locale.getDefault().displayLanguage}" to Locale.getDefault()
        ).distinctBy { it.second.language }
        val labels = choices.map { (name, locale) -> "$name · ${locale.toLanguageTag()}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Voice conversation language")
            .setMessage("Choose the language you plan to speak. It must be supported by an on-device speech-recognition pack. Offline spoken replies require a local text-to-speech voice in the same language.")
            .setItems(labels) { _, which ->
                assistantRecognitionLocale = choices[which].second
                voiceStatus = "Speech language: ${assistantRecognitionLocale.getDisplayLanguage(assistantRecognitionLocale)}."
                renderHome()
                if (!hasOfflineVoiceFor(assistantRecognitionLocale)) {
                    showToast("No matching offline speaking voice is installed. Open Offline voice settings to add one.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendAssistantTurn(rawText: String, speakResponse: Boolean) {
        val userText = rawText.trim().take(1_600)
        if (userText.isBlank()) { showToast("Say or type something first."); return }
        if (chatBusy) { showToast("Threadline is still thinking about the previous turn."); return }
        if (!localAi.isReady()) { showAiSetup(); return }
        val snapshot = appState ?: return
        chatBubbles.add(AssistantBubble(true, userText))
        chatBusy = true
        assistantListening = false
        voiceStatus = "Thinking locally about your context…"
        renderHome()
        val historySnapshot = chatBubbles.dropLast(1).takeLast(6).toList()
        background.execute {
            val response = try {
                AssistantResponse.parse(localAi.chat(userText, snapshot, historySnapshot), snapshot)
            } catch (e: Exception) {
                AssistantResponse("I couldn’t run the local model. ${(e.message ?: "Check that the imported model is compatible with LiteRT-LM.").take(220)}", emptyList())
            }
            runOnUiThread {
                if (isFinishing || appState == null || !vault.isUnlocked()) return@runOnUiThread
                chatBusy = false
                chatBubbles.add(AssistantBubble(false, response.reply))
                while (chatBubbles.size > 36) chatBubbles.removeAt(0)
                if (response.actions.isNotEmpty()) {
                    pendingAssistantActions = (pendingAssistantActions + response.actions).takeLast(6)
                }
                voiceStatus = if (voiceSessionActive) "Preparing spoken reply…" else "Reply ready."
                renderHome()
                if (speakResponse && voiceSessionActive) {
                    if (offlineTtsAvailable && hasOfflineVoiceFor(assistantRecognitionLocale)) speakAssistantReply(response.reply)
                    else {
                        voiceStatus = "Reply shown as text. Install a matching offline voice for spoken replies. Listening will continue."
                        renderHome()
                        mainHandler.postDelayed({ if (voiceSessionActive && appState != null) startAssistantListening() }, 500)
                    }
                }
            }
        }
    }

    private fun speakAssistantReply(reply: String) {
        val speech = tts
        val matchingVoice = offlineVoices.firstOrNull { it.locale.language == assistantRecognitionLocale.language }
        if (!ttsReady || !offlineTtsAvailable || speech == null || matchingVoice == null) {
            voiceSessionActive = false
            voiceStatus = "Offline spoken reply unavailable."
            renderHomeIfUnlocked()
            return
        }
        val languageStatus = runCatching {
            speech.voice = matchingVoice
            speech.setLanguage(matchingVoice.locale)
        }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
        if (languageStatus < TextToSpeech.LANG_AVAILABLE) {
            voiceSessionActive = false
            voiceStatus = "This offline voice cannot speak the selected language."
            renderHomeIfUnlocked()
            return
        }
        assistantSpeaking = true
        assistantListening = false
        voiceStatus = "Threadline is speaking…"
        val result = speech.speak(reply.take(1_800), TextToSpeech.QUEUE_FLUSH, null, "threadline-${UUID.randomUUID()}")
        if (result == TextToSpeech.ERROR) {
            assistantSpeaking = false
            voiceSessionActive = false
            voiceStatus = "Offline text-to-speech failed. Check Android voice settings."
            renderHomeIfUnlocked()
        }
    }

    private fun endVoiceSession(render: Boolean) {
        voiceSessionActive = false
        assistantListening = false
        assistantSpeaking = false
        runCatching { speechRecognizer?.cancel() }
        runCatching { speechRecognizer?.destroy() }
        speechRecognizer = null
        runCatching { tts?.stop() }
        if (render && appState != null) renderHome()
    }

    private fun renderHomeIfUnlocked() {
        if (appState != null && vault.isUnlocked() && !isFinishing) renderHome()
    }

    private fun applyAssistantActions() {
        var next = requireState()
        var applied = 0
        val failed = mutableListOf<String>()
        val proposals = pendingAssistantActions
        proposals.forEach { action ->
            val candidate: ThreadState? = when (action.type) {
                "create_task" -> {
                    val captured = Domain.capture(next, action.text)
                    val newTask = captured?.tasks?.lastOrNull()
                    if (captured == null || newTask == null) null else {
                        var linked = captured
                        if (action.projectId.isNotBlank()) {
                            linked = linked.copy(tasks = linked.tasks.map { if (it.id == newTask.id) it.copy(projectId = action.projectId) else it })
                        }
                        val target = runCatching { TaskStatus.valueOf(action.status) }.getOrNull() ?: TaskStatus.NEXT
                        if (target == TaskStatus.INBOX) linked else Domain.moveTask(linked, newTask.id, target)
                    }
                }
                "move_task" -> runCatching { Domain.moveTask(next, action.taskId, TaskStatus.valueOf(action.status)) }.getOrNull()
                "complete_task" -> Domain.moveTask(next, action.taskId, TaskStatus.DONE)
                "link_task" -> {
                    val existing = next.tasks.firstOrNull { it.id == action.taskId }
                    if (existing == null) null else next.copy(tasks = next.tasks.map {
                        if (it.id == action.taskId) it.copy(projectId = action.projectId.takeIf { id -> id.isNotBlank() }, updatedAt = System.currentTimeMillis()) else it
                    })
                }
                "create_project" -> Domain.addProject(next, action.title, action.outcome, action.nextAction)
                "update_project" -> {
                    val current = next.projects.firstOrNull { it.id == action.projectId }
                    if (current == null) null else {
                        val status = action.status.takeIf { it.isNotBlank() }?.let { runCatching { ProjectStatus.valueOf(it) }.getOrNull() }
                        Domain.updateProject(
                            next, current.id,
                            action.outcome.ifBlank { current.outcome },
                            action.nextAction.ifBlank { current.nextAction },
                            status
                        )
                    }
                }
                else -> null
            }
            if (candidate == null) failed.add(action.description(next))
            else {
                next = candidate
                applied++
            }
        }
        pendingAssistantActions = emptyList()
        if (applied == 0) {
            renderHome()
            showToast("No proposed changes could be applied. Check the project/task limits and try again.")
        } else {
            commit(next, "$applied proposed change${if (applied == 1) "" else "s"} applied to Threadline.")
            if (failed.isNotEmpty()) showToast("${failed.size} proposal${if (failed.size == 1) " was" else "s were"} skipped because the current state didn’t allow them.")
        }
    }

    private fun saveAssistantConversation() {
        val transcript = chatBubbles.joinToString("\n\n") { if (it.fromUser) "YOU: ${it.text}" else "THREADLINE: ${it.text}" }
            .take(MAX_TASK_TEXT)
        if (transcript.isBlank()) { showToast("There is no conversation to save yet."); return }
        val next = Domain.capture(requireState(), transcript)
        if (next == null) showToast("Could not save the conversation. Check the inbox limit.")
        else {
            activeTab = Tab.INBOX
            commit(next, "Conversation saved to your encrypted inbox.")
        }
    }

    private fun clearAssistantConversation() {
        if (chatBubbles.isEmpty() && pendingAssistantActions.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Start a new conversation?")
            .setMessage("This clears the current chat from memory and discards unapproved suggestions. Saved captures, tasks and projects remain unchanged.")
            .setNegativeButton("Keep chatting", null)
            .setPositiveButton("New conversation") { _, _ ->
                chatBubbles.clear()
                pendingAssistantActions = emptyList()
                voiceStatus = "Ready when you are."
                background.execute { localAi.resetConversation() }
                renderHome()
            }.show()
    }

    private fun confirmModelDownload() {
        if (modelDownloadRunning) { showToast("A model download is already running."); return }
        val description = label("Threadline will download only the public Qwen3-0.6B model from Hugging Face (about 345 MB). It is saved in private app storage. Your captures, voice transcript and project data are not uploaded. Use Wi-Fi if possible.", 13, C.MUTED)
        val progressText = label("No download started.", 12, C.MUTED).apply { setPadding(0, dp(8), 0, dp(4)) }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; progress = 0 }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(6), dp(20), dp(2))
            addView(description, bottom(8))
            addView(progress, bottom(2))
            addView(progressText)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Download a local brain")
            .setView(panel)
            .setNegativeButton("Close", null)
            .setPositiveButton("Download model", null)
            .create()
        dialog.setOnShowListener {
            val primary = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val secondary = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            secondary.setOnClickListener {
                if (modelDownloadRunning) {
                    modelDownloadCancelled.set(true)
                    progressText.text = "Stopping the download safely…"
                    secondary.isEnabled = false
                } else dialog.dismiss()
            }
            primary.setOnClickListener {
                if (modelDownloadRunning) return@setOnClickListener
                modelDownloadCancelled.set(false)
                modelDownloadRunning = true
                primary.isEnabled = false
                primary.text = "Downloading…"
                secondary.text = "Cancel download"
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                progressText.text = "Connecting securely to the model host…"
                background.execute {
                    val result: Exception? = try {
                        localAi.downloadDefaultModel({ modelDownloadCancelled.get() }) { downloaded, total ->
                            mainHandler.post {
                                if (total > 0L) {
                                    progress.isIndeterminate = false
                                    progress.progress = ((downloaded * 1000L) / total).toInt().coerceIn(0, 1000)
                                    progressText.text = "${downloaded / 1_000_000} / ${total / 1_000_000} MB downloaded"
                                } else {
                                    progress.isIndeterminate = true
                                    progressText.text = "${downloaded / 1_000_000} MB downloaded"
                                }
                            }
                        }
                        null
                    } catch (e: Exception) { e }
                    mainHandler.post {
                        modelDownloadRunning = false
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        if (result == null) {
                            dialog.dismiss()
                            showToast("Local model installed. Your private voice companion is ready to try.")
                            renderHomeIfUnlocked()
                        } else {
                            progressText.text = (result.message ?: "Download failed.").take(260)
                            primary.text = "Retry download"
                            primary.isEnabled = true
                            secondary.text = "Close"
                            secondary.isEnabled = true
                        }
                    }
                }
            }
        }
        dialog.show()
    }

    private fun captureCard(): View {
        val edit = textField("What's on your mind? Don't organize it yet…", MAX_TASK_TEXT).apply {
            minLines = 2
            maxLines = 4
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        return card().apply {
            addView(label("CAPTURE STUDIO", 10, C.TEAL, true), bottom(7))
            addView(label("Get it out of your head.", 19, C.INK, true), bottom(4))
            addView(label("Thoughts, conversations, photos and files. Keep the original; decide what it means later.", 13, C.MUTED), bottom(12))
            addView(edit, bottom(10))
            addView(button("Save to inbox  →", true) {
                val value = edit.text.toString()
                val next = Domain.capture(requireState(), value)
                if (next == null) showToast("Capture something up to $MAX_TASK_TEXT characters.")
                else commit(next, "Saved privately. You can decide what it means later.")
            }, bottom(10))
            val media = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            media.addView(button("🎙 Voice", false, compact = true) { startVoiceCapture() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
            media.addView(button("▧ Photo", false, compact = true) { startCameraCapture() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
            media.addView(button("＋ File", false, compact = true) { launchAttachmentPicker() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4) })
            addView(media)
            addView(label("Voice transcription runs on-device where supported. Attachments are stored inside your encrypted vault.", 11, C.MUTED).apply { setPadding(0, dp(9), 0, 0) })
        }
    }

    private fun taskCard(task: TaskItem, state: ThreadState, from: TaskStatus): View {
        val card = card()
        val associatedProject = state.projects.firstOrNull { it.id == task.projectId }
        if (associatedProject != null) card.addView(label(associatedProject.title.uppercase(), 10, C.TEAL, true), bottom(6))
        card.addView(label(task.text, 16, C.INK, true).apply {
            maxLines = 6
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, bottom(6))
        val created = Instant.ofEpochMilli(task.createdAt).atZone(ZoneId.systemDefault()).toLocalDate()
        card.addView(label("Added ${created.format(DateTimeFormatter.ofPattern("d MMM"))} · ${task.status.name.lowercase(Locale.ROOT).replace('_', ' ')}", 12, C.MUTED), bottom(10))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        when (from) {
            TaskStatus.TODAY -> {
                actions.addView(button("Done", true, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                    if (next != null) commit(next, "One less open loop.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Move to Next", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Moved out of today's focus.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.INBOX -> {
                val todayFull = state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS
                actions.addView(button("Today", true, compact = true, enabled = !todayFull) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next == null) showToast("Today already has three focus items. Move one to Next first.")
                    else commit(next, "Added to today's focus.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Next", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Promoted to Next.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
                actions.addView(button("Delete", false, compact = true) {
                    AlertDialog.Builder(this)
                        .setTitle("Delete this item?")
                        .setMessage("This removes it from your encrypted vault. It cannot be undone unless you have a backup.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ -> commit(Domain.deleteTask(requireState(), task.id), "Item deleted.") }
                        .show()
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.NEXT -> {
                val canFocus = state.tasks.count { it.status == TaskStatus.TODAY } < MAX_TODAY_TASKS
                actions.addView(button("Focus today", true, compact = true, enabled = canFocus) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next != null) commit(next, "Added to today's focus.")
                    else showToast("Today already has three focus items.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Later", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.LATER)
                    if (next != null) commit(next, "Parked for later.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
                actions.addView(button("Done", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                    if (next != null) commit(next, "Marked done.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.LATER -> {
                val canFocus = state.tasks.count { it.status == TaskStatus.TODAY } < MAX_TODAY_TASKS
                actions.addView(button("Bring to Next", true, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Brought back to Next.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Today", false, compact = true, enabled = canFocus) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next != null) commit(next, "Added to today's focus.")
                    else showToast("Today already has three focus items.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            else -> Unit
        }
        if (actions.childCount > 0) card.addView(actions, bottom(8))
        if (!task.attachmentName.isNullOrBlank()) {
            card.addView(label("▧  ${task.attachmentName}  ·  ${task.attachmentMime ?: "file"}", 12, C.TEAL, true), bottom(7))
            card.addView(button("View attachment", false, compact = true) { viewAttachment(task) }, bottom(8))
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(button("Edit", false, compact = true) { editTask(task) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
        tools.addView(button(if (localAi.isReady()) "✦ Think" else "AI setup", true, compact = true) {
            if (localAi.isReady()) processWithLocalAi(task) else showAiSetup()
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        tools.addView(button("Delete", false, compact = true) {
            AlertDialog.Builder(this).setTitle("Delete this capture?")
                .setMessage("The capture and its encrypted attachment will be removed from this phone. This cannot be undone unless you have a backup.")
                .setNegativeButton("Keep it", null)
                .setPositiveButton("Delete") { _, _ -> commit(Domain.deleteTask(requireState(), task.id), "Capture deleted.") }
                .show()
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3) })
        card.addView(tools)
        return card
    }

    private fun editTask(task: TaskItem) {
        val input = textField("Capture text", MAX_TASK_TEXT).apply { setText(task.text); minLines = 2; maxLines = 4 }
        AlertDialog.Builder(this)
            .setTitle("Edit capture")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save changes") { _, _ ->
                val next = Domain.updateTask(requireState(), task.id, input.text.toString())
                if (next == null) showToast("The capture cannot be empty or longer than $MAX_TASK_TEXT characters.")
                else commit(next, "Capture updated.")
            }
            .show()
    }

    private fun showGlobalSearch() {
        val input = textField("Search notes, tasks and projects", 100).apply { setSingleLine(true) }
        AlertDialog.Builder(this)
            .setTitle("Find a thread")
            .setMessage("Search your encrypted captures and project context on this device.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Search", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val q = input.text.toString().trim()
                        if (q.isBlank()) { input.error = "Enter a search term"; return@setOnClickListener }
                        val state = requireState()
                        val matches = buildList {
                            state.tasks.filter { it.text.contains(q, true) || it.attachmentName.orEmpty().contains(q, true) }
                                .take(20).forEach { add("${it.status.name}  ·  ${it.text}${it.attachmentName?.let { name -> "\nAttachment: $name" }.orEmpty()}") }
                            state.projects.filter { it.title.contains(q, true) || it.outcome.contains(q, true) || it.nextAction.contains(q, true) }
                                .take(10).forEach { add("PROJECT  ·  ${it.title}\n${it.nextAction.ifBlank { it.outcome }}") }
                            state.reviews.filter { it.movedForward.contains(q, true) || it.nextStep.contains(q, true) || it.parked.contains(q, true) }
                                .take(5).forEach { add("REVIEW  ·  ${it.day}\n${it.movedForward} ${it.nextStep} ${it.parked}".trim()) }
                        }.take(25)
                        dialog.dismiss()
                        val body = if (matches.isEmpty()) "No matches yet. Try a different word." else matches.joinToString("\n\n────────────────\n\n")
                        AlertDialog.Builder(this).setTitle("${matches.size} result${if (matches.size == 1) "" else "s"}")
                            .setMessage(body).setPositiveButton("Done", null).show()
                    }
                }
                dialog.show()
            }
    }

    private fun showAiSetup() {
        val size = localAi.modelSizeBytes()
        val status = if (localAi.isReady()) {
            "A local model is installed (${size / (1024 * 1024)} MB). The Talk screen can use it to reason about your actual projects and open tasks. Your personal data stays on this device."
        } else {
            "No local language model is installed yet. Threadline includes Google's LiteRT-LM runtime. Download the recommended model inside the app or import a compatible .litertlm file."
        }
        val guidance = if (localAi.isReady()) "\n\nModel setup is complete. Open Talk for voice conversation and proposed changes. You can remove or replace the model here." else "\n\nThe recommended Qwen3-0.6B download is about 345 MB (329 MiB). It needs internet once; inference then runs on-device. Spoken replies also need a matching offline voice in Android settings."
        val message = label(status + guidance, 14, C.INK)
        AlertDialog.Builder(this)
            .setTitle("Local AI setup")
            .setView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), dp(2)); addView(message) })
            .setNegativeButton("Close", null)
            .setNeutralButton(if (localAi.isReady()) "Remove model" else "Download model", null)
            .setPositiveButton(if (localAi.isReady()) "Import / replace" else "Import model") { _, _ -> launchModelPicker() }
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                        if (localAi.isReady()) {
                            AlertDialog.Builder(this).setTitle("Remove local model?")
                                .setMessage("This deletes only the downloaded AI model. Your encrypted captures and projects remain unchanged.")
                                .setNegativeButton("Cancel", null)
                                .setPositiveButton("Remove") { _, _ ->
                                    background.execute {
                                        localAi.removeModel()
                                        runOnUiThread { showToast("Local model removed."); if (appState != null) renderHome() else renderLocked() }
                                    }
                                }.show()
                        } else {
                            dialog.dismiss()
                            confirmModelDownload()
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun launchModelPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, "Choose a .litertlm model")
        }
        try {
            externalFlowActive = true
            startActivityForResult(intent, REQUEST_MODEL)
        } catch (e: Exception) {
            externalFlowActive = false
            showToast("Could not open the file picker.")
        }
    }

    private fun processWithLocalAi(task: TaskItem) {
        if (!localAi.isReady()) { showAiSetup(); return }
        showToast("Working locally on this phone… Larger models may take a little while.")
        background.execute {
            val result = try { localAi.think(task) } catch (e: Exception) {
                "LOCAL AI COULD NOT PROCESS THIS CAPTURE\n\n${(e.message ?: "The model could not be loaded.").take(350)}\n\nIf this is an image, the selected model may be text-only. Try a vision-capable .litertlm model for image understanding."
            }
            runOnUiThread {
                if (isFinishing || appState == null || !vault.isUnlocked()) return@runOnUiThread
                val isError = result.startsWith("LOCAL AI COULD NOT")
                val suggested = if (!isError) result.lineSequence()
                    .firstOrNull { it.trim().startsWith("POSSIBLE NEXT MOVE", ignoreCase = true) }
                    ?.substringAfter(':', "")?.trim()
                    ?.takeIf { it.isNotBlank() && !it.equals("No action needed", true) && !it.equals("None", true) && !it.startsWith("No clear", true) }
                    ?.replace(Regex("^[\\-•*\\s]+"), "")?.take(MAX_TASK_TEXT) else null
                AlertDialog.Builder(this)
                    .setTitle(if (isError) "Local AI needs attention" else "A way forward")
                    .setMessage(result)
                    .setNegativeButton("Close", null)
                    .setNeutralButton("Save insight") { _, _ ->
                        val insight = result.lineSequence().firstOrNull { it.trim().startsWith("WHAT I HEAR", true) }
                            ?.substringAfter(':', "")?.trim().takeIf { !it.isNullOrBlank() } ?: result
                        val next = Domain.capture(requireState(), insight.take(MAX_TASK_TEXT))
                        if (next == null) showToast("Could not save that insight.") else commit(next, "Insight saved to inbox.")
                    }
                    .setPositiveButton(if (suggested != null) "Add next move" else "Save response") { _, _ ->
                        if (suggested != null && !isError) {
                            val captured = Domain.capture(requireState(), suggested)
                            val newTask = captured?.tasks?.lastOrNull()
                            val next = if (captured != null && newTask != null) Domain.moveTask(captured, newTask.id, TaskStatus.NEXT) else null
                            if (next == null) showToast("Could not add the suggested move.") else commit(next, "Suggested next move added to Next. Review it before acting.")
                        } else {
                            val note = Domain.capture(requireState(), result.take(MAX_TASK_TEXT))
                            if (note == null) showToast("Could not save that response.") else commit(note, "Response saved to inbox.")
                        }
                    }.show()
            }
        }
    }

    private fun startVoiceCapture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            showToast("On-device voice capture requires Android 12 or newer. Keyboard dictation is still available.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            externalFlowActive = true
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), REQUEST_VOICE_PERMISSION)
            return
        }
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            showToast("This phone does not currently have an offline speech-recognition service available. Text capture still works.")
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { showToast("Listening… speak naturally.") }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { showToast("Processing speech on-device…") }
                    override fun onError(error: Int) {
                        speechRecognizer?.destroy(); speechRecognizer = null
                        showToast("Voice capture stopped (code $error). Try again or type instead.")
                    }
                    override fun onResults(results: Bundle?) {
                        val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        speechRecognizer?.destroy(); speechRecognizer = null
                        saveVoiceTranscript(transcript)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) {
            speechRecognizer?.destroy(); speechRecognizer = null
            showToast("Could not start on-device speech recognition. ${e.message.orEmpty()}".take(160))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_VOICE_PERMISSION || requestCode == REQUEST_ASSISTANT_PERMISSION) externalFlowActive = false
        if (requestCode == REQUEST_VOICE_PERMISSION) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceCapture()
            else showToast("Microphone permission was not granted. You can still capture text, photos and files.")
        } else if (requestCode == REQUEST_ASSISTANT_PERMISSION) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && voiceSessionActive) startAssistantListening()
            else {
                voiceSessionActive = false
                voiceStatus = "Microphone permission wasn't granted. You can still type to Threadline."
                renderHomeIfUnlocked()
            }
        }
    }

    private fun saveVoiceTranscript(raw: String) {
        val transcript = raw.trim().take(MAX_TASK_TEXT)
        if (transcript.isBlank()) { showToast("No speech was recognized. Try again."); return }
        val next = Domain.capture(requireState(), transcript)
        if (next == null) showToast("Could not save the transcript. Check the inbox limit.")
        else commit(next, "Voice transcript saved. No audio was uploaded or retained.")
    }

    private fun startCameraCapture() {
        try {
            val dir = File(cacheDir, "captures").apply { mkdirs() }
            val file = File(dir, "capture-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            pendingCameraFile = file
            pendingCameraUri = uri
            val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
                clipData = ClipData.newRawUri("Threadline photo", uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            externalFlowActive = true
            startActivityForResult(intent, REQUEST_CAMERA)
        } catch (e: Exception) {
            externalFlowActive = false
            pendingCameraFile?.delete(); pendingCameraFile = null; pendingCameraUri = null
            showToast("Could not open the camera. ${e.message.orEmpty()}".take(150))
        }
    }

    private fun launchAttachmentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        }
        try {
            externalFlowActive = true
            startActivityForResult(intent, REQUEST_ATTACHMENT)
        } catch (e: Exception) {
            externalFlowActive = false
            showToast("Could not open the file picker.")
        }
    }

    private fun saveCameraCapture(resultData: Intent? = null) {
        val file = pendingCameraFile
        pendingCameraFile = null; pendingCameraUri = null
        // Some camera apps ignore EXTRA_OUTPUT and return only a small thumbnail in the result.
        if (file != null && (!file.exists() || file.length() == 0L)) {
            val thumbnail = resultData?.extras?.get("data") as? Bitmap
            if (thumbnail != null) {
                runCatching {
                    file.outputStream().use { output ->
                        check(thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, output)) { "Could not save camera thumbnail." }
                    }
                }
            }
        }
        if (file == null || !file.exists() || file.length() == 0L) {
            file?.delete()
            showToast("No photo was captured.")
            return
        }
        showToast("Securing photo in your private vault…")
        background.execute {
            val result = try {
                val raw = file.inputStream().use { readLimited(it, 18 * 1024 * 1024) }
                normalizeImage(raw)
            } catch (e: Exception) { null } finally { file.delete() }
            runOnUiThread {
                if (result == null) { showToast("Could not process that image. Try another photo."); return@runOnUiThread }
                saveAttachmentBytes("Photo-${LocalDate.now()}.jpg", "image/jpeg", result)
            }
        }
    }

    private fun saveSelectedAttachment(uri: Uri) {
        showToast("Importing attachment into the encrypted vault…")
        background.execute {
            val name = try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: "attachment"
            } catch (_: Exception) { "attachment" }.take(180)
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val bytes = try {
                contentResolver.openInputStream(uri)?.use { readLimited(it, 12 * 1024 * 1024) }
                    ?: error("Could not read the selected file.")
            } catch (e: Exception) {
                runOnUiThread { showToast((e.message ?: "Could not read that file.").take(150)) }
                return@execute
            }
            val safeBytes = try { if (mime.startsWith("image/")) normalizeImage(bytes) else bytes.also { require(it.size <= MAX_ATTACHMENT_BYTES) { "This file is too large. Attachments are limited to 1.5 MB each in this build." } } }
                catch (e: Exception) {
                    bytes.fill(0)
                    runOnUiThread { showToast((e.message ?: "Could not process that file.").take(150)) }
                    return@execute
                }
            bytes.fill(0)
            runOnUiThread { saveAttachmentBytes(name, mime, safeBytes) }
        }
    }

    private fun saveAttachmentBytes(name: String, mime: String, bytes: ByteArray) {
        if (appState == null || !vault.isUnlocked()) {
            bytes.fill(0)
            showToast("Threadline locked before the attachment finished importing. Unlock and try again.")
            return
        }
        try {
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val text = "Review attachment: $name".take(MAX_TASK_TEXT)
            val next = Domain.capture(requireState(), text, name, mime, encoded)
            if (next == null) showToast("The attachment could not be saved. The encrypted vault has reached its attachment limit.")
            else commit(next, "Attachment saved inside your encrypted vault.")
        } finally { bytes.fill(0) }
    }

    private fun normalizeImage(raw: ByteArray): ByteArray {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(raw, 0, raw.size, options)
        require(options.outWidth > 0 && options.outHeight > 0) { "The selected file is not a readable image." }
        var sample = 1
        while (options.outWidth / sample > 1400 || options.outHeight / sample > 1400) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("Could not decode the image.")
        raw.fill(0)
        var working = bitmap
        var out: ByteArray
        var attempt = 0
        do {
            val stream = ByteArrayOutputStream()
            working.compress(Bitmap.CompressFormat.JPEG, if (attempt == 0) 76 else 64, stream)
            out = stream.toByteArray()
            if (out.size <= MAX_ATTACHMENT_BYTES || attempt >= 2) break
            val smaller = Bitmap.createScaledBitmap(working, (working.width * 0.72f).toInt().coerceAtLeast(1), (working.height * 0.72f).toInt().coerceAtLeast(1), true)
            if (smaller !== working) working.recycle()
            working = smaller
            attempt++
        } while (true)
        working.recycle()
        require(out.size <= MAX_ATTACHMENT_BYTES) { "Image could not be reduced below 1.5 MB." }
        return out
    }

    private fun viewAttachment(task: TaskItem) {
        val data = task.attachmentBase64 ?: return
        val bytes = try { Base64.decode(data, Base64.DEFAULT) } catch (_: Exception) { showToast("Attachment data is invalid."); return }
        val mime = task.attachmentMime ?: "application/octet-stream"
        if (mime.startsWith("image/")) {
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            bytes.fill(0)
            if (bitmap == null) { showToast("Could not preview this image."); return }
            val image = ImageView(this).apply {
                setImageBitmap(bitmap)
                adjustViewBounds = true
                maxHeight = dp(440)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            AlertDialog.Builder(this).setTitle(task.attachmentName ?: "Photo")
                .setView(image).setPositiveButton("Done") { _, _ -> bitmap.recycle() }.show()
        } else if (mime.startsWith("text/")) {
            val content = bytes.toString(Charsets.UTF_8).take(12_000)
            bytes.fill(0)
            val view = ScrollView(this).apply { addView(label(content.ifBlank { "This text file is empty." }, 14, C.INK).apply { setPadding(dp(18), dp(12), dp(18), dp(12)) }) }
            AlertDialog.Builder(this).setTitle(task.attachmentName ?: "Text attachment")
                .setView(view).setPositiveButton("Done", null).show()
        } else {
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(12), dp(20), 0)
                addView(label(task.attachmentName ?: "Attachment", 17, C.INK, true), bottom(6))
                addView(label("Type: $mime\nStored inside your encrypted vault.", 13, C.MUTED))
            }
            AlertDialog.Builder(this).setTitle("Attachment")
                .setView(panel).setNegativeButton("Close") { _, _ -> bytes.fill(0) }
                .setPositiveButton("Open in another app") { _, _ -> openAttachmentInViewer(task, bytes) }
                .show()
        }
    }

    private fun openAttachmentInViewer(task: TaskItem, bytes: ByteArray) {
        try {
            val dir = File(cacheDir, "captures").apply { mkdirs() }
            val file = File(dir, "preview-${System.currentTimeMillis()}-${task.attachmentName.orEmpty().replace(Regex("[^A-Za-z0-9._-]"), "_").take(40)}")
            file.writeBytes(bytes)
            transientViewerFile = file
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, task.attachmentMime ?: "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            transientViewerFile?.delete(); transientViewerFile = null
            showToast("No app could open this attachment, or access was denied. ${e.message.orEmpty()}".take(170))
        } finally { bytes.fill(0) }
    }

    private fun projectCard(project: ProjectItem): View {
        val card = card()
        val statusLine = project.status.name.lowercase(Locale.ROOT).replaceFirstChar { it.uppercaseChar() }
        card.addView(label(statusLine.uppercase(), 10, C.TEAL, true), bottom(5))
        card.addView(label(project.title, 18, C.INK, true), bottom(6))
        if (project.outcome.isNotBlank()) {
            card.addView(label("OUTCOME", 10, C.MUTED, true), bottom(2))
            card.addView(label(project.outcome, 14, C.INK), bottom(8))
        }
        card.addView(label("NEXT ACTION", 10, C.MUTED, true), bottom(2))
        card.addView(label(project.nextAction.ifBlank { "No next action recorded yet." }, 14, if (project.nextAction.isBlank()) C.MUTED else C.INK), bottom(12))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (project.status == ProjectStatus.ACTIVE) {
            row.addView(button("Add to Next", true, compact = true) {
                val current = requireState()
                val alreadyOpen = current.tasks.any {
                    it.projectId == project.id && it.text.equals(project.nextAction.trim(), ignoreCase = true) && it.status != TaskStatus.DONE
                }
                if (project.nextAction.isBlank()) showToast("Add a next action to this project first.")
                else if (alreadyOpen) showToast("This action already has an open task.")
                else {
                    val next = Domain.addProjectNextAction(current, project.id)
                    if (next == null) showToast("Could not add this action. Check the project and task limits.")
                    else commit(next, "Project action added to Next.")
                }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            row.addView(button("Focus", false, compact = true) { focusProject(project.id) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
            row.addView(button("Edit", false, compact = true) { editProject(project) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
            card.addView(row, bottom(8))
            card.addView(button("Park this project", false, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.PARKED)
                if (updated != null) commit(updated, "Project parked.")
            })
        } else if (project.status == ProjectStatus.PARKED) {
            card.addView(button("Reactivate project", true, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.ACTIVE)
                if (updated != null) commit(updated, "Project reactivated.")
            })
        } else {
            card.addView(button("Reopen project", false, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.ACTIVE)
                if (updated != null) commit(updated, "Project reopened.")
            })
        }
        return card
    }

    private fun projectSummary(project: ProjectItem): View = card().apply {
        addView(label(project.title, 16, C.INK, true), bottom(5))
        addView(label(project.nextAction.ifBlank { "Add a next action to get this moving." }, 13, C.MUTED), bottom(9))
        addView(button("Open projects", false, compact = true) { activeTab = Tab.PROJECTS; renderHome() })
    }

    private fun focusProject(projectId: String) {
        val state = requireState()
        if (state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS) {
            showToast("Today already has three focus items. Move one to Next first.")
            return
        }
        val project = state.projects.firstOrNull { it.id == projectId } ?: return
        if (project.nextAction.isBlank()) { showToast("Add a next action first."); return }
        val existing = state.tasks.firstOrNull { it.projectId == projectId && it.text == project.nextAction && it.status != TaskStatus.DONE }
        val next = if (existing != null) Domain.moveTask(state, existing.id, TaskStatus.TODAY)
        else state.copy(tasks = state.tasks + TaskItem(text = project.nextAction, status = TaskStatus.TODAY, projectId = project.id))
        if (next == null) showToast("Could not add that action to today.") else {
            activeTab = Tab.TODAY
            commit(next, "Project action is today's focus.")
        }
    }

    private fun editProject(project: ProjectItem) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val outcome = textField("Outcome", MAX_PROJECT_TEXT).apply { setText(project.outcome) }
        val next = textField("Next action", MAX_PROJECT_TEXT).apply { setText(project.nextAction) }
        panel.addView(outcome, bottom(8)); panel.addView(next)
        AlertDialog.Builder(this)
            .setTitle("Edit ${project.title}")
            .setView(panel)
            .setNegativeButton("Cancel", null)
            .setNeutralButton(if (project.status == ProjectStatus.DONE) "Keep done" else "Mark done") { _, _ ->
                val updated = Domain.updateProject(requireState(), project.id, outcome.text.toString(), next.text.toString(), ProjectStatus.DONE)
                if (updated != null) commit(updated, "Project marked completed.")
            }
            .setPositiveButton("Save") { _, _ ->
                val updated = Domain.updateProject(requireState(), project.id, outcome.text.toString(), next.text.toString())
                if (updated != null) commit(updated, "Project updated.")
            }.show()
    }

    private fun statCard(number: String, caption: String): View = card().apply {
        addView(label(number, 24, C.INK, true), bottom(3))
        addView(label(caption, 12, C.MUTED))
    }

    private fun emptyCard(title: String, body: String): View = card().apply {
        addView(label(title, 16, C.INK, true), bottom(5))
        addView(label(body, 13, C.MUTED))
    }

    private fun sectionTitle(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 18, C.INK, true), bottom(3))
        addView(label(subtitle, 12, C.MUTED))
    }

    private fun sectionLabel(text: String): View = label(text, 11, C.TEAL, true)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(C.WHITE, 18, C.BORDER)
    }

    private fun label(text: String, size: Int, textColor: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color(textColor))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        includeFontPadding = true
        setLineSpacing(dp(2).toFloat(), 1.0f)
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    private fun textField(hint: String, maxChars: Int): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 14f
        setTextColor(color(C.INK))
        setHintTextColor(color(C.MUTED))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = rounded(C.FIELD, 12, C.BORDER)
        filters = arrayOf(InputFilter.LengthFilter(maxChars))
        isSaveEnabled = false
        importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        setSingleLine(false)
        minHeight = dp(46)
    }

    private fun button(
        text: String,
        primary: Boolean,
        compact: Boolean = false,
        enabled: Boolean = true,
        onClick: () -> Unit
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = if (compact) 12.5f else 14f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(if (compact) 8 else 14), dp(10), dp(if (compact) 8 else 14), dp(10))
        setTextColor(color(if (primary) C.NAVY else C.INK))
        background = rounded(if (primary) C.MINT else C.SECONDARY, 14, if (primary) C.MINT else C.BORDER)
        alpha = if (enabled) 1f else 0.45f
        isEnabled = enabled
        isClickable = enabled
        if (enabled) setOnClickListener { onClick() }
        minHeight = dp(if (compact) 40 else 46)
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color(fill)); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), color(stroke))
    }

    private fun bottom(dpValue: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(dpValue) }
    private fun top(dpValue: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(dpValue) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun color(value: Int): Int = value
    private fun requireState(): ThreadState = appState ?: error("The vault is locked.")

    private fun commit(next: ThreadState, message: String) {
        try {
            val validated = Domain.validate(next)
            vault.save(validated)
            appState = validated
            latestError = null
            renderHome()
            showToast(message)
        } catch (e: Exception) {
            showToast((e.message ?: "Could not save. Your previous data remains unchanged.").take(180))
        }
    }

    private fun completedToday(state: ThreadState): Int {
        val today = LocalDate.now()
        return state.tasks.count { task ->
            task.status == TaskStatus.DONE && task.completedAt?.let {
                Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate() == today
            } == true
        }
    }

    private fun lockNow() {
        endVoiceSession(render = false)
        chatBubbles.clear()
        pendingAssistantActions = emptyList()
        chatBusy = false
        runCatching { background.execute { localAi.close() } }
        vault.clearSession()
        appState = null
        renderLocked()
    }

    private fun showToast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun promptExportPassword() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val first = textField("Backup passphrase (12+ characters)", 200).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        val second = textField("Repeat backup passphrase", 200).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        panel.addView(first, bottom(8)); panel.addView(second)
        val dialog = AlertDialog.Builder(this).setTitle("Encrypt a backup")
            .setMessage("Keep the passphrase separate from the backup file. Threadline cannot recover a forgotten passphrase.")
            .setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Encrypt backup", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = first.text.toString()
                val b = second.text.toString()
                if (a.length < 12) { first.error = "Use at least 12 characters"; return@setOnClickListener }
                if (a != b) { second.error = "Passphrases do not match"; return@setOnClickListener }
                val password = a.toCharArray()
                first.setText(""); second.setText(""); dialog.dismiss()
                val stateBytes = try { StateCodec.encode(requireState()) } catch (e: Exception) { showToast("Could not prepare backup."); return@setOnClickListener }
                showToast("Encrypting backup…")
                background.execute {
                    try {
                        val result = BackupCrypto.encrypt(stateBytes, password)
                        stateBytes.fill(0)
                        runOnUiThread {
                            pendingBackup?.fill(0)
                            pendingBackup = result
                            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "application/octet-stream"
                                putExtra(Intent.EXTRA_TITLE, "threadline-backup.tlb")
                            }
                            externalFlowActive = true
                            startActivityForResult(intent, REQUEST_EXPORT)
                        }
                    } catch (e: Exception) {
                        stateBytes.fill(0); password.fill('\u0000')
                        runOnUiThread { showToast((e.message ?: "Backup encryption failed.").take(180)) }
                    }
                }
            }
        }
        dialog.show()
    }

    private fun launchImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        externalFlowActive = true
        startActivityForResult(intent, REQUEST_IMPORT)
    }

    @Deprecated("Required for the Storage Access Framework and external camera picker.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode in setOf(REQUEST_EXPORT, REQUEST_IMPORT, REQUEST_MODEL, REQUEST_ATTACHMENT, REQUEST_CAMERA, REQUEST_TTS_SETTINGS)) externalFlowActive = false
        if (requestCode == REQUEST_TTS_SETTINGS) {
            refreshOfflineVoices()
            renderHomeIfUnlocked()
            return
        }
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == RESULT_OK) saveCameraCapture(data) else {
                pendingCameraFile?.delete(); pendingCameraFile = null; pendingCameraUri = null
                showToast("Photo capture cancelled.")
            }
            return
        }
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup?.fill(0); pendingBackup = null
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_EXPORT -> writeBackup(uri)
            REQUEST_IMPORT -> readBackup(uri)
            REQUEST_MODEL -> importSelectedModel(uri)
            REQUEST_ATTACHMENT -> saveSelectedAttachment(uri)
        }
    }

    private fun importSelectedModel(uri: Uri) {
        val name = try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            } ?: "model"
        } catch (_: Exception) { "model" }
        showToast("Importing model. This may take a few minutes…")
        background.execute {
            val result = try { localAi.importModel(contentResolver, uri, name) } catch (e: Exception) { e }
            runOnUiThread {
                if (result is Long) {
                    showToast("Local model imported (${result / (1024 * 1024)} MB). Try Make sense on an inbox capture.")
                    if (appState != null) renderHome() else renderLocked()
                } else {
                    val error = (result as? Exception)?.message ?: "Model import failed."
                    showToast(error.take(220))
                }
            }
        }
    }

    private fun writeBackup(uri: Uri) {
        val bytes = pendingBackup ?: run { showToast("No encrypted backup is ready."); return }
        try {
            contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes); it.flush() }
                ?: error("Could not open the selected destination.")
            showToast("Encrypted backup saved. Keep the passphrase safe.")
        } catch (e: Exception) {
            showToast((e.message ?: "Could not write backup file.").take(180))
        } finally {
            bytes.fill(0); pendingBackup = null
        }
    }

    private fun readBackup(uri: Uri) {
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { readLimited(it, 10 * 1024 * 1024) }
                ?: error("Could not open the selected file.")
        } catch (e: Exception) {
            showToast((e.message ?: "Could not read backup.").take(180)); return
        }
        promptImportPassword(bytes)
    }

    private fun promptImportPassword(bytes: ByteArray) {
        val input = textField("Backup passphrase", 200).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Restore encrypted backup")
            .setMessage("The current vault will be replaced after the backup is verified and you authenticate.")
            .setView(input).setNegativeButton("Cancel") { _, _ -> bytes.fill(0) }
            .setPositiveButton("Verify backup", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = input.text.toString()
                if (raw.length < 12) { input.error = "Enter your backup passphrase"; return@setOnClickListener }
                val password = raw.toCharArray()
                input.setText(""); dialog.dismiss()
                showToast("Verifying encrypted backup…")
                background.execute {
                    val imported = try {
                        val plaintext = BackupCrypto.decrypt(bytes, password)
                        bytes.fill(0)
                        try { StateCodec.decode(plaintext) } finally { plaintext.fill(0) }
                    } catch (e: Exception) {
                        bytes.fill(0); password.fill('\u0000')
                        runOnUiThread { showToast((e.message ?: "Backup verification failed.").take(180)) }
                        null
                    }
                    if (imported != null) runOnUiThread { authorizeAndRestore(imported) }
                }
            }
        }
        dialog.show()
    }

    private fun authorizeAndRestore(imported: ThreadState) {
        val finish: (ThreadState?, String?) -> Unit = { _, error ->
            if (error != null) {
                latestError = error
                appState = null
                vault.clearSession()
                renderLocked()
            } else {
                try {
                    vault.save(imported)
                    appState = imported
                    activeTab = Tab.TODAY
                    latestError = null
                    renderHome()
                    showToast("Backup restored successfully.")
                } catch (e: Exception) {
                    latestError = e.message ?: "Could not restore the backup."
                    appState = null
                    vault.clearSession()
                    renderLocked()
                }
            }
        }
        if (vault.isInitialized()) {
            vault.unlockForRestore(this) { authorized, error -> finish(if (authorized) imported else null, error) }
        } else {
            // On a clean install (or after explicitly erasing an inaccessible vault), establish a fresh key first.
            vault.setup(this) { newState, error ->
                if (newState == null) finish(null, error)
                else finish(imported, null)
            }
        }
    }

    private fun readLimited(input: InputStream, max: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= max) { "The selected file is larger than this operation allows." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private object C {
        const val NAVY = 0xff142521.toInt()
        const val BG = 0xfff2f5f1.toInt()
        const val WHITE = 0xffffffff.toInt()
        const val INK = 0xff19242c.toInt()
        const val MUTED = 0xff65736f.toInt()
        const val LIGHT_MUTED = 0xffbdc9c7.toInt()
        const val MINT = 0xffb2efcf.toInt()
        const val TEAL = 0xff276b56.toInt()
        const val BORDER = 0xffe0e7e3.toInt()
        const val FIELD = 0xfff8faf8.toInt()
        const val SECONDARY = 0xffe9efeb.toInt()
        const val ERROR = 0xffff8e83.toInt()
    }

    private companion object {
        const val REQUEST_EXPORT = 3001
        const val REQUEST_IMPORT = 3002
        const val REQUEST_VOICE_PERMISSION = 3003
        const val REQUEST_MODEL = 3004
        const val REQUEST_ATTACHMENT = 3005
        const val REQUEST_CAMERA = 3006
        const val REQUEST_ASSISTANT_PERMISSION = 3007
        const val REQUEST_TTS_SETTINGS = 3008
    }
}
