package com.threadline.privateplanner

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.app.KeyguardManager
import android.content.Intent
import android.speech.RecognizerIntent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : Activity() {
    private lateinit var webView: WebView
    @Volatile private var pendingShare = ""
    @Volatile private var pageReady = false
    private var cameraTempFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(247, 248, 245)
        window.navigationBarColor = Color.rgb(247, 248, 245)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        File(cacheDir, "attachments").deleteRecursively()
        pendingShare = incomingShare(intent)
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(247, 248, 245))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            addJavascriptInterface(VaultBridge(), "ThreadlineBridge")
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    // Keep the app shell local. External links are opened only through an explicit UI action.
                    return uri.scheme != "file" || !uri.path.orEmpty().endsWith("/android_asset/index.html")
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    deliverIncomingShare()
                }
            }
        }
        setContentView(webView)
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (keyguard.isDeviceSecure) {
            val authIntent = keyguard.createConfirmDeviceCredentialIntent(
                "Unlock Threadline",
                "Confirm your device credential to open your private workspace"
            )
            if (authIntent != null) {
                startActivityForResult(authIntent, 2404)
                return
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.evaluateJavascript("window.persistWorkspace && window.persistWorkspace()", null)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val shared = incomingShare(intent)
        if (shared.isNotBlank()) {
            pendingShare = shared
            deliverIncomingShare()
        }
    }

    private fun incomingShare(intent: Intent?): String {
        if (intent?.action != Intent.ACTION_SEND) return ""
        val data = JSONObject()
        data.put("text", intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty())
        data.put("title", intent.getCharSequenceExtra(Intent.EXTRA_SUBJECT)?.toString().orEmpty())
        val stream = try { intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) } catch (_: Exception) { null }
        if (stream != null) {
            data.put("uri", stream.toString())
            data.put("mime", intent.type.orEmpty())
            data.put("name", queryDisplayName(stream))
        }
        return if (data.optString("text").isNotBlank() || data.optString("uri").isNotBlank()) data.toString() else ""
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0).orEmpty() else "Shared attachment"
            } ?: "Shared attachment"
        } catch (_: Exception) { "Shared attachment" }
    }

    private fun deliverIncomingShare() {
        if (!pageReady || pendingShare.isBlank()) return
        val payload = pendingShare
        pendingShare = ""
        val quoted = JSONObject.quote(payload)
        runOnUiThread { webView.evaluateJavascript("window.receiveNativeShare && window.receiveNativeShare($quoted)", null) }
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2404) {
            if (resultCode == Activity.RESULT_OK) webView.loadUrl("file:///android_asset/index.html") else finish()
            return
        }
        if (resultCode != Activity.RESULT_OK) return
        when (requestCode) {
            2401 -> {
                val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) runOnUiThread {
                    webView.evaluateJavascript("window.receiveVoiceNote && window.receiveVoiceNote(${JSONObject.quote(spoken)})", null)
                }
            }
            2402 -> {
                val uri = data?.data ?: return
                val result = copyUriToAttachments(uri)
                if (result.isNotBlank()) runOnUiThread {
                    webView.evaluateJavascript("window.receiveNativeAttachment && window.receiveNativeAttachment(${JSONObject.quote(result)})", null)
                }
            }
            2403 -> {
                val file = cameraTempFile ?: return
                val result = copyFileToAttachments(file, "Photo.jpg", "image/jpeg")
                cameraTempFile = null
                if (result.isNotBlank()) runOnUiThread {
                    webView.evaluateJavascript("window.receiveNativeAttachment && window.receiveNativeAttachment(${JSONObject.quote(result)})", null)
                }
            }
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleSystemBack && window.handleSystemBack()") { result ->
            if (result == "false" || result == null) super@MainActivity.onBackPressed()
        }
    }

    inner class VaultBridge {
        @JavascriptInterface fun loadVault(): String = try {
            val file = File(filesDir, "threadline-vault-1.7.bin")
            if (!file.exists()) "" else decrypt(file.readBytes())
        } catch (_: Exception) { "" }

        @JavascriptInterface fun saveVault(json: String): Boolean = try {
            val bytes = encrypt(json)
            val temp = File(filesDir, "threadline-vault-1.7.tmp")
            FileOutputStream(temp).use { it.write(bytes); it.fd.sync() }
            val target = File(filesDir, "threadline-vault-1.7.bin")
            if (target.exists() && !target.delete()) throw IllegalStateException("Could not replace vault")
            if (!temp.renameTo(target)) throw IllegalStateException("Could not save vault")
            true
        } catch (_: Exception) { false }

        @JavascriptInterface fun copyText(text: String): Boolean = try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Threadline", text))
            runOnUiThread { Toast.makeText(this@MainActivity, "Copied to clipboard", Toast.LENGTH_SHORT).show() }
            true
        } catch (_: Exception) { false }

        @JavascriptInterface fun openUrl(value: String): Boolean {
            return try {
                val uri = Uri.parse(value.trim())
                if (uri.scheme !in listOf("https", "http", "mailto")) false
                else { startActivity(Intent(Intent.ACTION_VIEW, uri)); true }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun shareText(text: String, subject: String): Boolean = try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                putExtra(Intent.EXTRA_SUBJECT, subject)
            }
            runOnUiThread { startActivity(Intent.createChooser(send, "Share from Threadline")) }
            true
        } catch (_: Exception) { false }

        @JavascriptInterface fun startVoiceCapture(): Boolean {
            return try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your note")
                }
                if (intent.resolveActivity(packageManager) == null) false
                else { runOnUiThread { startActivityForResult(intent, 2401) }; true }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun pickAttachment(): Boolean {
            return try {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                if (intent.resolveActivity(packageManager) == null) false
                else { runOnUiThread { startActivityForResult(intent, 2402) }; true }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun capturePhoto(): Boolean {
            return try {
                val dir = File(cacheDir, "camera").apply { mkdirs() }
                val photo = File(dir, "threadline-${System.currentTimeMillis()}.jpg")
                cameraTempFile = photo
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", photo)
                val intent = Intent(Intent.ACTION_IMAGE_CAPTURE).apply {
                    putExtra(Intent.EXTRA_OUTPUT, uri)
                    addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                if (intent.resolveActivity(packageManager) == null) false
                else { runOnUiThread { startActivityForResult(intent, 2403) }; true }
            } catch (_: Exception) { cameraTempFile = null; false }
        }

        @JavascriptInterface fun importSharedAttachment(uriValue: String): String {
            return try { copyUriToAttachments(Uri.parse(uriValue)) } catch (_: Exception) { "" }
        }

        @JavascriptInterface fun openAttachment(id: String): Boolean {
            return try {
                if (!id.matches(Regex("[A-Za-z0-9_.-]{1,100}"))) return false
                val file = File(File(filesDir, "attachments"), id)
                if (!file.exists()) return false
                val mime = contentTypeFor(file.name)
                val openedDir = File(cacheDir, "attachments").apply { mkdirs() }
                val opened = File(openedDir, id)
                FileOutputStream(opened).use { output -> output.write(decryptBytes(file.readBytes())); output.fd.sync() }
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", opened)
                val launch = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                if (launch.resolveActivity(packageManager) == null) false
                else {
                    runOnUiThread { try { startActivity(launch) } catch (_: Exception) { Toast.makeText(this@MainActivity, "No app can open this attachment", Toast.LENGTH_SHORT).show() } }
                    true
                }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun consumeIncomingShare(): String {
            val payload = pendingShare
            pendingShare = ""
            return payload
        }
    }

    private fun copyUriToAttachments(uri: Uri): String {
        return try {
            val name = queryDisplayName(uri).ifBlank { "Attachment" }.take(160)
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val dir = File(filesDir, "attachments").apply { mkdirs() }
            val id = "att_${System.currentTimeMillis()}_${(1000..9999).random()}"
            val ext = when {
                mime == "image/jpeg" -> ".jpg"
                mime == "image/png" -> ".png"
                mime == "image/webp" -> ".webp"
                mime == "application/pdf" -> ".pdf"
                mime.startsWith("text/") -> ".txt"
                else -> ".bin"
            }
            val target = File(dir, id + ext)
            val bytes = contentResolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > 25L * 1024 * 1024) throw IllegalArgumentException("Attachment is larger than 25 MB")
                    output.write(buffer, 0, read)
                }
                output.toByteArray()
            } ?: return ""
            FileOutputStream(target).use { it.write(encryptBytes(bytes)); it.fd.sync() }
            JSONObject().put("id", target.name).put("name", name).put("mime", mime).put("size", bytes.size).toString()
        } catch (_: Exception) { "" }
    }

    private fun copyFileToAttachments(source: File, name: String, mime: String): String {
        return try {
            if (!source.exists() || source.length() <= 0L) return ""
            val dir = File(filesDir, "attachments").apply { mkdirs() }
            val id = "att_${System.currentTimeMillis()}_${(1000..9999).random()}.jpg"
            val target = File(dir, id)
            val bytes = source.readBytes()
            FileOutputStream(target).use { it.write(encryptBytes(bytes)); it.fd.sync() }
            JSONObject().put("id", target.name).put("name", name).put("mime", mime).put("size", bytes.size).toString()
        } catch (_: Exception) { "" }
    }

    private fun contentTypeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "pdf" -> "application/pdf"
        "txt" -> "text/plain"
        else -> "application/octet-stream"
    }

    private fun secretKey(): SecretKey {
        val alias = "threadline_local_vault_v1_7"
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun encrypt(value: String): ByteArray = encryptBytes(value.toByteArray(Charsets.UTF_8))

    private fun encryptBytes(value: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(value)
        return byteArrayOf(iv.size.toByte()) + iv + ciphertext
    }

    private fun decrypt(value: ByteArray): String = decryptBytes(value).toString(Charsets.UTF_8)

    private fun decryptBytes(value: ByteArray): ByteArray {
        require(value.isNotEmpty())
        val ivSize = value[0].toInt() and 0xff
        require(ivSize in 12..16 && value.size > ivSize + 1)
        val iv = value.copyOfRange(1, ivSize + 1)
        val ciphertext = value.copyOfRange(ivSize + 1, value.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }
}
