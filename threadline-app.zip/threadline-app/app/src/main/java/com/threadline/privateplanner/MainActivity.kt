package com.threadline.privateplanner

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.app.KeyguardManager
import android.content.Intent
import android.content.ComponentName
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.net.ConnectivityManager
import android.os.Process
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import androidx.core.app.ActivityCompat
import android.Manifest
import java.net.HttpURLConnection
import java.net.URL
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import android.database.Cursor
import android.os.Build
import android.os.StatFs
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.Executors
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : Activity() {
    private lateinit var webView: WebView
    @Volatile private var pendingShare = ""
    @Volatile private var pageReady = false
    @Volatile private var pendingCaptureLaunch = false
    @Volatile private var pendingOpenModels = false
    @Volatile private var pendingAssistantOpen = false
    @Volatile private var pendingLiveFeedOpen = false
    private var cameraTempFile: File? = null
    private val localAiExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var localAiBusy = false
    @Volatile private var modelDownloadBusy = false
    @Volatile private var modelImportBusy = false
    @Volatile private var pendingVoiceTarget = "capture"
    @Volatile private var pendingAssistantStart = false
    private var conversationalTts: TextToSpeech? = null
    @Volatile private var conversationalTtsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(247, 248, 245)
        window.navigationBarColor = Color.rgb(247, 248, 245)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        File(cacheDir, "attachments").deleteRecursively()
        pendingShare = incomingShare(intent)
        pendingCaptureLaunch = intent?.action == FloatingAssistantService.ACTION_QUICK_CAPTURE
        if (intent?.action == FloatingAssistantService.ACTION_OPEN_LIVE_FEED) pendingLiveFeedOpen = true
        if (intent?.action == FloatingAssistantService.ACTION_OPEN_ASSISTANT) pendingAssistantOpen = true
        pendingOpenModels = intent?.getBooleanExtra("open_models", false) == true
        SourceMirrorWorker.schedule(this)
        ModelCatalogueWorker.schedule(this)
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(247, 248, 245))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            addJavascriptInterface(VaultBridge(), "ThreadlineBridge")
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    // Keep the app shell local. External links are opened only through an explicit UI action.
                    return uri.scheme != "file" || !uri.path.orEmpty().endsWith("/android_asset/index.html")
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    deliverIncomingShare()
                    deliverFloatingCapture()
                    deliverPendingOpenModels()
                    deliverPendingAssistantOpen()
                    deliverPendingLiveFeedOpen()
                }
            }
        }
        setContentView(webView)
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (keyguard.isDeviceSecure) {
            val authIntent = keyguard.createConfirmDeviceCredentialIntent(
                "Unlock Threadline",
                "Confirm your device credential to open your private workspace"
            )
            if (authIntent != null) {
                startActivityForResult(authIntent, 2404)
                return
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized && pageReady) {
            webView.post { webView.evaluateJavascript("window.onThreadlineResumed && window.onThreadlineResumed()", null) }
        }
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.evaluateJavascript("window.persistWorkspace && window.persistWorkspace()", null)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val shared = incomingShare(intent)
        if (shared.isNotBlank()) {
            pendingShare = shared
            deliverIncomingShare()
        }
        if (intent.action == FloatingAssistantService.ACTION_QUICK_CAPTURE) {
            pendingCaptureLaunch = true
            deliverFloatingCapture()
        }
        if (intent.getBooleanExtra("open_models", false)) {
            pendingOpenModels = true
            deliverPendingOpenModels()
        }
        if (intent.action == FloatingAssistantService.ACTION_OPEN_ASSISTANT) { pendingAssistantOpen = true; deliverPendingAssistantOpen() }
        if (intent.action == FloatingAssistantService.ACTION_OPEN_LIVE_FEED) { pendingLiveFeedOpen = true; deliverPendingLiveFeedOpen() }
    }

    private fun deliverFloatingCapture() {
        if (!pageReady || !pendingCaptureLaunch || !::webView.isInitialized) return
        pendingCaptureLaunch = false
        runOnUiThread { webView.evaluateJavascript("window.launchQuickCapture && window.launchQuickCapture()", null) }
    }


    private fun deliverPendingOpenModels() {
        if (!pageReady || !pendingOpenModels || !::webView.isInitialized) return
        pendingOpenModels = false
        runOnUiThread { webView.evaluateJavascript("window.openLocalModels && window.openLocalModels()", null) }
    }

    private fun deliverPendingAssistantOpen() {
        if (!pageReady || !pendingAssistantOpen || !::webView.isInitialized) return
        pendingAssistantOpen = false
        runOnUiThread { webView.evaluateJavascript("window.openAssistant && window.openAssistant()", null) }
    }

    private fun deliverPendingLiveFeedOpen() {
        if (!pageReady || !pendingLiveFeedOpen || !::webView.isInitialized) return
        pendingLiveFeedOpen = false
        runOnUiThread { webView.evaluateJavascript("window.openLiveFeedSettings && window.openLiveFeedSettings()", null) }
    }

    private fun incomingShare(intent: Intent?): String {
        if (intent?.action != Intent.ACTION_SEND && intent?.action != Intent.ACTION_SEND_MULTIPLE) return ""
        val data = JSONObject()
        data.put("text", intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty())
        data.put("title", intent.getCharSequenceExtra(Intent.EXTRA_SUBJECT)?.toString().orEmpty())
        data.put("mime", intent.type.orEmpty())
        if (intent.action == Intent.ACTION_SEND_MULTIPLE) {
            val streams = try { intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty() } catch (_: Exception) { arrayListOf() }
            val uris = JSONArray()
            streams.distinctBy { it.toString() }.take(20).forEach { uri ->
                uris.put(JSONObject().put("uri", uri.toString()).put("name", queryDisplayName(uri)).put("mime", contentResolver.getType(uri) ?: intent.type.orEmpty()))
            }
            if (uris.length() > 0) data.put("uris", uris)
        } else {
            val stream = try { intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) } catch (_: Exception) { null }
            if (stream != null) {
                data.put("uri", stream.toString())
                data.put("name", queryDisplayName(stream))
            }
        }
        return if (data.optString("text").isNotBlank() || data.optString("uri").isNotBlank() || data.optJSONArray("uris")?.length()?.let { it > 0 } == true) data.toString() else ""
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0).orEmpty() else "Shared attachment"
            } ?: "Shared attachment"
        } catch (_: Exception) { "Shared attachment" }
    }

    private fun deliverIncomingShare() {
        if (!pageReady || pendingShare.isBlank()) return
        val payload = pendingShare
        pendingShare = ""
        val quoted = JSONObject.quote(payload)
        runOnUiThread { webView.evaluateJavascript("window.receiveNativeShare && window.receiveNativeShare($quoted)", null) }
    }

    /** Launch Android's Storage Access Framework without package-visibility checks. Some OEMs
     * omit a dedicated DocumentsUI activity, so fall back to ACTION_GET_CONTENT if needed. */
    private fun launchDocumentPicker(requestCode: Int, title: String, modelOnly: Boolean) {
        val first = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(first, requestCode)
            return
        } catch (_: Exception) { }
        val fallback = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_TITLE, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(Intent.createChooser(fallback, title), requestCode)
        } catch (_: Exception) {
            val msg = if (modelOnly) "No Android file picker could be opened. Open Files, find the .litertlm model, and try Import again." else "No Android file picker could be opened. Check that Files or a document provider is enabled."
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
    }

    /** Persist only URI permissions actually granted by the selected document provider. */
    private fun persistUriPermissionsIfGranted(uri: Uri, grantedFlags: Int) {
        if ((grantedFlags and Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // The provider may grant only temporary access.
            }
        }
        if ((grantedFlags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != 0) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: SecurityException) {
                // The provider may grant only temporary access.
            }
        }
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2404) {
            if (resultCode == Activity.RESULT_OK) webView.loadUrl("file:///android_asset/index.html") else finish()
            return
        }
        if (resultCode != Activity.RESULT_OK) return
        when (requestCode) {
            2405 -> {
                val uri = data?.data ?: return
                persistUriPermissionsIfGranted(uri, data.flags)
                modelImportBusy = true
                localAiExecutor.execute {
                    val result = importLocalModel(uri)
                    modelImportBusy = false
                    runOnUiThread {
                        val payload = JSONObject.quote(result)
                        if (::webView.isInitialized) webView.evaluateJavascript("window.onLocalModelImported && window.onLocalModelImported($payload)", null)
                    }
                }
            }
            2406 -> {
                val uri = data?.data ?: return
                persistUriPermissionsIfGranted(uri, data.flags)
                getSharedPreferences(SourceMirrorWorker.PREFS, Context.MODE_PRIVATE).edit()
                    .putString(SourceMirrorWorker.KEY_TREE_URI, uri.toString()).apply()
                SourceMirrorWorker.schedule(this)
                SourceMirrorWorker.syncNow(this)
                runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.onMirrorFolderSelected && window.onMirrorFolderSelected()", null) }
            }
            2401 -> {
                val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
                val target = pendingVoiceTarget
                pendingVoiceTarget = "capture"
                if (spoken.isNotBlank()) runOnUiThread {
                    val callback = if (target == "assistant") "receiveAssistantDictation" else "receiveVoiceNote"
                    webView.evaluateJavascript("window.$callback && window.$callback(${JSONObject.quote(spoken)})", null)
                }
            }
            2402 -> {
                val uri = data?.data ?: return
                persistUriPermissionsIfGranted(uri, data.flags)
                val result = copyUriToAttachments(uri)
                if (result.isNotBlank()) runOnUiThread {
                    webView.evaluateJavascript("window.receiveNativeAttachment && window.receiveNativeAttachment(${JSONObject.quote(result)})", null)
                }
            }
            2403 -> {
                val file = cameraTempFile ?: return
                val result = copyFileToAttachments(file, "Photo.jpg", "image/jpeg")
                cameraTempFile = null
                if (result.isNotBlank()) runOnUiThread {
                    webView.evaluateJavascript("window.receiveNativeAttachment && window.receiveNativeAttachment(${JSONObject.quote(result)})", null)
                }
            }
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleSystemBack && window.handleSystemBack()") { result ->
            if (result == "false" || result == null) super@MainActivity.onBackPressed()
        }
    }

    override fun onDestroy() {
        try { conversationalTts?.stop(); conversationalTts?.shutdown() } catch (_: Exception) { }
        conversationalTts = null
        localAiExecutor.shutdownNow()
        super.onDestroy()
    }

    inner class VaultBridge {
        @JavascriptInterface fun loadVault(): String = try {
            val file = File(filesDir, "threadline-vault-1.7.bin")
            if (!file.exists()) "" else decrypt(file.readBytes())
        } catch (_: Exception) { "" }

        @JavascriptInterface fun saveVault(json: String): Boolean = try {
            val bytes = encrypt(json)
            val temp = File(filesDir, "threadline-vault-1.7.tmp")
            FileOutputStream(temp).use { it.write(bytes); it.fd.sync() }
            val target = File(filesDir, "threadline-vault-1.7.bin")
            try {
                java.nio.file.Files.move(temp.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE)
            } catch (_: Exception) {
                if (target.exists() && !target.delete()) throw IllegalStateException("Could not replace vault")
                if (!temp.renameTo(target)) throw IllegalStateException("Could not save vault")
            }
            true
        } catch (_: Exception) { false }

        @JavascriptInterface fun copyText(text: String): Boolean = try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Threadline", text))
            runOnUiThread { Toast.makeText(this@MainActivity, "Copied to clipboard", Toast.LENGTH_SHORT).show() }
            true
        } catch (_: Exception) { false }

        @JavascriptInterface fun openUrl(value: String): Boolean {
            return try {
                val uri = Uri.parse(value.trim())
                if (uri.scheme !in listOf("https", "http", "mailto")) false
                else { startActivity(Intent(Intent.ACTION_VIEW, uri)); true }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun shareText(text: String, subject: String): Boolean = try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                putExtra(Intent.EXTRA_SUBJECT, subject)
            }
            runOnUiThread { startActivity(Intent.createChooser(send, "Share from Threadline")) }
            true
        } catch (_: Exception) { false }

        @JavascriptInterface fun startVoiceCapture(): Boolean = startSpeechCapture("capture")

        @JavascriptInterface fun startAssistantVoiceCapture(): Boolean = startSpeechCapture("assistant")

        private fun startSpeechCapture(target: String): Boolean {
            pendingVoiceTarget = target
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2411) }
                return true
            }
            return launchSpeechRecognizer(target)
        }

        private fun launchSpeechRecognizer(target: String): Boolean {
            return try {
                val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, ConversationalVoice.localeFor(this@MainActivity).toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, if (target == "assistant") "Talk to Threadline" else "Speak your note")
                }
                runOnUiThread { try { startActivityForResult(speechIntent, 2401) } catch (_: Exception) { pendingVoiceTarget = "capture"; Toast.makeText(this@MainActivity, "No speech recognizer is available.", Toast.LENGTH_SHORT).show() } }
                true
            } catch (_: Exception) { pendingVoiceTarget = "capture"; false }
        }

        @JavascriptInterface fun isVoiceOutputEnabled(): Boolean = getSharedPreferences(FloatingAssistantService.ASSISTANT_PREFS, Context.MODE_PRIVATE).getBoolean(FloatingAssistantService.KEY_VOICE_OUTPUT, true)

        @JavascriptInterface fun setVoiceOutputEnabled(enabled: Boolean): Boolean {
            getSharedPreferences(FloatingAssistantService.ASSISTANT_PREFS, Context.MODE_PRIVATE).edit().putBoolean(FloatingAssistantService.KEY_VOICE_OUTPUT, enabled).apply()
            return true
        }

        @JavascriptInterface fun speakText(text: String): Boolean {
            val plain = ConversationalVoice.cleanText(text)
            if (plain.isBlank()) return false
            runOnUiThread {
                if (conversationalTts == null) {
                    conversationalTts = TextToSpeech(this@MainActivity) { status ->
                        if (status == TextToSpeech.SUCCESS) {
                            conversationalTtsReady = true
                            conversationalTts?.let { ConversationalVoice.configure(it, this@MainActivity) }
                            conversationalTts?.speak(plain, TextToSpeech.QUEUE_FLUSH, null, "threadline-web-${System.currentTimeMillis()}")
                        }
                    }
                } else if (conversationalTtsReady) {
                    try { conversationalTts?.speak(plain, TextToSpeech.QUEUE_FLUSH, null, "threadline-web-${System.currentTimeMillis()}") } catch (_: Exception) { }
                }
            }
            return true
        }

        @JavascriptInterface fun stopSpokenReply(): Boolean = try { conversationalTts?.stop(); true } catch (_: Exception) { false }

        @JavascriptInterface fun assistantHistory(): String = AssistantStore.history(this@MainActivity).toString()
        @JavascriptInterface fun appendAssistantMessage(role: String, content: String): Boolean {
            if (content.length > 12000 || role !in setOf("user", "assistant", "system")) return false
            AssistantStore.appendMessage(this@MainActivity, role, content)
            return true
        }
        @JavascriptInterface fun pendingAssistantActions(): String = AssistantStore.pendingActions(this@MainActivity).toString()
        @JavascriptInterface fun acknowledgeAssistantActions(idsJson: String): Boolean {
            if (idsJson.length > 12000) return false
            return try {
                val parsed = JSONArray(idsJson)
                val ids = (0 until parsed.length()).mapNotNull { parsed.optString(it).takeIf { id -> id.matches(Regex("assistant_[A-Za-z0-9_]+")) } }.toSet()
                AssistantStore.acknowledgeActions(this@MainActivity, ids)
            } catch (_: Exception) { false }
        }
        @JavascriptInterface fun updateAssistantContext(value: String): Boolean {
            if (value.length > 12000) return false
            AssistantStore.setWorkspaceContext(this@MainActivity, value)
            return true
        }

        @JavascriptInterface fun pickAttachment(): Boolean {
            return try {
                runOnUiThread { launchDocumentPicker(2402, "Choose an attachment", false) }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun capturePhoto(): Boolean {
            return try {
                val dir = File(cacheDir, "camera").apply { mkdirs() }
                val photo = File(dir, "threadline-${System.currentTimeMillis()}.jpg")
                cameraTempFile = photo
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", photo)
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    putExtra(MediaStore.EXTRA_OUTPUT, uri)
                    addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { try { startActivityForResult(intent, 2403) } catch (_: Exception) { Toast.makeText(this@MainActivity, "No camera app is available.", Toast.LENGTH_LONG).show() } }
                true
            } catch (_: Exception) { cameraTempFile = null; false }
        }

        @JavascriptInterface fun importSharedAttachment(uriValue: String): String {
            return try { copyUriToAttachments(Uri.parse(uriValue)) } catch (_: Exception) { "" }
        }

        @JavascriptInterface fun openAttachment(id: String): Boolean {
            return try {
                if (!id.matches(Regex("[A-Za-z0-9_.-]{1,100}"))) return false
                val file = File(File(filesDir, "attachments"), id)
                if (!file.exists()) return false
                val mime = contentTypeFor(file.name)
                val openedDir = File(cacheDir, "attachments").apply { mkdirs() }
                val opened = File(openedDir, id)
                FileOutputStream(opened).use { output -> output.write(decryptBytes(file.readBytes())); output.fd.sync() }
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", opened)
                val launch = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { try { startActivity(launch) } catch (_: Exception) { Toast.makeText(this@MainActivity, "No app can open this attachment", Toast.LENGTH_SHORT).show() } }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun floatingAssistantEnabled(): Boolean {
            val allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this@MainActivity)
            return allowed && getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).getBoolean("floating_enabled", false)
        }

        @JavascriptInterface fun toggleFloatingAssistant(): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread {
                    try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "Open Android settings and allow Threadline to display over other apps.", Toast.LENGTH_LONG).show() }
                }
                return false
            }
            val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
            val currentlyEnabled = prefs.getBoolean("floating_enabled", false)
            if (currentlyEnabled) {
                stopService(Intent(this@MainActivity, FloatingAssistantService::class.java))
                prefs.edit().putBoolean("floating_enabled", false).apply()
                return true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingAssistantStart = true
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2412) }
                return false
            }
            return startFloatingAssistantNow()
        }

        @JavascriptInterface fun openAppDetailsSettings(): Boolean = try {
            runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            true
        } catch (_: Exception) { false }

        private fun startFloatingAssistantNow(): Boolean {
            val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
            return try {
                val serviceIntent = Intent(this@MainActivity, FloatingAssistantService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                prefs.edit().putBoolean("floating_enabled", true).apply()
                true
            } catch (e: Exception) {
                prefs.edit().putBoolean("floating_enabled", false).apply()
                runOnUiThread { Toast.makeText(this@MainActivity, "Could not start the floating assistant: ${e.message ?: "service unavailable"}", Toast.LENGTH_LONG).show() }
                false
            }
        }
        @JavascriptInterface fun localAIStatus(): String = localAIStatusJson()

        @JavascriptInterface fun importLocalAIModel(): Boolean {
            if (modelImportBusy || modelDownloadBusy || localAiBusy) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Wait for the current model operation to finish.", Toast.LENGTH_SHORT).show() }
                return false
            }
            return try {
                runOnUiThread { launchDocumentPicker(2405, "Choose a .litertlm model", true) }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun setActiveLocalAIModel(name: String): Boolean {
            val file = safeModelFile(name) ?: return false
            if (!file.isFile || file.length() <= 0L) return false
            getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).edit().putString("active_model", file.name).apply()
            return true
        }

        @JavascriptInterface fun deleteLocalAIModel(name: String): Boolean {
            val file = safeModelFile(name) ?: return false
            val active = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).getString("active_model", "")
            if (active == file.name) getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE).edit().remove("active_model").apply()
            return !file.exists() || file.delete()
        }

        @JavascriptInterface fun runLocalAI(prompt: String, requestId: String): Boolean {
            if (prompt.isBlank() || prompt.length > 18000 || !requestId.matches(Regex("[A-Za-z0-9_.-]{1,120}"))) return false
            val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
            val activeName = prefs.getString("active_model", "").orEmpty()
            val model = safeModelFile(activeName) ?: return false
            if (!model.isFile || localAiBusy || modelDownloadBusy || modelImportBusy || AssistantRuntime.busy) return false
            localAiBusy = true
            localAiExecutor.execute {
                var output = ""
                var error = ""
                try {
                    // The app chat and floating assistant share one serialized on-device inference runtime.
                    output = AssistantRuntime.generate(this@MainActivity, prompt)
                    if (output.isBlank()) error = "The local model returned an empty response. Try a smaller input or another model."
                } catch (e: Throwable) {
                    error = (e.message ?: e.javaClass.simpleName).take(500)
                } finally { localAiBusy = false }
                val payload = JSONObject().put("requestId", requestId).put("text", output).put("error", error).toString()
                runOnUiThread {
                    if (::webView.isInitialized) webView.evaluateJavascript("window.onLocalAIComplete && window.onLocalAIComplete(${JSONObject.quote(payload)})", null)
                }
            }
            return true
        }

        @JavascriptInterface fun extractTextFromAttachment(id: String, requestId: String): Boolean {
            if (!id.matches(Regex("[A-Za-z0-9_.-]{1,100}")) || !requestId.matches(Regex("[A-Za-z0-9_.-]{1,120}"))) return false
            val encrypted = File(File(filesDir, "attachments"), id)
            if (!encrypted.isFile) return false
            return try {
                val dir = File(cacheDir, "ocr-temp").apply { mkdirs() }
                val plain = File(dir, "ocr-${System.currentTimeMillis()}-${id.substringAfterLast('_').take(24)}")
                FileOutputStream(plain).use { it.write(decryptBytes(encrypted.readBytes())); it.fd.sync() }
                val image = InputImage.fromFilePath(this@MainActivity, Uri.fromFile(plain))
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val payload = JSONObject().put("requestId", requestId).put("text", result.text).put("error", "").toString()
                        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.onOCRComplete && window.onOCRComplete(${JSONObject.quote(payload)})", null) }
                    }
                    .addOnFailureListener { e ->
                        val payload = JSONObject().put("requestId", requestId).put("text", "").put("error", (e.message ?: "On-device OCR failed").take(300)).toString()
                        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.onOCRComplete && window.onOCRComplete(${JSONObject.quote(payload)})", null) }
                    }
                    .addOnCompleteListener { recognizer.close(); plain.delete() }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun chooseSourceMirrorFolder(): Boolean {
            return try {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                runOnUiThread { try { startActivityForResult(intent, 2406) } catch (_: Exception) { Toast.makeText(this@MainActivity, "Android could not open the folder picker.", Toast.LENGTH_LONG).show() } }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun runSourceMirrorSync(): Boolean {
            return try {
                if (getSharedPreferences(SourceMirrorWorker.PREFS, Context.MODE_PRIVATE).getString(SourceMirrorWorker.KEY_TREE_URI, null).isNullOrBlank()) return false
                SourceMirrorWorker.syncNow(this@MainActivity)
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun sourceMirrorStatus(): String {
            return try {
                val prefs = getSharedPreferences(SourceMirrorWorker.PREFS, Context.MODE_PRIVATE)
                val mirrorDir = File(filesDir, "source-mirror")
                val manifestFile = File(mirrorDir, "manifest.enc")
                val legacyManifestFile = File(mirrorDir, "manifest.json")
                val manifest = when {
                    manifestFile.isFile -> JSONObject(MirrorCrypto.decrypt(manifestFile.readBytes()).toString(Charsets.UTF_8))
                    legacyManifestFile.isFile -> JSONObject(legacyManifestFile.readText())
                    else -> JSONObject()
                }
                val entries = manifest.optJSONArray("entries") ?: JSONArray()
                val flattened = JSONArray()
                for (i in 0 until entries.length()) {
                    val entry = entries.optJSONObject(i) ?: continue
                    val versions = entry.optJSONArray("versions")
                    if (versions != null) for (v in 0 until versions.length()) {
                        val prior = versions.optJSONObject(v) ?: continue
                        flattened.put(JSONObject(prior.toString()).put("historicalVersion", true))
                    }
                    flattened.put(JSONObject(entry.toString()).apply { remove("versions") })
                }
                JSONObject().put("folderSelected", !prefs.getString(SourceMirrorWorker.KEY_TREE_URI, null).isNullOrBlank())
                    .put("treeUri", prefs.getString(SourceMirrorWorker.KEY_TREE_URI, "").orEmpty())
                    .put("lastSyncAt", prefs.getLong("mirror_last_sync", 0L))
                    .put("lastResult", try { JSONObject(prefs.getString("mirror_last_result", "{}") ?: "{}") } catch (_: Exception) { JSONObject() })
                    .put("records", flattened).toString()
            } catch (e: Exception) { JSONObject().put("folderSelected", false).put("error", e.message ?: "Mirror unavailable").put("records", JSONArray()).toString() }
        }

        @JavascriptInterface fun checkModelCatalogueNow(): Boolean {
            return try {
                val request = OneTimeWorkRequestBuilder<ModelCatalogueWorker>().build()
                WorkManager.getInstance(this@MainActivity).enqueueUniqueWork("threadline-model-catalogue-now", ExistingWorkPolicy.KEEP, request)
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun modelCatalogue(): String {
            val models = JSONArray()
            // These two files are documented by Google's current LiteRT-LM Android guide.
            // Keep the smaller Qwen first for phones with limited RAM/storage.
            models.put(JSONObject().put("id", "qwen3-0.6b")
                .put("name", "Qwen3 0.6B · CPU")
                .put("repo", "litert-community/Qwen3-0.6B")
                .put("file", "Qwen3-0.6B.litertlm").put("bytes", 600L * 1000 * 1000)
                .put("url", "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm")
                .put("repoUrl", "https://huggingface.co/litert-community/Qwen3-0.6B")
                .put("gated", false).put("description", "Smallest starting point in this catalogue. Roughly 0.6 GB; intended for on-device CPU inference."))
            models.put(JSONObject().put("id", "gemma4-e2b")
                .put("name", "Gemma 4 E2B · int4")
                .put("repo", "litert-community/gemma-4-E2B-it-litert-lm")
                .put("file", "gemma-4-E2B-it.litertlm").put("bytes", 2_600_000_000L)
                .put("url", "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm")
                .put("repoUrl", "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm")
                .put("gated", true).put("description", "Larger 2.6 GB model. Requires considerably more RAM, free storage and acceptance of the model terms."))

            // Add newly discovered compatible files from the official catalogue. Dynamic entries
            // are accepted only when the repository is the official publisher and the filename is
            // safe to use in app-private storage. Each entry keeps its own repo/file URL.
            val saved = getSharedPreferences(ModelCatalogueWorker.PREFS, Context.MODE_PRIVATE)
                .getString("discovered_models", "[]") ?: "[]"
            val discovered = try { JSONArray(saved) } catch (_: Exception) { JSONArray() }
            val existingKeys = mutableSetOf<String>()
            for (i in 0 until models.length()) {
                val known = models.getJSONObject(i)
                existingKeys.add(known.optString("repo") + "::" + known.optString("remoteFile", known.optString("file")))
            }
            for (i in 0 until discovered.length()) {
                val candidate = discovered.optJSONObject(i) ?: continue
                val repo = candidate.optString("repo")
                val file = candidate.optString("file")
                val bytes = candidate.optLong("bytes", 0L)
                if (!repo.startsWith("litert-community/") || safeModelFile(file) == null) continue
                if (bytes < 100L * 1024 * 1024 || bytes > 3L * 1024 * 1024 * 1024) continue
                val key = repo + "::" + candidate.optString("remoteFile", file)
                if (!existingKeys.add(key)) continue
                models.put(JSONObject(candidate.toString()))
                if (models.length() >= 40) break
            }
            return JSONObject()
                .put("checkedAt", getSharedPreferences(ModelCatalogueWorker.PREFS, Context.MODE_PRIVATE).getLong("catalogue_checked_at", 0L))
                .put("models", models)
                .put("catalogueSource", "LiteRT Community / Hugging Face")
                .toString()
        }

        @JavascriptInterface fun installCatalogueModel(modelId: String, requestId: String): Boolean {
            if (!requestId.matches(Regex("[A-Za-z0-9_.-]{1,120}"))) return false
            val catalogue = JSONObject(modelCatalogue()).getJSONArray("models")
            val model = (0 until catalogue.length()).map { catalogue.getJSONObject(it) }.firstOrNull { it.optString("id") == modelId } ?: return false
            synchronized(this@MainActivity) {
                if (modelDownloadBusy) return false
                modelDownloadBusy = true
            }
            localAiExecutor.execute {
                val name = model.optString("file")
                val target = safeModelFile(name) ?: run {
                    modelDownloadBusy = false
                    sendModelDownloadProgress(requestId, name, 0L, model.optLong("bytes", -1L), "failed", "Unsafe or unsupported local model filename.")
                    return@execute
                }
                val temp = File(target.parentFile, target.name + ".partial")
                var received = 0L
                var total = model.optLong("bytes", -1L)
                var err = ""
                try {
                    val available = StatFs(filesDir.absolutePath).availableBytes
                    if (total > 0 && total > available - 96L * 1024 * 1024) throw IllegalArgumentException("Not enough internal storage. Free at least ${((total + 96L * 1024 * 1024) / (1024*1024))} MB first.")
                    val conn = (URL(model.getString("url")).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 25000; readTimeout = 45000; instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "Threadline-Android/1.9.0")
                        setRequestProperty("Accept", "application/octet-stream")
                    }
                    val code = conn.responseCode
                    if (code !in 200..299) {
                        conn.disconnect()
                        if (code == 401 || code == 403) throw IllegalStateException("The model host requires licence acceptance or access approval. Open the model page, accept its licence, then use Import model.")
                        throw IllegalStateException("Model host returned HTTP $code")
                    }
                    val contentLength = conn.contentLengthLong
                    if (contentLength > 0) total = contentLength
                    val availableAfterConnect = StatFs(filesDir.absolutePath).availableBytes
                    if (total > 0 && total > availableAfterConnect - 96L * 1024 * 1024) throw IllegalArgumentException("Not enough free device storage for this model.")
                    modelDirectory().mkdirs()
                    FileOutputStream(temp).use { out ->
                        conn.inputStream.use { input ->
                            val buffer = ByteArray(1024 * 1024)
                            var lastProgress = 0L
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                received += n
                                if (received > 3L * 1024 * 1024 * 1024 || received > availableAfterConnect - 64L * 1024 * 1024) throw IllegalArgumentException("Download exceeded safe storage limits.")
                                out.write(buffer, 0, n)
                                val now = System.currentTimeMillis()
                                if (now - lastProgress >= 650) {
                                    lastProgress = now
                                    sendModelDownloadProgress(requestId, name, received, total, "downloading", "")
                                }
                            }
                            out.fd.sync()
                        }
                    }
                    conn.disconnect()
                    if (received < 100L * 1024 * 1024) throw IllegalArgumentException("The download was too small to be a valid model (${received} bytes). The host may have returned an HTML licence page.")
                    if (total > 0 && received < total * 95 / 100) throw IllegalArgumentException("Download ended early. Please retry on a stable connection.")
                    if (target.exists() && !target.delete()) throw IllegalStateException("Could not replace an existing model.")
                    if (!temp.renameTo(target)) throw IllegalStateException("Could not finalize the downloaded model.")
                    val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
                    if (prefs.getString("active_model", "").isNullOrBlank()) prefs.edit().putString("active_model", target.name).apply()
                } catch (e: Throwable) {
                    err = (e.message ?: e.javaClass.simpleName).take(400)
                    temp.delete()
                } finally {
                    modelDownloadBusy = false
                    sendModelDownloadProgress(requestId, name, received, total, if (err.isBlank()) "complete" else "failed", err)
                }
            }
            return true
        }

        @JavascriptInterface fun requestModelNotifications() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2410) }
            }
        }

        @JavascriptInterface fun openMirroredSource(blobName: String, mimeType: String, displayName: String): Boolean {
            if (!blobName.matches(Regex("[A-Za-z0-9_.-]{1,180}\\.bin"))) return false
            return try {
                val src = File(File(filesDir, "source-mirror/blobs"), blobName)
                if (!src.isFile) return false
                val outDir = File(cacheDir, "mirror-open").apply { mkdirs() }
                val clean = displayName.replace(Regex("[^A-Za-z0-9_.() -]"), "_").take(120).ifBlank { "mirrored-source" }
                val out = File(outDir, clean)
                FileOutputStream(out).use { it.write(MirrorCrypto.decrypt(src.readBytes())); it.fd.sync() }
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", out)
                val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mimeType.ifBlank { "application/octet-stream" }); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                runOnUiThread {
                    try { startActivity(Intent.createChooser(intent, "Open mirrored original")) }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "No app can open this file type.", Toast.LENGTH_LONG).show() }
                }
                true
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun chooseLanguage(language: String): Boolean {
            if (language !in listOf("en", "pl", "tr")) return false
            getSharedPreferences("threadline-settings", Context.MODE_PRIVATE).edit().putString("language", language).apply()
            return true
        }

        @JavascriptInterface fun currentLanguage(): String = getSharedPreferences("threadline-settings", Context.MODE_PRIVATE).getString("language", "en") ?: "en"

        @JavascriptInterface fun appInventory(): String {
            val hidden = getSharedPreferences("threadline-app-manager", Context.MODE_PRIVATE).getStringSet("hidden", emptySet()) ?: emptySet()
            val apps = JSONArray()
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val resolved = packageManager.queryIntentActivities(intent, 0)
            val usage = usageByPackage()
            resolved.distinctBy { it.activityInfo.packageName }.filter { it.activityInfo.packageName != packageName }.forEach { info ->
                val pkg = info.activityInfo.packageName
                val item = JSONObject().put("name", info.loadLabel(packageManager)?.toString() ?: pkg)
                    .put("package", pkg).put("hidden", hidden.contains(pkg)).put("usageMs", usage[pkg]?.totalTimeInForeground ?: 0L)
                try { @Suppress("DEPRECATION") val p = packageManager.getPackageInfo(pkg, 0); item.put("version", p.versionName ?: "") } catch (_: Exception) { }
                apps.put(item)
            }
            return JSONObject().put("apps", apps).put("usageAccess", hasUsageAccess()).toString()
        }

        @JavascriptInterface fun appManagerAction(pkg: String, action: String): Boolean {
            if (!pkg.matches(Regex("[A-Za-z0-9_.]{3,255}") ) || pkg == packageName) return false
            return try {
                val prefs = getSharedPreferences("threadline-app-manager", Context.MODE_PRIVATE)
                val hidden = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
                when (action) {
                    "hide" -> { hidden.add(pkg); prefs.edit().putStringSet("hidden", hidden).apply(); true }
                    "unhide" -> { hidden.remove(pkg); prefs.edit().putStringSet("hidden", hidden).apply(); true }
                    "open" -> { val launch = packageManager.getLaunchIntentForPackage(pkg) ?: return false; runOnUiThread { try { startActivity(launch) } catch (_: Exception) { } }; true }
                    "settings" -> { runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }; true }
                    "notifications" -> { runOnUiThread { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)) }; true }
                    "uninstall" -> { runOnUiThread { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) }; true }
                    "store" -> {
                        runOnUiThread {
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))) }
                            catch (_: Exception) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))) } catch (_: Exception) { } }
                        }
                        true
                    }
                    else -> false
                }
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun hasUsageAccess(): Boolean {
            return try {
                val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                @Suppress("DEPRECATION")
                val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
                mode == AppOpsManager.MODE_ALLOWED
            } catch (_: Exception) { false }
        }

        @JavascriptInterface fun openUsageAccessSettings(): Boolean {
            return try { runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }; true } catch (_: Exception) { false }
        }

        @JavascriptInterface fun appUsageRecommendations(): String {
            val usage = usageByPackage().entries.sortedByDescending { it.value.totalTimeInForeground }.take(15)
            val apps = JSONArray()
            usage.forEach { (pkg, stat) ->
                var name = pkg
                try { name = packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { }
                apps.put(JSONObject().put("package", pkg).put("name", name).put("foregroundMs", stat.totalTimeInForeground).put("lastUsed", stat.lastTimeUsed))
            }
            return JSONObject().put("usageAccess", hasUsageAccess()).put("apps", apps).toString()
        }

        private fun usageByPackage(): Map<String, android.app.usage.UsageStats> {
            if (!hasUsageAccess()) return emptyMap()
            return try {
                val mgr = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                mgr.queryAndAggregateUsageStats(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000, System.currentTimeMillis()) ?: emptyMap()
            } catch (_: Exception) { emptyMap() }
        }

        @JavascriptInterface fun liveFeedStatus(): String {
            val component = ComponentName(this@MainActivity, LiveAppAccessibilityService::class.java).flattenToString()
            val enabledServices = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            val shortComponent = ComponentName(this@MainActivity, LiveAppAccessibilityService::class.java).flattenToShortString()
            val serviceEnabled = enabledServices.split(':').any { it.equals(component, true) || it.equals(shortComponent, true) }
            val prefs = getSharedPreferences(LiveAppAccessibilityService.PREFS, Context.MODE_PRIVATE)
            val snapshot = try { JSONObject(LiveFeedStorage.read(prefs.getString("snapshot", null), "{}")) } catch (_: Exception) { JSONObject() }
            val events = try { JSONArray(LiveFeedStorage.read(prefs.getString("events", null), "[]")) } catch (_: Exception) { JSONArray() }
            return JSONObject().put("serviceEnabled", serviceEnabled).put("feedEnabled", prefs.getBoolean("feed_enabled", false))
                .put("autoMirror", prefs.getBoolean("feed_auto_mirror", false)).put("snapshot", snapshot).put("events", events).toString()
        }

        @JavascriptInterface fun toggleLiveFeed(): Boolean {
            val status = JSONObject(liveFeedStatus())
            if (!status.optBoolean("serviceEnabled")) {
                runOnUiThread { try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) { } }
                return false
            }
            val prefs = getSharedPreferences(LiveAppAccessibilityService.PREFS, Context.MODE_PRIVATE)
            val enable = !prefs.getBoolean("feed_enabled", false)
            prefs.edit().putBoolean("feed_enabled", enable).putBoolean("feed_auto_mirror", enable).apply()
            return true
        }

        @JavascriptInterface fun openAccessibilitySettings(): Boolean {
            return try { runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }; true } catch (_: Exception) { false }
        }

        @JavascriptInterface fun performLiveAction(action: String, targetLabel: String): Boolean {
            return LiveAppAccessibilityService.instance?.performThreadlineAction(action, targetLabel) ?: false
        }

        @JavascriptInterface fun clearLiveFeed(): Boolean {
            getSharedPreferences(LiveAppAccessibilityService.PREFS, Context.MODE_PRIVATE).edit().remove("events").remove("snapshot").apply()
            return true
        }

        @JavascriptInterface fun consumeIncomingShare(): String {
            val payload = pendingShare
            pendingShare = ""
            return payload
        }
    }

    private fun sendModelDownloadProgress(requestId: String, name: String, received: Long, total: Long, status: String, error: String) {
        val payload = JSONObject().put("requestId", requestId).put("name", name).put("received", received)
            .put("total", total).put("status", status).put("error", error).toString()
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript("window.onModelDownloadProgress && window.onModelDownloadProgress(${JSONObject.quote(payload)})", null) }
    }

    private fun modelDirectory(): File = File(filesDir, "local-models").apply { mkdirs() }

    private fun safeModelFile(name: String): File? {
        if (name.isBlank() || name.length > 180 || name != File(name).name || !name.matches(Regex("[A-Za-z0-9_.() -]{1,180}\\.litertlm"))) return null
        return File(modelDirectory(), name)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2411) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val target = pendingVoiceTarget
            if (granted) { launchGrantedSpeech(target) }
            else { pendingVoiceTarget = "capture"; Toast.makeText(this, "Microphone permission is needed for voice input.", Toast.LENGTH_LONG).show() }
        }
        if (requestCode == 2412) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted && pendingAssistantStart) {
                pendingAssistantStart = false
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                    val started = startFloatingAssistantFromActivity()
                    Toast.makeText(this, if (started) "Threadline conversation bubble is ready. Tap it from any app." else "Could not start the Threadline assistant.", Toast.LENGTH_LONG).show()
                    if (::webView.isInitialized) webView.evaluateJavascript("window.onThreadlineResumed && window.onThreadlineResumed()", null)
                } else {
                    Toast.makeText(this, "Allow Threadline to display over other apps, then enable the floating assistant again.", Toast.LENGTH_LONG).show()
                }
            } else if (!granted) {
                pendingAssistantStart = false
                Toast.makeText(this, "Microphone permission is needed for voice chat. Threadline does not listen until you tap Talk.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun launchGrantedSpeech(target: String) {
        try {
            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, ConversationalVoice.localeFor(this@MainActivity).toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (target == "assistant") "Talk to Threadline" else "Speak your note")
            }
            startActivityForResult(speechIntent, 2401)
        } catch (_: Exception) {
            pendingVoiceTarget = "capture"
            Toast.makeText(this, "No speech recognizer is available.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFloatingAssistantFromActivity(): Boolean {
        val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
        return try {
            val serviceIntent = Intent(this, FloatingAssistantService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
            prefs.edit().putBoolean("floating_enabled", true).apply()
            true
        } catch (_: Exception) { prefs.edit().putBoolean("floating_enabled", false).apply(); false }
    }

    private fun localAIStatusJson(): String {
        val dir = modelDirectory()
        val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
        val active = prefs.getString("active_model", "").orEmpty()
        val models = JSONArray()
        dir.listFiles()?.filter { it.isFile && it.name.endsWith(".litertlm", true) }?.sortedBy { it.name }?.forEach { f ->
            models.put(JSONObject().put("name", f.name).put("bytes", f.length()).put("active", f.name == active))
        }
        return JSONObject().put("runtime", "LiteRT-LM / CPU").put("busy", localAiBusy || modelDownloadBusy || modelImportBusy || AssistantRuntime.busy).put("activeModel", active).put("models", models).toString()
    }

    private fun importLocalModel(uri: Uri): String {
        return try {
            val originalName = queryDisplayName(uri).ifBlank { "local-model.litertlm" }
            if (!originalName.endsWith(".litertlm", true)) return JSONObject().put("ok", false).put("error", "Choose a LiteRT-LM .litertlm model file. GGUF and MediaPipe .task models use different runtimes.").toString()
            val stem = originalName.replace(Regex("(?i)\\.litertlm$"), "").replace(Regex("[^A-Za-z0-9_.() -]"), "_").take(150)
            val clean = "$stem.litertlm"
            val dir = modelDirectory()
            val target = File(dir, clean)
            val temp = File(dir, clean + ".partial")
            val available = StatFs(filesDir.absolutePath).availableBytes
            var total = 0L
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > 3L * 1024 * 1024 * 1024 || total > available - 64L * 1024 * 1024) throw IllegalArgumentException("Not enough storage for this model (or the model exceeds the 3 GB import limit).")
                        output.write(buffer, 0, n)
                    }
                    output.fd.sync()
                }
            } ?: throw IllegalArgumentException("Could not read the selected model file.")
            if (total < 1024L * 1024) throw IllegalArgumentException("The selected file is too small to be a language model.")
            if (target.exists() && !target.delete()) throw IllegalStateException("Could not replace the existing model file.")
            if (!temp.renameTo(target)) throw IllegalStateException("Could not finalize the imported model.")
            val prefs = getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
            val activeName = prefs.getString("active_model", "").orEmpty()
            if (activeName.isBlank() || safeModelFile(activeName)?.isFile != true) {
                prefs.edit().putString("active_model", target.name).apply()
            }
            JSONObject().put("ok", true).put("name", target.name).put("bytes", total).put("status", localAIStatusJson()).toString()
        } catch (e: Throwable) {
            JSONObject().put("ok", false).put("error", (e.message ?: "Model import failed").take(400)).toString()
        } finally {
            // Remove interrupted imports if present.
            modelDirectory().listFiles()?.filter { it.name.endsWith(".partial") }?.forEach { it.delete() }
        }
    }

    private fun copyUriToAttachments(uri: Uri): String {
        return try {
            val name = queryDisplayName(uri).ifBlank { "Attachment" }.take(160)
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val dir = File(filesDir, "attachments").apply { mkdirs() }
            val id = "att_${System.currentTimeMillis()}_${(1000..9999).random()}"
            val ext = when {
                mime == "image/jpeg" -> ".jpg"
                mime == "image/png" -> ".png"
                mime == "image/webp" -> ".webp"
                mime == "application/pdf" -> ".pdf"
                mime.startsWith("text/") -> ".txt"
                else -> ".bin"
            }
            val target = File(dir, id + ext)
            val bytes = contentResolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > 25L * 1024 * 1024) throw IllegalArgumentException("Attachment is larger than 25 MB")
                    output.write(buffer, 0, read)
                }
                output.toByteArray()
            } ?: return ""
            FileOutputStream(target).use { it.write(encryptBytes(bytes)); it.fd.sync() }
            JSONObject().put("id", target.name).put("name", name).put("mime", mime).put("size", bytes.size).toString()
        } catch (_: Exception) { "" }
    }

    private fun copyFileToAttachments(source: File, name: String, mime: String): String {
        return try {
            if (!source.exists() || source.length() <= 0L) return ""
            val dir = File(filesDir, "attachments").apply { mkdirs() }
            val id = "att_${System.currentTimeMillis()}_${(1000..9999).random()}.jpg"
            val target = File(dir, id)
            val bytes = source.readBytes()
            FileOutputStream(target).use { it.write(encryptBytes(bytes)); it.fd.sync() }
            JSONObject().put("id", target.name).put("name", name).put("mime", mime).put("size", bytes.size).toString()
        } catch (_: Exception) { "" }
    }

    private fun contentTypeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "pdf" -> "application/pdf"
        "txt" -> "text/plain"
        else -> "application/octet-stream"
    }

    private fun secretKey(): SecretKey {
        val alias = "threadline_local_vault_v1_7"
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun encrypt(value: String): ByteArray = encryptBytes(value.toByteArray(Charsets.UTF_8))

    private fun encryptBytes(value: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(value)
        return byteArrayOf(iv.size.toByte()) + iv + ciphertext
    }

    private fun decrypt(value: ByteArray): String = decryptBytes(value).toString(Charsets.UTF_8)

    private fun decryptBytes(value: ByteArray): ByteArray {
        require(value.isNotEmpty())
        val ivSize = value[0].toInt() and 0xff
        require(ivSize in 12..16 && value.size > ivSize + 1)
        val iv = value.copyOfRange(1, ivSize + 1)
        val ciphertext = value.copyOfRange(ivSize + 1, value.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }
}
