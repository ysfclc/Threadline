package com.threadline.privateplanner

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.fragment.app.FragmentActivity
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.Executors

internal class MainActivity : FragmentActivity() {
    private lateinit var vault: SecureVault
    private var appState: ThreadState? = null
    private var activeTab = Tab.TODAY
    private var latestError: String? = null
    private var pendingBackup: ByteArray? = null
    private val background = Executors.newSingleThreadExecutor()

    private enum class Tab { TODAY, INBOX, PROJECTS, REVIEW }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = color(C.NAVY)
        window.navigationBarColor = color(C.NAVY)
        window.decorView.systemUiVisibility = 0
        vault = SecureVault(this)
        renderLocked()
    }

    override fun onStop() {
        // The in-memory data key is discarded whenever the app leaves the foreground.
        vault.clearSession()
        appState = null
        if (!isChangingConfigurations) renderLocked()
        super.onStop()
    }

    override fun onDestroy() {
        background.shutdownNow()
        pendingBackup?.fill(0)
        pendingBackup = null
        vault.clearSession()
        super.onDestroy()
    }

    private fun renderLocked() {
        val available = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        val initialized = ::vault.isInitialized && vault.isInitialized()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(color(C.NAVY))
        }
        root.addView(label("T /", 22, C.MINT, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })
        root.addView(label("THREADLINE", 28, C.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        root.addView(label("A quieter place for the next action.", 16, C.LIGHT_MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })
        root.addView(card().apply {
            addView(label("PRIVATE BY DEFAULT", 11, C.MINT, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            addView(label("Your tasks and project notes stay encrypted on this phone. No account, analytics, or network access.", 15, C.WHITE))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        val authReady = available == BiometricManager.BIOMETRIC_SUCCESS
        val mainText = when {
            !authReady -> "Set up a strong biometric unlock in your phone's settings to use the secure vault. Threadline requires biometric authentication."
            initialized -> "Your vault is locked. Authenticate to continue."
            else -> "Create your private vault. New data is encrypted before it is written to storage."
        }
        root.addView(label(mainText, 14, C.LIGHT_MUTED), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        val action = when {
            !authReady -> "Biometrics unavailable"
            initialized -> "Unlock with biometrics"
            else -> "Create secure vault"
        }
        root.addView(button(action, true, enabled = authReady) {
            latestError = null
            if (initialized) vault.unlock(this) { state, error -> onVaultResult(state, error) }
            else vault.setup(this) { state, error -> onVaultResult(state, error) }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        root.addView(button("Restore encrypted backup", false) { launchImportPicker() },
            LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(12) })
        if (latestError != null) {
            root.addView(label(latestError!!, 13, C.ERROR), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }
        if (initialized || latestError != null) {
            root.addView(button("Reset / erase local vault", false) {
                AlertDialog.Builder(this)
                    .setTitle("Erase this vault?")
                    .setMessage("This permanently deletes this phone's encrypted Threadline data and its key. It cannot be undone. An encrypted backup can be imported after you create a new vault.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Erase permanently") { _, _ ->
                        vault.resetLocalVault()
                        latestError = null
                        renderLocked()
                    }.show()
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        setContentView(root)
    }

    private fun onVaultResult(state: ThreadState?, error: String?) {
        if (state == null) {
            latestError = error ?: "Authentication did not complete."
            renderLocked()
            return
        }
        appState = state
        latestError = null
        renderHome()
    }

    private fun renderHome() {
        val state = appState ?: run { renderLocked(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(C.BG))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(16), dp(16))
            setBackgroundColor(color(C.NAVY))
        }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(label("THREADLINE  /  PRIVATE", 11, C.MINT, true))
        titleColumn.addView(label("Your working memory,", 19, C.WHITE, true).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("Lock", false, compact = true) { lockNow() })
        root.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        when (activeTab) {
            Tab.TODAY -> renderToday(content, state)
            Tab.INBOX -> renderInbox(content, state)
            Tab.PROJECTS -> renderProjects(content, state)
            Tab.REVIEW -> renderReview(content, state)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(color(C.NAVY))
        }
        listOf(Tab.TODAY to "Today", Tab.INBOX to "Inbox", Tab.PROJECTS to "Projects", Tab.REVIEW to "Review").forEach { (tab, text) ->
            val label = when (tab) {
                Tab.INBOX -> if (state.tasks.count { it.status == TaskStatus.INBOX } > 0) "$text · ${state.tasks.count { it.status == TaskStatus.INBOX }}" else text
                else -> text
            }
            nav.addView(button(label, tab == activeTab, compact = true) {
                activeTab = tab
                renderHome()
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun renderToday(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("${LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))}", 13, C.MUTED))
        parent.addView(label("Today, not everything.", 27, C.INK, true), bottom(6))
        parent.addView(label("Choose a few real moves. Let the rest wait.", 14, C.MUTED), bottom(16))

        val todayTasks = state.tasks.filter { it.status == TaskStatus.TODAY }.sortedBy { it.createdAt }
        val doneToday = completedToday(state)
        val statRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        statRow.addView(statCard("${todayTasks.size}/3", "focus slots"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        statRow.addView(statCard("$doneToday", "done today"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        parent.addView(statRow, bottom(16))

        parent.addView(sectionLabel("QUICK CAPTURE"), bottom(8))
        parent.addView(captureCard(), bottom(18))

        parent.addView(sectionTitle("Your three moves", "A task only earns a slot if it matters today."), bottom(10))
        if (todayTasks.isEmpty()) {
            parent.addView(emptyCard("Nothing is locked in yet.", "Pick one useful next step from your inbox. You don't need a perfect plan."), bottom(12))
            parent.addView(button("Choose from inbox", true) { activeTab = Tab.INBOX; renderHome() }, bottom(18))
        } else {
            todayTasks.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.TODAY), bottom(10)) }
        }

        val nextTasks = state.tasks.filter { it.status == TaskStatus.NEXT }.sortedByDescending { it.updatedAt }.take(4)
        if (nextTasks.isNotEmpty()) {
            parent.addView(sectionTitle("Ready when you are", "Next actions, not a giant backlog."), bottom(10))
            nextTasks.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.NEXT), bottom(10)) }
        }
        val activeProjects = state.projects.filter { it.status == ProjectStatus.ACTIVE }
        if (activeProjects.isNotEmpty()) {
            parent.addView(sectionTitle("Active threads", "Keep each project pointed at one next action."), bottom(10))
            activeProjects.take(3).forEach { project ->
                parent.addView(projectSummary(project), bottom(10))
            }
        }
        parent.addView(button("Close the day / review", false) { activeTab = Tab.REVIEW; renderHome() }, top(6))
    }

    private fun renderInbox(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("CAPTURE WITHOUT SORTING", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Inbox", 28, C.INK, true), bottom(6))
        parent.addView(label("Get it out of your head first. Decide what it means later.", 14, C.MUTED), bottom(16))
        parent.addView(captureCard(), bottom(18))
        val inbox = state.tasks.filter { it.status == TaskStatus.INBOX }.sortedByDescending { it.createdAt }
        parent.addView(sectionTitle("${inbox.size} uncategorized ${if (inbox.size == 1) "item" else "items"}", "Keep capture easy; sorting is optional."), bottom(10))
        if (inbox.isEmpty()) {
            parent.addView(emptyCard("Inbox is clear.", "Capture an idea the moment it shows up. It doesn't need to become a task."), bottom(12))
        }
        inbox.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.INBOX), bottom(10)) }

        val later = state.tasks.filter { it.status == TaskStatus.LATER }.sortedByDescending { it.updatedAt }
        parent.addView(sectionTitle("Parked for later · ${later.size}", "You can bring these back when the timing is right."), bottom(10))
        if (later.isEmpty()) parent.addView(emptyCard("Nothing parked.", "Move work to Later when it should stop competing for attention."), bottom(12))
        later.forEach { task -> parent.addView(taskCard(task, state, TaskStatus.LATER), bottom(10)) }
    }

    private fun renderProjects(parent: LinearLayout, state: ThreadState) {
        parent.addView(label("WORKSTREAMS, NOT MORE BOARDS", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Projects", 28, C.INK, true), bottom(6))
        parent.addView(label("Give each important thread an outcome and a visible next step.", 14, C.MUTED), bottom(16))
        parent.addView(sectionLabel("START A PROJECT"), bottom(8))
        val title = textField("Project name (required)", MAX_PROJECT_TITLE)
        val outcome = textField("What does finished look like?", MAX_PROJECT_TEXT)
        val nextAction = textField("Next physical action (optional)", MAX_PROJECT_TEXT)
        parent.addView(card().apply {
            addView(title, bottom(8)); addView(outcome, bottom(8)); addView(nextAction, bottom(10))
            addView(button("Add project", true) {
                val next = Domain.addProject(requireState(), title.text.toString(), outcome.text.toString(), nextAction.text.toString())
                if (next == null) showToast("Add a unique project name. Keep it under ${MAX_PROJECT_TITLE} characters.")
                else commit(next, "Project added.")
            })
        }, bottom(18))

        val active = state.projects.filter { it.status == ProjectStatus.ACTIVE }
        val parked = state.projects.filter { it.status == ProjectStatus.PARKED }
        val done = state.projects.filter { it.status == ProjectStatus.DONE }
        parent.addView(sectionTitle("Active · ${active.size}", "No project needs more than one next action."), bottom(10))
        if (active.isEmpty()) parent.addView(emptyCard("No active projects yet.", "Keep this list deliberately short."), bottom(12))
        active.sortedByDescending { it.updatedAt }.forEach { parent.addView(projectCard(it), bottom(10)) }
        if (parked.isNotEmpty()) {
            parent.addView(sectionTitle("Parked · ${parked.size}", "Not abandoned. Just not active today."), bottom(10))
            parked.forEach { parent.addView(projectCard(it), bottom(10)) }
        }
        if (done.isNotEmpty()) {
            parent.addView(sectionTitle("Completed · ${done.size}", "Finished threads stay out of the way."), bottom(10))
            done.take(5).forEach { parent.addView(projectCard(it), bottom(10)) }
        }
    }

    private fun renderReview(parent: LinearLayout, state: ThreadState) {
        val today = LocalDate.now().toString()
        val existing = state.reviews.firstOrNull { it.day == today }
        parent.addView(label("A SMALL RESET", 11, C.TEAL, true), bottom(7))
        parent.addView(label("Review & reset", 28, C.INK, true), bottom(6))
        parent.addView(label("Close open loops without pretending you can finish everything.", 14, C.MUTED), bottom(16))
        val todayItems = state.tasks.filter { it.status == TaskStatus.TODAY }
        val completed = completedToday(state)
        val summary = card()
        summary.addView(label("TODAY'S RECEIPT", 11, C.TEAL, true), bottom(12))
        summary.addView(label("$completed tasks completed", 20, C.INK, true), bottom(4))
        summary.addView(label("${todayItems.size} focus items still open · ${state.tasks.count { it.status == TaskStatus.INBOX }} items in inbox", 13, C.MUTED))
        parent.addView(summary, bottom(18))

        parent.addView(sectionLabel("WHAT MOVED FORWARD?"), bottom(7))
        val moved = textField("One thing that actually moved", 800).apply { minLines = 2; maxLines = 4; setText(existing?.movedForward.orEmpty()) }
        val next = textField("The next visible step", 800).apply { minLines = 2; maxLines = 4; setText(existing?.nextStep.orEmpty()) }
        val parked = textField("What can wait without guilt?", 800).apply { minLines = 2; maxLines = 4; setText(existing?.parked.orEmpty()) }
        parent.addView(card().apply {
            addView(moved, bottom(8)); addView(next, bottom(8)); addView(parked, bottom(10))
            addView(button("Save today's review", true) {
                val updated = Domain.saveReview(requireState(), moved.text.toString(), next.text.toString(), parked.text.toString())
                commit(updated, "Review saved on this device.")
            })
        }, bottom(18))
        parent.addView(sectionTitle("Close the loop", "Unfinished focus items move to Next; nothing is deleted."), bottom(8))
        parent.addView(button("Move unfinished focus to Next", false) {
            if (requireState().tasks.none { it.status == TaskStatus.TODAY }) showToast("There are no open focus items to move.")
            else AlertDialog.Builder(this)
                .setTitle("Close today's focus?")
                .setMessage("Any unfinished Today items will move to Next. Completed work and your saved review stay unchanged.")
                .setNegativeButton("Keep today open", null)
                .setPositiveButton("Move open items") { _, _ -> commit(Domain.rollDay(requireState()), "Open focus items moved to Next.") }
                .show()
        }, bottom(18))

        parent.addView(sectionTitle("Private backup", "Exports are encrypted with a separate passphrase."), bottom(8))
        parent.addView(card().apply {
            addView(label("A backup file is useful if you change phones or reset your device. It is not stored by Threadline.", 14, C.MUTED), bottom(12))
            addView(button("Export encrypted backup", true) { promptExportPassword() }, bottom(8))
            addView(button("Import encrypted backup", false) { launchImportPicker() })
        }, bottom(18))
        val recentDone = state.tasks.filter { it.status == TaskStatus.DONE }.sortedByDescending { it.completedAt ?: it.updatedAt }.take(6)
        parent.addView(sectionTitle("Recent wins", "A short record of work that is actually finished."), bottom(8))
        if (recentDone.isEmpty()) parent.addView(emptyCard("No completed tasks yet.", "Small finishes count, too."), bottom(12))
        recentDone.forEach { task ->
            parent.addView(card().apply {
                addView(label(task.text, 14, C.INK, true), bottom(3))
                val doneAt = task.completedAt ?: task.updatedAt
                val doneDate = Instant.ofEpochMilli(doneAt).atZone(ZoneId.systemDefault()).toLocalDate()
                addView(label("Completed ${doneDate.format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", 12, C.MUTED))
            }, bottom(8))
        }
        val pastReviews = state.reviews.filterNot { it.day == today }.sortedByDescending { it.day }.take(5)
        if (pastReviews.isNotEmpty()) {
            parent.addView(sectionTitle("Previous reviews", "Your notes remain private on this device."), bottom(8))
            pastReviews.forEach { review ->
                parent.addView(card().apply {
                    addView(label(review.day, 12, C.TEAL, true), bottom(5))
                    if (review.movedForward.isNotBlank()) addView(label("Moved forward: ${review.movedForward}", 13, C.INK), bottom(4))
                    if (review.nextStep.isNotBlank()) addView(label("Next: ${review.nextStep}", 13, C.INK), bottom(4))
                    if (review.parked.isNotBlank()) addView(label("Parked: ${review.parked}", 13, C.MUTED))
                }, bottom(8))
            }
        }
        parent.addView(label("Privacy model", 14, C.INK, true), bottom(6))
        parent.addView(label("AES-256-GCM encrypted local vault · Android Keystore key protected by strong biometrics · app data excluded from Android backup · no Internet permission · no analytics.", 13, C.MUTED))
    }

    private fun captureCard(): View {
        val edit = textField("A thought, task, or thing to check…", MAX_TASK_TEXT).apply {
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        return card().apply {
            addView(edit, bottom(10))
            addView(button("Capture to inbox", true) {
                val value = edit.text.toString()
                val next = Domain.capture(requireState(), value)
                if (next == null) showToast("Capture something up to $MAX_TASK_TEXT characters.")
                else commit(next, "Captured. You can sort it later.")
            })
        }
    }

    private fun taskCard(task: TaskItem, state: ThreadState, from: TaskStatus): View {
        val card = card()
        val associatedProject = state.projects.firstOrNull { it.id == task.projectId }
        if (associatedProject != null) card.addView(label(associatedProject.title.uppercase(), 10, C.TEAL, true), bottom(6))
        card.addView(label(task.text, 16, C.INK, true), bottom(6))
        val created = Instant.ofEpochMilli(task.createdAt).atZone(ZoneId.systemDefault()).toLocalDate()
        card.addView(label("Added ${created.format(DateTimeFormatter.ofPattern("d MMM"))} · ${task.status.name.lowercase(Locale.ROOT).replace('_', ' ')}", 12, C.MUTED), bottom(10))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        when (from) {
            TaskStatus.TODAY -> {
                actions.addView(button("Done", true, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                    if (next != null) commit(next, "One less open loop.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Move to Next", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Moved out of today's focus.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.INBOX -> {
                val todayFull = state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS
                actions.addView(button("Today", true, compact = true, enabled = !todayFull) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next == null) showToast("Today already has three focus items. Move one to Next first.")
                    else commit(next, "Added to today's focus.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Next", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Promoted to Next.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
                actions.addView(button("Delete", false, compact = true) {
                    AlertDialog.Builder(this)
                        .setTitle("Delete this item?")
                        .setMessage("This removes it from your encrypted vault. It cannot be undone unless you have a backup.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ -> commit(Domain.deleteTask(requireState(), task.id), "Item deleted.") }
                        .show()
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.NEXT -> {
                val canFocus = state.tasks.count { it.status == TaskStatus.TODAY } < MAX_TODAY_TASKS
                actions.addView(button("Focus today", true, compact = true, enabled = canFocus) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next != null) commit(next, "Added to today's focus.")
                    else showToast("Today already has three focus items.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Later", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.LATER)
                    if (next != null) commit(next, "Parked for later.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
                actions.addView(button("Done", false, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.DONE)
                    if (next != null) commit(next, "Marked done.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            TaskStatus.LATER -> {
                val canFocus = state.tasks.count { it.status == TaskStatus.TODAY } < MAX_TODAY_TASKS
                actions.addView(button("Bring to Next", true, compact = true) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.NEXT)
                    if (next != null) commit(next, "Brought back to Next.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("Today", false, compact = true, enabled = canFocus) {
                    val next = Domain.moveTask(requireState(), task.id, TaskStatus.TODAY)
                    if (next != null) commit(next, "Added to today's focus.")
                    else showToast("Today already has three focus items.")
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            }
            else -> Unit
        }
        if (actions.childCount > 0) card.addView(actions)
        return card
    }

    private fun projectCard(project: ProjectItem): View {
        val card = card()
        val statusLine = project.status.name.lowercase(Locale.ROOT).replaceFirstChar { it.uppercaseChar() }
        card.addView(label(statusLine.uppercase(), 10, C.TEAL, true), bottom(5))
        card.addView(label(project.title, 18, C.INK, true), bottom(6))
        if (project.outcome.isNotBlank()) {
            card.addView(label("OUTCOME", 10, C.MUTED, true), bottom(2))
            card.addView(label(project.outcome, 14, C.INK), bottom(8))
        }
        card.addView(label("NEXT ACTION", 10, C.MUTED, true), bottom(2))
        card.addView(label(project.nextAction.ifBlank { "No next action recorded yet." }, 14, if (project.nextAction.isBlank()) C.MUTED else C.INK), bottom(12))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (project.status == ProjectStatus.ACTIVE) {
            row.addView(button("Add to Next", true, compact = true) {
                val current = requireState()
                val alreadyOpen = current.tasks.any {
                    it.projectId == project.id && it.text.equals(project.nextAction.trim(), ignoreCase = true) && it.status != TaskStatus.DONE
                }
                if (project.nextAction.isBlank()) showToast("Add a next action to this project first.")
                else if (alreadyOpen) showToast("This action already has an open task.")
                else {
                    val next = Domain.addProjectNextAction(current, project.id)
                    if (next == null) showToast("Could not add this action. Check the project and task limits.")
                    else commit(next, "Project action added to Next.")
                }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            row.addView(button("Focus", false, compact = true) { focusProject(project.id) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
            row.addView(button("Edit", false, compact = true) { editProject(project) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4) })
            card.addView(row, bottom(8))
            card.addView(button("Park this project", false, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.PARKED)
                if (updated != null) commit(updated, "Project parked.")
            })
        } else if (project.status == ProjectStatus.PARKED) {
            card.addView(button("Reactivate project", true, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.ACTIVE)
                if (updated != null) commit(updated, "Project reactivated.")
            })
        } else {
            card.addView(button("Reopen project", false, compact = true) {
                val updated = Domain.updateProject(requireState(), project.id, project.outcome, project.nextAction, ProjectStatus.ACTIVE)
                if (updated != null) commit(updated, "Project reopened.")
            })
        }
        return card
    }

    private fun projectSummary(project: ProjectItem): View = card().apply {
        addView(label(project.title, 16, C.INK, true), bottom(5))
        addView(label(project.nextAction.ifBlank { "Add a next action to get this moving." }, 13, C.MUTED), bottom(9))
        addView(button("Open projects", false, compact = true) { activeTab = Tab.PROJECTS; renderHome() })
    }

    private fun focusProject(projectId: String) {
        val state = requireState()
        if (state.tasks.count { it.status == TaskStatus.TODAY } >= MAX_TODAY_TASKS) {
            showToast("Today already has three focus items. Move one to Next first.")
            return
        }
        val project = state.projects.firstOrNull { it.id == projectId } ?: return
        if (project.nextAction.isBlank()) { showToast("Add a next action first."); return }
        val existing = state.tasks.firstOrNull { it.projectId == projectId && it.text == project.nextAction && it.status != TaskStatus.DONE }
        val next = if (existing != null) Domain.moveTask(state, existing.id, TaskStatus.TODAY)
        else state.copy(tasks = state.tasks + TaskItem(text = project.nextAction, status = TaskStatus.TODAY, projectId = project.id))
        if (next == null) showToast("Could not add that action to today.") else {
            activeTab = Tab.TODAY
            commit(next, "Project action is today's focus.")
        }
    }

    private fun editProject(project: ProjectItem) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val outcome = textField("Outcome", MAX_PROJECT_TEXT).apply { setText(project.outcome) }
        val next = textField("Next action", MAX_PROJECT_TEXT).apply { setText(project.nextAction) }
        panel.addView(outcome, bottom(8)); panel.addView(next)
        AlertDialog.Builder(this)
            .setTitle("Edit ${project.title}")
            .setView(panel)
            .setNegativeButton("Cancel", null)
            .setNeutralButton(if (project.status == ProjectStatus.DONE) "Keep done" else "Mark done") { _, _ ->
                val updated = Domain.updateProject(requireState(), project.id, outcome.text.toString(), next.text.toString(), ProjectStatus.DONE)
                if (updated != null) commit(updated, "Project marked completed.")
            }
            .setPositiveButton("Save") { _, _ ->
                val updated = Domain.updateProject(requireState(), project.id, outcome.text.toString(), next.text.toString())
                if (updated != null) commit(updated, "Project updated.")
            }.show()
    }

    private fun statCard(number: String, caption: String): View = card().apply {
        addView(label(number, 24, C.INK, true), bottom(3))
        addView(label(caption, 12, C.MUTED))
    }

    private fun emptyCard(title: String, body: String): View = card().apply {
        addView(label(title, 16, C.INK, true), bottom(5))
        addView(label(body, 13, C.MUTED))
    }

    private fun sectionTitle(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 18, C.INK, true), bottom(3))
        addView(label(subtitle, 12, C.MUTED))
    }

    private fun sectionLabel(text: String): View = label(text, 11, C.TEAL, true)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(C.WHITE, 18, C.BORDER)
    }

    private fun label(text: String, size: Int, textColor: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color(textColor))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        includeFontPadding = true
        setLineSpacing(dp(2).toFloat(), 1.0f)
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    private fun textField(hint: String, maxChars: Int): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 14f
        setTextColor(color(C.INK))
        setHintTextColor(color(C.MUTED))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = rounded(C.FIELD, 12, C.BORDER)
        filters = arrayOf(InputFilter.LengthFilter(maxChars))
        isSaveEnabled = false
        importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        setSingleLine(false)
        minHeight = dp(46)
    }

    private fun button(
        text: String,
        primary: Boolean,
        compact: Boolean = false,
        enabled: Boolean = true,
        onClick: () -> Unit
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = if (compact) 12.5f else 14f
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(if (compact) 8 else 14), dp(10), dp(if (compact) 8 else 14), dp(10))
        setTextColor(color(if (primary) C.NAVY else C.INK))
        background = rounded(if (primary) C.MINT else C.SECONDARY, 14, if (primary) C.MINT else C.BORDER)
        alpha = if (enabled) 1f else 0.45f
        isEnabled = enabled
        isClickable = enabled
        if (enabled) setOnClickListener { onClick() }
        minHeight = dp(if (compact) 40 else 46)
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color(fill)); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), color(stroke))
    }

    private fun bottom(dpValue: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(dpValue) }
    private fun top(dpValue: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(dpValue) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun color(value: Int): Int = value
    private fun requireState(): ThreadState = appState ?: error("The vault is locked.")

    private fun commit(next: ThreadState, message: String) {
        try {
            val validated = Domain.validate(next)
            vault.save(validated)
            appState = validated
            latestError = null
            renderHome()
            showToast(message)
        } catch (e: Exception) {
            showToast((e.message ?: "Could not save. Your previous data remains unchanged.").take(180))
        }
    }

    private fun completedToday(state: ThreadState): Int {
        val today = LocalDate.now()
        return state.tasks.count { task ->
            task.status == TaskStatus.DONE && task.completedAt?.let {
                Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate() == today
            } == true
        }
    }

    private fun lockNow() {
        vault.clearSession()
        appState = null
        renderLocked()
    }

    private fun showToast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun promptExportPassword() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val first = textField("Backup passphrase (12+ characters)", 200).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        val second = textField("Repeat backup passphrase", 200).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        panel.addView(first, bottom(8)); panel.addView(second)
        val dialog = AlertDialog.Builder(this).setTitle("Encrypt a backup")
            .setMessage("Keep the passphrase separate from the backup file. Threadline cannot recover a forgotten passphrase.")
            .setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Encrypt backup", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val a = first.text.toString()
                val b = second.text.toString()
                if (a.length < 12) { first.error = "Use at least 12 characters"; return@setOnClickListener }
                if (a != b) { second.error = "Passphrases do not match"; return@setOnClickListener }
                val password = a.toCharArray()
                first.setText(""); second.setText(""); dialog.dismiss()
                val stateBytes = try { StateCodec.encode(requireState()) } catch (e: Exception) { showToast("Could not prepare backup."); return@setOnClickListener }
                showToast("Encrypting backup…")
                background.execute {
                    try {
                        val result = BackupCrypto.encrypt(stateBytes, password)
                        stateBytes.fill(0)
                        runOnUiThread {
                            pendingBackup?.fill(0)
                            pendingBackup = result
                            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "application/octet-stream"
                                putExtra(Intent.EXTRA_TITLE, "threadline-backup.tlb")
                            }
                            startActivityForResult(intent, REQUEST_EXPORT)
                        }
                    } catch (e: Exception) {
                        stateBytes.fill(0); password.fill('\u0000')
                        runOnUiThread { showToast((e.message ?: "Backup encryption failed.").take(180)) }
                    }
                }
            }
        }
        dialog.show()
    }

    private fun launchImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        startActivityForResult(intent, REQUEST_IMPORT)
    }

    @Deprecated("Required for the Storage Access Framework in this minimal native activity.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup?.fill(0); pendingBackup = null
            return
        }
        val uri = data.data!!
        when (requestCode) {
            REQUEST_EXPORT -> writeBackup(uri)
            REQUEST_IMPORT -> readBackup(uri)
        }
    }

    private fun writeBackup(uri: Uri) {
        val bytes = pendingBackup ?: run { showToast("No encrypted backup is ready."); return }
        try {
            contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes); it.flush() }
                ?: error("Could not open the selected destination.")
            showToast("Encrypted backup saved. Keep the passphrase safe.")
        } catch (e: Exception) {
            showToast((e.message ?: "Could not write backup file.").take(180))
        } finally {
            bytes.fill(0); pendingBackup = null
        }
    }

    private fun readBackup(uri: Uri) {
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { readLimited(it, 10 * 1024 * 1024) }
                ?: error("Could not open the selected file.")
        } catch (e: Exception) {
            showToast((e.message ?: "Could not read backup.").take(180)); return
        }
        promptImportPassword(bytes)
    }

    private fun promptImportPassword(bytes: ByteArray) {
        val input = textField("Backup passphrase", 200).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Restore encrypted backup")
            .setMessage("The current vault will be replaced after the backup is verified and you authenticate.")
            .setView(input).setNegativeButton("Cancel") { _, _ -> bytes.fill(0) }
            .setPositiveButton("Verify backup", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val raw = input.text.toString()
                if (raw.length < 12) { input.error = "Enter your backup passphrase"; return@setOnClickListener }
                val password = raw.toCharArray()
                input.setText(""); dialog.dismiss()
                showToast("Verifying encrypted backup…")
                background.execute {
                    val imported = try {
                        val plaintext = BackupCrypto.decrypt(bytes, password)
                        bytes.fill(0)
                        try { StateCodec.decode(plaintext) } finally { plaintext.fill(0) }
                    } catch (e: Exception) {
                        bytes.fill(0); password.fill('\u0000')
                        runOnUiThread { showToast((e.message ?: "Backup verification failed.").take(180)) }
                        null
                    }
                    if (imported != null) runOnUiThread { authorizeAndRestore(imported) }
                }
            }
        }
        dialog.show()
    }

    private fun authorizeAndRestore(imported: ThreadState) {
        val finish: (ThreadState?, String?) -> Unit = { _, error ->
            if (error != null) {
                latestError = error
                appState = null
                vault.clearSession()
                renderLocked()
            } else {
                try {
                    vault.save(imported)
                    appState = imported
                    activeTab = Tab.TODAY
                    latestError = null
                    renderHome()
                    showToast("Backup restored successfully.")
                } catch (e: Exception) {
                    latestError = e.message ?: "Could not restore the backup."
                    appState = null
                    vault.clearSession()
                    renderLocked()
                }
            }
        }
        if (vault.isInitialized()) {
            vault.unlockForRestore(this) { authorized, error -> finish(if (authorized) imported else null, error) }
        } else {
            // On a clean install (or after explicitly erasing an inaccessible vault), establish a fresh key first.
            vault.setup(this) { newState, error ->
                if (newState == null) finish(null, error)
                else finish(imported, null)
            }
        }
    }

    private fun readLimited(input: InputStream, max: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= max) { "The selected backup is larger than 10 MB." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private object C {
        const val NAVY = 0xff101722.toInt()
        const val BG = 0xfff4f6f4.toInt()
        const val WHITE = 0xffffffff.toInt()
        const val INK = 0xff19242c.toInt()
        const val MUTED = 0xff65736f.toInt()
        const val LIGHT_MUTED = 0xffbdc9c7.toInt()
        const val MINT = 0xff79d4bb.toInt()
        const val TEAL = 0xff007d68.toInt()
        const val BORDER = 0xffe0e7e3.toInt()
        const val FIELD = 0xfff8faf8.toInt()
        const val SECONDARY = 0xffe9efeb.toInt()
        const val ERROR = 0xffff8e83.toInt()
    }

    private companion object {
        const val REQUEST_EXPORT = 3001
        const val REQUEST_IMPORT = 3002
    }
}
