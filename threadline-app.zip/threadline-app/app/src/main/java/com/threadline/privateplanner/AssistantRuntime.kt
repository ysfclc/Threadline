package com.threadline.privateplanner

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File

/** One serialized local inference path shared by the foreground UI and the floating assistant. */
internal object AssistantRuntime {
    @Volatile var busy: Boolean = false
        private set
    private val lock = Any()

    @Throws(IllegalStateException::class)
    fun generate(context: Context, prompt: String): String = synchronized(lock) {
        busy = true
        try {
            val preferences = context.getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
            val activeName = preferences.getString("active_model", "").orEmpty()
            if (activeName.isBlank() || activeName != File(activeName).name ||
                !activeName.matches(Regex("[A-Za-z0-9_.() -]{1,180}\\.litertlm"))) {
                throw IllegalStateException("No active local AI model. Open Threadline and set up a model in Assistant settings.")
            }
            val directory = File(context.filesDir, "local-models")
            val model = File(directory, activeName)
            if (!model.isFile || model.length() <= 0L) {
                throw IllegalStateException("The selected model is missing. Open Assistant settings and activate a model again.")
            }
            val engine = Engine(EngineConfig(modelPath = model.absolutePath, backend = Backend.CPU(), cacheDir = context.cacheDir.absolutePath))
            var initialized = false
            val output = try {
                engine.initialize()
                initialized = true
                engine.createConversation().use { conversation -> conversation.sendMessage(prompt).toString() }
            } finally {
                if (initialized) engine.close()
            }
            if (output.isBlank()) throw IllegalStateException("The local model returned an empty response.")
            output
        } finally {
            busy = false
        }
    }
}

/** Strips markup and chooses the best matching installed TTS voice; the installed engine controls actual voice quality. */
internal object ConversationalVoice {
    fun cleanText(input: String): String {
        var text = input
        text = text.replace(Regex("```[\\s\\S]*?```"), " code omitted ")
        text = text.replace(Regex("!?\\[([^]]+)\\]\\([^)]*\\)")) { it.groupValues[1] }
        text = text.replace(Regex("https?://\\S+"), "")
        text = text.replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        text = text.replace(Regex("(?m)^\\s*[-*+]\\s+"), "")
        text = text.replace(Regex("(?m)^\\s*\\d+[.)]\\s+"), "")
        text = text.replace(Regex("[*_`~]"), "")
        text = text.replace(Regex("[<>]"), " ")
        text = text.replace(Regex("\\s+"), " ").trim()
        return text.take(6000)
    }

    fun localeFor(context: Context): java.util.Locale {
        val lang = context.getSharedPreferences("threadline-settings", Context.MODE_PRIVATE).getString("language", "en")
        return when (lang) {
            "pl" -> java.util.Locale("pl", "PL")
            "tr" -> java.util.Locale("tr", "TR")
            else -> java.util.Locale.US
        }
    }

    fun configure(engine: android.speech.tts.TextToSpeech, context: Context) {
        val locale = localeFor(context)
        engine.setLanguage(locale)
        engine.setSpeechRate(0.96f)
        engine.setPitch(1.0f)
        val candidates = try { engine.voices?.filter { it.locale.language == locale.language }.orEmpty() } catch (_: Exception) { emptyList() }
        val selected = candidates.sortedWith(
            compareByDescending<android.speech.tts.Voice> { it.quality }
                .thenByDescending { it.isNetworkConnectionRequired }
                .thenBy { it.name }
        ).firstOrNull()
        if (selected != null) try { engine.voice = selected } catch (_: Exception) { }
    }
}
