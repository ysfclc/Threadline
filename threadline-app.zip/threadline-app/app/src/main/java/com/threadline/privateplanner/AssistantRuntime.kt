package com.threadline.privateplanner

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File

/** One serialized local inference path shared by the foreground UI and the floating assistant.
 * Keeping the initialized engine alive avoids paying model-load cost for every single message.
 */
internal object AssistantRuntime {
    @Volatile var busy: Boolean = false
        private set
    private val lock = Any()
    private var cachedEngine: Engine? = null
    private var cachedModelPath: String = ""

    @Throws(IllegalStateException::class)
    fun generate(context: Context, prompt: String): String = synchronized(lock) {
        busy = true
        try {
            val preferences = context.getSharedPreferences("threadline-local-ai", Context.MODE_PRIVATE)
            val activeName = preferences.getString("active_model", "").orEmpty()
            if (activeName.isBlank() || activeName != File(activeName).name ||
                !activeName.matches(Regex("[A-Za-z0-9_.() -]{1,180}\\.litertlm"))) {
                throw IllegalStateException("No active local AI model. Open Threadline and set up a model in Assistant settings.")
            }
            val directory = File(context.filesDir, "local-models")
            val model = File(directory, activeName)
            if (!model.isFile || model.length() <= 0L) {
                throw IllegalStateException("The selected model is missing. Open Assistant settings and activate a model again.")
            }
            val engine = engineFor(model, context)
            val output = engine.createConversation().use { conversation -> conversation.sendMessage(prompt).toString() }
            if (output.isBlank()) throw IllegalStateException("The local model returned an empty response.")
            output
        } finally {
            busy = false
        }
    }

    private fun engineFor(model: File, context: Context): Engine {
        val path = model.absolutePath
        val present = cachedEngine
        if (present != null && cachedModelPath == path) return present
        releaseLocked()
        val created = Engine(EngineConfig(modelPath = path, backend = Backend.CPU(), cacheDir = context.cacheDir.absolutePath))
        try {
            created.initialize()
            cachedEngine = created
            cachedModelPath = path
            return created
        } catch (failure: Throwable) {
            try { created.close() } catch (_: Throwable) { }
            throw failure
        }
    }

    /** Called when the active model is deleted or the process explicitly releases model resources. */
    fun release() = synchronized(lock) { releaseLocked() }

    private fun releaseLocked() {
        val old = cachedEngine
        cachedEngine = null
        cachedModelPath = ""
        try { old?.close() } catch (_: Throwable) { }
    }
}

/** Strips markup and chooses a suitable installed TTS voice. The installed engine controls voice quality. */
internal object ConversationalVoice {
    fun cleanText(input: String): String {
        var text = input
        text = text.replace(Regex("```[\\s\\S]*?```"), " code omitted ")
        text = text.replace(Regex("!?\\[([^]]+)\\]\\([^)]*\\)")) { it.groupValues[1] }
        text = text.replace(Regex("https?://\\S+"), "")
        text = text.replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        text = text.replace(Regex("(?m)^\\s*[-*+]\\s+"), "")
        text = text.replace(Regex("(?m)^\\s*\\d+[.)]\\s+"), "")
        text = text.replace(Regex("[*_`~]"), "")
        text = text.replace(Regex("[<>]"), " ")
        text = text.replace(Regex("\\s+"), " ").trim()
        return text.take(6000)
    }

    fun localeFor(context: Context): java.util.Locale {
        val lang = context.getSharedPreferences("threadline-settings", Context.MODE_PRIVATE).getString("language", "en")
        return when (lang) {
            "pl" -> java.util.Locale("pl", "PL")
            "tr" -> java.util.Locale("tr", "TR")
            else -> java.util.Locale.US
        }
    }

    fun configure(engine: android.speech.tts.TextToSpeech, context: Context) {
        val locale = localeFor(context)
        engine.setLanguage(locale)
        engine.setSpeechRate(0.96f)
        engine.setPitch(1.0f)
        val candidates = try { engine.voices?.filter { it.locale.language == locale.language }.orEmpty() } catch (_: Exception) { emptyList() }
        // Prefer a high-quality voice that can start quickly without a network dependency.
        val selected = candidates.sortedWith(
            compareByDescending<android.speech.tts.Voice> { it.quality }
                .thenBy { it.isNetworkConnectionRequired }
                .thenBy { it.name }
        ).firstOrNull()
        if (selected != null) try { engine.voice = selected } catch (_: Exception) { }
    }
}
