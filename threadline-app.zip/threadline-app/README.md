# Threadline 1.5.0

**A private, voice-first personal orchestrator for Android.** Capture what is happening, talk it through with a local model, and let Threadline propose concrete next moves. It is designed to reduce the effort of staying organized—not create another productivity dashboard to maintain.

## Product principles

- **Capture before categorization.** Voice transcripts, quick text, photos, files, and shared text enter the same private inbox.
- **Talk, don't fill forms.** Use a continuous voice session with Android's on-device speech recognizer and an offline text-to-speech voice where installed.
- **Local intelligence, deterministic execution.** LiteRT-LM runs compatible models on-device. Threadline validates proposed operations against real task/project IDs and asks for approval before applying them.
- **Poke me when I need it.** Local task reminders and an optional daily nudge; notification text stays generic so task content isn't exposed on a lock screen.
- **One tap from anywhere.** An optional draggable system-wide floating button opens quick capture, Talk, Studio, voice note, translation, camera and file actions. It requires Android's “Display over other apps” permission and stays visible through a foreground-service notification. The microphone is not used until the user chooses a voice action.
- **Keep evidence.** Original captures and attachments remain intact; AI suggestions are separate and reviewable.
- **Private by default.** The vault remains encrypted and local. The only intended network use is downloading a selected public model and normal Android system flows. Local inference does not call an AI API.

## What changed in 1.5.0

- Added a shared light/dark/system design palette and a persistent Appearance setting.
- Added native view-property transitions, staggered navigation entrances, animated button presses and haptic feedback, with reduced-motion support.
- Added premium gradient hero surfaces, clearer elevation/surface contrast, a tighter mobile toolbar and a shimmer while the local model initializes.
- Applied the same press feedback and staged menu entrance to the cross-app floating action bubble.
- Extracted design tokens and motion primitives into dedicated Kotlin files; kept Android-native Views and avoided a React Native migration.

## What changed in 1.4.0

- Added a dedicated Agent workspace with a visible, governed orchestration pipeline and pending-approval entry point.
- Added a one-tap compact local-model download directly from Today and Agent; the alternative model chooser and compatible model import remain available.
- Incremented Android version code so the new build can be distinguished from the previous APK.

## What changed in 1.3.0

- Added Studio: a local-AI content workspace for LinkedIn posts, carousel outlines, short-video scripts, build logs, case studies, technical breakdowns, diagrams, website stories, portfolio proof, comments/replies and email drafts.
- Added channel, format, voice and editable brand/privacy rules that persist across sessions; including project context is an explicit opt-in and off by default.
- Added “Use recent capture” and “Use completed work” source pickers so the user can reuse existing work without manually copying it into Studio. Source material remains in the editor so one event can produce multiple formats.
- Added encrypted Studio draft persistence, edit/copy/archive/restore/delete, global search and a deliberate Private → Public-safe review step. This never publishes content.
- Talk can propose creating a private content draft; it is saved only after the user approves the proposal.
- Added Studio to the floating quick-action menu and an animated status orb that reflects a live product rather than a static icon.
- Migrated the private state format from schema v1 to v2 in memory while preserving existing tasks, projects and reviews.

## What changed in 1.2.0

- Reworked Today into a more intentional command center with a strong Talk entry point and direct capture actions.
- Rebuilt Talk around a large voice control, local-model status, and visible streaming text while the model generates.
- LiteRT-LM now tries GPU acceleration first, then falls back to CPU if GPU initialization fails. It reuses the loaded engine, warms it on a background thread, caps the token context at 4096, disables optional thinking for routine tasks, limits routine output, and streams the answer to the UI.
- Added a model chooser: **Qwen3-0.6B** (about 345 MB) for lower resource use, or **Qwen3-1.7B** (about 977 MB) for stronger instruction following. The larger model is optional and may need considerably more memory; it is not guaranteed to be faster. Downloads are pinned and SHA-256 checked before replacing an existing model.
- Added an always-available floating action bubble, Android text-selection integration, and shared-text/file intake.
- Added offline OCR for image captures using the bundled ML Kit text-recognition model. This lets Threadline interpret text in whiteboards, screenshots and documents without pretending a text-only LLM can see arbitrary images.
- Added per-task reminders, a daily nudge, reboot rescheduling, and AI-proposed reminder actions. Notifications don't show task titles or capture text.
- Refreshed the Threadline mark and app theme.

## Content Studio

Open **Studio** or choose Studio from the floating button. Add the real source material first, then select destination, output format and voice. Optionally include a small selection of active project context; it is off by default. Generated drafts are stored in the encrypted vault and remain private. You can edit/copy/archive/delete them. Marking a draft **Public-safe** is a deliberate review step and never publishes it. The model is instructed not to invent results, metrics, dates, quotes or credentials, but output still requires human fact-checking.

Studio defaults, the editable brand/privacy profile and the speech language are saved in local app preferences. The Studio data itself is stored with the encrypted vault and included in encrypted backups.

## AI model setup

1. Unlock the vault.
2. Open **Talk** and choose a local model.
3. Download over Wi-Fi. The model is saved in private app storage and its SHA-256 is verified before installation.
4. The first initialization is done in the background. The UI reports whether GPU acceleration or CPU fallback is active.
5. Tap the large voice control. Voice recognition and spoken replies depend on the phone's installed offline language/voice packs.

Models are replaceable. To import a different LiteRT-LM model, use the model import option and select a compatible `.litertlm` file. A model file that passes file selection is not automatically compatible; Threadline attempts to initialize it before the first useful conversation.

## Always-on floating button

Tap **Float** in the top bar and grant **Display over other apps**. The floating `T` can be dragged around the screen. Tap it for Capture, Talk, Studio, Voice note, Translate, Photo or File. Disable it from the app header or its persistent notification. Android can hide overlays over protected/system surfaces, and battery managers may stop background services on some devices.

The bubble is **not an always-listening microphone**. It listens only after you explicitly select Talk or voice note. A visible foreground-service notification explains that the quick-action bubble is active.

## Reminders

- Set a reminder from a task card, or ask the local assistant to schedule one. AI-generated reminders are proposals and must be approved.
- The daily nudge is optional and can be changed or disabled from Today.
- Notifications are generic; task content is only shown after opening and unlocking Threadline.
- Android may delay inexact alarms in battery-saving modes. This is not an exact-alarm clock app.

## Privacy boundaries and limitations

- Text model inference is local after model download.
- The default Qwen3 models are text models. Image captures are handled with local OCR; arbitrary image understanding requires a compatible multimodal model and is not claimed for the default model.
- Android's speech-recognition and TTS providers must be checked for offline availability on the actual phone. Threadline requests on-device recognition, but cannot guarantee every installed provider behaves offline.
- Local text-to-image generation is **not included in this build**. Google's MediaPipe image-generation path is experimental and needs a separate converted diffusion model pack; Google's current Android codelab recommends a device with at least 8 GB RAM. This should be an optional, device-tested download, not a fake button or a model bundled into every APK.
- External actions such as sending email, changing calendars, posting online, or spending money are not performed by the local orchestrator.

## Build

- JDK 17
- Android SDK platform 35 / build-tools 35.0.0
- Gradle 8.14.4 or newer compatible with the configured Android Gradle Plugin
- Kotlin compiler options target JVM 17

Run from the project root:

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug
```

The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Product and verification notes

See `DESIGN_SYSTEM.md`, `PRODUCT_SYSTEM.md`, `USER_NEEDS_MAP.md`, `ROADMAP.md` and `FEATURE_STATUS.md` for the complete product direction and the explicit boundary between implemented, planned and verified capabilities.

The available standalone Kotlin compiler validated `Domain.kt`; full Android Gradle build, lint, unit tests, emulator test, v1-vault migration, backup restore and real-device performance/permission tests still need to run in GitHub Actions and on the target phone. Do not treat this archive as a device-verified release until those checks pass.
