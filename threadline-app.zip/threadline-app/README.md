# Threadline Android · 1.9.0

Threadline is a local-first personal operating workspace built around **capture, source mirroring, automation, evidence-linked understanding and user-controlled actions**. This archive preserves the ZIP layout used by the existing GitHub Actions workflow: extraction creates `threadline-app/settings.gradle.kts` and `threadline-app/app/build.gradle.kts`. The workflow file does not need to change.

## What is in this build

### One local workspace (Threadline + ME + Troy + Nexus + EBO)
- A mobile-first capture/library/studio/actions/profile interface, including Android Share-sheet intake, attachment and camera capture, voice dictation, and a movable floating capture bubble.
- An AES-GCM encrypted app-private workspace vault, encrypted attachment files, and encrypted source-mirror blobs/manifests. The originals in a selected folder are never modified by Threadline.
- **Source mirror:** pick a folder through Android's Storage Access Framework; Threadline makes local encrypted copies, hashes current content (rather than trusting only size and modification time), and retains prior content versions when a file changes. Each sync reads up to 200 files and continues from a cursor on subsequent syncs; individual files over 25 MB are skipped. A full directory listing is used before marking paths absent, so a partial scan doesn't look like mass deletion. Background sync is scheduled by Android WorkManager about every six hours; manual sync is also available. Android may suspend background work or revoke a folder grant, in which case the folder must be selected again.
- **Automation rules:** deterministic rules can add a tag, create a linked follow-up task, or queue local interpretation into review when a new capture/mirrored version matches the rule. Runs have a visible history and de-duplication key. Mirrored changes are reflected into the workspace when it next opens/resumes and checks the mirror manifest; this is not a promise of instantaneous background automation while the app is closed.
- **Local language model:** LiteRT-LM Android runtime with model import, activation, test prompt, deletion and one-click catalogue download. The built-in catalogue begins with Qwen3 0.6B and Gemma 4 E2B where the official `.litertlm` artifact is exposed; later compatible `.litertlm` entries can be discovered from the official LiteRT Community Hugging Face catalogue. A weekly background check can notify about new artifact files where Android notification permission is granted. Model terms, hardware needs and file sizes should be reviewed before installation.
- Model import uses Android's document picker, with a fallback to the content picker. The app copies the chosen `.litertlm` file into its private model folder; it does not load a model in-place from another app's private storage. If AI Edge Gallery keeps a model only inside its private sandbox, export/copy the file into a user-accessible Downloads folder or use the in-app catalogue.
- **On-device OCR** for image attachments (bundled ML Kit Latin script recognizer).
- **Nexus-style gates:** source is retained separately from OCR/interpretation. Output must pass deterministic JSON/schema and evidence checks; proposed entities, concepts and relationships stay in Review until you approve them.
- **Live App Feed and controls (opt-in):** enable Threadline under Android Accessibility settings, then turn the feed on inside Threadline. The floating `T` bubble opens quick capture on tap and live controls on long-press. When available, those controls can read exposed text, scroll, invoke Back and tap a visible control with an exact label without opening the Threadline activity over the current app. Snapshots and event history are encrypted locally; password fields are excluded. Apps can hide their UI from accessibility, and secure surfaces may be unreadable or non-interactive. This is accessibility-based control, not a universal screen recorder or security bypass.
- **App manager:** lists launchable apps; open app, open Android app details, notification settings, store listing/update page, hide/unhide within Threadline, and request uninstall through Android's own confirmation. Optional Usage Access supports local 30-day use summaries and review recommendations. Threadline cannot silently uninstall apps or hide/disable them system-wide as a normal third-party app.
- **Language options:** English, Polish and Turkish for the primary interface and the main workspace headings/navigation. Some detailed feature dialogs and platform-generated screens still use English. Language changes do not translate or alter stored source text.

## First-run setup

1. Install and open Threadline. Existing ZIP-based Actions builds will create the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
2. Open **Profile → Local intelligence & review**. Choose **Install with one tap** for a listed model, or **Import .litertlm** and select a model file available through Android Files. The first catalogue download needs internet. Inference itself is on-device; the runtime uses CPU in this build.
3. Press **Test active model**. A model can take substantial RAM/storage and may fail on devices that do not meet its requirements. The Qwen entry is the smaller starting choice; Gemma E2B is a much larger download and can require licence acceptance.
4. Open **Profile → Source mirror**, select only a folder you want to mirror, then start sync. Originals are read-only to Threadline; mirrored copies and their manifest are encrypted in app-private storage.
5. Add an **Automation** rule and choose its matching trigger/action. Review the execution history after saving. The `interpret locally` action requires a usable local model and text in the source; output is not automatically approved.
6. To use live cross-app reading/navigation, explicitly enable Threadline in Android Accessibility settings, return to Threadline and start the Live App Feed. Enable the floating capture bubble if you want the controller above other apps. A long-press on the floating `T` opens the live control panel.
7. Select English, Polski or Türkçe in **Profile → Language**.

## Model compatibility and privacy

This build accepts **LiteRT-LM `.litertlm` files**. It does not load GGUF (including normal Ollama exports) or MediaPipe `.task` files. AI inference and OCR run locally. The internet permission exists only for explicit model catalogue checks and downloading model files; the app does not sync its workspace/source mirror to a cloud service. Model catalogue requests contact Hugging Face, and model download/terms pages may require external network access or licence acceptance. Android speech recognition uses the device's selected recognizer, which may process voice outside Threadline depending on its configuration.

Cross-app accessibility is powerful and deliberately off until the user enables the Android service and separately turns on the in-app feed. The app records exposed UI text and user-requested controls on this device, not raw screen video. Password nodes are skipped; apps that mask content, secure screens and custom-rendered controls may not be available. User-defined automation actions are limited to local organization/tasks/local AI review in this build; it does not auto-send messages, purchase items or publish content.

Exported workspace JSON backups are **not encrypted** and do not include attachment bytes. Keep them secure. The local vault, attachments, mirror blobs and live feed snapshots use AES-GCM with an Android Keystore-managed key. Uninstalling the app normally deletes app-private data, including the local model cache and mirror copy.

## Build configuration

- Android application ID: `com.threadline.privateplanner`
- `minSdk 30`, `targetSdk 34`, `compileSdk 35`
- Java 17, Android Gradle Plugin 8.7.3, Kotlin Gradle Plugin 2.4.21
- LiteRT-LM `0.18.1`, ML Kit Text Recognition `16.0.1`, AndroidX DocumentFile `1.0.1`, WorkManager `2.10.0`
- The existing CI uses Java 17, Android SDK 35 and Gradle 8.13. Kotlin currently warns that later Kotlin plugin releases will require newer Gradle; this warning is not itself the earlier compiler failure. The workflow has intentionally not been changed.

## Important scope boundary

This build joins working capture, local inference/OCR, encrypted folder mirroring, local automations, review/approval, cross-app accessibility controls and app management under one workspace. It is still not an unrestricted OS replacement: Android permission boundaries apply, continuous background work can be deferred, some apps expose no accessible UI, and third-party integrations such as email/social services are not automatically connected. The project must pass the GitHub Actions Gradle build and be tested on the target phone before treating APK compilation/device behavior as verified.
