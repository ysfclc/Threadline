# Threadline Android · 1.8.0

Threadline is a local-first personal workspace for frictionless capture, context recovery, evidence-linked knowledge, and user-controlled follow-through. This archive is laid out for the existing ZIP-based GitHub Actions workflow: extraction creates `threadline-app/settings.gradle.kts` and `threadline-app/app/build.gradle.kts`. No workflow change is required.

## Included

- Existing mobile-first workspace: Home, Library, Studio, Actions, and Profile.
- Capture notes, links, ideas, people, companies, articles, video, and files.
- Android Share-sheet intake for text, links, images, PDFs, and generic attachments, plus camera capture, file picker, and voice dictation.
- Optional user-enabled floating capture bubble above other apps. Android overlay permission and an ongoing notification are required; tapping the bubble opens Threadline capture. It does not inspect, record, or read other apps.
- Android Keystore AES-GCM encrypted workspace vault and encrypted attachment files in app-private storage.
- Export/import of the workspace JSON (attachment file bytes are not part of that export).
- **On-device text inference** through Google's LiteRT-LM Android runtime. No cloud inference endpoint is configured, and the app does not request `INTERNET` permission.
- **Local model manager**: import compatible `.litertlm` model files from device storage, select an active model, test inference, and remove a model without removing workspace data. Import limit: 3 GB per model, bounded by free storage.
- **On-device OCR** for imported image attachments using the bundled ML Kit Latin text recognizer.
- **Nexus-style processing records**: Pending → Active → Review → Approved / Dismissed. The original capture is kept separate from derived OCR and interpretation. Model output must pass deterministic JSON/schema checks; cited evidence strings are matched against the supplied source text. Outputs remain in Review until the user approves them.
- On approval, only entity/concept suggestions whose evidence text matches the source are written into local entities/dictionary collections. Relationship suggestions are recorded only when the evidence matches and both endpoints resolve to approved entities. No model output silently approves itself.
- Processing events record stage, detail, timestamp, selected model, source capture, model output, validation state, and user decision inside the encrypted workspace.
- Backwards-tolerant normalization: workspaces created before this version receive empty processing, entity, relationship, and dictionary collections on load.

## First-run local model setup

1. Open **Profile → Local intelligence & review**.
2. Open the model link to the Hugging Face LiteRT Community `Gemma3-1B-IT` repository. Review and accept the Gemma licence on Hugging Face before downloading a compatible `.litertlm` file. The repository may require sign-in/licence acceptance.
3. Return to Threadline and use **Import .litertlm** to choose the downloaded file. The model is copied into app-private storage. Activate it, then press **Test model**.
4. Open a saved capture's quick actions and choose **Understand with on-device AI**. Image attachments first go through on-device OCR. The interpretation is queued for Review, not auto-approved.

Model repository: https://huggingface.co/litert-community/Gemma3-1B-IT
Runtime documentation: https://ai.google.dev/edge/litert-lm/android

### Model compatibility

This build uses LiteRT-LM and accepts `.litertlm` files. It does **not** directly load GGUF models (including typical Ollama exports) or MediaPipe `.task` files. The language model is deliberately not bundled in the source ZIP/APK: models are large, have separate licences, and vary in hardware requirements. Importing a model is a deliberate user action. Actual speed and memory use depend on the Android device and selected model.

## Architecture boundaries

- **Threadline** is the capture and everyday interaction surface.
- **ME** principles shape local context, persistent memory, provenance, and privacy boundaries.
- **Troy** principles shape evidence-linked concepts, entity resolution, dictionary entries, and explicit relationships. It does not impose a large fixed ontology.
- **Nexus** supplies the processing lifecycle, validation gates, visible history, and user approval.
- **EBO** principles shape source intake and deterministic processing before model interpretation.

The local LLM is a metadata helper, not the authority on what becomes knowledge or an external action. This version is a foundation, not a claim that every future ME/Troy/Nexus/EBO capability is implemented: cross-app passive monitoring, autonomous integrations, remote sync, and screen recording are not included in this package. The floating bubble is a launcher only, not an always-on screen observer.

## Build

The existing CI workflow runs with Gradle 8.13, Java 17, Android SDK 35, and Android Gradle Plugin 8.7.3. Dependencies include LiteRT-LM Android (`latest.release`) and ML Kit Text Recognition 16.0.1. The project requires min SDK 30, target SDK 34, compile SDK 35. The existing GitHub Actions ZIP extraction path is unchanged.

## Vault compatibility note

This archive keeps the installed application ID `com.threadline.privateplanner`. It does not contain an automatic migration from the older 1.6.0 vault or reintroduce source-only features that were absent from the available 1.7.0 archive. Export the old workspace before replacing an installation if its vault needs to be preserved. The new processing records live within the current versioned encrypted vault.
