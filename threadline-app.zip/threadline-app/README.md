# Threadline Mobile

Threadline is a local-first Android workspace for capturing useful things, preserving their context, preparing next actions, and tracking content drafts and outcomes.

## Project layout

This archive intentionally has the `threadline-app/` root and Kotlin Gradle files expected by the existing ZIP-based GitHub Actions workflow:

- `settings.gradle.kts`
- `build.gradle.kts`
- `app/build.gradle.kts`
- `app/src/main/`

No workflow changes are required. Upload this ZIP in place of the existing source ZIP.

## Included in this build

- Mobile-first, responsive UI with Home, Library, Studio, Actions, and Profile areas
- Quick capture for notes, links, ideas, content, people, companies, articles, video, and files
- Android Sharesheet receive support for text, links, images, and PDFs; shared files are copied into app-private storage and encrypted at rest
- In-app file picker, camera capture, and voice dictation through the device speech recognizer
- Capture editing, deletion, source opening, tags, inbox status, and searchable/filterable library
- Draft creation/editing, copy-to-clipboard, source-linked drafts, and safe handoff to the original app
- Action creation, editing, completion, reopening, and deletion
- Published-content records and manually entered reach/engagement/click metrics
- JSON workspace export/import; attachments stay in the encrypted on-device vault and are not embedded in JSON exports
- Android Keystore AES-GCM encrypted local vault and attachment files; app-private storage; device-credential gate when a secure device lock is configured; no Internet permission
- Demo workspace to make the first launch useful and to demonstrate the intended workflows

## Build

Use the existing GitHub Actions workflow. The workflow should find `threadline-app/settings.gradle.kts` at the archive root after extraction. Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, min SDK 30, and Java 17 are configured.

## Migration note

This archive preserves the installed package ID (`com.threadline.privateplanner`) and uses a new, versioned vault filename/key alias so it will not overwrite an older vault by accident. Automatic migration from the previous 1.6.0 vault and its local-model/floating-assistant features is not included because the previous source archive/storage schema was not present in the build workspace. Export your existing 1.6.0 workspace before installing this version if you need that data; do not treat this build as a drop-in preservation of every previous feature.

## Privacy and current boundaries

Threadline does not read other apps in the background, mirror private feeds, or sync to a cloud. Users explicitly share items into Threadline. External actions remain user-controlled: the app can copy a draft and open a source but does not claim to have sent or published it. Exported JSON backups are not encrypted and do not contain attachment bytes; store them carefully. Attachments are encrypted at rest and decrypted only to a temporary cache file when opened; temporary plaintext cache is cleared on the next app launch.
