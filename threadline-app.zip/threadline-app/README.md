# Threadline — private daily execution app

Threadline is a small, offline-first Android app for turning thoughts into next actions without making another heavyweight project-management system. It is tailored around an assumption that the user needs a reliable capture point, a limited daily focus, a visible next action for active projects, and a low-pressure daily reset.

## Current build status

- Android-native Kotlin application source is included.
- The environment used to prepare this project had Java 21 and Kotlin 1.9, but no Android SDK, Gradle installation, or network/DNS access. Consequently, an APK could not be built or runtime-tested inside that environment.
- A GitHub Actions workflow is included to install the Android SDK and Gradle, run unit tests, build the debug APK, and publish it as a workflow artifact. Do not treat the source archive itself as an APK.

## Product behavior

- **Today:** up to three focus tasks; mark tasks done or move them to Next.
- **Inbox:** one-step capture, with options to focus, promote to Next, or delete.
- **Projects:** record an intended outcome and one explicit next action; add it to Next or focus it today; park and reactivate projects.
- **Review:** brief end-of-day reflection and a non-destructive roll-over of unfinished focus items.
- **Backup:** export/import a separately passphrase-encrypted backup through Android's file picker.

There is no account, server, analytics SDK, advertising, or in-app AI. Threadline is not a clinical tool and makes no assumptions about ADHD or any diagnosis.

## Security design

- No `INTERNET` permission is declared, so the app does not make network requests. TLS is therefore not applicable to its current local-only data path.
- The app state is serialized as JSON in memory, then encrypted using AES-256-GCM before it is written to the app-private files directory. The random 256-bit data key is wrapped by a separate AES-256-GCM Android Keystore key that requires `BIOMETRIC_STRONG` authentication for each cryptographic use.
- The in-memory data key is zeroed when the app leaves the foreground, when it is locked, and on destruction. A secure-window flag prevents Android screenshots and recents previews.
- Android cloud backup/device transfer are disabled for this app's data.
- Backups use AES-256-GCM with a key derived from a user-chosen passphrase using PBKDF2-HMAC-SHA-256 (600,000 iterations), a random salt, and a random IV. Keep the backup passphrase separate from the file; it cannot be recovered by the app.
- There are no hardcoded credentials or API secrets. The only requested permission is `USE_BIOMETRIC`; no contacts, location, microphone, camera, notification, or Internet permission is requested.

### Important security/availability trade-off

Use a strong biometric configured on the phone before creating a vault. Keep current encrypted backups in a safe place. Biometric or device/OS changes can affect access to Keystore-protected data; this app intentionally does not upload or escrow the key. If the vault key is unavailable, the app cannot decrypt the local vault; an independent encrypted backup is the recovery path. The “Reset / erase local vault” operation is destructive and should be used only when starting over.

Security controls are implemented in source but still require device testing and a proper security review before any claim of production certification. The included CI build/tests are not a substitute for testing biometric flows on a physical Android device.

## Requirements

- Android 11 (API 30) or newer. The current personal-install build targets API 34 to avoid edge-to-edge layout surprises in this fully programmatic UI; it compiles against SDK 35.
- A strong biometric enrolment supported by Android's `BIOMETRIC_STRONG` authenticator.
- To build: JDK 17, Gradle 8.13, and Android SDK platform 35 / build-tools 35.0.0.

## Build locally

From this directory, set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) to the Android SDK path and run:

```bash
./scripts/build-apk.sh
```

The APK is copied to `dist/threadline-debug.apk`. The first build needs access to Maven/Google repositories to download Gradle and declared libraries.

## Build through GitHub Actions

1. Create an empty GitHub repository and push the contents of this folder to its `main` branch.
2. Open the repository's **Actions** tab and run **Build Threadline Android APK** (or let the push trigger it).
3. Wait for the workflow to finish successfully. Download the `threadline-debug-apk` artifact from that run and extract `app-debug.apk`.
4. Transfer the APK to your Android phone, open it, and allow installation from that source when Android asks. Install and open Threadline, then create the vault with your strong biometric.

This workflow produces an unsigned debug APK for personal installation, not a Play Store release. A release build requires a deliberate signing and distribution setup.

## Tests

The project includes unit tests for focus-slot limits, input validation, project deduplication, end-of-day roll-over, encrypted backup round-tripping, incorrect passwords, and backup tampering. Run `gradle testDebugUnitTest lintDebug` as part of the Android build setup.

## Data model

- `TaskItem`: id, text, status (`INBOX`, `TODAY`, `NEXT`, `LATER`, `DONE`), timestamps, optional project id.
- `ProjectItem`: id, title, intended outcome, next action, status (`ACTIVE`, `PARKED`, `DONE`), timestamps.
- `DayReview`: date, what moved forward, next step, what is parked, updated timestamp.

The app validates imported data sizes, identifiers, required fields, valid statuses, and the three-item Today limit before replacing the current data.
