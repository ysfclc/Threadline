# Threadline 1.0.0

**A private, offline-first capture-to-action workspace.** Threadline is a small mobile-first tool for catching thoughts, converting likely action items into tasks, keeping project context, and finding things again without another SaaS account.

It is deliberately deterministic. It does not use a cloud AI service, send telemetry, or require a backend. The Android project wraps the same locally bundled UI with Android Keystore-backed encryption and the system authentication prompt. A Progressive Web App (PWA) build can be installed from HTTPS in Chrome on Android.

## What is included

- Quick text capture, deterministic task/idea hinting, and editable capture types.
- A “next actions” list, task completion, inbox filters, due-date detection for common relative days, and local search.
- Four starter project spaces: **QRkey**, **Troy**, **Threadline**, and **Work & income**. They begin empty; no historical content or fake tasks are seeded.
- Optional image, document, and voice-note attachments, with per-file and total-size guards.
- Project linking, edit/convert/delete actions, and confirmation for destructive actions.
- Password-encrypted backup and restore.
- Offline PWA shell after the first successful load; Android assets are bundled into the APK.
- Local-only operation, no analytics/tracking, no remote scripts, no backend, and no app `INTERNET` permission.

## Security model

### Native Android app

- Android Keystore holds a non-exportable AES-256 key. The vault is encrypted with AES-GCM (96-bit random IV; 128-bit authentication tag).
- Opening/creating the vault requires Android's biometric or device-credential prompt. The key is configured for a short OS authentication validity window; the app also locks on leaving the foreground and after inactivity.
- Data is stored in an app-private file and atomically replaced after encryption. The key alias is recorded inside the encrypted-vault envelope to allow safe backup restoration with a new key. The reader retains compatibility with the original `TLV1` envelope.
- `FLAG_SECURE` suppresses screenshots in Android's task switcher. Android OS backup is disabled (`allowBackup=false`).
- No `INTERNET` permission is declared. The WebView only serves the bundled `https://appassets.androidplatform.net` assets and blocks navigation to other origins. Only audio capture is requested, and only after a user action.
- The application does not implement remote sync, so it has no network transport or TLS endpoint. Encrypted backup files are exported through Android's system document picker.

### Browser / PWA build

- The passphrase is processed with PBKDF2-HMAC-SHA-256 (600,000 iterations) to derive an AES-256-GCM key. The random salt and ciphertext are stored in IndexedDB; the passphrase-derived key stays in memory only while unlocked.
- The application locks after ten minutes of inactivity, and a hidden page locks after three minutes.
- Browser storage is only treated as secure when served from HTTPS (or a browser-trusted localhost origin). A service worker caches only the app shell; it does not cache personal data or external responses.
- Backups use a separate user-chosen passphrase, PBKDF2-SHA-256, and AES-256-GCM. Keep the backup passphrase separate from the backup file.

**Important limitations:** this is a first release and has not undergone an independent security audit or testing on a physical Android handset in this environment. Anyone who can unlock the device/browser profile may be able to access the app while its session is open. A forgotten vault passphrase cannot be recovered by the developer. Use the built-in encrypted export regularly and store it somewhere safe. Do not treat the app as a password manager or a substitute for a tested backup strategy.

## Requirements

### To build the Android APK locally

- Android SDK Platform 35 and Build Tools 35.0.0.
- JDK 17.
- Gradle 8.9 (Android Gradle Plugin 8.7.3).
- A device or emulator running Android 11 / API 30 or newer with a configured screen lock. For voice notes, microphone permission is asked at the time of use.

The project uses Gradle directly rather than checking in the binary Gradle wrapper JAR. If you use Android Studio, open the `android/` folder as the project and let the IDE configure the local SDK/Gradle installation.

### To run the checks

```bash
npm test
```

This repository intentionally has no npm runtime dependencies.

## Build and install the Android APK

With Gradle and the Android SDK configured:

```bash
./scripts/build-android.sh
```

The script runs the repository checks, builds the debug APK, and copies it to `dist/Threadline-debug.apk`. If `adb` is available and a device is connected, it also runs `adb install -r`.

Equivalent build command:

```bash
cd android
gradle --no-daemon assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Debug builds use the package ID `app.threadline.mobile.debug` so they can coexist with another build. The APK is debug-signed for personal testing; it is not a Play Store release artifact.

### Build the APK in GitHub Actions

This environment does not have an Android SDK or Gradle installed, and its network sandbox could not download them. Therefore **a real APK was not built or device-tested here**. The repository includes `.github/workflows/android-apk.yml` to build one in a clean GitHub-hosted runner:

1. Create a repository in GitHub and upload/push this project's files to the `main` or `master` branch.
2. Open **Actions → Build Android APK** and run the workflow (or let the push trigger it).
3. Open the successful run and download the `threadline-android-debug-apk` artifact.
4. Download `app-debug.apk` to your Android phone and open it. If prompted, allow installation from the source you used to download it. Install only APKs you built or trust.

The workflow installs JDK 17, Gradle 8.9, Android platform 35 and build tools 35.0.0, then runs `assembleDebug`. Artifacts are retained for 14 days. The APK is not signed with a personal release key.

## Install the PWA on Android without building an APK

This alternative still keeps vault data on the device, but its security gate is a passphrase rather than Android Keystore biometric authentication.

1. Push the project to GitHub.
2. In **Settings → Pages**, set the build/deployment source to **GitHub Actions**.
3. Run the **Deploy private-first PWA shell** workflow (or push to `main`/`master`).
4. Open the published HTTPS Pages URL in Chrome on Android, then use **⋮ → Install app** or **Add to Home screen**.
5. Open Threadline once while online; the app shell is then cached for offline use. Create a strong vault passphrase and export an encrypted backup.

GitHub Pages hosting serves static application files, not personal notes; Threadline does not send captures to the hosting origin. Private-repository Pages availability may depend on your GitHub plan. For a sensitive vault, check hosting/account policies before selecting a host.

## Repository structure

```text
public/                       PWA UI, styles, app logic, icons, manifest, service worker
android/                      Native Android WebView shell and Android Keystore storage
  app/src/main/java/...       MainActivity and guarded JavaScript bridge
  app/src/main/assets/        Bundled copy of public/ (Gradle syncs it before build)
.github/workflows/
  android-apk.yml             Build and upload a debug APK
  deploy-pwa.yml              Deploy the PWA static shell to GitHub Pages
scripts/check.mjs             Dependency-free static sanity checks
scripts/build-android.sh      Local build/install convenience script
```

## Design choices

- **No local LLM bundled:** task detection, project organization, and exact text search are handled deterministically. Bundling a 0.5B–3B model would increase APK/storage size, memory use, heat, and battery demand without materially improving this capture workflow. Nothing prevents adding an optional local model later for a specifically validated semantic-search use case.
- **No sync service:** no affordable, self-controlled backend is necessary for the first version. Portability is via encrypted export/import.
- **No analytics or tracking:** no analytics SDK is included.
- **Least privilege:** no native network permission; microphone permission only for a user-triggered recording; file access uses the system document picker.

## Known limitations and next improvements

- Native build/runtime behavior still needs confirmation on a physical Android 11+ handset and at least one recent Android release.
- Attachments are stored inside encrypted vault data; large media files are capped to avoid uncontrolled storage use.
- The “task” label is an editable heuristic, not an AI judgment; users should confirm important due dates.
- The app currently has no cloud sync, cross-device merge, push notifications, calendar integration, or automatic external-app imports.
- A PWA lock cannot guarantee that a browser will instantly zero every copy of sensitive bytes from memory; the Android build is the stronger option for biometric/device-credential access control.
