# Threadline — private capture, voice and orchestration

Threadline is an Android working companion for turning unstructured life into progress. Capture first, then talk it through. Threadline can use the current contents of your local projects and open tasks to help clarify a problem, choose a next move, and **propose** changes to its own task/project records. It is not just a checklist or a chatbot disconnected from your actual work.

## Product experience

- **Talk to Threadline:** tap to start a voice session, speak, get a spoken answer, then keep talking without tapping the microphone for every turn. It uses Android's on-device speech recognizer, a local language model, and an installed offline text-to-speech voice. A language selector offers English, Polish, Turkish and Kurdish; support depends on installed local speech/voice packs.
- **Local AI download inside the app:** the Talk screen can download a compatible Qwen3-0.6B LiteRT-LM model directly into Threadline. The recommended dynamic INT4 model is about 345 MB. This is a separate download so the APK stays reasonably small. A compatible `.litertlm` file can also be imported.
- **Orchestration proposals:** the model receives a bounded snapshot of current projects, active tasks, recent completions and a recent chat excerpt. It may propose creating a task/project, moving or completing a task, updating a project, or connecting a task to a project. Threadline validates IDs and status values; changes are never applied until you tap **Review & apply changes**.
- **Capture studio:** quick text, voice transcripts, camera photos and files. The original capture remains separate from AI suggestions. Attachments live in the encrypted vault; images are normalized and size-limited.
- **Edit, delete and search:** edit captures and projects, search captures/projects/reviews locally, inspect attachments, and delete captures.
- **Useful work surface:** keep a maximum of three items in Today, maintain a short Next list, park work without deleting it, track one next action per project, and optionally save a conversation into the inbox.
- **Private backup:** export and restore a passphrase-encrypted backup through the Android document picker.

## Set up local AI

1. Install and open Threadline. Create or unlock the local vault.
2. Open **Talk** and tap **Download local model · ~345 MB**. Use Wi-Fi if possible; allow enough free storage for the model plus working memory/cache.
3. After download, start a text conversation or tap **Start voice conversation**.
4. For spoken replies, an offline text-to-speech voice matching your chosen language must be installed in Android settings. Threadline will not silently choose a network voice. On-device speech recognition also requires a compatible recognizer and offline language pack.

The default model is the `Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm` build from the [LiteRT Community Qwen3-0.6B model page](https://huggingface.co/litert-community/Qwen3-0.6B). It is small enough to try on many phones, but has limited reasoning and may occasionally produce malformed suggestions or wrong answers. Check proposed changes. The runtime is Google's [LiteRT-LM for Android](https://developers.google.com/edge/litert-lm/android). Alternative compatible models can be imported.

The default Qwen3 model is text-only. Although Threadline can store photos and files, the default model does not understand images. Image reasoning needs a compatible vision-language model and more memory. The standalone per-capture **Think** function can fail on image attachments if the selected model is text-only; the app reports that error rather than claiming success.

## Privacy and security

- No account, ads, analytics SDK or application backend. The app requests Internet access **only for the in-app download of the public model file**; the networking code does not send captures, transcripts, project records or chat content to a server. Inference happens locally after the model is installed.
- Voice input uses Android's on-device speech-recognition API where available. Raw audio is not retained by Threadline. Spoken replies use an installed offline Android TTS voice; no network voice is selected by Threadline.
- Captures, projects, reviews and attachments are serialized as JSON in memory and encrypted with AES-256-GCM before being written to the app-private files directory. A random data key is wrapped by an Android Keystore AES key requiring `BIOMETRIC_STRONG` authentication for each cryptographic use.
- The vault session is cleared when Threadline is locked or normally backgrounded. The in-memory chat transcript and unapproved proposals are cleared at that point. Use **Save conversation** if you want to keep a conversation as a capture.
- Screenshots/recents previews are blocked. Android cloud backup and device transfer are disabled for app data.
- Encrypted backups use AES-256-GCM with a key derived from a separate user-selected passphrase using PBKDF2-HMAC-SHA-256 (600,000 iterations), a random salt and a random IV. Keep the passphrase separate from the backup; Threadline cannot recover it.
- The model file is public and stored separately in app-private storage, not inside the encrypted personal vault. Removing the model does not remove your data. A non-previewable attachment is opened through a short-lived decrypted cache file, deleted when you return to Threadline.

**Security status:** the implementation has not received a physical-device security review. The voice/model integration also needs testing on the target phone, including supported offline languages, model load speed and RAM use. Keep an independent encrypted backup and do not treat this as certified security software.

## Requirements

- Android 11 (API 30) or newer for the app and vault.
- A phone with `BIOMETRIC_STRONG` authentication configured.
- Android 12 (API 31) or newer plus a working on-device speech recognition service for voice conversation.
- An internet connection for the initial model download only; after download, model inference can run offline.
- Around 345 MB for the default model plus temporary/cache storage and sufficient available RAM. Actual performance depends heavily on chipset, GPU/runtime compatibility, Android version and background memory pressure.

## Build

This is a Kotlin Android project. To build locally, use JDK 17, Gradle 8.13, Android SDK platform 35/build-tools 35.0.0, then run:

```bash
./scripts/build-apk.sh
```

The first build needs Google Maven and Maven Central to download dependencies. The included `.github/workflows/android.yml` builds a debug APK when the project itself is checked out at repository root.

### Rebuilding from a ZIP stored in a GitHub repository

If your existing GitHub repository has the separate root workflow that extracts this source ZIP into `threadline-app/`, keep that root workflow unchanged. Replace the uploaded `threadline-app.zip` with the new source ZIP, run the existing workflow again, and download/extract the `threadline-debug-apk` artifact. The installable file is `app-debug.apk`.

The result is an unsigned debug APK for personal installation, not a Play Store release.
