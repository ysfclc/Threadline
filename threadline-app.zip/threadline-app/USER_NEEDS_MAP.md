# Threadline — Personal Needs Map

This document synthesizes recurring needs from prior project discussions. It is intended to guide product behavior; it is not a public biography and should not be treated as proof of any unverified claim.

## Recurring problems the product should solve

### 1. Too many ideas and partially built systems

The owner moves between product concepts, architecture work, career questions, monetization ideas and technical implementation. New ideas arrive faster than existing projects finish.

**Product response:** capture without friction; automatically connect ideas to known projects; separate Active, Incubating and Captured; show the cost of switching; ask what outcome earns focus; make parking an idea feel safe rather than like abandoning it.

### 2. A lot of thinking, but the next step can remain unclear

The owner often explores system architecture deeply, but needs help converting broad questions into the smallest real-world move.

**Product response:** every discussion can end with optional “decision / next action / blocked by / evidence needed / deliberately parked.” Don't force task creation for every conversation. Offer one next move and a reason.

### 3. Manual processes repeatedly become systems projects

Across outbound, CRM, language intelligence, agentic development and real-world workflows, the recurring instinct is to eliminate repetitive manual work and design reusable primitives.

**Product response:** detect repeated operations; propose a reusable skill or workflow only after there is evidence of recurrence; show the existing tools/skills that can be reused; keep deterministic execution separate from model reasoning.

### 4. Context gets lost between conversations and tools

Important reasoning is scattered across chats, repositories, documents, coding sessions, social networks, messages and notes.

**Product response:** preserve source and timestamps; connect people, projects, files, decisions, code sessions and outputs; support import/search before pretending the system already knows all historical context; make “why is this connected?” inspectable.

### 5. Building without a clear proof trail is hard to communicate

Real work should become usable evidence and a story, but public content must not exaggerate or reveal private details.

**Product response:** attach tests, screenshots, diffs, demos, outcomes and source references to work; offer to create public-safe stories from verified evidence; keep private truth separate from public versions.

### 6. Professional positioning is difficult to keep coherent

CVs, LinkedIn, the personal website, portfolio pieces, networking and anonymous experimental content need to reinforce one real story without being duplicated or contradictory.

**Product response:** canonical career facts and reusable proof; separate channel/format projections; preserve distinct identity rules for real and anonymous brands; generate role-specific CV variants from verified facts; use the user's natural, specific voice rather than generic “AI expert” claims.

### 7. Sales and outreach skills are useful, but quota-heavy sales is not the desired destination

The product should not assume that every opportunity needs a cold outreach campaign. The owner is more energized by systems, architecture, implementation and removing friction.

**Product response:** career recommendations should consider systems/automation/implementation roles and proof of building; help qualify an opportunity and prepare a targeted conversation; avoid turning the whole product into a CRM or forcing a sales pipeline on every relationship.

### 8. The user wants a partner, not another app to maintain

Manual categorization, dashboards, repetitive forms and complex setup make a tool easy to abandon.

**Product response:** voice-first capture, optional context, sensible defaults, editable settings, automatic linking proposals, one-tap actions, reminders with quiet hours, and a system that can be ignored without guilt.

### 9. The owner values ownership and privacy

Local-first/self-hostable, portable data and replaceable models matter, but a useful external capability should not be rejected on principle.

**Product response:** local by default; opt-in connectors; explicit per-source permissions; no hidden uploads; encrypted backup; model and provider replacement; clear offline capability reporting.

### 10. Quality expectations are high

The owner dislikes generic templates, fake metrics, unsupported claims, visual AI clichés and prototype UI. Motion should communicate state, not decorate it.

**Product response:** polished typography, a controlled visual system, real live status, responsive touch targets, no dead controls, evidence-led outputs, accessibility and device-level verification.

## Existing project DNA to preserve

| Existing system | Reusable product lesson |
|---|---|
| ME | One connected private and external world; stable identities; source truth and privacy boundaries |
| Troy | Language/context intelligence; evidence-backed meanings; aliases and context; AI proposes, human approves |
| Nexus | Small work units, review gates, independent verification, proof and durable work memory |
| EBO / Cockpit | Workflow orchestration, identity resolution, source records, routing, outcomes and audit trail |
| Kovan | Constrained domain execution; AI proposals checked by deterministic rules and a real geometry/process model |
| Zommo | Online service sales and operational follow-through |
| QRKey | Entities and relationships; reusable pages/modules; attribution and outcomes |
| Oddo | Real-world constraints, driver networks, message-based intake and logistics lifecycles |
| SynthOS | Traceable multi-model handoff/council rather than opaque model chatter |
| iBuild | Anonymous identity and public/private separation |
| Career / Presence | One factual career source, multiple verified projections, proof-led communication |

## Hard product boundaries

- Don't call the product a chatbot, second brain, CRM, task tracker, social media manager or coding IDE. Those are capabilities, not the identity.
- Don't hardcode a closed universe of entity types or a fixed set of four agents.
- Don't let a model execute arbitrary instructions or write to arbitrary systems.
- Don't let AI interpretation silently become accepted truth.
- Don't publish private data because it appeared in context or in a generated output.
- Don't link the anonymous identity to the real identity in public output.
- Don't invent proof, results, metrics or qualifications.
- Don't use an always-listening microphone without a clear, explicit opt-in and visible state.
- Don't encourage more engineering projects when a validation step, job application, customer conversation or finishing an existing product would move the owner's actual goals forward more directly.
- Don't optimize for app usage. Optimize for useful outcomes and fewer steps.

## Product acceptance test

Threadline is genuinely helping when the owner can say, without filling in a dozen fields:

- “I just had a thought” → it is captured and preserved.
- “What was I doing with this?” → it finds the relevant project, source and next action.
- “Help me move this forward” → it proposes a bounded plan, uses existing capabilities and shows what is happening.
- “What can I share from what I built?” → it finds real proof, proposes angles and creates a private draft in the correct voice.
- “I need to follow up with that person” → it connects the person/conversation/opportunity and offers a timely reminder or draft.
- “I'm driving / walking” → it uses short voice interaction and avoids unsafe screen dependence.
- “What should I stop doing?” → it helps park low-value projects and protect focus without guilt.
- “Show me what happened” → it presents a trustworthy event/proof history rather than a magical black box.
