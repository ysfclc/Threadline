# Threadline 1.5.0 — Design and Motion System

## Audit findings

The previous interface used a mostly static native-View layout with one animated status orb. The header packed search, floating actions, Studio, settings and lock into the same row; cards reused one flat surface; colour values were embedded directly in a large activity; and light mode was effectively fixed. Most feature UI is still composed by `MainActivity.kt`, so a complete screen-by-screen extraction remains a separate architectural task. This rebuild establishes one repeatable visual and motion system without replacing the secure vault or local model runtime.

## Palette

| Token | Light | Dark |
|---|---|---|
| Canvas | `#F2F5F1` | `#101714` |
| Surface | `#FFFFFF` | `#18211D` |
| Main text | `#19242C` | `#EDF5F0` |
| Secondary text | `#65736F` | `#A5B7AE` |
| Accent | `#276B56` | `#83D8B0` |
| Border | `#E0E7E3` | `#34443C` |
| Input surface | `#F8FAF8` | `#1A2420` |
| Main action fill | `#B2EFCF` | `#B2EFCF` |

The deep evergreen header and navigation remain stable across themes. Light surfaces use a restrained one-dp lift; dark surfaces rely on tonal separation rather than heavy shadows. High-salience content uses a dark, three-stop green gradient, not decorative neon. JVM unit tests were added to enforce at least 4.5:1 contrast for the main text/accent combinations; this does not substitute for checking every layout and dialog on-device.

## Type, space and shape

The system typeface remains Android's sans-serif for legibility, coverage and small-device performance. Headline sizes are typically 17–29sp; supporting copy is 12–14sp; all-caps section labels are 10–11sp. Spacing follows a 4dp rhythm, with 18dp content gutters, 16dp card padding, 14dp control corners, 18dp standard cards and 24–26dp hero surfaces. Primary tap targets remain at least 40dp high for compact navigation and 46dp for normal actions.

## Motion contract

All interaction motion uses native Android `ViewPropertyAnimator` / property animation, not a JavaScript animation bridge:

- Screen entrance: 230ms fade + 7dp upward settle.
- First content entrance on tab change: 235ms fade + 10dp settle, 28ms stagger, capped to the first nine direct children.
- Button press: scale to 0.965 over 85ms; release to 1.0 over 170ms.
- Tap: Android view haptic feedback; the floating `T` also gets drag-safe scale feedback.
- Quick-action menu: 210ms panel entrance with 22ms child staggering.
- Local-model warm-up: 1.15s repeating shimmer over three skeleton bars; animator cancels when the view detaches.

The whole screen is not reanimated after every record save or token-stream update. Entrance motion is limited to first render, successful unlock, navigation changes and explicit theme changes. This is intended to avoid making normal work feel slower.

## Appearance and accessibility

Appearance is stored in app preferences as `system`, `light` or `dark`. System mode responds to device `uiMode` changes while the activity is alive, without explicitly restarting the activity. Talk remains one tap away from the header while the five primary workspaces have more room in bottom navigation. The setting can be changed without clearing the encrypted vault. The app's Reduce Motion preference and Android's animator-disabled setting suppress entrance/press/shimmer/status-orb motion. Buttons expose a content description; icon-only toolbar actions have explicit names.

## Performance boundary

The motion implementation changes alpha, scale and translation properties and avoids per-frame layout changes. The shimmer reuses its bounds and shader instead of allocating new gradients every frame. These choices are appropriate for a small native Android app and avoid adding React Native/Reanimated solely for animation. They do **not** establish a measured 60fps guarantee: frame pacing, power use, accessibility and model-initialization behavior still require profiling on the user's actual phone.

## Remaining architecture work

`MainActivity.kt` still owns too much feature orchestration and builds the active tab's native views in one place. Design tokens, property motion and the skeleton view are now isolated; a safe next refactor would split each tab into renderers with explicit state/actions, then add screenshot/golden coverage before replacing more of the layout. The current change does not pretend that a complete renderer-state-management refactor has already happened.
