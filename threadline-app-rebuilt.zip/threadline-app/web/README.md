Companion web/PWA implementation is not included in this native Android source rebuild. The Android app is the build target for this package.
