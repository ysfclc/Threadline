package com.threadline.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Canvas = Color(0xFFF7F7F4)
private val Ink = Color(0xFF202721)
private val Muted = Color(0xFF7A827B)
private val Green = Color(0xFF426451)
private val PaleGreen = Color(0xFFE5ECE5)
private val Line = Color(0xFFE5E7E0)
private val Amber = Color(0xFFF4E9D3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ThreadlineApp(this) }
    }
}

data class ThreadItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val detail: String = "",
    val kind: String = "Note",
    val created: Long = System.currentTimeMillis(),
    val done: Boolean = false,
    val pinned: Boolean = false
)

private fun loadItems(context: Context): List<ThreadItem> {
    return try {
        val raw = context.getSharedPreferences("threadline", Context.MODE_PRIVATE).getString("items", null) ?: return starterItems()
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ThreadItem(o.optString("id"), o.optString("title"), o.optString("detail"), o.optString("kind", "Note"), o.optLong("created"), o.optBoolean("done"), o.optBoolean("pinned"))
        }
    } catch (_: Exception) { starterItems() }
}

private fun saveItems(context: Context, items: List<ThreadItem>) {
    val arr = JSONArray()
    items.forEach { item ->
        arr.put(JSONObject().put("id", item.id).put("title", item.title).put("detail", item.detail).put("kind", item.kind).put("created", item.created).put("done", item.done).put("pinned", item.pinned))
    }
    context.getSharedPreferences("threadline", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
}

private fun starterItems() = listOf(
    ThreadItem(title = "Follow up with Marta about the prototype", detail = "Ask if she can share feedback by Thursday.", kind = "Task", pinned = true),
    ThreadItem(title = "A thought about the capture flow", detail = "The best inbox is one that doesn't ask me to organise everything first.", kind = "Idea"),
    ThreadItem(title = "Weekend plan", detail = "Find a quiet place for a long walk and coffee.", kind = "Reminder")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreadlineApp(context: Context) {
    var items by remember { mutableStateOf(loadItems(context)) }
    var selectedTab by remember { mutableStateOf("Everything") }
    var query by remember { mutableStateOf("") }
    var showComposer by remember { mutableStateOf(false) }
    var draftTitle by remember { mutableStateOf("") }
    var draftDetail by remember { mutableStateOf("") }
    var draftKind by remember { mutableStateOf("Note") }
    var showSearch by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf<ThreadItem?>(null) }

    fun update(next: List<ThreadItem>) { items = next; saveItems(context, next) }
    val filtered = items.filter { item ->
        (selectedTab == "Everything" || (selectedTab == "Tasks" && item.kind == "Task") || (selectedTab == "Ideas" && item.kind == "Idea") || (selectedTab == "Done" && item.done)) &&
            (query.isBlank() || item.title.contains(query, true) || item.detail.contains(query, true))
    }.sortedWith(compareBy<ThreadItem> { it.done }.thenByDescending { it.pinned }.thenByDescending { it.created })

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, background = Canvas, surface = Color.White, onSurface = Ink)) {
        Scaffold(containerColor = Canvas, bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                NavigationBarItem(selected = selectedTab == "Everything", onClick = { selectedTab = "Everything" }, icon = { Icon(Icons.Default.Inbox, null) }, label = { Text("Inbox", fontSize = 11.sp) })
                NavigationBarItem(selected = selectedTab == "Tasks", onClick = { selectedTab = "Tasks" }, icon = { Icon(Icons.Default.TaskAlt, null) }, label = { Text("Tasks", fontSize = 11.sp) })
                NavigationBarItem(selected = selectedTab == "Ideas", onClick = { selectedTab = "Ideas" }, icon = { Icon(Icons.Default.Lightbulb, null) }, label = { Text("Ideas", fontSize = 11.sp) })
                NavigationBarItem(selected = selectedTab == "Done", onClick = { selectedTab = "Done" }, icon = { Icon(Icons.Default.Archive, null) }, label = { Text("Done", fontSize = 11.sp) })
            }
        }, floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { draftTitle = ""; draftDetail = ""; draftKind = if (selectedTab == "Tasks") "Task" else if (selectedTab == "Ideas") "Idea" else "Note"; showComposer = true }, containerColor = Green, contentColor = Color.White, shape = RoundedCornerShape(18.dp), icon = { Icon(Icons.Default.Add, null) }, text = { Text("Capture", fontWeight = FontWeight.SemiBold) })
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 20.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("THREADLINE", fontSize = 11.sp, letterSpacing = 2.4.sp, color = Green, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text(when (selectedTab) { "Tasks" -> "Your next moves"; "Ideas" -> "Things worth keeping"; "Done" -> "Closed loops"; else -> "Keep the thread." }, fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                    }
                    Surface(shape = CircleShape, color = PaleGreen, modifier = Modifier.size(44.dp).clickable { showSearch = !showSearch; if (!showSearch) query = "" }) {
                        Box(contentAlignment = Alignment.Center) { Icon(if (showSearch) Icons.Default.Close else Icons.Default.Search, contentDescription = "Search", tint = Green) }
                    }
                }
                if (showSearch) {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), placeholder = { Text("Find a thought, task or person…") }, singleLine = true, shape = RoundedCornerShape(16.dp), leadingIcon = { Icon(Icons.Default.Search, null) })
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatPill("${items.count { !it.done }}", "open")
                    StatPill("${items.count { it.kind == "Task" && !it.done }}", "to do")
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.Tune, contentDescription = "Filters", tint = Muted, modifier = Modifier.align(Alignment.CenterVertically).size(19.dp))
                }
                if (filtered.isEmpty()) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Surface(shape = CircleShape, color = PaleGreen, modifier = Modifier.size(72.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.EditNote, null, tint = Green, modifier = Modifier.size(34.dp)) } }
                        Spacer(Modifier.height(16.dp))
                        Text(if (query.isNotBlank()) "Nothing found" else "A little room to think", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(7.dp))
                        Text(if (query.isNotBlank()) "Try another word." else "Capture a thought, save a link, or get a next step out of your head.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp)
                        Spacer(Modifier.height(16.dp))
                        OutlinedButton(onClick = { showComposer = true }, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Capture something") }
                    }
                } else {
                    LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 92.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 2.dp, top = 4.dp)) {
                                Text(if (selectedTab == "Done") "RECENTLY CLOSED" else "YOUR THREADS", fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold, color = Muted)
                                Spacer(Modifier.weight(1f)); Text("${filtered.size} items", fontSize = 11.sp, color = Muted)
                            }
                        }
                        items(filtered, key = { it.id }) { item ->
                            ThreadCard(item = item, onClick = { selectedItem = item }, onDone = { update(items.map { if (it.id == item.id) it.copy(done = !it.done) else it }) }, onPin = { update(items.map { if (it.id == item.id) it.copy(pinned = !it.pinned) else it }) })
                        }
                        item {
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PaleGreen.copy(alpha = 0.72f)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lightbulb, null, tint = Green, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(10.dp))
                                Text("Capture first. Make sense of it later.", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }

        if (showComposer) {
            AlertDialog(onDismissRequest = { showComposer = false }, title = { Text("Capture a thread", fontWeight = FontWeight.SemiBold) }, text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Get it out of your head. You can organise it later.", color = Muted, fontSize = 13.sp)
                    OutlinedTextField(value = draftTitle, onValueChange = { draftTitle = it }, label = { Text("What's on your mind?") }, placeholder = { Text("A thought, task, link…") }, singleLine = false, minLines = 2, shape = RoundedCornerShape(14.dp))
                    OutlinedTextField(value = draftDetail, onValueChange = { draftDetail = it }, label = { Text("Add context (optional)") }, minLines = 2, shape = RoundedCornerShape(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Note", "Task", "Idea", "Reminder").forEach { kind ->
                            FilterChip(selected = draftKind == kind, onClick = { draftKind = kind }, label = { Text(kind, fontSize = 12.sp) })
                        }
                    }
                }
            }, confirmButton = { Button(onClick = { if (draftTitle.isNotBlank()) { update(listOf(ThreadItem(title = draftTitle.trim(), detail = draftDetail.trim(), kind = draftKind)) + items); showComposer = false } }, enabled = draftTitle.isNotBlank(), shape = RoundedCornerShape(12.dp)) { Text("Save thread") } }, dismissButton = { TextButton(onClick = { showComposer = false }) { Text("Cancel") } }, shape = RoundedCornerShape(24.dp))
        }

        selectedItem?.let { item ->
            AlertDialog(onDismissRequest = { selectedItem = null }, title = { Text(item.title, fontWeight = FontWeight.SemiBold) }, text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { KindTag(item.kind); Text(SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(Date(item.created)), fontSize = 11.sp, color = Muted) }
                    Text(if (item.detail.isBlank()) "No extra context yet." else item.detail, color = Ink, lineHeight = 22.sp)
                    Text(if (item.done) "Completed" else "Still open", color = Muted, fontSize = 12.sp)
                }
            }, confirmButton = { TextButton(onClick = { update(items.map { if (it.id == item.id) it.copy(done = !it.done) else it }); selectedItem = null }) { Text(if (item.done) "Reopen" else "Mark done") } }, dismissButton = { Row { TextButton(onClick = { draftTitle = item.title; draftDetail = item.detail; draftKind = item.kind; update(items.filterNot { it.id == item.id }); selectedItem = null; showComposer = true }) { Text("Edit") }; TextButton(onClick = { update(items.filterNot { it.id == item.id }); selectedItem = null }) { Text("Delete", color = Color(0xFF9B4D40)) } } }, shape = RoundedCornerShape(24.dp))
        }
    }
}

@Composable
private fun StatPill(number: String, label: String) {
    Surface(color = Color.White, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(number, fontWeight = FontWeight.Bold, color = Ink, fontSize = 13.sp)
            Spacer(Modifier.width(5.dp)); Text(label, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun KindTag(kind: String) {
    val bg = when (kind) { "Task" -> PaleGreen; "Idea" -> Amber; "Reminder" -> Color(0xFFE8E7F5); else -> Color(0xFFEDEFEA) }
    val fg = when (kind) { "Task" -> Green; "Idea" -> Color(0xFF87652B); "Reminder" -> Color(0xFF5C578D); else -> Color(0xFF69716A) }
    Surface(color = bg, shape = RoundedCornerShape(7.dp)) { Text(kind.uppercase(), modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = fg, fontSize = 9.sp, letterSpacing = 0.7.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ThreadCard(item: ThreadItem, onClick: () -> Unit, onDone: () -> Unit, onPin: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                KindTag(item.kind)
                Spacer(Modifier.width(8.dp))
                Text(if (item.pinned) "PINNED" else SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(item.created)), fontSize = 10.sp, letterSpacing = 0.5.sp, color = Muted)
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(30.dp).clip(CircleShape).background(if (item.done) PaleGreen else Canvas).clickable { onDone() }, contentAlignment = Alignment.Center) {
                    Icon(if (item.done) Icons.Default.Check else Icons.Default.TaskAlt, contentDescription = if (item.done) "Reopen" else "Mark done", tint = if (item.done) Green else Muted, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(item.title, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold, color = if (item.done) Muted else Ink, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (item.detail.isNotBlank()) {
                Spacer(Modifier.height(6.dp)); Text(item.detail, fontSize = 13.sp, lineHeight = 19.sp, color = Muted, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Open thread", color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(4.dp)); Text("↗", color = Green, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.EventNote, null, tint = Line, modifier = Modifier.size(18.dp))
            }
        }
    }
}
